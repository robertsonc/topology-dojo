import type { Scene } from './core/model.js';

/**
 * A realistic-ish SD-WAN demo scene with 5 beats, the kind of NOC narrative the
 * tool targets. Authored as deltas — note how each beat only states what changes.
 */
export const sampleScene: Scene = {
  topology: {
    title: 'SD-WAN Branch → Hub → SaaS',
    viewBox: [0, 0, 1000, 600],
    layers: {
      L1: { id: 'L1', name: 'Underlay', hiddenInEditor: false, locked: false },
    },
    zones: {
      branch: { id: 'branch', label: 'Branch Site', x: 40, y: 360, w: 280, h: 200, color: '#4aa3ff' },
      dc: { id: 'dc', label: 'Data Center', x: 380, y: 60, w: 280, h: 200, color: '#05cc93' },
      cloud: { id: 'cloud', label: 'SaaS / Cloud', x: 720, y: 360, w: 240, h: 200, color: '#9b8cff' },
    },
    nodes: {
      ecBranch: { id: 'ecBranch', type: 'ec', x: 180, y: 460, label: 'EC-Branch', layerId: 'L1', zoneId: 'branch' },
      host: { id: 'host', type: 'host', x: 90, y: 460, label: 'User', layerId: 'L1', zoneId: 'branch' },
      ecHub: { id: 'ecHub', type: 'ec', x: 520, y: 160, label: 'EC-Hub', layerId: 'L1', zoneId: 'dc' },
      fw: { id: 'fw', type: 'firewall', x: 520, y: 320, label: 'SRX', layerId: 'L1' },
      server: { id: 'server', type: 'server', x: 600, y: 160, label: 'App', layerId: 'L1', zoneId: 'dc' },
      saas: { id: 'saas', type: 'cloud', x: 840, y: 460, label: 'M365', layerId: 'L1', zoneId: 'cloud' },
    },
    links: {
      lan: { id: 'lan', type: 'line', from: 'host', to: 'ecBranch', waypoints: [], layerId: 'L1' },
      tunnel: { id: 'tunnel', type: 'tunnel3d', from: 'ecBranch', to: 'ecHub', color: '#05cc93', waypoints: [{ x: 350, y: 460 }], layerId: 'L1' },
      hubFw: { id: 'hubFw', type: 'line', from: 'ecHub', to: 'fw', waypoints: [], layerId: 'L1' },
      hubApp: { id: 'hubApp', type: 'line', from: 'ecHub', to: 'server', waypoints: [], layerId: 'L1' },
      breakout: { id: 'breakout', type: 'tunnel3d', from: 'ecBranch', to: 'saas', color: '#9b8cff', waypoints: [{ x: 520, y: 540 }], layerId: 'L1' },
    },
  },
  beats: [
    {
      id: 'b1',
      name: 'Branch site',
      note: 'Start with the branch. A user connects to the local EdgeConnect appliance over the LAN.',
      overrides: {
        ecHub: { visible: false }, fw: { visible: false }, server: { visible: false }, saas: { visible: false },
        tunnel: { visible: false }, hubFw: { visible: false }, hubApp: { visible: false }, breakout: { visible: false },
        ecBranch: { emphasis: 'focus' },
      },
    },
    {
      id: 'b2',
      name: 'Overlay to hub',
      note: 'The branch builds an IKE-less IPsec overlay tunnel to the hub in the data center.',
      overrides: {
        ecHub: { visible: true }, tunnel: { visible: true, flowActive: true },
        ecBranch: { emphasis: 'neutral' }, host: { emphasis: 'dim' }, lan: { emphasis: 'dim' },
      },
    },
    {
      id: 'b3',
      name: 'DC services',
      note: 'Behind the hub: the SRX firewall and the application server come online.',
      overrides: {
        fw: { visible: true }, server: { visible: true },
        hubFw: { visible: true }, hubApp: { visible: true, flowActive: true },
      },
    },
    {
      id: 'b4',
      name: 'SaaS breakout',
      note: 'Trusted SaaS (M365) breaks out locally from the branch instead of hairpinning through the DC.',
      overrides: {
        saas: { visible: true, emphasis: 'focus' }, breakout: { visible: true, flowActive: true },
        host: { emphasis: 'neutral' }, lan: { emphasis: 'neutral' },
      },
    },
    {
      id: 'b5',
      name: 'Full picture',
      note: 'The complete steered topology: backhaul to DC for apps, local breakout for trusted SaaS.',
      overrides: {
        saas: { emphasis: 'neutral' },
        ecBranch: { emphasis: 'neutral' }, ecHub: { emphasis: 'neutral' },
      },
    },
  ],
};
