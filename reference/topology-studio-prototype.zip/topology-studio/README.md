# Topology Studio — Beat Model Prototype

Proves the **beat-based** choreography model as a replacement for Acts→Steps→Phases.

## Run
```bash
npm install
npm run dev      # http://localhost:5173
npm test         # 7 core tests
npm run build    # production build (~14KB JS)
```

## What to evaluate
- **Author mode**: pick a beat in the bottom strip, toggle each element's
  visible/emphasis/flow. That's the entire authoring surface — no acts, no steps,
  no time ruler. Compare the cognitive load to the old choreography panel.
- **Present mode**: click anywhere or →/← to walk beats. Position/visibility
  changes auto-tween (Magic Move). This replaces the old viewer entirely.

## Architecture (the seam that kills editor/viewer duplication)
```
core/        model.ts resolve.ts tween.ts   ← pure, typed, tested. No DOM.
render-svg/  render.ts                       ← ResolvedScene -> SVG. Knows nothing of beats.
main.ts                                       ← editor + presenter, both call resolve()
```

`resolve(scene, beatIndex)` is the single source of truth. Editor draws
`resolve(scene, currentBeat)`; presenter draws the same and advances the index.
One renderer, two consumers.

## Carried over from the monolith
- 3D tunnel renderer (faithful port of render3DTunnel)
- Zones, layers (layers demoted to editor-only grouping), waypoints
- Node types, emphasis/focus, animated flow

## Deliberately cut
- viewer.html, standalone exporter, Act/Step/Phase model, parallel layer-visibility timeline
