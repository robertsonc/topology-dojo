# Migration: monolith -> beat model

## Decisions locked by the prototype
1. **TS + Vite**, strict mode + noUncheckedIndexedAccess. The two model bugs
   found during the build (emphasis reset, link-only-in-one-scene) were caught
   by the compiler, not at runtime. This is the payoff for leaving vanilla JS.
2. **Beats replace Act/Step/Phase.** One ordered list of deltas. Set-and-hold
   inheritance is in resolve.ts and tested.
3. **Layers demoted** to editor-only grouping (hiddenInEditor/locked). They are
   no longer a playback axis — that was the dual-timeline conflict.
4. **resolve() is the seam.** No separate viewer codebase.

## Port plan (renderers are the bulk of the work)
| From (monolith)                       | To                          | Effort |
|---------------------------------------|-----------------------------|--------|
| topology-ds.js node renderers (~14)   | render-svg/nodes/*.ts        | M — mechanical, 1:1 |
| topology-ds.js link renderers (~7)    | render-svg/links/*.ts        | M |
| svgDefs() filters/gradients           | render-svg/render.ts defs()  | done (subset) |
| render3DTunnel                        | render-svg/render.ts         | done |
| editor.html canvas interaction        | editor/ (drag, palette, props)| L — biggest remaining piece |
| registerNodeType plugin API           | core node registry            | S — keep the API shape |
| Acts/Steps/Phases UI + state          | DELETE                        | — |
| viewer.html                           | presenter/ (done in proto)    | — |

## Open risks to decide before full port
- **Custom node renderers won't morph-tween** (cross-fade instead). Confirmed
  acceptable in conversation.
- **Drag-to-author beats**: prototype edits overrides via toggles. Real editor
  should let you drag a node on canvas and have it write an x/y override to the
  current beat automatically. This is the key UX bet — design it explicitly.
- **Import from old JSON**: need a one-time converter from acts/steps/phases ->
  beats. Lossy by design (collapses 3 levels to 1); write it as a best-effort
  flattener + manual cleanup.
