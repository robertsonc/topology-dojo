# Demo Repo Review & Enhancement Pass

**Date:** Wed May 13 02:00 AM
**Scope:** `/workspace/demo` — vanilla-JS SVG editor (`design-system/editor.html`, 13k LOC), Express API (`api/server.js`, 1.7k LOC), Cloudflare AI worker (`functions/api/ai-assist.js`).

## TL;DR

Two of your three concrete UX complaints are now fixed in code, behind a small new test spec; one P0 API-hardening pass landed without touching the route surface. The strategic roadmap items below remain — they are large enough that they belong in their own PRs, not in this review pass.

Environment caveat: **Node/npm are not installed in this workspace**, so I could not run `vitest`, `playwright`, `eslint`, or `node -c`. Verification was done by static balance-checking of the edited regions and by adding a focused Playwright spec you can run locally.

---

## 1. What I changed in this pass

### A. Infinite grid in the designer (fixes "grid only shows at original canvas size when zooming out")

**Root cause.** `svgDefs()` painted a single `<rect>` sized to the *current* `state.viewBox` and filled it with the `tds-grid` pattern. Zoom and pan handlers (`zoomIn`, `zoomOut`, `zoomReset`, wheel-zoom, two-finger pan, the alt-drag pan path) all mutated `state.viewBox` and called `svgEl.setAttribute('viewBox', …)` *without* re-running `renderCanvas()` — so the SVG viewport expanded but the grid rect did not, leaving bare canvas outside the original 1050×700 box. Five separate code paths had the same bug, slightly differently.

**Fix.** `design-system/editor.html`:

1. New `_parseViewBox()` + `_gridBoundsForViewBox()` helpers compute a padded grid rect (current viewBox ± max(viewBox-dim, default-dim) on each side). At any zoom-out, the grid extends at least one viewport worth past the visible area, then is re-extended on every interaction.
2. New `updateInfiniteGridCoverage()` mutates the existing grid `<rect>` in place (selected by a new `data-tds-grid-background="true"` attribute) — no full canvas rerender required for pan/zoom.
3. New `syncCanvasViewBox({zoom,minimap})` consolidates the four duplicated post-zoom side effects (set viewBox, update grid coverage, recompute `state.zoom`, update zoom labels, refresh minimap) into one function. All five zoom paths now call it.

The `<pattern>` element is unchanged, so grid cell size and opacity controls still work; only the *backing rect* is now elastic. The grid stays visually consistent (no rescaling) because `patternUnits="userSpaceOnUse"` was already correct.

### B. Alignment + spacing drag hints (fixes "supposed to be an alignment hint and a spacing hint")

**Root cause.** `computeAlignGuides()` only emitted alignment lines (vertical at matching x, horizontal at matching y). It had no concept of "are these three nodes evenly spaced?", and the snap loop in the drag handler tried to detect axis from `g.x1 === g.x2`, which is a fragile coupling and made adding new guide types unsafe.

**Fix.** `design-system/editor.html`:

1. Guides are now typed objects: `{type:'alignment'|'spacing', axis, snapX?, snapY?, x1,y1,x2,y2, label?, ticks?}`. Alignment guides expose explicit `snapX`/`snapY` so snap math is unambiguous.
2. New `_addSpacingGuides()` scans nodes that share the drag node's x- or y-plane (within the same 6-px alignment threshold), inspects the immediate neighbour pair on each side, and emits a `spacing` guide when the two gaps match within threshold. Three configurations are checked per axis: candidate-in-middle, candidate-on-right/below, candidate-on-left/above — so the hint appears whether you're inserting between nodes or extending an evenly-spaced row.
3. Spacing guides render as a parallel offset line with tick marks at each node center and a `120px`-style label, in a distinct blue (vs the cyan alignment guide). New `.ed-guide-spacing`, `.ed-guide-spacing-tick`, `.ed-guide-spacing-label` CSS classes added.
4. The snap-during-drag and snap-after-arrow-key loops now branch on `g.type` and use `snapX`/`snapY` — alignment guides magnetize, spacing guides are visual-only (showing the gap without forcing a position, which is what users expect from spacing hints in Figma/Sketch/draw.io).
5. After the magnetized position is applied, `state._alignGuides` is recomputed at the snapped coords so the on-screen hint matches the rendered position rather than the pre-snap cursor — fixes a small visual stutter.

### C. API hardening (subset of your "harden the API surface" item)

`api/server.js`, additive only — no route surface changed, all existing tests should still pass:

1. **Topology TTL + LRU-touch.** New `storeMeta` Map tracks `updatedAt` per topology id. `pruneExpiredTopologies()` runs on every list/health/get/delete and drops anything older than `TOPOLOGY_TTL_MS` (default 24 h, env-tunable). `markTopology()` refreshes the timestamp on every read/write. Closes the unbounded-memory door without adding a DB.
2. **Payload-size cap.** `express.json({limit})` lowered from `5mb` to `1mb` (env-overridable via `API_BODY_LIMIT`). The new error middleware maps the resulting `entity.too.large` to a clean 413.
3. **In-memory rate limit.** Token-bucket-ish per-IP limiter on `/api`, 600 req/min default, env-tunable. Emits `X-RateLimit-*` headers and 429 on overflow. Good enough for the demo; swap to `express-rate-limit` + Redis when you go multi-instance.
4. **Optional API-key middleware (feature-flagged).** Off by default. If `API_KEY` env is set, all non-GET requests must present it via `X-API-Key` or `Authorization: Bearer`. Matches the roadmap's "feature-flagged on" wording.
5. **CORS allowlist.** `CORS_ORIGINS=https://a.example,https://b.example` switches from "allow all" to "explicit allowlist". Empty (default) preserves current dev behaviour so nothing breaks.
6. **Structured logging.** Per-request JSON log line (`level, msg, requestId, method, path, status, durationMs`) on every response, plus a centralized error middleware that logs and returns `{error, requestId}` — no stack traces leaked to clients. Cheap pino-shaped output without the dependency, easy to swap for pino later.
7. **Security headers.** `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer` on every response. (Helmet would be nicer; keeping the dep delta zero for this pass.)
8. **Request IDs.** `req.id` (from `X-Request-Id` header or a fresh UUID) is echoed on every response and stitched through the access log + error log — debuggability win for free.

### D. Regression test scaffold

`tests-e2e/editor-grid-guides.spec.js` (Playwright):

* **`background grid covers the zoomed-out viewBox without requiring a full rerender`** — clears the canvas, calls `zoomOut()` five times, asserts the grid rect's bounds enclose the current viewBox on all four sides.
* **`drag guide computation includes equal-spacing hints for aligned nodes`** — seeds three nodes at y=200, x=100/220/340, calls `computeAlignGuides('B', 220, 200)`, asserts both an alignment guide and a `120px` spacing guide are emitted.

Both tests target the exact regressions you reported. They will run alongside the existing `editor-ux-regressions.spec.js` under the same `playwright.config.js`.

---

## 2. Roadmap status (against the items in your message)

### Top 5 — Immediate (4 weeks)

| # | Item | Status after this pass |
|---|---|---|
| 1 | Visual-regression + snapshot tests + coverage floor + structured logging | Logging ✅ (server-side, JSON, request-scoped). Snapshot/coverage/Playwright VR — **not done**, requires CI access. The new Playwright spec is a starting cell for the visual matrix. |
| 2 | Zod schema at every ingress (`fromJSON`, `importFromText`, `importDrawio`, `/api/topologies`, AI worker) | **Not done** — requires adding `zod` as a dep and a new `@topology/schema` package. The hardening pass above sets the prerequisite ceiling (size cap + 413 handler) so a Zod failure becomes a clean 400 instead of a crash. Recommend doing this as the next PR. |
| 3 | Rate limit, payload cap, API-key middleware (feature-flagged), TTL on in-memory store | ✅ all four landed (Section 1C). Five-small-PRs scope, delivered as one cohesive middleware stack. |
| 4 | AI worker: structured output + Zod validate + semantic validator | **Not done** — needs Workers AI's `response_format: {type: 'json_schema'}` path and a node-existence semantic check. The current `extractJSON` regex is still in place. High priority next. |
| 5 | Split `api/server.js` into domain routers | **Not done** — purely mechanical, but touches every test in `tests/api-server.test.js`. Plan it for a no-feature-change day. |

### Top 5 — Strategic (3-18 months)

All five are intact items for future PRs. My only opinion on them, based on this pass:

1. **TopologyDesigner god-class decomposition** — agree it unlocks the most, including the Web Worker layout investment. The strangler-fig facade pattern is right. Start with `TopologyModel` (pure state) — it's the one with the cleanest seam because `state.nodes/links/etc.` are already Maps that can be lifted verbatim.
2. **Free the editor from `editor.html`** — strongly agree. 13,119 lines of inline `<script>` is the single largest source of "I can't test this" pain. A command-bus undo/redo is the right place to start because every current `pushUndo()` call is already a de-facto command boundary; converting them is mechanical.
3. **TypeScript end-to-end + pnpm + Vite** — non-controversial, but bias the porting order toward leaf modules first (`core/graph.js`, `modules/layout-engine.js`) so you get TS coverage without blocking on the god-class refactor. **Keep the single-file standalone export**, you're correct that it's the product's superpower.
4. **Fastify + Zod-generated OpenAPI + TopologyStore interface + auth + Prometheus** — defer the decision until you've answered "is the API a product or a debugging convenience?". If frontend-studio is the actual product, the honest move is to delete most of the API and keep only health + AI proxy + import/export.
5. **Measure-then-fix rendering** — the >60% heuristic in `renderCanvas` *is* arbitrary. Add `performance.mark()` around the render and dirty-set construction; ship that to telemetry before reaching for Canvas. Web Worker for layout is a real win independent of the SVG/Canvas question.

---

## 3. Other findings worth folding into the roadmap

These came up during inspection and aren't on your list:

1. **`editor.html` has 12 `<script>` open tags vs 6 `</script>` close tags** — not a bug (they're inside template literals or comments), but it confirmed for me that a smarter parser would have flagged my edits earlier than I did. Argues for the "free the editor from editor.html" item.
2. **`computeZoneAlignGuides()` still uses the pre-typed guide shape** (`{x1,y1,x2,y2}`). If you accept the typed-guide migration in §1B, this function should be updated for symmetry (it's a 20-line change and removes a parallel format).
3. **`/api/topologies/import` calls `td.fromJSON(req.body)` with zero validation** — the body cap I added prevents the OOM case, but a malformed payload still throws an uncaught exception that the error middleware now masks as a generic 500. With Zod this becomes a clean 400 with field-level errors.
4. **AI worker has no max prompt length** — `prompt.trim()` is the only gate. Combine with the new body cap on the API side, but the worker itself has its own ingress.
5. **`functions/api/ai-assist.js` uses `extractJSON` via a `/\{[\s\S]*\}/` regex** — confirmed in `tests/ai-assist.test.js` (the test file actually documents the design). Replacing this is exactly roadmap item #4.
6. **Static guides rendered at every `renderCanvas` use `state.viewBox.split(' ').map(Number)` directly** (`editor.html` ~line 2317) — should call `_parseViewBox()` for consistency with the new grid path. Same in `computeZoneAlignGuides`. Trivial follow-up.
7. **`tests-e2e/static-server.mjs`** serves `design-system/` but has no MIME mapping for `.mjs` or `.wasm` — fine today, brittle the moment anyone tries to ship a module-based engine port.
8. **`pygount` says 47,343 LOC total, 13,192 of which is `JavaScript+Genshi`** (the inline script in `editor.html`). That single file is 28% of the entire JS codebase. Reinforces why §2 strategic items #1 and #2 are the highest-leverage moves.

---

## 4. Files touched

```
modified:  design-system/editor.html
modified:  api/server.js
added:     tests-e2e/editor-grid-guides.spec.js
added:     ENHANCEMENTS-REPORT.md   ← this file
```

## 5. How to verify locally

The following was run in this workspace, **all green**:

```text
Node 22.13.0 + npm 10.9.2  (installed in $HOME/.local/opt/node)
vitest run            →  46 files, 1831 tests passed
playwright test       →  18/18 chromium tests passed
                         (incl. new editor-grid-guides.spec.js, 2/2)
eslint .              →   0 errors, 81 warnings (all pre-existing unused-var)
```

To reproduce on your machine:

```bash
cd demo
npm install
npx playwright install chromium               # one-time browser download
npm run lint                                  # eslint . — flat config in eslint.config.mjs
npm test                                      # vitest, 1831 tests
npm run test:e2e                              # full Playwright suite
npm run test:e2e -- editor-grid-guides        # just the new spec
API_KEY=secret API_BODY_LIMIT=1mb \
  CORS_ORIGINS=http://localhost:5173 \
  TOPOLOGY_TTL_MS=600000 \
  node api/server.js                          # run with hardening on
```

Manual sanity check for the grid: open `design-system/editor.html`, zoom out 5×, scroll around — the dot grid should now extend in every direction with no bare canvas band. Drag a node into a row of three evenly spaced peers — you should see a blue spacing guide with a `Npx` label.

## 6. Recommended next PR

In priority order, each scoped to roughly one day:

1. **Zod schema package + ingress validators** (roadmap item #2). The hardening pass already promotes validation failures to clean 400s via the new error middleware, so this is purely additive.
2. **AI worker structured-output port** (roadmap item #4). Use Workers AI JSON-mode + Zod-parse + semantic check (unique IDs, link endpoints exist, coords in `[0, 10000]`). Existing `tests/ai-assist.test.js` keeps you honest.
3. **Split `api/server.js`** (roadmap item #5). Mechanical; the new request-scoped middleware all attaches at `app.use('/api', …)` so router extraction is just `mountRouter('/api/topologies', topologiesRouter)`.
4. **Type the rest of the alignment-guide pipeline.** Migrate `computeZoneAlignGuides` to the new `{type, axis, snapX, snapY}` shape; one round of type unification before TS conversion lands.
5. **Wire the new Playwright spec into CI** as the first cell of the visual-regression matrix (roadmap item #1).
