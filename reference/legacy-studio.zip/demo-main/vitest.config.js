import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'jsdom',
    globals: true,
    include: ['tests/**/*.test.js'],
    environmentMatchGlobs: [
      ['**/openapi-spec.test.js', 'node']
    ],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'text-summary'],
      include: [
        'design-system/topology-ds.js',
        'design-system/modules/layout-engine.js',
        'design-system/modules/template-parser.js',
        'design-system/modules/theme-engine.js',
        'design-system/core/graph.js',
        'api/server.js',
        'api/openapi-definition.js',
        'functions/api/ai-assist.js',
      ],
      all: false,
    },
  },
});
