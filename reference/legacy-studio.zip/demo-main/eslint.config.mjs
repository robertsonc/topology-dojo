// Minimal flat ESLint config for the demo repo.
// Goal: catch real bugs (parse errors, unused names, undef refs) without
// flooding the existing 13k-line editor.html with cosmetic warnings.

import js from '@eslint/js';
import globals from 'globals';

// Editor-page globals that exist on `window` and are referenced by Playwright
// specs which run `page.evaluate(() => clearAll())`. They're not real globals
// in the test process — they live in the browser — so we tell ESLint they're
// readonly so `no-undef` stops yelling about every `state.nodes.set(...)`.
const EDITOR_PAGE_GLOBALS = Object.fromEntries(
  [
    'state', 'clearAll', 'renderCanvas', 'renderChoreo', 'renderProps',
    'selectElement', 'addZone', 'serializeState', 'deserializeState',
    'computeAlignGuides', 'zoomIn', 'zoomOut', 'zoomReset', 'showToast',
    'pushUndo', 'syncCanvasViewBox', 'updateMinimap', 'updateInfiniteGridCoverage',
    'setTool', 'undo', 'redo', 'saveAsJson', 'loadFromJson', 'exportPNG',
    'exportSVG', 'exportPDF', 'exportStandaloneHTML', 'present', 'exitPresentation',
    'TopologyDesigner', 'topo', 'editor', 'renderMinimap', 'autoLayout',
    'addNode', 'addLink', 'batchGroupZone', 'batchUngroup', 'batchToggleLock',
    'deleteSelected', 'finishFlowPath', 'setTheme', 'getTheme',
  ].map(name => [name, 'readonly'])
);

const VITEST_GLOBALS = {
  describe: 'readonly', it: 'readonly', test: 'readonly', expect: 'readonly',
  beforeEach: 'readonly', afterEach: 'readonly', beforeAll: 'readonly',
  afterAll: 'readonly', vi: 'readonly', vitest: 'readonly',
};

const SHARED_RULES = {
  'no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
  'no-empty': ['warn', { allowEmptyCatch: true }],
};

export default [
  {
    ignores: [
      'node_modules/**',
      'design-system/**',           // huge inline-script HTML files — not lint-friendly
      'playwright-report/**',
      'test-results/**',
      'docs/**',
      'other/**',
      '**/*.min.js',
    ],
  },

  js.configs.recommended,

  // Node / CommonJS sources (Express server, scripts)
  {
    files: ['api/**/*.js', 'scripts/**/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'commonjs',
      globals: globals.node,
    },
    rules: SHARED_RULES,
  },

  // Vitest unit tests (ESM with import/export). Many use jsdom + reference
  // `window`/`document`/`Element`, so include browser globals alongside node.
  {
    files: ['tests/**/*.{js,mjs}'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: { ...globals.node, ...globals.browser, ...VITEST_GLOBALS },
    },
    rules: { ...SHARED_RULES, 'no-unused-expressions': 'off' },
  },

  // Cloudflare worker — ESM
  {
    files: ['functions/**/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: { ...globals.worker, ...globals.browser },
    },
    rules: SHARED_RULES,
  },

  // Playwright e2e specs — ESM + page.evaluate() body globals. Disable
  // no-undef here because every `page.evaluate(() => foo())` body references
  // names that only exist in the browser context, and statically enumerating
  // them is whack-a-mole that doesn't catch real bugs.
  {
    files: ['tests-e2e/**/*.{js,mjs}'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: { ...globals.node, ...globals.browser, ...EDITOR_PAGE_GLOBALS },
    },
    rules: { ...SHARED_RULES, 'no-undef': 'off' },
  },

  // Top-level project config files — Node/CommonJS-ish runtime
  {
    files: ['*.config.{js,mjs,cjs}', 'playwright.config.js', 'vitest.config.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: globals.node,
    },
    rules: SHARED_RULES,
  },

  // Loose ESM helpers
  {
    files: ['**/*.mjs'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      globals: globals.node,
    },
    rules: SHARED_RULES,
  },
];
