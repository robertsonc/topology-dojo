import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor selection regressions', () => {
  test('select all links by color selects matching links and only links', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#fc6161', label: 'Backup' });
      renderCanvas();
      selectLinksByColor('#01a982');
    });

    const selected = await page.evaluate(() => [...state.selectedIds]);
    expect(selected.sort()).toEqual(['L1', 'L2']);
    expect(await page.evaluate(() => [...state.selectedIds].every(id => state.links.has(id)))).toBe(true);
  });

  test('select all links by type selects matching links and only links', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#fc6161' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#65aef9' });
      renderCanvas();
      selectLinksByType('line');
    });

    const selected = await page.evaluate(() => [...state.selectedIds]);
    expect(selected.sort()).toEqual(['L1', 'L2']);
  });

  test('select all nodes by color selects matching nodes and not links', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.nodes.get('N1').color = '#01a982';
      state.nodes.get('N2').color = '#01a982';
      state.nodes.get('N3').color = '#fc6161';
      renderCanvas();
      selectByColor('#01a982');
    });

    const selected = await page.evaluate(() => [...state.selectedIds]);
    expect(selected.sort()).toEqual(['N1', 'N2']);
    expect(await page.evaluate(() => [...state.selectedIds].every(id => state.nodes.has(id)))).toBe(true);
  });

  test('context-menu style layer move preserves multi-selection and is undoable for mixed items', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.selectedIds = new Set(['N1', 'L1']);
      moveSelectionToLayer('overlay', 'N1', 'node');
    });

    expect(await page.evaluate(() => state.nodes.get('N1').layer)).toBe('overlay');
    expect(await page.evaluate(() => state.links.get('L1').layer)).toBe('overlay');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.get('N1').layer || 'physical')).toBe('physical');
    expect(await page.evaluate(() => state.links.get('L1').layer || 'physical')).toBe('physical');
  });
});
