/**
 * seed-topology.js
 * Opens the editor page and seeds a simple topology via programmatic
 * JavaScript injection. Returns the page ready for further assertions.
 *
 * The topology created:
 *   Nodes:  N1 (ec / router), N2 (cloud), N3 (host)
 *   Links:  L1 (N1→N2), L2 (N2→N3)
 *   Act:    a1 "Demo Act"
 *   Step:   step1 "Demo Step"  (shows N1, L1, N2, L2, N3)
 */

/**
 * @param {import('@playwright/test').Page} page
 * @param {{ waitForIdle?: boolean }} [opts]
 */
export async function seedTopology(page, opts = {}) {
  // Navigate to the editor
  await page.goto('/editor.html');

  // Wait for the canvas SVG to be present and topology-ds.js to initialise
  await page.waitForSelector('#canvas', { timeout: 15_000 });

  // Clear any auto-saved state so we start fresh
  await page.evaluate(() => {
    localStorage.removeItem('tds-editor-autosave');
    // dismiss the restore-autosave confirm if it fires
  });

  // Dismiss any pending dialogs (auto-save restore) by accepting them
  page.on('dialog', dialog => dialog.dismiss());

  // Reload fresh after clearing storage
  await page.reload();
  await page.waitForSelector('#canvas', { timeout: 15_000 });

  // Wait until the editor JS global functions are available
  await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });

  // Seed topology programmatically
  await page.evaluate(() => {
    // Start from clean slate
    clearAll();

    // Add nodes
    state.nodes.set('N1', { id: 'N1', type: 'ec',     x: 200, y: 300, label: 'Router',  color: '#01a982' });
    state.nodes.set('N2', { id: 'N2', type: 'cloud',  x: 525, y: 200, label: 'Internet', color: '#65aef9' });
    state.nodes.set('N3', { id: 'N3', type: 'host',   x: 800, y: 300, label: 'Host',    color: '#deb146' });

    // Add links
    state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
    state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: '' });

    // Add act + step
    state.acts.push({ id: 'a1', label: 'Demo Act', color: '#01a982' });
    state.steps.push({
      id: 'step1', act: 'a1', name: 'Demo Step',
      goal: 'Show topology',
      narration: 'This step reveals all topology elements.',
      focus: ['N2'],
      phases: [
        { show: ['N1', 'N2', 'N3'], diff: 'All nodes' },
        { show: ['L1', 'L2'],       diff: 'All links'  },
      ],
    });

    // Update counters
    state._nextNodeNum = 10;
    state._nextLinkNum = 10;
    state._nextActNum  = 2;
    state._nextStepNum = 2;

    renderCanvas();
    renderChoreo();
  });

  // Wait for SVG content to appear
  await page.waitForFunction(
    () => document.querySelector('#canvas [data-node-id]') !== null,
    { timeout: 10_000 }
  );

  if (opts.waitForIdle !== false) {
    // Brief settle time for animations
    await page.waitForTimeout(300);
  }

  return page;
}

/**
 * Serialise the current editor state to JSON (as saveAsJson() would).
 * @param {import('@playwright/test').Page} page
 * @returns {Promise<object>}
 */
export async function getEditorState(page) {
  return page.evaluate(() => {
    const json = serializeState();
    return JSON.parse(json);
  });
}
