/**
 * load-fixture.js
 * Helpers for loading canonical fixture topologies into the editor or viewer.
 *
 * Usage:
 *   import { loadFixtureInEditor, loadFixtureInViewer, getFixture } from './helpers/load-fixture.js';
 */

import { resolve } from 'path';

// Fixtures live at <project-root>/tests-e2e/fixtures/
const FIXTURES_DIR = resolve(process.cwd(), 'tests-e2e', 'fixtures');

async function waitForEditorReady(page, timeout = 30_000) {
  await page.waitForLoadState('domcontentloaded', { timeout });
  await page.waitForSelector('#canvas', { timeout, state: 'attached' });
  await page.waitForFunction(
    () => {
      const canvas = document.getElementById('canvas');
      if (!canvas) return false;
      const rect = canvas.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    },
    { timeout }
  );
}

/**
 * Read a fixture JSON from disk and return the parsed object.
 * @param {string} name - Fixture filename without extension, e.g. 'sdwan-branch'
 * @returns {Promise<object>}
 */
export async function getFixture(name) {
  const { readFileSync } = await import('fs');
  const filePath = resolve(FIXTURES_DIR, `${name}.json`);
  const raw = readFileSync(filePath, 'utf8');
  return JSON.parse(raw);
}

/**
 * Open the editor and load a named fixture topology via deserializeState().
 * Returns the page after the topology has been applied and rendered.
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} fixtureName - e.g. 'sdwan-branch'
 * @param {{ waitForIdle?: boolean }} [opts]
 */
export async function loadFixtureInEditor(page, fixtureName, opts = {}) {
  const fixture = await getFixture(fixtureName);
  const jsonStr = JSON.stringify(fixture);

  // Clear autosave before editor boot so restore paths do not interfere.
  await page.addInitScript(() => {
    try {
      localStorage.removeItem('tds-editor-autosave');
      localStorage.removeItem('tds-viewer-topology');
    } catch {}
  });

  // Navigate to editor
  await page.goto('/editor.html');
  await waitForEditorReady(page);

  // Dismiss any restore dialogs and clear state once the page is ready.
  page.on('dialog', d => d.dismiss());

  // Inject the fixture
  await page.evaluate((json) => {
    clearAll();
    deserializeState(json);
    renderCanvas();
    renderChoreo();
  }, jsonStr);

  // Wait for nodes to render if topology has nodes
  await page.waitForFunction(
    () => {
      const hasNodes = state.nodes.size > 0;
      if (!hasNodes) return true; // Empty is fine
      return document.querySelector('#canvas [data-node-id]') !== null;
    },
    { timeout: 10_000 }
  );

  if (opts.waitForIdle !== false) {
    await page.waitForTimeout(300);
  }

  return page;
}

/**
 * Load a fixture topology into the viewer via localStorage handoff.
 * Navigates directly to viewer.html with the fixture pre-loaded.
 *
 * @param {import('@playwright/test').Page} page
 * @param {string} fixtureName
 */
export async function loadFixtureInViewer(page, fixtureName) {
  const fixture = await getFixture(fixtureName);

  // Write to localStorage before loading viewer
  await page.addInitScript(() => {
    try {
      localStorage.removeItem('tds-editor-autosave');
    } catch {}
  });

  await page.goto('/editor.html');
  await waitForEditorReady(page);
  await page.waitForFunction(
    () => typeof localStorage !== 'undefined',
    { timeout: 10_000 }
  );

  await page.evaluate((data) => {
    localStorage.setItem('tds-viewer-topology', JSON.stringify(data));
  }, fixture);

  // Navigate to viewer
  await page.goto('/viewer.html');
  await page.waitForSelector('#app', { timeout: 15_000 });
  await page.waitForSelector('#tds-diagram', { timeout: 15_000 });
  await page.waitForTimeout(400);

  return page;
}

/**
 * Get the serialised state from the editor (after fixture is loaded).
 * @param {import('@playwright/test').Page} page
 * @returns {Promise<object>}
 */
export async function getEditorState(page) {
  return page.evaluate(() => {
    const json = serializeState();
    return JSON.parse(json);
  });
}

/**
 * List all canonical fixture names (without .json extension).
 * @returns {string[]}
 */
export function listFixtures() {
  return [
    'sdwan-branch',
    'ztna-user-to-app',
    'firewall-blocked-flow',
    'multi-layer-policy',
    'executive-multi-act',
    'dense-topology',
  ];
}
