import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor Phase 3 UX audit', () => {
  test('link delete button is undoable', async ({ page }) => {
    await seedTopology(page);
    page.removeAllListeners('dialog');
    page.on('dialog', d => d.accept());

    await page.evaluate(() => {
      selectElement('L1', 'link');
      renderProps();
    });

    expect(await page.evaluate(() => state.links.has('L1'))).toBe(true);
    await page.getByRole('button', { name: 'Delete Link' }).click();
    expect(await page.evaluate(() => state.links.has('L1'))).toBe(false);

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.links.has('L1'))).toBe(true);
  });

  test('link color context-menu selection remains correct after prior node selection', async ({ page }) => {
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#fc6161', label: 'Backup' });
      state.selectedIds = new Set(['N1', 'N2']);
      selectElement('N1', 'node');
      renderCanvas();
      renderProps();
    });

    const linkHit = page.locator('#canvas [data-elem-type="link"][data-elem-id="L1"]').first();
    await linkHit.click({ button: 'right', force: true });

    const colorAction = page.locator('#contextMenu .ed-context-item').filter({ hasText: 'links' }).filter({ hasText: 'Select' }).first();
    await colorAction.click();

    const selected = await page.evaluate(() => [...state.selectedIds].sort());
    expect(selected).toEqual(['L1', 'L2']);
    expect(await page.evaluate(() => state.selectedType)).toBe('link');
  });

  test('select all links by color remains correct after save/load round-trip', async ({ page }) => {
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#fc6161', label: 'Backup' });
    });

    const snapshot = await page.evaluate(() => serializeState());
    await page.evaluate((json) => {
      clearAll();
      deserializeState(json);
      renderCanvas();
      renderProps();
      selectLinksByColor('#01a982');
    }, snapshot);

    const selected = await page.evaluate(() => [...state.selectedIds].sort());
    expect(selected).toEqual(['L1', 'L2']);
  });
});
