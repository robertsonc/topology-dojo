/**
 * export.spec.js
 * Browser-level tests for all export paths:
 *   - PNG download (non-empty)
 *   - SVG download (contains topology content)
 *   - PDF download (structurally valid)
 *   - Preview as standalone (opens and renders)
 *   - Export Standalone HTML (downloads + independent render)
 */

import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

// ── PNG export ────────────────────────────────────────────────────────────────
test.describe('Export — PNG', () => {
  test('PNG download is triggered and file is non-empty', async ({ page }) => {
    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 15_000 });
    await page.evaluate(() => exportPNG());
    const download = await downloadPromise;

    expect(download.suggestedFilename()).toMatch(/\.png$/i);

    // Verify file is non-empty
    const path = await download.path();
    const { readFileSync } = await import('fs');
    const buf = readFileSync(path);
    expect(buf.length).toBeGreaterThan(100);

    // PNG magic bytes: 89 50 4E 47
    expect(buf[0]).toBe(0x89);
    expect(buf[1]).toBe(0x50); // P
    expect(buf[2]).toBe(0x4e); // N
    expect(buf[3]).toBe(0x47); // G
  });
});

// ── SVG export ────────────────────────────────────────────────────────────────
test.describe('Export — SVG', () => {
  test('SVG download is triggered', async ({ page }) => {
    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 15_000 });
    await page.evaluate(() => exportSVG());
    const download = await downloadPromise;

    expect(download.suggestedFilename()).toMatch(/\.svg$/i);

    const path = await download.path();
    const { readFileSync } = await import('fs');
    const content = readFileSync(path, 'utf8');

    // SVG file must contain SVG root element
    expect(content).toContain('<svg');
    expect(content).toContain('</svg>');
  });

  test('SVG download contains expected topology content', async ({ page }) => {
    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 15_000 });
    await page.evaluate(() => exportSVG());
    const download = await downloadPromise;

    const path = await download.path();
    const { readFileSync } = await import('fs');
    const content = readFileSync(path, 'utf8');

    // The SVG should reference nodes and paths from the canvas
    expect(content.length).toBeGreaterThan(500);
  });
});

// ── PDF export ────────────────────────────────────────────────────────────────
test.describe('Export — PDF', () => {
  test('PDF download is triggered and is structurally valid', async ({ page, browserName }) => {
    // PDF export uses browser print/canvas — works in Chromium; WebKit may skip
    if (browserName === 'webkit') {
      test.skip(true, 'PDF export via window.print is limited in WebKit headless');
    }

    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 20_000 });
    await page.evaluate(() => exportPDF());
    const download = await downloadPromise;

    const name = download.suggestedFilename();
    expect(name).toMatch(/\.(pdf)$/i);

    const path = await download.path();
    const { readFileSync } = await import('fs');
    const buf = readFileSync(path);
    expect(buf.length).toBeGreaterThan(100);

    // PDF magic bytes: %PDF
    const header = buf.slice(0, 4).toString('ascii');
    expect(header).toBe('%PDF');
  });
});

// ── Preview as Standalone ─────────────────────────────────────────────────────
test.describe('Export — Preview as Standalone', () => {
  test('standalone HTML generation produces valid self-contained output', async ({ page }) => {
    await seedTopology(page);

    // Build the standalone HTML directly and validate its contents
    // (blob URL popups are unreliable in headless browsers)
    const html = await page.evaluate(() => _buildStandaloneHtml());

    expect(html).toContain('<!DOCTYPE html>');
    expect(html).toContain('TopologyDesigner');
    expect(html).toContain('<div id="app">');
    // Should have inlined CSS and JS
    expect(html).toContain('<style>');
    expect(html).toContain('</script>');
    // Should contain our seeded node IDs in the runtime code
    expect(html).toContain('N1');
    expect(html).toContain('N2');
    expect(html).toContain('N3');
    expect(html.length).toBeGreaterThan(10_000); // substantial inlined content
  });
});

// ── Export Standalone HTML ────────────────────────────────────────────────────
test.describe('Export — Standalone HTML', () => {
  test('exportStandaloneHTML downloads a .html file', async ({ page }) => {
    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 15_000 });
    await page.evaluate(() => exportStandaloneHTML());
    const download = await downloadPromise;

    expect(download.suggestedFilename()).toMatch(/\.html$/i);

    const path = await download.path();
    const { readFileSync } = await import('fs');
    const content = readFileSync(path, 'utf8');

    expect(content).toContain('<!DOCTYPE html>');
    expect(content).toContain('TopologyDesigner');
    expect(content.length).toBeGreaterThan(1000);
  });

  test('exported standalone HTML contains topology runtime code', async ({ page }) => {
    await seedTopology(page);

    const downloadPromise = page.waitForEvent('download', { timeout: 15_000 });
    await page.evaluate(() => exportStandaloneHTML());
    const download = await downloadPromise;

    const { readFileSync } = await import('fs');
    const htmlPath = await download.path();
    const htmlContent = readFileSync(htmlPath, 'utf8');

    // Verify the standalone HTML is self-contained and has the topology
    expect(htmlContent).toContain('TopologyDesigner');
    expect(htmlContent).toContain('<div id="app">');
    expect(htmlContent).toContain('<style>'); // inlined CSS
    // Should contain the seeded node references
    expect(htmlContent).toContain('N1');
    expect(htmlContent).toContain('N2');
    // Substantial size means JS + CSS were inlined
    expect(htmlContent.length).toBeGreaterThan(10_000);
  });
});
