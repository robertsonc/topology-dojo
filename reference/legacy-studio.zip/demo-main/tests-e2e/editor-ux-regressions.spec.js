import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor UX regressions', () => {
  test('zone color change is undoable and redoable', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      // Ensure clean-ish slate for zone test
      if (!state.zones) state.zones = new Map();
      state.selectedIds = new Set(['N1', 'N2']);
      selectElement('N1', 'node');
      addZone();
      const zoneId = [...state.zones.keys()][0];
      selectElement(zoneId, 'zone');
      renderProps();
    });

    const zoneId = await page.evaluate(() => [...state.zones.keys()][0]);
    const before = await page.evaluate((id) => state.zones.get(id).color, zoneId);

    const swatches = page.locator('#propsBody .ed-color-swatch');
    const swatchCount = await swatches.count();
    expect(swatchCount).toBeGreaterThan(1);

    // click a different swatch than current default
    await swatches.nth(1).click();

    const changed = await page.evaluate((id) => state.zones.get(id).color, zoneId);
    expect(changed).not.toBe(before);
    expect(await page.evaluate(() => state._undoStack.length)).toBeGreaterThan(0);

    await page.locator('#undoBtn').click();
    const undone = await page.evaluate((id) => state.zones.get(id).color, zoneId);
    expect(undone).toBe(before);

    await page.locator('#redoBtn').click();
    const redone = await page.evaluate((id) => state.zones.get(id).color, zoneId);
    expect(redone).toBe(changed);
  });

  test('zone creation and node assignment survive save/load round trip', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      if (!state.zones) state.zones = new Map();
      state.selectedIds = new Set(['N1', 'N2']);
      addZone();
    });

    const before = await page.evaluate(() => {
      const id = [...state.zones.keys()][0];
      return { id, zone: structuredClone(state.zones.get(id)) };
    });

    const snapshot = await page.evaluate(() => serializeState());
    await page.evaluate((json) => {
      clearAll();
      deserializeState(json);
      renderCanvas();
      renderProps();
    }, snapshot);

    const after = await page.evaluate((id) => state.zones.get(id), before.id);
    expect(after.label).toBe(before.zone.label);
    expect(after.color).toBe(before.zone.color);
    expect(after.nodes.sort()).toEqual(before.zone.nodes.sort());
  });

  test('toolbar undo/redo works for zone label edits', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.selectedIds = new Set(['N1']);
      addZone();
      const zoneId = [...state.zones.keys()][0];
      selectElement(zoneId, 'zone');
      renderProps();
    });

    const zoneId = await page.evaluate(() => [...state.zones.keys()][0]);
    const labelInput = page.locator('#propsBody input').nth(1); // Zone ID disabled, label is second input
    await expect(labelInput).toBeVisible();

    const before = await page.evaluate((id) => state.zones.get(id).label, zoneId);
    await labelInput.fill('Updated Zone Label');
    await labelInput.dispatchEvent('change');

    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe('Updated Zone Label');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe(before);

    await page.locator('#redoBtn').click();
    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe('Updated Zone Label');
  });

  test('real keyboard shortcut path can trigger undo/redo for zone edits', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.selectedIds = new Set(['N1']);
      addZone();
      const zoneId = [...state.zones.keys()][0];
      selectElement(zoneId, 'zone');
      renderProps();
    });

    const zoneId = await page.evaluate(() => [...state.zones.keys()][0]);
    const labelInput = page.locator('#propsBody input').nth(1);
    await labelInput.click();
    await labelInput.fill('Keyboard Updated');
    await labelInput.dispatchEvent('change');
    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe('Keyboard Updated');

    await page.locator('#canvas').click({ force: true });
    await page.keyboard.press('Control+z');
    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe('ZONE 1');

    await page.keyboard.press('Control+Shift+z');
    expect(await page.evaluate((id) => state.zones.get(id).label, zoneId)).toBe('Keyboard Updated');
  });
});
