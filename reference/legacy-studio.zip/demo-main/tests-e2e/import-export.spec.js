/**
 * import-export.spec.js
 * Round-trip fidelity tests for JSON save/load and HTML import.
 */

import { test, expect } from '@playwright/test';
import { seedTopology, getEditorState } from './helpers/seed-topology.js';

// ── JSON round-trip ───────────────────────────────────────────────────────────
test.describe('Import/Export — JSON round-trip', () => {
  test('save topology as JSON then re-import and verify node fidelity', async ({ page }) => {
    await seedTopology(page);

    // Capture original state
    const original = await getEditorState(page);
    const originalNodes = new Map(original.nodes);
    const originalLinks = new Map(original.links);

    expect(originalNodes.size).toBeGreaterThanOrEqual(3);
    expect(originalLinks.size).toBeGreaterThanOrEqual(2);

    // Serialise to JSON string
    const jsonStr = await page.evaluate(() => serializeState());

    // Clear and re-import
    await page.evaluate((json) => {
      clearAll();
      // Use the internal deserializeState function directly
      deserializeState(json);
      renderCanvas();
      renderChoreo();
    }, jsonStr);

    // Allow UI to settle
    await page.waitForTimeout(300);

    // Verify fidelity
    const restored = await getEditorState(page);

    expect(restored.nodes.length).toBe(original.nodes.length);
    expect(restored.links.length).toBe(original.links.length);
    expect(restored.steps.length).toBe(original.steps.length);
    expect(restored.title).toBe(original.title);

    // Check specific node properties preserved
    const n1Original = original.nodes.find(([id]) => id === 'N1');
    const n1Restored = restored.nodes.find(([id]) => id === 'N1');
    expect(n1Restored).toBeDefined();
    expect(n1Restored[1].label).toBe(n1Original[1].label);
    expect(n1Restored[1].type).toBe(n1Original[1].type);
    expect(n1Restored[1].x).toBe(n1Original[1].x);
    expect(n1Restored[1].y).toBe(n1Original[1].y);
  });

  test('link properties preserved after round-trip', async ({ page }) => {
    await seedTopology(page);

    const jsonStr = await page.evaluate(() => serializeState());

    await page.evaluate((json) => {
      clearAll();
      deserializeState(json);
      renderCanvas();
    }, jsonStr);

    const restored = await getEditorState(page);
    const l1 = restored.links.find(([id]) => id === 'L1');
    expect(l1).toBeDefined();
    expect(l1[1].from).toBe('N1');
    expect(l1[1].to).toBe('N2');
    expect(l1[1].type).toBe('line');
  });

  test('choreography (acts and steps) preserved after round-trip', async ({ page }) => {
    await seedTopology(page);

    const original = await getEditorState(page);
    const jsonStr = await page.evaluate(() => serializeState());

    await page.evaluate((json) => {
      clearAll();
      deserializeState(json);
      renderCanvas();
      renderChoreo();
    }, jsonStr);

    const restored = await getEditorState(page);
    expect(restored.acts.length).toBe(original.acts.length);
    expect(restored.steps.length).toBe(original.steps.length);

    if (original.steps.length > 0) {
      const origStep = original.steps[0];
      const restStep = restored.steps[0];
      expect(restStep.name).toBe(origStep.name);
      expect(restStep.goal).toBe(origStep.goal);
    }
  });

  test('importing via the importJSON modal works', async ({ page }) => {
    await seedTopology(page);
    const jsonStr = await page.evaluate(() => serializeState());

    // Clear state
    await page.evaluate(() => clearAll());

    // Open the import JSON modal and fill it
    await page.evaluate(() => {
      document.getElementById('importJSONModal').style.display = 'flex';
    });
    await page.locator('#importJSONInput').fill(jsonStr);

    // Click Import button in the modal
    await page.evaluate(() => executeImportJSON());
    await page.waitForTimeout(300);

    const nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBeGreaterThanOrEqual(3);
  });
});

// ── HTML import round-trip ────────────────────────────────────────────────────
test.describe('Import/Export — HTML import round-trip', () => {
  test('exportCode generates valid HTML that can be re-imported', async ({ page }) => {
    await seedTopology(page);

    // Get the generated HTML code (this is the "Save as HTML" format)
    const exportedCode = await page.evaluate(() => {
      // We call the same function that the modal calls, but capture the result
      // from the exportCode element text
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    expect(exportedCode).toContain('topo.node');
    expect(exportedCode).toContain('topo.link');
    expect(exportedCode).toContain('N1');
    expect(exportedCode).toContain('N2');
    expect(exportedCode).toContain('N3');

    // Re-import via parseImportedCode
    await page.evaluate(() => clearAll());

    const nodeCountBefore = await page.evaluate(() => state.nodes.size);
    expect(nodeCountBefore).toBe(0);

    await page.evaluate((code) => {
      parseImportedCode(code);
      renderCanvas();
    }, exportedCode);

    await page.waitForTimeout(300);

    const nodeCountAfter = await page.evaluate(() => state.nodes.size);
    expect(nodeCountAfter).toBeGreaterThanOrEqual(3);
  });

  test('round-trip preserves node positions', async ({ page }) => {
    await seedTopology(page);

    const original = await getEditorState(page);

    // Export as HTML code
    const exportedCode = await page.evaluate(() => {
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    // Clear and re-import
    await page.evaluate((code) => {
      clearAll();
      parseImportedCode(code);
      renderCanvas();
    }, exportedCode);

    await page.waitForTimeout(300);
    const restored = await getEditorState(page);

    // N1 position should be preserved
    const n1Original = original.nodes.find(([id]) => id === 'N1');
    const n1Restored = restored.nodes.find(([id]) => id === 'N1');

    expect(n1Restored).toBeDefined();
    expect(n1Restored[1].x).toBe(n1Original[1].x);
    expect(n1Restored[1].y).toBe(n1Original[1].y);

    // NOTE: color may not survive HTML code round-trip via parseImportedCode
    // if the exported code doesn't include color in the node options.
    // This is a known fidelity gap — see product backlog.
    if (n1Restored[1].color) {
      expect(n1Restored[1].color).toBe(n1Original[1].color);
    }
  });
});

// ── Standalone HTML import ────────────────────────────────────────────────────
// TODO: A full standalone HTML round-trip (export → open in new tab → navigate)
// is tested in export.spec.js via exported standalone HTML loaded with setContent().
