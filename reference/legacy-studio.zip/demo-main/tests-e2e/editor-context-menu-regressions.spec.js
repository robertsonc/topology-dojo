import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor context menu regressions', () => {
  test('right-clicking a link shows select-all-links-by-color action when multiple links share color', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#fc6161', label: 'Backup' });
      renderCanvas();
    });

    const linkHit = page.locator('#canvas [data-elem-type="link"][data-elem-id="L1"]').first();
    await expect(linkHit).toBeVisible();
    await linkHit.click({ button: 'right', force: true });

    const menu = page.locator('#contextMenu');
    await expect(menu).toBeVisible();
    await expect(menu).toContainText('Select all');
    await expect(menu).toContainText('links');
  });

  test('link context menu select-by-color action actually selects the matching links', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      state.links.set('L3', { id: 'L3', type: 'tunnel', from: 'N1', to: 'N3', color: '#fc6161', label: 'Backup' });
      renderCanvas();
    });

    const linkHit = page.locator('#canvas [data-elem-type="link"][data-elem-id="L1"]').first();
    await linkHit.click({ button: 'right', force: true });

    const colorAction = page.locator('#contextMenu .ed-context-item').filter({ hasText: 'links' }).filter({ hasText: 'Select' }).first();
    await expect(colorAction).toBeVisible();
    await colorAction.click();

    const selected = await page.evaluate(() => [...state.selectedIds].sort());
    expect(selected).toEqual(['L1', 'L2']);
  });
});
