import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor workflow sequence regressions', () => {
  test('node edit → zone create → zone recolor → link select by color → undo chain remains consistent', async ({ page }) => {
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'line', from: 'N2', to: 'N3', color: '#01a982', label: 'LAN' });
      renderCanvas();

      selectElement('N1', 'node');
      state._undoDesc = 'Edit node label';
      pushUndo();
      state.nodes.get('N1').label = 'HQ Router';
      renderCanvas();

      state.selectedIds = new Set(['N1', 'N2']);
      addZone();
      const zoneId = [...state.zones.keys()][0];
      selectElement(zoneId, 'zone');
      state._undoDesc = 'Change zone color';
      pushUndo();
      state.zones.get(zoneId).color = '#fc6161';
      renderCanvas();
      renderProps();

      selectLinksByColor('#01a982');
    });

    expect(await page.evaluate(() => [...state.selectedIds].sort())).toEqual(['L1', 'L2']);
    expect(await page.evaluate(() => [...state.zones.values()][0].color)).toBe('#fc6161');
    expect(await page.evaluate(() => state.nodes.get('N1').label)).toBe('HQ Router');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => [...state.zones.values()][0].color)).not.toBe('#fc6161');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.zones.size)).toBe(0);

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.get('N1').label)).toBe('Router');
  });

  test('selection remains sane across mixed node/link operations and save-load', async ({ page }) => {
    await seedTopology(page);

    await page.evaluate(() => {
      state.links.clear();
      state.links.set('L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', label: 'WAN' });
      state.links.set('L2', { id: 'L2', type: 'tunnel', from: 'N2', to: 'N3', color: '#01a982', label: 'Overlay' });
      renderCanvas();

      state.selectedIds = new Set(['N1', 'L1']);
      moveSelectionToLayer('overlay', 'N1', 'node');
      selectLinksByColor('#01a982');
    });

    expect(await page.evaluate(() => [...state.selectedIds].sort())).toEqual(['L1', 'L2']);

    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
      renderProps();
      selectLinksByType('line');
    }, json);

    expect(await page.evaluate(() => [...state.selectedIds])).toEqual(['L1']);
    expect(await page.evaluate(() => state.nodes.get('N1').layer)).toBe('overlay');
  });
});
