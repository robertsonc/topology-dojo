/**
 * editor-basic.spec.js
 * Tests for the Topology Studio editor page.
 * Covers: load, node/link creation, label editing, undo/redo, save/load JSON.
 */

import { test, expect } from '@playwright/test';
import { seedTopology, getEditorState } from './helpers/seed-topology.js';

// ── Collect console errors ───────────────────────────────────────────────────
function attachConsoleCapture(page) {
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', err => errors.push(err.message));
  return errors;
}

// ── 1. Editor loads successfully ─────────────────────────────────────────────
test.describe('Editor — load', () => {
  test('editor page loads without console errors', async ({ page }) => {
    const errors = attachConsoleCapture(page);

    await page.goto('/editor.html');
    await page.waitForSelector('#canvas', { timeout: 15_000 });

    // Ensure the main UI elements are present
    await expect(page.locator('.ed-toolbar')).toBeVisible();
    await expect(page.locator('#canvas')).toBeVisible();
    await expect(page.locator('.ed-panel')).toBeVisible();

    // Wait a tick for any deferred errors
    await page.waitForTimeout(500);

    // Filter out known benign warnings (fonts, CORS)
    const realErrors = errors.filter(e =>
      !e.includes('ERR_BLOCKED_BY_CLIENT') &&
      !e.includes('Failed to load resource') &&
      !e.includes('favicon') &&
      !e.includes('fonts.googleapis')
    );
    expect(realErrors, `Console errors found: ${realErrors.join('\n')}`).toHaveLength(0);
  });

  test('toolbar buttons are present', async ({ page }) => {
    await page.goto('/editor.html');
    await page.waitForSelector('.ed-toolbar', { timeout: 10_000 });

    await expect(page.getByText('File ▾')).toBeVisible();
    await expect(page.locator('#undoBtn')).toBeVisible();
    await expect(page.locator('#redoBtn')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Select', exact: true })).toBeVisible();
  });
});

// ── 2. Create nodes via the UI ────────────────────────────────────────────────
test.describe('Editor — create nodes and links', () => {
  test('can create a node via clicking the canvas', async ({ page }) => {
    // Dismiss autosave dialog BEFORE navigating
    page.on('dialog', d => d.dismiss());

    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof setTool === 'function', { timeout: 10_000 });
    await page.waitForFunction(() => typeof clearAll === 'function');

    // Clear autosave state and dismiss the onboarding coach overlay
    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      // Hide the empty-state coach overlay that intercepts canvas clicks
      const coach = document.getElementById('emptyCoach');
      if (coach) coach.style.display = 'none';
    });

    // Activate add-node tool (set type to 'ec' first)
    await page.evaluate(() => {
      state.addNodeType = 'ec';
      setTool('add-node');
    });

    // Click center of canvas
    const canvas = page.locator('#canvas');
    const box = await canvas.boundingBox();
    await canvas.click({ position: { x: box.width / 2, y: box.height / 2 } });

    // A node should exist in state and in the SVG
    const nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBeGreaterThanOrEqual(1);

    await expect(canvas.locator('[data-node-id]')).toHaveCount(nodeCount);
  });

  test('can create two nodes and a link', async ({ page }) => {
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });
    page.on('dialog', d => d.dismiss());

    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      // Place two nodes
      state.nodes.set('A', { id:'A', type:'ec',    x: 250, y: 300, label: 'NodeA', color: '#01a982' });
      state.nodes.set('B', { id:'B', type:'cloud', x: 700, y: 300, label: 'NodeB', color: '#65aef9' });
      state._nextNodeNum = 3;
      renderCanvas();
    });

    // Now draw a link between them via the API
    await page.evaluate(() => {
      state.links.set('L1', { id:'L1', type:'line', from:'A', to:'B', color:'#01a982' });
      state._nextLinkNum = 2;
      renderCanvas();
    });

    const linkCount = await page.evaluate(() => state.links.size);
    expect(linkCount).toBe(1);

    // The SVG hit area for the link should exist
    await expect(page.locator('#canvas [data-elem-type="link"]')).toHaveCount(1);
  });
});

// ── 3. Edit labels and properties ─────────────────────────────────────────────
test.describe('Editor — edit labels / properties', () => {
  test('selecting a node shows properties panel', async ({ page }) => {
    await seedTopology(page);

    // Click on the N1 node hit area
    await page.evaluate(() => selectElement('N1', 'node'));
    await page.waitForTimeout(200);

    // Properties panel should show the node ID
    await expect(page.locator('#propSelId')).toContainText('N1');
  });

  test('editing a label in the properties panel updates the canvas', async ({ page }) => {
    await seedTopology(page);

    // Select N1
    await page.evaluate(() => selectElement('N1', 'node'));
    await page.waitForTimeout(200);

    // Find the label input in the props panel and change it
    const labelInput = page.locator('.ed-panel-body input[value="Router"]');
    await expect(labelInput).toBeVisible({ timeout: 5_000 });
    await labelInput.fill('Updated Label');
    await labelInput.dispatchEvent('change');

    // Canvas should now show the new label
    const labelInCanvas = await page.evaluate(() => state.nodes.get('N1').label);
    expect(labelInCanvas).toBe('Updated Label');
  });
});

// ── 4. Undo / Redo ────────────────────────────────────────────────────────────
test.describe('Editor — undo / redo', () => {
  test('undo reverts a node addition', async ({ page }) => {
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });
    page.on('dialog', d => d.dismiss());

    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
    });

    // Add a node with undo tracking
    await page.evaluate(() => {
      pushUndo();
      state.nodes.set('X1', { id:'X1', type:'ec', x:300, y:300, label:'Test', color:'#01a982' });
      renderCanvas();
    });

    let nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBe(1);

    // Undo
    await page.evaluate(() => undo());
    nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBe(0);
  });

  test('redo re-applies a reverted change', async ({ page }) => {
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });
    page.on('dialog', d => d.dismiss());

    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      pushUndo();
      state.nodes.set('X1', { id:'X1', type:'ec', x:300, y:300, label:'Test', color:'#01a982' });
      renderCanvas();
    });

    await page.evaluate(() => undo());
    let count = await page.evaluate(() => state.nodes.size);
    expect(count).toBe(0);

    // Redo
    await page.evaluate(() => redo());
    count = await page.evaluate(() => state.nodes.size);
    expect(count).toBe(1);
  });

  test('Ctrl+Z / Ctrl+Shift+Z keyboard shortcuts work', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });

    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      // Hide coach overlay so canvas clicks work
      const coach = document.getElementById('emptyCoach');
      if (coach) coach.style.display = 'none';
      pushUndo();
      state.nodes.set('K1', { id:'K1', type:'ec', x:400, y:300, label:'K', color:'#01a982' });
      renderCanvas();
    });

    // Focus the canvas (click center to avoid zoom control overlays in corners)
    const box = await page.locator('#canvas').boundingBox();
    await page.locator('#canvas').click({ position: { x: box.width / 2, y: box.height / 2 }, force: true });
    // Deselect any input
    await page.keyboard.press('Escape');

    await page.keyboard.press('Control+z');
    let count = await page.evaluate(() => state.nodes.size);
    expect(count).toBe(0);

    await page.keyboard.press('Control+Shift+z');
    count = await page.evaluate(() => state.nodes.size);
    expect(count).toBe(1);
  });
});

// ── 5. Save / Load JSON ───────────────────────────────────────────────────────
test.describe('Editor — save / load JSON', () => {
  test('saveAsJson triggers a file download', async ({ page }) => {
    await seedTopology(page);

    // Set up download listener before triggering save
    const downloadPromise = page.waitForEvent('download', { timeout: 10_000 });
    await page.evaluate(() => saveAsJson());
    const download = await downloadPromise;

    expect(download.suggestedFilename()).toMatch(/\.json$/);
  });

  test('JSON round-trip preserves nodes, links, steps', async ({ page }) => {
    await seedTopology(page);

    // Get current state as JSON
    const originalState = await getEditorState(page);
    expect(originalState.nodes.length).toBeGreaterThanOrEqual(3);
    expect(originalState.links.length).toBeGreaterThanOrEqual(2);
    expect(originalState.steps.length).toBeGreaterThanOrEqual(1);

    // Serialise and re-import
    const jsonStr = await page.evaluate(() => serializeState());
    await page.evaluate((json) => {
      clearAll();
      deserializeState(json);
      renderCanvas();
      renderChoreo();
    }, jsonStr);
    await page.waitForTimeout(300);

    const restoredState = await getEditorState(page);
    expect(restoredState.nodes.length).toBe(originalState.nodes.length);
    expect(restoredState.links.length).toBe(originalState.links.length);
  });

  test('importJSON modal accepts pasted JSON', async ({ page }) => {
    await seedTopology(page);
    const jsonStr = await page.evaluate(() => serializeState());

    // Clear and open import modal
    await page.evaluate(() => {
      clearAll();
      document.getElementById('importJSONModal').style.display = 'flex';
    });

    await page.locator('#importJSONInput').fill(jsonStr);
    await page.getByRole('button', { name: /Import/ }).first().click();
    await page.waitForTimeout(300);

    const nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBeGreaterThanOrEqual(3);
  });
});
