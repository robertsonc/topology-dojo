/**
 * uat-interop.spec.js  —  Scenario Pack D: Interop
 *
 * UAT coverage:
 *   D1 - Import each canonical JSON fixture into the editor
 *   D2 - Import HTML/code format (exportCode → parseImportedCode round-trip)
 *   D3 - draw.io XML import via topo.importDrawio() (topology-ds.js)
 *       NOTE: The importDrawio() function lives in topology-ds.js (the viewer engine),
 *             not as a UI function in the editor. The editor does not yet expose
 *             a draw.io import UI. These tests validate the engine function directly.
 *   D4 - Round-trip fidelity after edits (edit then re-import)
 */

import { test, expect } from '@playwright/test';
import { loadFixtureInEditor, getEditorState, getFixture } from './helpers/load-fixture.js';

// ─────────────────────────────────────────────────────────────────────────────
// D1 — Import each canonical JSON fixture
// ─────────────────────────────────────────────────────────────────────────────

test.describe('UAT-D1 — Import JSON fixtures', () => {
  const fixtures = [
    { name: 'sdwan-branch',          nodes: 8,  links: 8 },
    { name: 'ztna-user-to-app',      nodes: 7,  links: 7 },
    { name: 'firewall-blocked-flow', nodes: 7,  links: 6 },
    { name: 'multi-layer-policy',    nodes: 10, links: 10 },
    { name: 'executive-multi-act',   nodes: 10, links: 10 },
    { name: 'dense-topology',        nodes: 30, links: 30 },
  ];

  for (const { name, nodes, links } of fixtures) {
    test(`${name}: loads correct node and link counts`, async ({ page }) => {
      await loadFixtureInEditor(page, name);

      const nodeCount = await page.evaluate(() => state.nodes.size);
      const linkCount = await page.evaluate(() => state.links.size);

      expect(nodeCount).toBe(nodes);
      expect(linkCount).toBe(links);
    });
  }

  test('importJSONModal: importing sdwan-branch via modal works', async ({ page }) => {
    await loadFixtureInEditor(page, 'sdwan-branch');
    const jsonStr = await page.evaluate(() => serializeState());

    // Clear and re-import via modal
    await page.evaluate(() => clearAll());
    await page.evaluate(() => {
      document.getElementById('importJSONModal').style.display = 'flex';
    });
    await page.locator('#importJSONInput').fill(jsonStr);
    await page.evaluate(() => executeImportJSON());
    await page.waitForTimeout(300);

    const nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBe(8);
  });

  test('importJSONModal: importing dense-topology via modal works', async ({ page }) => {
    await loadFixtureInEditor(page, 'dense-topology');
    const jsonStr = await page.evaluate(() => serializeState());

    await page.evaluate(() => clearAll());
    await page.evaluate(() => {
      document.getElementById('importJSONModal').style.display = 'flex';
    });
    await page.locator('#importJSONInput').fill(jsonStr);
    await page.evaluate(() => executeImportJSON());
    await page.waitForTimeout(400);

    const nodeCount = await page.evaluate(() => state.nodes.size);
    expect(nodeCount).toBe(30);
  });

  test('each fixture title is preserved after import', async ({ page }) => {
    await loadFixtureInEditor(page, 'executive-multi-act');

    const title = await page.evaluate(() => state.title);
    expect(title).toBe('Executive Security Architecture');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// D2 — Import HTML/code format (exportCode → parseImportedCode)
// ─────────────────────────────────────────────────────────────────────────────

test.describe('UAT-D2 — HTML code import', () => {
  test('sdwan-branch: exportCode → parseImportedCode round-trip', async ({ page }) => {
    await loadFixtureInEditor(page, 'sdwan-branch');
    const original = await getEditorState(page);

    // Export as HTML code
    const exportedCode = await page.evaluate(() => {
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    expect(exportedCode).toContain('topo.node');
    expect(exportedCode).toContain('topo.link');

    // Re-import
    await page.evaluate(() => clearAll());
    await page.evaluate((code) => {
      parseImportedCode(code);
      renderCanvas();
    }, exportedCode);
    await page.waitForTimeout(300);

    const restored = await getEditorState(page);
    expect(restored.nodes.length).toBe(original.nodes.length);
    expect(restored.links.length).toBe(original.links.length);
  });

  test('HTML code round-trip preserves node positions', async ({ page }) => {
    await loadFixtureInEditor(page, 'ztna-user-to-app');
    const original = await getEditorState(page);

    const exportedCode = await page.evaluate(() => {
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    await page.evaluate((code) => {
      clearAll();
      parseImportedCode(code);
      renderCanvas();
    }, exportedCode);
    await page.waitForTimeout(300);

    const restored = await getEditorState(page);

    // Find USER node in both
    const origUser = original.nodes.find(([id]) => id === 'USER');
    const restUser = restored.nodes.find(([id]) => id === 'USER');

    if (origUser && restUser) {
      expect(restUser[1].x).toBe(origUser[1].x);
      expect(restUser[1].y).toBe(origUser[1].y);
    } else {
      // If node IDs differ after HTML code round-trip, just check counts
      expect(restored.nodes.length).toBe(original.nodes.length);
    }
  });

  test('HTML code export contains expected topology API calls', async ({ page }) => {
    await loadFixtureInEditor(page, 'firewall-blocked-flow');

    const exportedCode = await page.evaluate(() => {
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    // Should contain topo API calls
    expect(exportedCode).toContain('topo.node');
    expect(exportedCode).toContain('topo.link');
    expect(exportedCode).toContain('topo.act');
    // Choreography may be emitted as topo.step(...) or topo.addStep(...)
    expect(/topo\.(step|addStep)\(/.test(exportedCode)).toBe(true);
  });

  test('empty topology export produces minimal code', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function', { timeout: 10_000 });
    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
    });

    const exportedCode = await page.evaluate(() => {
      exportCode();
      const code = document.getElementById('exportCode').textContent;
      document.getElementById('exportModal').style.display = 'none';
      return code;
    });

    expect(typeof exportedCode).toBe('string');
    // Empty topology may produce a minimal template
    expect(exportedCode.length).toBeGreaterThanOrEqual(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// D3 — draw.io XML import (via topology-ds.js engine)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * TODO (Product Gap): The editor.html does not yet expose a draw.io import UI.
 * The importDrawio() function exists on the TopologyDesigner class in topology-ds.js
 * and is documented in USER-MANUAL.md, but it cannot be called from the editor's
 * global scope (no bridge function). These tests verify the engine function works
 * by calling it on a TopologyDesigner instance directly.
 *
 * To unblock a full editor UI test, add a global `importDrawioXML(xmlString)` function
 * to editor.html that creates a TopologyDesigner instance, calls importDrawio(),
 * and merges the result into the editor state.
 */

test.describe('UAT-D3 — draw.io XML import (engine)', () => {
  test('TopologyDesigner.importDrawio() is available on the class', async ({ page }) => {
    await page.goto('/viewer.html');
    await page.waitForFunction(() => typeof TopologyDesigner !== 'undefined', { timeout: 15_000 });

    const hasImportDrawio = await page.evaluate(() =>
      typeof TopologyDesigner.prototype.importDrawio === 'function'
    );
    expect(hasImportDrawio).toBe(true);
  });

  test('importDrawio() parses a simple draw.io XML and creates nodes', async ({ page }) => {
    await page.goto('/viewer.html');
    await page.waitForFunction(() => typeof TopologyDesigner !== 'undefined', { timeout: 15_000 });

    // Minimal draw.io XML with two nodes and one edge
    const drawioXml = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />
    <mxCell id="2" value="Router" style="shape=mxgraph.cisco.routers.router" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry" />
    </mxCell>
    <mxCell id="3" value="Switch" style="shape=mxgraph.cisco.switches.workgroup_switch" vertex="1" parent="1">
      <mxGeometry x="300" y="100" width="60" height="60" as="geometry" />
    </mxCell>
    <mxCell id="4" value="" edge="1" source="2" target="3" parent="1">
      <mxGeometry relative="1" as="geometry" />
    </mxCell>
  </root>
</mxGraphModel>`;

    const result = await page.evaluate((xml) => {
      const topo = new TopologyDesigner({ title: 'DrawIO Test' });
      topo.importDrawio(xml);
      // After import, topology should have nodes
      return {
        nodeCount: topo._nodes.size,
        linkCount: topo._links.size,
      };
    }, drawioXml);

    expect(result.nodeCount).toBeGreaterThanOrEqual(2);
    expect(result.linkCount).toBeGreaterThanOrEqual(1);
  });

  test('importDrawio() creates an act and step when autoAct is true', async ({ page }) => {
    await page.goto('/viewer.html');
    await page.waitForFunction(() => typeof TopologyDesigner !== 'undefined', { timeout: 15_000 });

    const drawioXml = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />
    <mxCell id="2" value="Firewall" style="shape=mxgraph.cisco.firewalls.firewall" vertex="1" parent="1">
      <mxGeometry x="200" y="200" width="60" height="60" as="geometry" />
    </mxCell>
    <mxCell id="3" value="Host" style="shape=mxgraph.cisco.computers_and_peripherals.pc" vertex="1" parent="1">
      <mxGeometry x="400" y="200" width="60" height="60" as="geometry" />
    </mxCell>
  </root>
</mxGraphModel>`;

    const result = await page.evaluate((xml) => {
      const topo = new TopologyDesigner({ title: 'DrawIO Act Test' });
      topo.importDrawio(xml, { autoAct: true });
      return {
        actCount:  topo._acts.length,
        stepCount: topo._steps.length,
      };
    }, drawioXml);

    expect(result.actCount).toBeGreaterThanOrEqual(1);
    expect(result.stepCount).toBeGreaterThanOrEqual(1);
  });

  test.skip('editor UI: draw.io import button — not yet implemented', async () => {
    /**
     * TODO: A draw.io import UI does not yet exist in editor.html.
     * The USER-MANUAL documents importDrawio() as an engine API only.
     * When a UI is added (file picker or paste modal), add tests here:
     *
     *   1. Open the import modal (e.g. "Import draw.io XML")
     *   2. Paste the XML string into the textarea
     *   3. Click Import
     *   4. Verify nodes appear on the canvas
     *
     * Blocking gap: No global `executeImportDrawio()` or equivalent in editor.html.
     */
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// D4 — Round-trip fidelity after edits
// ─────────────────────────────────────────────────────────────────────────────

test.describe('UAT-D4 — Round-trip fidelity after edits', () => {
  test('add a node, export, reimport — new node is preserved', async ({ page }) => {
    await loadFixtureInEditor(page, 'sdwan-branch');

    const beforeCount = await page.evaluate(() => state.nodes.size);

    // Add a new node
    await page.evaluate(() => {
      pushUndo();
      state.nodes.set('EXTRA', { id:'EXTRA', type:'host', x:525, y:560, label:'Extra Host', color:'#deb146' });
      state._nextNodeNum++;
      renderCanvas();
    });

    // Serialize and reimport
    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
    }, json);

    const afterCount = await page.evaluate(() => state.nodes.size);
    const hasExtra = await page.evaluate(() => state.nodes.has('EXTRA'));

    expect(afterCount).toBe(beforeCount + 1);
    expect(hasExtra).toBe(true);
  });

  test('rename a node label, export, reimport — label change persists', async ({ page }) => {
    await loadFixtureInEditor(page, 'ztna-user-to-app');

    await page.evaluate(() => {
      pushUndo();
      state.nodes.get('USER').label = 'Remote Worker';
      renderCanvas();
    });

    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
    }, json);

    const label = await page.evaluate(() => state.nodes.get('USER')?.label);
    expect(label).toBe('Remote Worker');
  });

  test('delete a link, export, reimport — link stays deleted', async ({ page }) => {
    await loadFixtureInEditor(page, 'firewall-blocked-flow');

    const beforeLinks = await page.evaluate(() => state.links.size);

    await page.evaluate(() => {
      pushUndo();
      state.links.delete('fw-log');
      renderCanvas();
    });

    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
    }, json);

    const afterLinks = await page.evaluate(() => state.links.size);
    const hasLink = await page.evaluate(() => state.links.has('fw-log'));

    expect(afterLinks).toBe(beforeLinks - 1);
    expect(hasLink).toBe(false);
  });

  test('add a step, export, reimport — step is preserved with narration', async ({ page }) => {
    await loadFixtureInEditor(page, 'sdwan-branch');

    const beforeSteps = await page.evaluate(() => state.steps.length);
    const actId = await page.evaluate(() => state.acts[0]?.id);

    await page.evaluate((aid) => {
      pushUndo();
      state.steps.push({
        id: 'extra_step', act: aid,
        name: 'Extra Step',
        goal: 'UAT test step',
        narration: 'This step was added during round-trip editing.',
        focus: ['HQ'],
        phases: [{ show: ['HQ', 'SSW'], diff: 'After edit' }],
      });
      renderChoreo();
    }, actId);

    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
      renderChoreo();
    }, json);

    const afterSteps = await page.evaluate(() => state.steps.length);
    const step = await page.evaluate(() => state.steps.find(s => s.id === 'extra_step'));

    expect(afterSteps).toBe(beforeSteps + 1);
    expect(step).toBeDefined();
    expect(step.narration).toBe('This step was added during round-trip editing.');
  });

  test('modify node position, export, reimport — position change persists', async ({ page }) => {
    await loadFixtureInEditor(page, 'sdwan-branch');

    const newX = 999, newY = 444;

    await page.evaluate(({ x, y }) => {
      pushUndo();
      const n = state.nodes.get('HQ');
      n.x = x;
      n.y = y;
      renderCanvas();
    }, { x: newX, y: newY });

    const json = await page.evaluate(() => serializeState());
    await page.evaluate((j) => {
      clearAll();
      deserializeState(j);
      renderCanvas();
    }, json);

    const node = await page.evaluate(() => ({ ...state.nodes.get('HQ') }));
    expect(node.x).toBe(newX);
    expect(node.y).toBe(newY);
  });
});
