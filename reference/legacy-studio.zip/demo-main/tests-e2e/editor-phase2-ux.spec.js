import { test, expect } from '@playwright/test';
import { seedTopology } from './helpers/seed-topology.js';

test.describe('Editor Phase 2 UX coverage', () => {
  test('node label edit is undoable via toolbar and keyboard', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      selectElement('N1', 'node');
      renderProps();
    });

    const before = await page.evaluate(() => state.nodes.get('N1').label);
    const labelInput = page.locator('#propsBody .ed-field').filter({ has: page.locator('label:text("Label")') }).locator('input').first();

    await labelInput.click();
    await labelInput.fill('Branch Router');
    await labelInput.dispatchEvent('change');
    expect(await page.evaluate(() => state.nodes.get('N1').label)).toBe('Branch Router');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.get('N1').label)).toBe(before);

    await page.locator('#canvas').click({ force: true });
    await page.keyboard.press('Control+Shift+z');
    expect(await page.evaluate(() => state.nodes.get('N1').label)).toBe('Branch Router');
  });

  test('node color edit is undoable', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      selectElement('N1', 'node');
      renderProps();
    });

    const before = await page.evaluate(() => state.nodes.get('N1').color);
    const swatches = page.locator('#propsBody .ed-color-swatch');
    await swatches.nth(1).click();

    const changed = await page.evaluate(() => state.nodes.get('N1').color);
    expect(changed).not.toBe(before);

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.get('N1').color)).toBe(before);
  });

  test('link label edit is undoable', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      selectElement('L1', 'link');
      renderProps();
    });

    const before = await page.evaluate(() => state.links.get('L1').label || '');
    const labelInput = page.locator('#propsBody .ed-field').filter({ has: page.locator('label:text("Label")') }).locator('input').first();

    await labelInput.click();
    await labelInput.fill('Primary Path');
    await labelInput.dispatchEvent('change');
    expect(await page.evaluate(() => state.links.get('L1').label)).toBe('Primary Path');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.links.get('L1').label || '')).toBe(before);
  });

  test('delete selected node is undoable', async ({ page }) => {
    await seedTopology(page);

    page.removeAllListeners('dialog');
    page.on('dialog', d => d.accept());

    await page.evaluate(() => {
      selectElement('N1', 'node');
      renderProps();
    });

    expect(await page.evaluate(() => state.nodes.has('N1'))).toBe(true);
    await page.getByRole('button', { name: 'Delete Node' }).click();
    expect(await page.evaluate(() => state.nodes.has('N1'))).toBe(false);

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.has('N1'))).toBe(true);
  });

  test('multi-select layer move remains undoable', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await seedTopology(page);

    await page.evaluate(() => {
      state.selectedIds = new Set(['N1', 'N2']);
      moveSelectionToLayer('overlay', 'N1', 'node');
    });

    expect(await page.evaluate(() => state.nodes.get('N1').layer)).toBe('overlay');
    expect(await page.evaluate(() => state.nodes.get('N2').layer)).toBe('overlay');

    await page.locator('#undoBtn').click();
    expect(await page.evaluate(() => state.nodes.get('N1').layer)).not.toBe('overlay');
    expect(await page.evaluate(() => state.nodes.get('N2').layer)).not.toBe('overlay');
  });
});
