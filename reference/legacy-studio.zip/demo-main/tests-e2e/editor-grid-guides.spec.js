import { test, expect } from '@playwright/test';

/**
 * Regression coverage for canvas authoring aids that are easy to break because
 * they are rendered in the editor's browser-only inline script.
 */
test.describe('Editor canvas grid and drag guides', () => {
  test('background grid covers the zoomed-out viewBox without requiring a full rerender', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function' && typeof zoomOut === 'function');

    await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      state.gridVisible = true;
      state.gridOpacity = 0.08;
      state.viewBox = '0 0 1050 700';
      renderCanvas();
      // zoomOut updates only the SVG viewBox; the grid background must still
      // cover the newly visible area after repeated zoom-outs.
      for (let i = 0; i < 5; i++) zoomOut();
    });

    const coverage = await page.evaluate(() => {
      const vb = state.viewBox.split(' ').map(Number);
      const grid = document.querySelector('#canvas [data-tds-grid-background="true"]');
      return {
        vb,
        x: Number(grid?.getAttribute('x')),
        y: Number(grid?.getAttribute('y')),
        width: Number(grid?.getAttribute('width')),
        height: Number(grid?.getAttribute('height')),
      };
    });

    expect(Number.isFinite(coverage.x)).toBe(true);
    expect(coverage.x).toBeLessThanOrEqual(coverage.vb[0]);
    expect(coverage.y).toBeLessThanOrEqual(coverage.vb[1]);
    expect(coverage.x + coverage.width).toBeGreaterThanOrEqual(coverage.vb[0] + coverage.vb[2]);
    expect(coverage.y + coverage.height).toBeGreaterThanOrEqual(coverage.vb[1] + coverage.vb[3]);
  });

  test('drag guide computation includes equal-spacing hints for aligned nodes', async ({ page }) => {
    page.on('dialog', d => d.dismiss());
    await page.goto('/editor.html');
    await page.waitForFunction(() => typeof clearAll === 'function' && typeof computeAlignGuides === 'function');

    const guides = await page.evaluate(() => {
      localStorage.removeItem('tds-editor-autosave');
      clearAll();
      state.nodes.set('A', { id: 'A', type: 'ec', x: 100, y: 200, label: 'A' });
      state.nodes.set('B', { id: 'B', type: 'ec', x: 220, y: 200, label: 'B' });
      state.nodes.set('C', { id: 'C', type: 'ec', x: 340, y: 200, label: 'C' });
      state.viewBox = '0 0 600 400';
      return computeAlignGuides('B', 220, 200);
    });

    expect(guides.some(g => g.type === 'spacing' && g.axis === 'h' && g.label === '120px')).toBe(true);
    expect(guides.some(g => g.type !== 'spacing' && g.y1 === 200 && g.y2 === 200)).toBe(true);
  });
});
