import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const root = path.resolve(process.cwd(), 'design-system');
const host = '127.0.0.1';
const port = Number(process.env.PORT || 5432);

const mime = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.gif', 'image/gif'],
  ['.webp', 'image/webp'],
  ['.ico', 'image/x-icon'],
  ['.txt', 'text/plain; charset=utf-8'],
]);

function send(res, status, body, type = 'text/plain; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type });
  res.end(body);
}

const server = http.createServer((req, res) => {
  const parsed = new URL(req.url, `http://${host}:${port}`);
  let pathname = decodeURIComponent(parsed.pathname);
  if (pathname === '/') pathname = '/index.html';

  const requested = path.normalize(path.join(root, pathname));
  if (!requested.startsWith(root)) {
    return send(res, 403, 'Forbidden');
  }

  fs.stat(requested, (err, stat) => {
    if (!err && stat.isFile()) {
      const ext = path.extname(requested).toLowerCase();
      res.writeHead(200, { 'Content-Type': mime.get(ext) || 'application/octet-stream' });
      fs.createReadStream(requested).pipe(res);
      return;
    }

    if (!err && stat.isDirectory()) {
      const indexFile = path.join(requested, 'index.html');
      fs.stat(indexFile, (indexErr, indexStat) => {
        if (!indexErr && indexStat.isFile()) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          fs.createReadStream(indexFile).pipe(res);
        } else {
          send(res, 404, 'Not Found');
        }
      });
      return;
    }

    send(res, 404, 'Not Found');
  });
});

server.listen(port, host, () => {
  console.log(`Static server listening on http://${host}:${port}`);
});
