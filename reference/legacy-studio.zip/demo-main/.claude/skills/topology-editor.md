# Topology Editor & Choreographer Skill

Generate production-quality network topology visualizations with step-by-step cinematic choreography using the Topology Design System.

## Trigger

Activate when the user asks to:
- Create, build, or generate a network topology diagram
- Design a network architecture visualization
- Build a choreographed topology walkthrough or presentation
- Add nodes, links, or steps to a topology
- Create an SD-WAN, ZTNA, data center, cloud, or any network diagram
- Generate topology code for the Topology Design System

## System Overview

The Topology Design System is a vanilla JavaScript + SVG + CSS engine (`design-system/topology-ds.js` + `design-system/topology-ds.css`) that renders animated, cinematic network topology visualizations. It uses a declarative, chainable API. The visual editor is at `design-system/editor.html`.

All output is a standalone HTML file that loads the engine and declares topology data.

## Output Format

Always generate a **complete, standalone HTML file** with this structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>TOPOLOGY_TITLE</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="topology-ds.css">
</head>
<body>
<div id="app"></div>
<script src="topology-ds.js"></script>
<script>
const topo = new TopologyDesigner({
  title: 'TITLE',
  subtitle: 'SUBTITLE',
  viewBox: '0 0 1050 700',
  phaseMs: 600,
});

// ── Nodes ──
// ── Anchors ──
// ── Links ──
// ── Glossary ──
// ── Acts & Steps ──

topo.mount('app');
</script>
</body>
</html>
```

Save generated files into the `design-system/` directory so relative paths to `topology-ds.js` and `topology-ds.css` resolve correctly.

## Constructor Options

```javascript
new TopologyDesigner({
  title: 'My Topology',           // Top bar title
  subtitle: 'Subtitle text',      // Top bar subtitle
  viewBox: '0 0 1050 700',        // SVG viewBox (width x height coordinate space)
  phaseMs: 600,                    // Delay between phases in ms (controls reveal pacing)
  drawDuration: 0.7,              // Stroke draw-in animation duration (seconds)
  fadeDuration: 0.55,             // Phase fade-in transition duration (seconds)
  mode: 'manual',                 // Playback mode: 'manual' | 'auto' | 'presenter'
  speedMs: 4000,                  // Auto-play interval in ms
  routing: true,                  // Smart link routing (avoid crossing nodes)
  interpolationDuration: 800,     // Position interpolation animation duration (ms)
})
```

## Node Registration

```javascript
topo.node(id, config)
```

### Required Properties
| Property | Type | Description |
|----------|------|-------------|
| `type` | `string` | Node type (see Node Types table) |
| `x` | `number` | X position in SVG coordinates |
| `y` | `number` | Y position in SVG coordinates |

### Optional Properties
| Property | Type | Description |
|----------|------|-------------|
| `label` | `string` | Text label displayed below the node |
| `sublabel` | `string` | Secondary label (smaller, gray) |
| `color` | `string` | Override color for the node |
| `labelOffset` | `number` | Vertical offset for label (default: 24) |
| `labelY` | `number` | Absolute Y position for the label |
| `labelColor` | `string` | Override color for the label text |
| `haloColor` | `string` | Override focus halo filter color |
| `sideLabel` | `object` | `{ x, y, label, sublabel, color, anchor }` — placed to the side |
| `zoneIndicator` | `string` | `'left'` or `'right'` — shows WAN/LAN zone labels |
| `zoneLabel` | `object` | `{ text, color }` — dashed zone rectangle below the node |
| `zoneLabelOffset` | `number` | Vertical offset for zone label (default: 22) |

### Node Types

| Type | Visual | Typical Use |
|------|--------|-------------|
| `ec` | EdgeConnect appliance — rounded rect with triangle logo, LED indicators | SD-WAN gateways, branch routers |
| `switch` | Network switch — rect with 8 port indicators | L2/L3 switches |
| `switchEnterprise` | Enterprise switch — larger rect with more ports | Data center switches |
| `cloud` | Cloud — double ellipse with inner puffs | Cloud services, SaaS platforms, internet |
| `host` | Laptop/device — screen + keyboard | End-user devices, workstations |
| `connector` | ZTNA connector — rect with hub-spoke graphic | ZTNA connectors, PEP |
| `apps` | Private apps rack — tall rect with 3 shelves + LEDs | Application servers, private app groups |
| `saas` | SaaS cloud — ellipse with 4 colored app squares | SaaS applications |
| `server` | Server rack — square with 2 shelf units | Servers, compute |
| `router` | Router — circle with 4-directional arrows | Core/edge routers |
| `firewall` | Firewall — rect with brick wall pattern | Firewalls, security appliances |
| `database` | Database — cylinder with dashed ring | Databases, storage |
| `idcard` | Identity badge — card with user/host/role fields | Identity/auth cards |
| `ap` | Access point — rect with antenna + signal arcs | Wireless access points |
| `overlayCloud` | Spanning overlay — dashed ellipse encompassing nodes | Overlay networks, fabric |
| `text` | Plain text label | Text annotations, titles, descriptions |
| `custom` | User-provided render function | Anything else |

### Type-Specific Properties

**Cloud** (`type: 'cloud'`):
- `sub1`: First subtitle line (e.g., `'SWG · ZTNA · CASB'`)
- `sub2`: Second subtitle line
- `innerClouds`: `'both'` | `'left'` | `'right'` | `'none'`

**Host** (`type: 'host'`):
- `managed`: `boolean` — Show green border + shield badge
- `agent`: `boolean` — Show agent hub icon
- `agentColor`: `string` — Override agent icon color (default: `'#65aef9'`)

**Connector** (`type: 'connector'`):
- `pe`: `boolean` — Private Edge variant (green, thicker border + badge)

**IdCard** (`type: 'idcard'`):
- `mode`: `'id'` (gold) | `'auth'` (green)
- `user`, `host`, `role`: Card field strings

**OverlayCloud** (`type: 'overlayCloud'`):
- `spans`: `string[]` — Node IDs to encompass
- `padding`: `number` — Extra padding (default: 90)

## Link Registration

```javascript
topo.link(id, config)
```

### Required Properties
| Property | Type | Description |
|----------|------|-------------|
| `type` | `string` | Link type (see below) |
| `from` | `string` | Source node ID or anchor ID |
| `to` | `string` | Destination node ID or anchor ID |

### Optional Properties
| Property | Type | Description |
|----------|------|-------------|
| `color` | `string` | Line/tunnel color |
| `label` | `string` | Text label on the link |
| `sublabel` | `string` | Secondary label (packet type only) |
| `dashed` | `boolean` | Dashed line style (line type only) |
| `dots` | `boolean` | Show animated particles (default: true for tunnels/flows) |
| `path` | `string` | Custom SVG path string (flow type) |
| `labelPos` | `object` | `{ x, y }` for label placement (flow type) |
| `fromLabel` | `string` | Port label near source (e.g., `'ge0/1'`) |
| `toLabel` | `string` | Port label near destination (e.g., `'eth0'`) |
| `reason` | `string` | Reason text (blocked type only) |
| `opacity` | `number` | Override opacity |

### Link Types

| Type | Visual | When to Use |
|------|--------|-------------|
| `line` | Simple straight line with draw animation | Physical connections, basic links |
| `tunnel` | Thick glow + dashed overlay + optional particles | IPsec tunnels, encrypted connections |
| `wireguard` | Blue dashed line + bloom-filtered particle | WireGuard tunnels |
| `flow` | Custom SVG path with draw animation + particles | Curved overlay paths, data flows |
| `packet` | Large animated particle with dashed trail + badge | Packet flows, protocol exchanges |
| `blocked` | Red X mark with pulsing glow + "BLOCKED" badge | Blocked/denied connections |
| `wifi` | 3D tube with signal wave arcs at midpoint | Wireless links |
| `poe` | Solid line with lightning bolt icon at midpoint | Power over Ethernet connections |
| `optical` | Thin bright line with laser warning triangle at midpoint | Fiber optic links |

### Flow Paths

For curved links, use `type: 'flow'` with a custom SVG path:

```javascript
topo.link('overlay', {
  type: 'flow', from: 'SEA', to: 'LAX',
  color: '#01a982',
  label: 'SD-WAN Overlay',
  path: 'M280,274 C430,220 620,220 770,274',  // Cubic Bezier curve
  labelPos: { x: 525, y: 234 },
  dots: true,
});
```

The `path` uses standard SVG path syntax. For arcs between two nodes at similar Y positions, use:
`M{fromX},{fromY} C{fromX+dx},{fromY-lift} {toX-dx},{toY-lift} {toX},{toY}`

## Anchor Registration

Anchors are invisible position markers for precise link endpoint placement.

```javascript
topo.anchor(id, { x, y })
```

Use anchors when:
- Tunnel endpoints should attach to a specific spot on a node's edge
- You need link waypoints for complex routing
- Links should not connect to a node's center point

## Acts, Steps & Phases — The Choreography System

This three-level hierarchy controls the **narrative sequence**. Elements are revealed through cinematic, step-by-step choreography.

### Hierarchy

```
Topology
└── Act (thematic group — presentation section)
    └── Step (narrative unit — one click/advance)
        └── Phase (sub-animation within a step — timed reveal)
```

### Acts

```javascript
topo.act(id, {
  label: 'Act 1 · Infrastructure',
  color: '#01a982',
  intro: ['Baseline topology and cloud security services.'],
});
```

Acts are thematic groups. They organize the sidebar and provide intro cards in the narrator. Properties:
- `label`: Displayed in sidebar headers
- `color`: Accent color for this act section
- `intro`: Array of intro text lines shown when entering this act

### Steps

```javascript
topo.addStep(id, {
  act: 'a1',
  name: 'The Network',
  goal: 'Branch + DC + Internet + encrypted overlay.',
  focus: ['SEA', 'LAX'],
  phases: [ ... ],
});
```

Steps are the primary navigation unit. Each "Next" click advances one step.

| Property | Type | Description |
|----------|------|-------------|
| `act` | `string` | Parent act ID |
| `name` | `string` | Step display name |
| `goal` | `string` | Description shown in narrator |
| `focus` | `string[]` | Element IDs to spotlight. `[]` = everything at full brightness |
| `phases` | `object[]` | Timed element reveal sequence |

### Phases

```javascript
phases: [
  { show: ['SEA'],              diff: 'Seattle EC appears' },          // delay: 0ms
  { show: ['INET', 'sea-inet'], diff: 'Internet + uplink' },          // delay: 600ms
  { show: ['LAX', 'lax-inet'],  diff: 'Los Angeles EC' },             // delay: 1200ms
  { show: ['overlay'],          diff: 'SD-WAN overlay draws' },       // delay: 1800ms
]
```

| Property | Type | Description |
|----------|------|-------------|
| `show` | `string[]` | Element IDs (nodes/links) to reveal in this phase |
| `diff` | `string` | Narrative text in the narrator's "Changed" bullets |

### Critical Rules

1. **Each element appears in exactly one phase's `show[]` array** — it persists automatically in all subsequent steps.
2. **Once shown, elements remain visible** — going back hides them again.
3. **`focus: []`** means everything is at full brightness. **`focus: ['A', 'B']`** means A and B are bright, everything else dims to 35% opacity + blur.
4. **Links auto-compute opacity** from both endpoints: a link is only bright if both its source and destination are focused.
5. **Phases play with staggered delays** — phase N plays at `N * phaseMs` milliseconds.
6. **Empty `show: []` phases** are valid — useful with `onRender` hooks for custom animations.

## Persistent Visibility

For elements that should be visible across a range of steps (not tied to a single phase):

```javascript
topo.showDuring(['dashed-line', 'badge'], { from: 'identity', until: 'agent' });
```

Elements listed will be visible from step `from` through step `until` (inclusive). Useful for temporary annotations, highlight lines, or callout badges spanning multiple steps.

## Path Helpers

Generate SVG paths programmatically for flow links or custom render hooks:

```javascript
// Straight-line path through multiple nodes/anchors
const path = topo.pathThrough('HOST', 'SSW', 'SEA', 'NAC');

// Curved path between two elements (bulge controls curvature)
const arc = topo.pathBetween('SEA', 'LAX', { bulge: -60 });
```

These are also available in render context as `ctx.pathThrough()` and `ctx.pathBetween()`.

## Glossary

```javascript
topo.glossary([
  { t: 'SSE', d: 'Security Service Edge: cloud-delivered security.' },
  { t: 'ZTNA', d: 'Zero Trust Network Access: per-app access control.' },
]);
```

## Color Palette

Use these standard colors for consistency with the design system:

| Color | Hex | Usage |
|-------|-----|-------|
| Green | `#01a982` | Primary accent — EC nodes, SD-WAN, success |
| Green OK | `#05cc93` | Authenticated, verified |
| Blue | `#65aef9` | WireGuard, tunnels, SSE |
| Purple | `#7764fc` | NAC, identity services |
| Gold | `#deb146` | Apps, database, private apps |
| Red | `#fc6161` | Blocked, firewall, denied |
| Orange | `#ec8c25` | Warnings |
| Teal | `#00a4b3` | Switches |
| PE Green | `#068667` | Private Edge |
| Coral | `#d25f4b` | SaaS, internet |
| Gray | `#b1b9be` | Neutral — internet cloud, generic |

## Layout Guidelines

The default viewBox is `0 0 1050 700`. Follow these spatial conventions:

- **Center X**: ~525 for symmetric layouts
- **Cloud services**: Top area (y: 30–100)
- **Core network devices** (ECs, routers): Middle band (y: 200–300)
- **Access layer** (switches): Below core (y: 350–420)
- **Endpoints** (hosts, apps): Bottom (y: 450–600)
- **Minimum spacing**: ~120px between nodes horizontally, ~100px vertically
- **Anchors**: Place 8–20px from node edges for tunnel endpoints
- **Flow path arcs**: Lift control points 40–80px above endpoints for visible curves

## Choreography Best Practices

1. **Start with infrastructure** — Deploy core network elements first (routers, internet, WAN).
2. **Layer in services** — Add cloud platforms, security services, identity providers.
3. **Add endpoints last** — Users, hosts, applications, and their access links.
4. **Use focus to tell a story** — Each step spotlights the elements being discussed while dimming the rest.
5. **2–5 phases per step** — Enough detail without overwhelming. Each phase should reveal a logically grouped set (e.g., a node + its connecting link).
6. **Group related elements in the same phase** — A node and its connecting link should appear together.
7. **Use acts for major sections** — 3–6 acts for a typical presentation. Each act represents a conceptual shift.
8. **Write meaningful `diff` text** — These appear in the narrator and should describe what changed and why.
9. **Write concise `goal` text** — One sentence describing the step's purpose.
10. **Keep `focus` arrays tight** — Only spotlight elements actively being discussed.

## Custom Render Hooks (Advanced)

For complex animations beyond show/hide, use `onRender`:

```javascript
topo.addStep('identity', {
  act: 'a3',
  name: 'Network Gate',
  focus: ['HOST', 'SSW', 'SEA', 'NAC'],
  phases: [
    { show: [], diff: 'RADIUS Request flows' },
    { show: [], diff: 'NAC verifies identity' },
    { show: [], diff: 'Access-Accept returns' },
  ],
  onRender: (ctx) => {
    let svg = '';
    const HOST = ctx.pos('HOST'), NAC = ctx.pos('NAC');

    // Render animated flow in phase 0
    svg += ctx.renderFlow('identity', 0,
      `M${HOST.x},${HOST.y} L${NAC.x},${NAC.y}`,
      '#deb146', 'RADIUS Request', 400, 200, ctx.dim('HOST'));

    return svg;
  },
});
```

### Render Context (ctx) Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `ctx.pos(id)` | `{ x, y }` | Get position of a node or anchor |
| `ctx.vis(stepId)` | `boolean` | Has this step been reached? |
| `ctx.dim(id)` | `number` | Opacity for element (1.0 if focused, 0.35 if not) |
| `ctx.dimAll(...ids)` | `number` | Minimum opacity across multiple elements |
| `ctx.pathThrough(...ids)` | `string` | SVG path through sequence of node/anchor positions |
| `ctx.pathBetween(fromId, toId, opts?)` | `string` | Cubic bezier path between two elements |
| `ctx.ph(stepId, phaseNum)` | `{ show, anim, delay }` | Phase visibility state |
| `ctx.pw(stepId, phaseNum, opacity, svgString)` | `string` | Wrap SVG in phase-aware group |
| `ctx.renderFlow(stepId, phase, path, color, label, lx, ly, opacity, dots)` | `string` | Animated flow path |
| `ctx.renderLine(stepId, phase, x1, y1, x2, y2, color, opacity, dashed)` | `string` | Simple line |
| `ctx.renderTunnel(stepId, phase, x1, y1, x2, y2, color, label, opacity, dots)` | `string` | Tunnel |
| `ctx.renderWG(stepId, phase, x1, y1, x2, y2, label, opacity, dots)` | `string` | WireGuard tunnel |
| `ctx.renderBlocked(stepId, phase, x1, y1, x2, y2, reason)` | `string` | Blocked indicator |
| `ctx.renderCallout(stepId, phase, x, y, w, h, lines, borderColor, opacity)` | `string` | Callout badge |
| `ctx.renderNode(type, x, y, cfg)` | `string` | Render a node by type |

### Callout Lines Format

```javascript
ctx.renderCallout('myStep', 0, 100, 200, 180, 40, [
  { text: 'Header', color: '#01a982', size: '10', weight: '700' },
  { text: 'Detail', color: '#b1b9be', size: '8', weight: '400' },
], '#01a982', 1);
```

## Complete Example

```javascript
const topo = new TopologyDesigner({
  title: 'Data Center Network',
  subtitle: 'Core · Distribution · Access',
  viewBox: '0 0 900 600',
  phaseMs: 500,
});

// ── Nodes ──
topo.node('CORE1', { type: 'router', x: 350, y: 100, label: 'Core-1', color: '#01a982' });
topo.node('CORE2', { type: 'router', x: 550, y: 100, label: 'Core-2', color: '#01a982' });
topo.node('FW1', { type: 'firewall', x: 250, y: 250, label: 'Firewall' });
topo.node('SW1', { type: 'switch', x: 450, y: 250 });
topo.node('SW2', { type: 'switch', x: 650, y: 250 });
topo.node('SRV1', { type: 'server', x: 350, y: 400, label: 'App Server', color: '#01a982' });
topo.node('DB1', { type: 'database', x: 550, y: 400, label: 'Database' });
topo.node('HOST1', { type: 'host', x: 150, y: 400, label: 'Admin' });
topo.node('INET', { type: 'cloud', x: 450, y: 30, label: 'Internet', color: '#b1b9be' });

// ── Links ──
topo.link('inet-core1', { type: 'line', from: 'INET', to: 'CORE1', color: '#b1b9be' });
topo.link('inet-core2', { type: 'line', from: 'INET', to: 'CORE2', color: '#b1b9be' });
topo.link('core-core', { type: 'tunnel', from: 'CORE1', to: 'CORE2', color: '#01a982', label: 'iBGP', dots: true });
topo.link('core1-fw', { type: 'line', from: 'CORE1', to: 'FW1', color: '#fc6161' });
topo.link('core1-sw1', { type: 'line', from: 'CORE1', to: 'SW1', color: '#01a982' });
topo.link('core2-sw2', { type: 'line', from: 'CORE2', to: 'SW2', color: '#01a982' });
topo.link('sw1-srv', { type: 'line', from: 'SW1', to: 'SRV1', color: '#01a982' });
topo.link('sw2-db', { type: 'line', from: 'SW2', to: 'DB1', color: '#deb146' });
topo.link('fw-host', { type: 'line', from: 'FW1', to: 'HOST1', color: '#fc6161' });

// ── Acts ──
topo.act('a1', { label: 'Act 1 · Core', color: '#01a982', intro: ['The backbone of the data center.'] });
topo.act('a2', { label: 'Act 2 · Services', color: '#deb146', intro: ['Application and data tiers.'] });
topo.act('a3', { label: 'Act 3 · Access', color: '#fc6161', intro: ['Security and user access.'] });

// ── Steps ──
topo.addStep('core', {
  act: 'a1', name: 'Core Routers', goal: 'Deploy redundant core routing.',
  focus: ['CORE1', 'CORE2'],
  phases: [
    { show: ['INET'], diff: 'Internet cloud' },
    { show: ['CORE1', 'inet-core1'], diff: 'Core-1 with uplink' },
    { show: ['CORE2', 'inet-core2'], diff: 'Core-2 with uplink' },
    { show: ['core-core'], diff: 'iBGP peering tunnel' },
  ],
});

topo.addStep('distro', {
  act: 'a2', name: 'Distribution Layer', goal: 'Switches connect core to services.',
  focus: ['SW1', 'SW2', 'SRV1', 'DB1'],
  phases: [
    { show: ['SW1', 'core1-sw1'], diff: 'Switch 1 connects to Core-1' },
    { show: ['SW2', 'core2-sw2'], diff: 'Switch 2 connects to Core-2' },
    { show: ['SRV1', 'sw1-srv'], diff: 'App server behind Switch 1' },
    { show: ['DB1', 'sw2-db'], diff: 'Database behind Switch 2' },
  ],
});

topo.addStep('security', {
  act: 'a3', name: 'Firewall & Access', goal: 'Secure admin access through firewall.',
  focus: ['FW1', 'HOST1'],
  phases: [
    { show: ['FW1', 'core1-fw'], diff: 'Firewall deployed' },
    { show: ['HOST1', 'fw-host'], diff: 'Admin workstation via firewall' },
  ],
});

// ── Glossary ──
topo.glossary([
  { t: 'iBGP', d: 'Internal BGP: routing protocol between core routers in the same AS.' },
  { t: 'Distribution', d: 'Network layer providing policy-based connectivity between access and core.' },
]);

topo.mount('app');
```

## Validation Checklist

Before delivering topology code, verify:

- [ ] Every element in a `show[]` array has a corresponding `node()`, `link()`, or `anchor()` registration
- [ ] Every element ID appears in exactly one phase's `show[]` across all steps
- [ ] Every `link.from` and `link.to` references a registered node or anchor ID
- [ ] Every `step.act` references a registered act ID
- [ ] `focus` arrays only contain IDs of elements that are already visible at that step
- [ ] Node positions don't overlap (minimum ~80px apart)
- [ ] Anchor positions are within ~20px of the associated node's edge
- [ ] Flow paths use valid SVG path syntax (`M`, `C`, `L`, `Q` commands)
- [ ] Colors use hex strings from the standard palette when possible
- [ ] The file is saved in the `design-system/` directory
