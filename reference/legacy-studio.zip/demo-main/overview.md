# Topology Design System — Overview

A cinematic network topology visualization engine with step-by-step choreography. Built with pure vanilla JavaScript, SVG, and CSS — no build tools, no runtime dependencies.

~6600 lines of core engine code. 2278 automated tests across 55 files (Vitest) plus 15 Playwright end-to-end spec files. A Node/Express REST API wraps the engine for headless automation. Zero runtime browser dependencies.

## What It Is

Topology Design System is an interactive presentation engine for network architecture diagrams. It renders animated SVG topologies with a choreographed narrative — users advance through steps that progressively reveal nodes, links, and annotations, turning a static diagram into a guided walkthrough.

It is designed for:

- Network architecture presentations (SD-WAN, ZTNA, security services)
- Educational topology walkthroughs with narrative flow
- Interactive technical demos and proof-of-concept showcases
- Architecture documentation that tells a story
- Enterprise template-based topology creation (SD-WAN, ZTNA, campus, data center, cloud, starter)

## Core Concepts

The system is organized around a three-level hierarchy:

```
Topology
├── Act        — thematic group of steps (e.g. "Infrastructure", "Endpoints")
│   └── Step   — a single narrative unit, advanced by one click
│       └── Phase — a timed sub-animation within a step (staggered reveal)
```

- **Nodes** represent network devices — appliances, switches, clouds, hosts, firewalls, routers, databases, and more.
- **Links** represent connections between nodes — lines, tunnels, WireGuard links, data flows, packet bursts, blocked indicators, and Wi-Fi.
- **Anchors** are invisible position markers that give links precise start/end points beyond node centers.
- **Focus** is a spotlight system: focused elements stay bright while everything else dims and blurs, directing the viewer's attention.

## Node Types

18+ built-in node types cover a wide range of network diagrams:

| Type | Description |
|------|-------------|
| `ec` | EdgeConnect appliance with LED indicators and variant support (generic, virtual, physical, aws, azure, gcp, oracle) |
| `switch` | Network switch with port indicators |
| `switchEnterprise` | Enterprise-class switch with configurable copper (RJ45) and fiber (SFP) ports, status LEDs, and console port |
| `cloud` | Cloud service (double ellipse with puffs) |
| `host` | Laptop/endpoint device |
| `connector` | Hub-spoke ZTNA connector |
| `apps` | Private application rack |
| `saas` | SaaS destination (ellipse with app icons) |
| `server` | Backend server rack |
| `router` | Router with directional arrows |
| `firewall` | Brick-wall firewall |
| `database` | Cylinder storage |
| `idcard` | Identity badge card |
| `ap` | Wi-Fi access point with signal arcs |
| `overlayCloud` | Dashed ellipse spanning multiple nodes |
| `text` | Freeform text label/annotation with configurable font size, weight, and multi-line sublabel support |
| `shape*` | Geometric shapes (arrow, square, rectangle, triangle, circle, ellipse, diamond, pentagon, hexagon, star, cross) with configurable size, dimensions, direction, and color |
| `custom` | User-provided render function |

Nodes support labels, sublabels, side labels, zone indicators, halo colors, z-order layering, VRRP active/standby indicators (EC type), and visual variants (e.g. managed hosts with shield icons, private-edge connectors with badges, cloud-provider EC variants).

## Link Types

9 link types with distinct visual styles and animations:

| Type | Visual | Use Case |
|------|--------|----------|
| `line` | Straight stroke | Basic connections |
| `tunnel` | Thick glow + dashes + animated particles | IPsec / encrypted tunnels |
| `wireguard` | Dashed blue with animated particle | WireGuard connections |
| `flow` | Custom SVG path with glow + particles | Data flows, SD-WAN overlays |
| `packet` | Large directional particle + dashed trail | RADIUS / control traffic |
| `blocked` | Red X at midpoint with pulsing glow | Denial indicators |
| `wifi` | 3D tube + perpendicular signal arcs + wifi icon | Wireless links |
| `poe` | Line with lightning bolt icon at midpoint | Power over Ethernet |
| `optical` | Line with laser warning triangle icon | Fiber optic connections |

Links support port labels, sublabels, custom opacity, bidirectional animated particles, z-order layering, 8 dash style presets (solid, dashed, dotted, long dash, dash-dot, dash-dot-dot, dense, sparse), label offset positioning, animate flow option for lines, and smart auto-routing around obstructing nodes.

## Choreography & Animation

### Acts, Steps, and Phases

- **Acts** group related steps under a theme (e.g. "Act 1 - Infrastructure") with optional intro text.
- **Steps** are the narrative units. Each step declares which elements to `show`, an optional `focus` list, and descriptive metadata (`name`, `goal`).
- **Phases** are timed sub-animations within a step. Each phase reveals additional elements with a configurable stagger delay (default 600ms between phases).

### Animation Effects

- **Stroke-dashoffset drawing** — links animate a "drawing" effect over 0.7s.
- **Phase-in fading** — elements fade in over 0.55s with per-phase stagger delays.
- **Animated particles** — SVG `<animateMotion>` dots travel along links (2–3s loops).
- **Ambient light leaks** — three radial gradient layers (green, purple, blue) pulse slowly behind the canvas.
- **Focus spotlight** — unfocused elements drop to 35% opacity with a depth-of-field blur; focused elements gain a colored halo.
- **Glow-depth lift** — focused nodes physically "lift" off the canvas with drop shadows and colored bloom via advanced SVG filter chains.
- **Choreography smoothing** — `setNodePositions()` enables position keyframes across steps with cubic ease-in-out interpolation.
- **Ambient atmosphere** — three optional background effects: scanning grid lines, floating data bits, and pulse ring radar (all motion-safe).

### Playback Modes

| Mode | Behavior |
|------|----------|
| Manual | Click to advance one step at a time |
| Auto | Continuous playback at a configurable speed (2–7s per step) |
| Presenter | Auto-play that pauses at act boundaries for section breaks |
| Presentation | Fullscreen cinematic mode with auto-advance, presenter notes, keyboard navigation (Escape to exit), and act-boundary pauses |

### Declarative Phase Properties

Phases support declarative shorthand for common visual elements without writing custom render functions:

- **`flow`** — Animated flow path with `{ path|through, color, label, labelPos, dots, dimIds, hideAfter }`
- **`label`** — Text label at a node position with `{ at, text, color, size, weight, opacity, offsetX, offsetY, anchor }`
- **`badge`** — Rectangular badge at a node with `{ at, text, color, width, height, offsetX, offsetY, border, rx, textOffsetY }`
- **`callout`** — Multi-line callout box with `{ x, y, w, h, lines: [{text, color, size, weight}], border, dimIds, opacity }`
- **`blocked`** — Blocked indicator with `{ from, to, fromOffset, toOffset, reason }`
- **`rerender`** — Re-render a node with new config mid-choreography with `{ node, type, x, y, cfg, label, sublabel, hideAfter }`
- **`delayMs`** — Per-phase timing override in milliseconds

### Custom Render Hooks

Steps can include `onRender` callbacks and phases can include `custom` functions that generate arbitrary SVG, enabling complex visuals like RADIUS request flows, animated tunnels, or callout badges that go beyond the built-in primitives.

### Persistent Visibility

The `showDuring()` API makes elements visible across a range of steps:

```javascript
topo.showDuring(['dashed-line', 'badge'], { from: 'step1', until: 'step5' });
```

## Core Engine

### SVG Diffing (Incremental Rendering)

The engine uses a virtual-DOM-lite approach: on each phase transition, it computes dirty elements and performs incremental updates rather than re-rendering the entire SVG. This improves performance on large topologies with many nodes and links.

### Plugin System

Node and link types use a formal plugin interface with `registerNodeType()` and `registerLinkType()`. Plugins can declare defaults, hit boxes, validation rules, metadata, and lifecycle hooks (init, render, destroy).

### Lifecycle Hooks

The engine exposes three lifecycle hooks for observing render and navigation events:

```javascript
topo.on('beforeRender', (ctx) => { /* before SVG render */ });
topo.on('afterRender', (ctx) => { /* after SVG render */ });
topo.on('onStepChange', ({ prevStep, step, designer }) => { /* step changed */ });
```

### Type Registry

Query registered node and link types at runtime:

```javascript
TopologyDesigner.getRegisteredNodeTypes();  // ['ec', 'switch', 'cloud', ...]
TopologyDesigner.getRegisteredLinkTypes();  // ['line', 'tunnel', 'wireguard', ...]
```

### Smart Link Routing

Links automatically detect obstructing nodes via AABB collision detection and route around them using quadratic Bezier curve detours, preventing overlapping visuals in dense topologies.

## API

All registration methods return `this` for chaining:

```javascript
const topo = new TopologyDesigner({
  title: 'My Topology',
  subtitle: 'Overview',
  viewBox: '0 0 1050 700',
  phaseMs: 600,
  mode: 'manual',
});

topo
  .node('SEA', { type: 'ec', x: 280, y: 280, label: 'Seattle' })
  .node('LAX', { type: 'ec', x: 770, y: 280, label: 'Los Angeles' })
  .anchor('seaPort', { x: 320, y: 280 })
  .link('overlay', { type: 'tunnel', from: 'seaPort', to: 'LAX', color: '#01a982' })
  .act('a1', { label: 'Act 1 · Network' })
  .addStep('network', {
    act: 'a1',
    name: 'The Network',
    goal: 'Branch offices connected via encrypted overlay.',
    focus: [],
    phases: [
      { show: ['SEA'], diff: 'Seattle branch' },
      { show: ['LAX', 'overlay'], diff: 'LA branch + SD-WAN overlay' },
    ],
  })
  .glossary([
    { t: 'SD-WAN', d: 'Software-Defined WAN: centralized overlay networking.' },
  ])
  .mount('container');
```

### Playback Control

```javascript
topo.play();      // start auto-play
topo.pause();     // stop
topo.next();      // advance one step
topo.prev();      // go back one step
topo.reset();     // return to step 0
topo.goTo(5);     // jump to step 5
topo.render();    // force re-render
```

### Persistent Visibility & Choreography

```javascript
topo.showDuring(['elem1', 'elem2'], { from: 'step1', until: 'step5' }); // visible across step range
topo.setNodePositions('R1', { 2: { x: 300, y: 200 }, 5: { x: 500, y: 200 } }); // position keyframes
```

### Flow Paths, Policy Markers & Layers

```javascript
topo.layer('flow_1', { name: 'Traffic', type: 'flow', visible: true, opacity: 0.8 });
topo.flowPath('fp_1', { waypoints: ['USER', 'SW', 'FW'], color: '#01a982', animation: 'particles' });
topo.policyMarker('pm_1', { nodeId: 'FW', type: 'inspect', color: '#deb146', layer: 'policy_1' });
topo.setLayers(layers);           // replace all layers
topo.setFlowPaths(entries);       // replace all flow paths
topo.setPolicyMarkers(entries);   // replace all policy markers
```

### Serialization & Import

```javascript
topo.toJSON();              // export full state
topo.fromJSON(data);        // import state
topo.importFromText(str);   // import from Mermaid-esque diagram-as-code text
topo.loadTemplate(name);    // load a built-in template (hub-spoke, 3-tier, mesh, etc.)
topo.applyTheme(name);      // apply a color theme at runtime
topo.autoLayout(algorithm); // auto-layout nodes (force-directed, hierarchical, circular, grid, magnetic north)
```

## Visual Editor

The included editor (`design-system/editor.html`) provides a full-featured GUI for building topologies:

### Core Editing
- **Node palette** — select from 18+ node types (including shapes) and drop onto a grid-snapped canvas.
- **Link creation** — select source and destination nodes, choose from 9 link types.
- **Properties panel** — edit node/link attributes, reposition anchors, configure variants, delete elements, and lock/unlock individual items.
- **Anchor placement** — double-click to add invisible position markers with optional labels and offsets.
- **Undo/Redo** — unlimited history with click-and-hold popover for multi-step undo/redo.
- **Arrow key movement** — move selected nodes/anchors 1px (or 10px with Shift) with alignment guide display. Locked elements are skipped.

### Canvas Interaction
- **Hand mode** — left-click-hold (300ms) on empty canvas activates pan mode; double-click returns to select.
- **Multi-select delete** — Shift+click or marquee select, then Delete/Backspace removes every item (including cascaded links, zones, markers, flow paths, anchors) in a single undo entry.
- **Batch operations** — Shift+click multi-select with align H/V, distribute H/V, **group into zone**, **ungroup**, and **lock/unlock**.
- **Group / Ungroup** — wrap a selection in an overlayCloud zone (`Ctrl+G`) or remove the enclosing wrapper (`Ctrl+Shift+G`).
- **Lock / Unlock** — freeze individual elements against drag and arrow-key moves (`Ctrl+L`).
- **Copy/Paste Format** — right-click context menu or Ctrl+Shift+C/V to copy visual properties between elements.
- **Z-order layering** — context menu and keyboard shortcuts (`]`/`[`/`Ctrl+]`/`Ctrl+[`) for stacking order.
- **Tablet touch support** — single-finger drag, two-finger pinch-to-zoom with pan.

### Layer Panel
- **Rename** — double-click a layer name to edit it in place.
- **Recolor** — click the color swatch to pick from preset colors or enter a custom hex value.
- **Visibility toggle** — per-layer eye icon and per-step `layerVisibility` overrides on steps.
- **Lock** — padlock icon freezes all elements on the layer.

### Choreography & Timeline
- **Timeline UI** — video-editor-style visual representation of acts/steps/phases with drag-to-reorder.
- **Choreography panel** — collapsible bottom panel for defining acts, steps, and phases.
- **Double-click inline editing** — edit link labels directly on canvas.

### Export & Import
- **Export PNG** — rasterized topology screenshot.
- **Export SVG** — vector export with full topology content.
- **Export PDF** — print-ready PDF generation.
- **Export Standalone HTML** — self-contained single-file HTML with embedded CSS/JS that opens independently and replays choreography.
- **Copy Embed Code** — iframe snippet for embedding a live viewer.
- **Export animated GIF** — real choreography frames with median-cut palette, Floyd-Steinberg dithering, and per-frame timing.
- **Diagram-as-Code** — import and export topologies as Mermaid-esque text format.
- **draw.io Import** — import draw.io XML diagrams with node/link mapping.
- **Template Gallery** — visual card-based browser for enterprise templates (SD-WAN, ZTNA, campus, data center, cloud, starter, plus hub-spoke, 3-tier, mesh, star, spine-leaf, firewall-dmz).
- **File System Access API** — live sync to disk with auto-save every 2s and visual sync status.
- **Live preview** — side-by-side HTML preview of the exported topology.
- **REST import/export** — the companion Node/Express server exposes `POST /api/topologies/import` and `GET /api/topologies/{id}/export` for headless CI pipelines.

### Toolbar Organization
- Grouped dropdown menus: Core tools, Insert, View, Select, File.
- Theme selector with color swatch previews.
- Auto-Layout modal with algorithm selection.

## UI & Layout

### Desktop (>980px)

The interface features a sidebar listing acts and steps, a central SVG canvas, a narrator panel showing the current step's name/goal/changes, and a toolbar with mode/speed/playback controls.

### Mobile (<=980px)

The layout stacks vertically — sidebar on top, canvas in the middle, narrator below — with enlarged touch targets.

### Glassmorphism Theme

The UI uses a dark theme with glassmorphism effects: backdrop blur, saturation boost, subtle borders, and inset glow highlights. Color tokens include green, blue, purple, gold, red, orange, teal, coral, and private-edge green.

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `Arrow Right` / `Arrow Left` | Next / Previous step |
| `Home` / `End` | First / Last step |
| `G` | Open glossary |
| `N` | Toggle narrator panel |
| `I` | Toggle node/anchor ID labels |
| `T` | Insert text label (editor) |
| `]` / `[` | Bring forward / Send backward (editor) |
| `Ctrl+]` / `Ctrl+[` | Bring to front / Send to back (editor) |
| `Ctrl+Shift+C` / `Ctrl+Shift+V` | Copy / Paste format (editor) |
| `Arrow Keys` | Move selected element 1px (editor) |
| `Shift+Arrow Keys` | Move selected element 10px (editor) |

## Theme Engine

Dark and light mode with automatic OS preference detection, persistent local storage settings, and support for built-in presets plus custom palette generation. All UI elements, exports, and the viewer respect the active theme.

## Zone Annotations

Rectangular zone regions that visually group related nodes. Zones support:
- Custom labels, colors, and opacity
- Step-awareness (show/hide per step via choreography)
- Group-into-zone from multi-select

## Link Waypoints & Orthogonal Routing

Links support intermediate waypoints for precise path control. Orthogonal routing creates clean right-angle connections. Waypoints are draggable in the editor for fine-tuning.

## Layout Edit Mode

Interactive node repositioning with real-time coordinate readback. Displays X/Y positions for precision placement and alignment. Supports arrow-key movement (1px or 10px with Shift) with alignment guides.

## Mobile Safari Compatibility

Full compatibility with Mobile Safari / iPhone WebKit. Touch targets are enlarged, pinch-to-zoom works, and all key demo pages render correctly on iOS.

## Additional Features

- **Glossary modal** — define and display terminology in a searchable overlay.
- **URL state persistence** — current step and mode are saved to the query string for shareable, bookmarkable links.
- **Reduced motion support** — respects `prefers-reduced-motion`: disables particles, immediate reveals, no auto-play.
- **Accessibility** — supports full keyboard navigation, uses semantic HTML and ARIA attributes, and is designed for screen reader compatibility.
- **3D perspective effects** — sidebar tilt on hover, canvas depth via CSS perspective.
- **Custom node registration** — `TopologyDesigner.registerNodeType(name, plugin)` for adding new node shapes with render functions, defaults, hit boxes, validation, and lifecycle hooks.
- **Custom link registration** — `TopologyDesigner.registerLinkType(name, plugin)` for adding new link types with full plugin interfaces.
- **Lifecycle hooks** — `topo.on('beforeRender'|'afterRender'|'onStepChange', callback)` for observing engine events.
- **Type registry** — `TopologyDesigner.getRegisteredNodeTypes()` and `getRegisteredLinkTypes()` for runtime type queries.
- **Declarative phase properties** — `flow`, `label`, `badge`, `callout`, `blocked`, `rerender` for common visuals without custom render functions.
- **Per-phase timing** — `phase.delayMs` overrides the default stagger delay per individual phase.
- **Persistent visibility** — `showDuring(elementIds, { from, until })` makes elements visible across a range of steps.
- **Theme engine** — 5 color presets, palette generation from brand colors, WCAG contrast checking, and runtime theme switching.
- **Layout engine** — 8 auto-layout algorithms (force-directed, hierarchical, circular, grid, magnetic north, network, spine-leaf, cluster) with animated transitions and overlap removal.
- **Template system** — 13 built-in templates for common network topologies (hub-spoke, 3-tier, mesh, star, spine-leaf, SD-WAN, firewall-DMZ, ZTNA, campus, data center, cloud migration, simple), plus a diagram-as-code workflow with Mermaid-like text syntax.
- **EC variants** — EdgeConnect nodes support cloud-provider variants (aws, azure, gcp, oracle) with distinct visual styles and iconography.
- **VRRP indicators** — active/standby status on EC green status LEDs.
- **Dash style presets** — 8 dash patterns for links (solid, dashed, dotted, long dash, dash-dot, dash-dot-dot, dense, sparse).
- **Flow paths** — Animated overlay paths that follow waypoints through the topology, with configurable animation (particles, dashed, pulse), speed, direction (forward, reverse, bidirectional), and layer assignment.
- **Policy markers** — Badges on nodes showing policy actions (inspect, allow, deny, redirect, encrypt, decrypt, nat, load-balance, log) with color and layer support.
- **Layer system** — Visual planes (physical, flow, policy) that group elements for independent visibility, opacity, and locking control. Supports per-step layer visibility overrides via `layerVisibility` on steps.
- **Network layout** — WAN/LAN-aware auto-layout algorithm that classifies nodes into cloud, WAN, and LAN tiers based on type and arranges them in a semantically meaningful hierarchy.
- **Responsive design** — adapts to mobile viewports at a 980px breakpoint while preserving core interactive features.
- **Engagement analytics** — tracks completion rate and dwell time by step, with a glassmorphism-style analytics dashboard.
- **Graph data model** — `TopologyGraph` (`core/graph.js`) provides adjacency queries, shortest path, connected components, articulation points, bridges, blast radius analysis, and subgraph extraction.
- **AI-assisted topology generation** — Cloudflare Workers AI endpoint (`functions/api/ai-assist.js`) generates topologies from natural language descriptions, with local keyword-parsing fallback.
- **Node/link removal** — `removeNode(id)` and `removeLink(id)` APIs for programmatic topology mutation.
- **Event unsubscribe** — `off(event, callback)` to cleanly detach lifecycle listeners.
- **Temporal digital twin** — `setTemporalMode(mode)` switches between design, operational, and incident modes for live or historical topology views.
- **Mobile quick-edit** — `enableMobileQuickEdit()` adds a floating action button and quick-edit panel for touch-based node editing on tablets.

## REST API

An optional Node/Express wrapper (`api/server.js`, run with `npm run api`) exposes the `TopologyDesigner` engine as a RESTful service. It is used by CI pipelines, headless authoring tools, and external integrations that need to produce or analyze topologies without launching a browser.

- **Swagger UI**: http://localhost:3000/api-docs
- **Raw spec**: http://localhost:3000/openapi.json (also served statically as `design-system/openapi.json`)
- **Health**: http://localhost:3000/api/health

Endpoint groups:

| Group | Paths | Purpose |
|-------|-------|---------|
| Topologies | `/api/topologies`, `/api/topologies/{id}`, `/api/topologies/import`, `/api/topologies/{id}/export` | Lifecycle & full-state serialization |
| Nodes | `/api/topologies/{id}/nodes`, `/api/topologies/{id}/nodes/{nodeId}` (GET/PUT/DELETE), `/neighbors`, `/blast-radius`, `/positions` | CRUD + neighbor/blast queries + position keyframes |
| Links | `/api/topologies/{id}/links`, `/api/topologies/{id}/links/{linkId}` (GET/PUT/DELETE) | Link CRUD |
| Anchors | `/api/topologies/{id}/anchors`, `/api/topologies/{id}/anchors/{anchorId}` (GET/PUT/DELETE) | Anchor CRUD |
| Acts & Steps | `/api/topologies/{id}/acts`, `/api/topologies/{id}/steps` | Choreography mutation |
| Glossary | `/api/topologies/{id}/glossary` | Terminology management |
| Analysis | `/api/topologies/{id}/analysis`, `/paths`, `/components`, `/bridges`, `/articulation-points`, `/bfs`, `/subgraph` | Graph algorithms |
| Playback | `/api/topologies/{id}/playback` | Step/mode/speed state |
| Layers | `/api/topologies/{id}/layers`, `/api/topologies/{id}/layers/{layerId}` (PUT/DELETE) | Visual layer CRUD |
| Flow paths | `/api/topologies/{id}/flow-paths`, `/api/topologies/{id}/flow-paths/{flowPathId}` | Animated overlay flow paths |
| Policy markers | `/api/topologies/{id}/policy-markers`, `/api/topologies/{id}/policy-markers/{markerId}` | Policy action badges |
| Meta | `/api/meta/node-types`, `/api/meta/link-types`, `/api/health` | Introspection |

Schemas: `TopologyConfig`, `TopologySummary`, `TopologyExport`, `NodeConfig`, `LinkConfig`, `AnchorPosition`, `ActConfig`, `StepConfig`, `Phase`, `GlossaryTerm`, `AnalysisFinding`, `BlastRadius`, `PathResult`, `PlaybackState`, `PositionKeyframes`, `Layer`, `FlowPath`, `PolicyMarker`, `DeleteResult`, `HealthStatus`, `Error` — all defined in `api/openapi-definition.js` and mirrored to `design-system/openapi.json`.

See USER-MANUAL.md § 55 "REST API & OpenAPI Spec" for full request/response examples and limitations.

## Testing

- **Unit & component tests**: Vitest (`npm test`) — 2278 tests across 55 files.
- **End-to-end**: Playwright (`npm run test:e2e`) — 15 spec files covering smoke, UAT authoring, presentation, distribution, and interop suites.
- **Coverage** (`npm run test:coverage`) — tracks coverage for `topology-ds.js`, `layout-engine.js`, `template-parser.js`, `theme-engine.js`, `core/graph.js`, `api/server.js`, `api/openapi-definition.js`, and `functions/api/ai-assist.js`.

## Project Structure

| File | Purpose |
|------|---------|
| `design-system/topology-ds.js` | Core rendering engine |
| `design-system/topology-ds.css` | Theme, animations, and layout |
| `design-system/editor.html` | Visual drag-and-drop editor |
| `design-system/viewer.html` | Lightweight read-only topology viewer |
| `design-system/USER-MANUAL.md` | Comprehensive API documentation |
| `design-system/openapi.json` | OpenAPI 3.0 specification for REST API (static copy) |
| `design-system/api-docs.html` | Swagger UI API reference (loads `openapi.json`) |
| `design-system/manual.html` | HTML-rendered user manual |
| `design-system/landing.html` | Landing page with links to all demos |
| `design-system/demo-templates.html` | Template gallery showcase |
| `design-system/index.html` | SD-WAN / ZTNA demo topology |
| `design-system/sase-rsa-topology.html` | SASE RSA architecture demo |
| `design-system/core/graph.js` | TopologyGraph data model (adjacency, paths, analysis) |
| `design-system/modules/layout-engine.js` | Auto-layout algorithms |
| `design-system/modules/template-parser.js` | Diagram-as-code parser + built-in templates |
| `design-system/modules/theme-engine.js` | Color theme system with WCAG contrast checking |
| `design-system/modules/iso3d-nodes.js` | Isometric 3D node plugin (iso:box, iso:server, iso:rack, etc.) |
| `functions/api/ai-assist.js` | Cloudflare Workers AI endpoint for topology generation |
| `api/server.js` | Express REST API server (Swagger-annotated) |
| `api/openapi-definition.js` | Shared OpenAPI 3.0 base spec |
| `api/generate-spec.js` | CLI to regenerate the static `openapi.json` |
| `tests/` | Vitest unit & integration suites |
| `tests-e2e/` | Playwright end-to-end suites |
| `other/` | Additional demos (packet flow, reference architecture, narrative, master control) |

Questions? I’m happy to dive deeper into any part of the project.
