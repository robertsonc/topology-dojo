# UX/IA Review — Topology Studio vs design-tool conventions (2026-04)

Ground truth source: `docs/ux-review-discovery.md`.

## 1) Findings

### Finding 1: “Stack / Back / Front / ±1” naming is non-standard for layering
**Severity:** High  
**Category:** Terminology  
**Current behavior:** Node and link inspectors use `Stack` with controls labeled `Back`, `-1`, `+1`, `Front` rather than canonical order verbs.【docs/ux-review-discovery.md:79-80】【docs/ux-review-discovery.md:116-117】  
**Why it's friction:** Experienced diagram users expect explicit z-order verbs and read `-1/+1` as technical internals, not object-order actions.  
**Industry convention:** Figma: “Bring forward / Send backward / Bring to front / Send to back”; Visio: “Bring Forward / Send Backward”; PowerPoint: “Bring to Front / Send to Back.”  
**Recommendation:** Keep existing behavior but relabel to `Bring to Front`, `Bring Forward`, `Send Backward`, `Send to Back` in inspector and any matching surfaces.  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 2: Node label positioning uses numeric Y offset instead of anchor affordance
**Severity:** High  
**Category:** Control affordance  
**Current behavior:** Node inspector exposes `Label Position (Y offset)` as a raw numeric field.【docs/ux-review-discovery.md:58-59】  
**Why it's friction:** Numeric offsets are engineering-centric; diagram tools typically expose anchor positions visually (top/center/bottom or 9-point anchor).  
**Industry convention:** draw.io Format panel uses text-position controls; Visio exposes text block position handles; OmniGraffle Text inspector provides positional controls rather than raw offset-only numbers.  
**Recommendation:** Add a compact 3x3 “Label Alignment” picker for common positions while retaining offset as an advanced disclosure.  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 3: Link label positioning uses “Along line / Perpendicular” numeric offsets only
**Severity:** High  
**Category:** Control affordance  
**Current behavior:** Link label position is edited via numeric `Along line` and `Perpendicular` fields.【docs/ux-review-discovery.md:98-100】  
**Why it's friction:** Users expect drag/anchor-based label placement semantics first, then numeric fine-tuning if needed.  
**Industry convention:** draw.io label movement is direct-manipulation; Visio supports draggable text blocks; Lucidchart supports draggable text placement on connectors.  
**Recommendation:** Add common preset buttons (start/middle/end + above/on/below) and map to existing offset model.  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 4: “Plane” is unfamiliar for everyday layer assignment
**Severity:** Medium  
**Category:** Terminology  
**Current behavior:** Node and link inspectors label layer assignment as `Plane`.【docs/ux-review-discovery.md:78-79】【docs/ux-review-discovery.md:115-116】  
**Why it's friction:** “Plane” sounds domain-specific; most users expect “Layer.”  
**Industry convention:** Figma: “Layers”; draw.io: “Layers”; OmniGraffle: “Layers.”  
**Recommendation:** Rename `Plane` to `Layer` (keep internal data model unchanged).  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 5: Insert menu mixes structural and cinematic objects
**Severity:** High  
**Category:** Information architecture  
**Current behavior:** `Insert` includes basic objects (link, anchor, text) and cinematic entities (`New Act`, `New Step`) in one list.【docs/ux-review-discovery.md:184-193】  
**Why it's friction:** First-time diagrammers expect Insert to mean shapes/connectors; narrative timeline entities belong in a different mental bucket.  
**Industry convention:** Figma/OmniGraffle/Visio separate object insertion from presentation/timeline constructs.  
**Recommendation:** Move `New Act` and `New Step` into a dedicated `Choreography` menu (or bottom panel controls), keep `Insert` structural.  
**Effort:** S  
**Touches cinematic layer?** Yes — location only; keep same Act/Step model.

### Finding 6: View menu contains choreography command among visual-view controls
**Severity:** Medium  
**Category:** Information architecture  
**Current behavior:** View menu includes `Choreographer Builder` between view-level commands.【docs/ux-review-discovery.md:194-201】  
**Why it's friction:** In design tools, View is camera/visibility/grid/zoom; timeline/editor-mode features usually live in animation/presentation sections.  
**Industry convention:** Keynote/PowerPoint separate “View” from animation panes; Figma keeps view controls (zoom, rulers, outlines) separate from prototyping flows.  
**Recommendation:** Relocate `Choreographer Builder` to `Choreography` or `Animate` controls.  
**Effort:** S  
**Touches cinematic layer?** Yes — entry-point relocation only.

### Finding 7: Context menu uses standard arrange labels; inspector does not
**Severity:** Medium  
**Category:** Terminology  
**Current behavior:** Right-click context menu already uses canonical arrange labels, while inspector uses shorthand stack labels.【docs/ux-review-discovery.md:238-242】【docs/ux-review-discovery.md:79-80】  
**Why it's friction:** Intra-product inconsistency makes users relearn the same command in two places.  
**Industry convention:** Visio, PowerPoint, and draw.io keep naming consistent across ribbon/context menu/dialogs.  
**Recommendation:** Align inspector wording to match context menu wording exactly.  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 8: Context menu on blank canvas omits common creation shortcuts
**Severity:** Medium  
**Category:** Discoverability  
**Current behavior:** Canvas context menu includes paste/select/zoom/snap but not quick `Add Node` / `Add Link` / `Text` actions.【docs/ux-review-discovery.md:250-257】  
**Why it's friction:** Right-click-to-create is a common fallback path in diagram tools, especially for mouse-first users.  
**Industry convention:** draw.io and Lucidchart use context menus for insert/create shortcuts; Visio right-click often exposes shape/layout actions contextually.  
**Recommendation:** Add `Insert Node`, `Insert Text`, `Draw Link` entries to blank-canvas context menu.  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 9: “Select All” excludes links from keyboard path
**Severity:** High  
**Category:** Keyboard/interaction  
**Current behavior:** `Ctrl/Cmd+A` selects nodes + anchors only; links are not included by default.【docs/ux-review-discovery.md:264-265】  
**Why it's friction:** In general-purpose design tools, Select All means all selectable objects.  
**Industry convention:** Figma `Cmd/Ctrl+A` selects all objects; PowerPoint/Keynote equivalent select-all behavior spans objects; Visio select-all includes shapes/connectors.  
**Recommendation:** Change `Ctrl/Cmd+A` to include links (and optionally zones/markers) for full-surface select-all semantics.  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 10: Duplicate shortcut exists, but discoverability is fragmented
**Severity:** Medium  
**Category:** Discoverability  
**Current behavior:** `Ctrl/Cmd+D` exists in shortcuts, but duplicate is not prominently shown in top-level menus; appears in context path/shortcuts only.【docs/ux-review-discovery.md:269-270】【docs/ux-review-discovery.md:235-236】  
**Why it's friction:** Users migrating from Figma/PowerPoint expect duplicate in Edit/context surfaces consistently.  
**Industry convention:** Figma “Duplicate”; PowerPoint “Duplicate Slide/Object” style commands in menu/ribbon/context; OmniGraffle “Duplicate”.  
**Recommendation:** Add explicit `Duplicate` item under a top-level Edit-like dropdown (or File submenu) with shortcut hint.  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 11: No explicit Hide/Show object control in object inspector/context
**Severity:** Medium  
**Category:** Discoverability  
**Current behavior:** Node/anchor have `Hide ID`, but no generic hide/show visibility toggle for objects appears in listed controls/menus.【docs/ux-review-discovery.md:51-52】【docs/ux-review-discovery.md:124-125】【docs/ux-review-discovery.md:231-258】  
**Why it's friction:** Users expect temporary object visibility toggles as a core drafting behavior.  
**Industry convention:** Figma layer eye toggle; draw.io layer/object visibility controls; Visio selection/layer visibility workflows.  
**Recommendation:** Add object-level `Hide`/`Show` in context menu and inspector (map to existing opacity/visibility model).  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 12: Color control lacks eyedropper/recent-color affordances
**Severity:** Medium  
**Category:** Control affordance  
**Current behavior:** Color controls are swatches + raw hex inputs for node/link/flowpath/marker; no eyedropper/recent palette indicated.【docs/ux-review-discovery.md:57-58】【docs/ux-review-discovery.md:96-97】  
**Why it's friction:** Users expect quick color reuse and sampling workflows in design tools.  
**Industry convention:** Figma color picker with eyedropper + recent colors; PowerPoint/Keynote include recent/document colors.  
**Recommendation:** Add lightweight recent-color row and browser eyedropper integration where available.  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 13: Topology/canvas properties are detached from inspector mental model
**Severity:** Low  
**Category:** Information architecture  
**Current behavior:** Canvas/topology fields (`Title`, `Subtitle`, `ViewBox`) are in toolbar dropdown, not in right inspector object model.【docs/ux-review-discovery.md:137-140】【docs/ux-review-discovery.md:336-337】  
**Why it's friction:** Many tools keep document/canvas properties in predictable side-panel tabs or document settings panels discoverable from inspector context.  
**Industry convention:** Figma file/page settings grouped in side panes; Visio page setup/document properties are clearly grouped.  
**Recommendation:** Keep toolbar entry, but add “Canvas” pseudo-selection in inspector for discoverable document settings.  
**Effort:** M  
**Touches cinematic layer?** No

### Finding 14: Terminology overload from cinematic verbs in everyday link editing
**Severity:** High  
**Category:** Information architecture  
**Current behavior:** Standard link inspector includes `Animate Flow`, `Flow Particles`, `Reverse Dir`, `3D Tunnel` alongside basic line formatting by default.【docs/ux-review-discovery.md:104-111】【docs/ux-review-discovery.md:307-308】  
**Why it's friction:** Core diagramming tasks become visually crowded by presentation-specific controls, increasing cognitive load.  
**Industry convention:** Figma/draw.io/Visio default connector panels prioritize geometry/stroke/text first; advanced effects are secondary/expandable.  
**Recommendation:** Keep features but collapse under an “Effects / Animation (Advanced)” accordion.  
**Effort:** S  
**Touches cinematic layer?** Yes — visibility of controls, not behavior.

### Finding 15: Shortcut help exists but not in conventional trigger pattern
**Severity:** Low  
**Category:** Discoverability  
**Current behavior:** Cheatsheet is available via `?` / `Shift+?`; menu path is implicit and non-persistent in toolbar labels.【docs/ux-review-discovery.md:303-304】  
**Why it's friction:** Many users look for explicit “Keyboard Shortcuts” item in Help menu or `Cmd+/` convention.  
**Industry convention:** Figma uses `?` help surfaces; many apps expose `Keyboard Shortcuts` in Help; Slack/Notion-style `Cmd+/` expectations are common.  
**Recommendation:** Add explicit `Keyboard Shortcuts` item in File/Help area and support `Cmd/Ctrl+/` alias.  
**Effort:** S  
**Touches cinematic layer?** No

### Finding 16: Arrange shortcuts use bracket keys without on-surface mnemonic text
**Severity:** Medium  
**Category:** Keyboard/interaction  
**Current behavior:** Arrange shortcuts exist (`Ctrl/Cmd+[`, `Ctrl/Cmd+]`, `[`, `]`), but inspector button labels are symbolic (`-1`, `+1`, `Back`, `Front`).【docs/ux-review-discovery.md:299-303】【docs/ux-review-discovery.md:79-80】  
**Why it's friction:** Users who don’t know bracket shortcuts cannot infer mapping from symbolic labels.  
**Industry convention:** Visio/PowerPoint context/ribbon surfaces show command text + shortcut hints; draw.io menus use explicit wording.  
**Recommendation:** Add textual tooltips with full labels and shortcut hints on arrange buttons.  
**Effort:** S  
**Touches cinematic layer?** No

## 2) Themes (max 5)

1. **Terminology drift from design-tool language.** Core object-order and layer actions are implemented but named with shorthand or domain terms (`Stack`, `Plane`, `-1/+1`) that diverge from mainstream mental models. This is high-impact because capability exists, but trust/perceived polish drops due to wording.

2. **Information architecture mixes “drawing” and “choreography” primitives too early.** Insert/View/default link inspector include cinematic concepts in first-tier surfaces. Keeping cinematic power while re-tiering where it appears would reduce onboarding friction without removing differentiators.

3. **Strong keyboard depth, inconsistent discoverability.** The product has a rich keymap, but visibility is uneven (some commands only in context menu or shortcuts). Minor menu/help surfacing changes can materially improve approachability.

4. **Controls are often technically precise but visually non-native.** Numeric offsets and engineering-style toggles are powerful, yet primary UX should offer familiar visual affordances first, with numeric precision as secondary.

## 3) Design-tool parity checklist

Legend: ✅ present and good | ⚠️ present but unconventional | ❌ missing | N/A

- Right-click context menu on nodes — ✅
- Right-click context menu on canvas — ✅
- Bring to Front / Send to Back / Bring Forward / Send Backward — ⚠️ (Finding 1, 7, 16)
- Group / Ungroup — ✅
- Lock / Unlock object — ✅
- Hide / Show object — ❌ (Finding 11)
- Copy / Paste / Duplicate (Cmd+D) — ⚠️ (Finding 10)
- Multi-select with marquee — ✅
- Multi-select with Shift+click — ✅
- Align (left, center, right, top, middle, bottom) — ✅
- Distribute (horizontal, vertical) — ✅
- Snap to grid / snap to objects / smart guides — ⚠️ (grid + guides present; object/smart-guide language/behavior unconventional)
- Undo / Redo with deep history — ✅
- Keyboard nudge (arrows = 1px, Shift+arrows = 10px) — ✅
- Zoom to fit / zoom to selection / zoom presets — ⚠️ (fit present; selection/presets not surfaced)
- Pan with spacebar+drag — ✅
- Search/jump to object by name — ⚠️ (partial via select menus, no direct object search box)
- 9-position label anchor (not numeric offset) — ❌ (Finding 2, 3)
- Color picker with eyedropper and recent colors — ❌ (Finding 12)
- Find and replace — ❌
- Templates / stencils / shape library with search — ✅
- Export to PNG / SVG / PDF — ✅
- Keyboard shortcut cheat sheet (? or Cmd+/) — ⚠️ (`?` present; Cmd+/ not explicit; Finding 15)

## 4) Roadmap reconciliation

Reference roadmap in discovery: `QA-UAT-ROADMAP.md` summary.【docs/ux-review-discovery.md:312-325】

| Roadmap overlap / mismatch | Reconciliation from this UX review |
|---|---|
| Roadmap heavily emphasizes QA automation and cross-browser confidence. | Keep as-is for reliability, but pair with terminology/IA quick wins so quality gains are visible to end users immediately. |
| Export, interop, and scenario workflow priorities are covered by roadmap. | Maintain priority; these affect trust and enterprise readiness. |
| UX friction items in this review (terminology, inspector affordances, menu placement) are not explicit roadmap items. | Add a UX parity track (copy/label harmonization + IA tidy-up) with S/M effort items from Findings 1–8, 14–16. |
| Some roadmap future items (visual regression, performance) are strategic but not immediate first-use friction reducers. | Sequence small UX convention fixes in parallel to improve perceived maturity while deeper QA work continues. |

## 5) Top 5 quick wins (S-effort, impact per hour)

1. **Finding 1 — Rename stack controls to canonical arrange labels.** Highest trust gain for almost no engineering risk.
2. **Finding 5 — Move `New Act`/`New Step` out of Insert.** Immediate IA clarity for first-time diagrammers.
3. **Finding 6 — Move `Choreographer Builder` out of View.** Makes View feel like a standard design-tool view menu.
4. **Finding 7 — Unify arrange terminology across inspector/context menu.** Removes self-contradiction in one pass.
5. **Finding 15 — Add explicit “Keyboard Shortcuts” menu item + `Cmd/Ctrl+/`.** Big discoverability gain for keyboard depth already implemented.
