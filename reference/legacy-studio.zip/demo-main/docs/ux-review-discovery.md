# UX Review Discovery — Topology Studio Editor Surface

## 1. Repo map

### Top-level structure
- `design-system/` — primary browser app surfaces (`editor.html`, `viewer.html`, `manual.html`), core engine (`topology-ds.js`), API spec (`openapi.json`), design docs (`UX-REVIEW.md`, `USER-MANUAL.md`).
- `design-system/core/` — graph model (`graph.js`).
- `design-system/modules/` — modularized engines (`layout-engine.js`, `theme-engine.js`, `template-parser.js`).
- `api/` — Node/Express API server + OpenAPI generation (`server.js`, `openapi-definition.js`, `generate-spec.js`).
- `functions/` — edge/function handlers (`functions/api/ai-assist.js`).
- `tests/` — Vitest unit/integration tests.
- `tests-e2e/` — Playwright browser workflow specs + fixtures.
- `other/` — architecture and planning docs (`ARCHITECTURE-VISION.md`, `ARCH_REVIEW.md`, etc.).
- `uat/` — static UAT scenarios.

### Languages / stack observed
- HTML/CSS/vanilla JS in browser surfaces (not React/Vue).
- Node.js (Express, CORS, Swagger tooling) for API.
- Test stack: Vitest + Playwright.

### Build / run system
- NPM scripts in `package.json` provide test, API, and e2e tasks (`test`, `api`, `api:spec`, `test:e2e`, etc.).
- No bundler-centric front-end app structure observed for editor (inline script in `design-system/editor.html`).

## 2. Key surfaces (table)

| Surface | Located path(s) | Notes |
|---|---|---|
| Editor entry HTML | `design-system/editor.html` | Main authoring UI markup + large inline script. |
| Editor main script/component | `design-system/editor.html` (inline JS) | Global `state`, tool handlers, rendering orchestration. |
| Property inspector / right panel | `design-system/editor.html` (`#propsPanel`, `renderProps`, `renderNodeProps`, `renderLinkProps`, `renderAnchorProps`, `renderZoneProps`) | Dynamic form by selected type. |
| Toolbar component | `design-system/editor.html` (`.ed-toolbar`) | File/View/Insert menus, tools, mode toggle, undo/redo, properties menu. |
| Canvas / SVG renderer | `design-system/editor.html` (`#canvas`, `renderCanvas`) + `design-system/topology-ds.js` (engine render methods) | Editor renders interactive SVG; core engine also provides renderer. |
| Context menu code | `design-system/editor.html` (`showContextMenu`) | Supports hit-target menu + canvas menu. |
| Keyboard shortcut handler | `design-system/editor.html` (`document.addEventListener('keydown', ...)`) | Comprehensive keymap in one handler. |
| Node type definitions (`NodeConfig`) | `design-system/openapi.json` (`components.schemas.NodeConfig`); `api/openapi-definition.js` (`NodeConfig`) | API schema source + generated artifact both present. |
| Link type definitions (`LinkConfig`) | `design-system/openapi.json` (`components.schemas.LinkConfig`); `api/openapi-definition.js` (`LinkConfig`) | API schema source + generated artifact both present. |
| Schema source of truth | `api/openapi-definition.js` (authoring source), `design-system/openapi.json` (generated/served artifact) | `api/generate-spec.js` exists for regeneration. |
| Cinematic layer: Acts / Steps / Phases / playback | `design-system/topology-ds.js` (`act`, `addStep`, phase evaluation, `play/pause/present/next/prev/goTo`); `design-system/editor.html` (choreography panel and `renderChoreo`) | Cinematic model and editor coexist in authoring surface. |
| User manual content source | `design-system/USER-MANUAL.md` | `manual.html` fetches this markdown at runtime. |
| Manual loader page | `design-system/manual.html` | Contains markdown renderer + `fetch('USER-MANUAL.md')`. |
| README / ROADMAP / CHANGELOG / ARCHITECTURE / docs | `README.md`: not found; `ROADMAP.md`: not found; `CHANGELOG.md`: not found; architecture docs found in `other/`; existing docs in `design-system/UX-REVIEW.md`, `design-system/USER-MANUAL.md`, `overview.md`, `REVIEW.md`, `QA-UAT-ROADMAP.md` | No top-level `docs/` content existed before this task. |

## 3. Property inspector inventory (one table per object type)

### 3.1 Node properties (`renderNodeProps`)

| Field name in code | Label shown to user | Control type | Notes |
|---|---|---|---|
| `id` | `ID` | text input + lock toggle button | Lock button text toggles `🔒 Locked` / `🔓 Unlocked`. |
| `hideId` | `Hide ID` | checkbox | Boolean toggle. |
| `type` | `Type` | select | Uses `ALL_NODE_TYPES`. |
| `x` | `X` | number input | Position. |
| `y` | `Y` | number input | Position. |
| `label` | `Label` | text input | Primary label. |
| `sublabel` | `Sublabel` | text input | Secondary label. |
| `color` | `Color` | swatch set + hex text input | Custom hex allowed. |
| `labelOffset` | `Label Position (Y offset)` | number input | Numeric offset model. |
| `opacity` | `Opacity` | range slider | 0..1 step 0.05. |
| `sub1` (cloud only) | `Sub1` | text input | Conditional by node type. |
| `sub2` (cloud only) | `Sub2` | text input | Conditional by node type. |
| `managed` (host only) | `Managed` | select (Yes/No) | Host-specific. |
| `agent` (host only) | `Agent` | select (Yes/No) | Host-specific. |
| `variant` (ec only) | `Variant` | select | `generic/virtual/physical/aws/azure/gcp/oracle`. |
| `vrrpState` (ec only) | `VRRP State` | select | `None/Active/Standby`. |
| `pe` (connector only) | `Private Edge` | select (Yes/No) | Connector-specific. |
| `copperPorts` (switchEnterprise only) | `Copper Ports` | number input | Port count. |
| `fiberPorts` (switchEnterprise only) | `Fiber Ports` | number input | Port count. |
| `sublabel` (text only) | `Sublabel (multi-line)` | textarea | Reuses field with multiline UI. |
| `fontSize` (text only) | `Font Size` | number input | Text-only typography control. |
| `fontWeight` (text only) | `Font Weight` | select | `Normal/Semi-Bold/Bold`. |
| `logoUrl` (saas only) | `Logo URL` | text input | Optional URL. |
| `logo fetch helper` (saas only) | `Fetch Logo` | text input + button | Domain helper to populate logo URL. |
| `variant` (shape arrow/triangle) | `Direction` | select | `right/left/up/down` for directional shapes. |
| `shapeSize` (shape families) | `Size` | number input | Shape size dimension. |
| `shapeWidth` (rectangle/ellipse) | `Width` | number input | Conditional by shape type. |
| `shapeHeight` (rectangle/ellipse) | `Height` | number input | Conditional by shape type. |
| `layer` | `Plane` | select | Maps to layer system (`Physical/Flow/Policy`). |
| `zOrder` | `Stack` | button group (`Back`, `-1`, `+1`, `Front`) | Arrange actions presented as short labels. |
| `sideLabel.label` | `Side Label` | text input | Creates/updates side label object. |
| `zoneLabel.text` | `Zone Label` | text input | Creates/deletes zone label object. |
| connected links (derived) | `CONNECTED LINKS (n)` | clickable tag list | Not a direct scalar field; selection helper. |
| policy marker list/add | `POLICY MARKERS`, `Add Marker` | list + buttons | Marker management embedded in node inspector. |
| delete action | `Delete Node` | button | Destructive action. |

### 3.2 Link properties (`renderLinkProps`)

| Field name in code | Label shown to user | Control type | Notes |
|---|---|---|---|
| `id` | `ID` | text input + lock toggle button | Lock toggle in label row. |
| `type` | `Type` | select | `line/tunnel/wireguard/flow/packet/blocked/wifi/poe/optical`. |
| `from/to/fromPort/toPort` | `ENDPOINTS` block + `From Node`, `From Side`, `To Node`, `To Side` | summary text, selects, 3x3 side picker, swap button | Endpoint routing controls. |
| `lineStyle` | `Line Style` | segmented button group | `straight/orthogonal/curved`. |
| `cornerRadius` | `Corner Radius` | range slider | Geometric rounding. |
| `waypoints[]` | `WAYPOINTS (n)` | repeated number inputs + remove buttons + add button | Per-waypoint X/Y editing. |
| `color` | `Color` | swatches + hex input | Visual styling. |
| `label` | `Label` | text input | Link label. |
| `labelOffset.x` | `Along line` | number input | Numeric label offset model. |
| `labelOffset.y` | `Perpendicular` | number input | Numeric label offset model. |
| `strokeWidth` | `Stroke Width` | range slider | Width in px. |
| `opacity` | `Opacity` | range slider | 0..1. |
| `dashed/dashStyle` | `Stroke Pattern` | select | Solid + multiple dash presets. |
| `dots` | `Dots` | select (Yes/No) | Dot rendering toggle. |
| `animateFlow` | `Animate Flow` | select (Off/On) | Animation toggle. |
| `flowSpeed` | `Flow Speed` | range slider | Flow animation speed. |
| `flowParticles` | `Flow Particles` | number input | Particle count. |
| `reverseFlow` | `Reverse Dir` | select | Direction toggle. |
| `tunnel3d` | `3D Tunnel Mode` | select (Off/On) | Tunnel visual mode. |
| `tunnelWidth` | `Tunnel Width` | range slider | Conditional when 3D tunnel on. |
| tunnel preset helper | `Tunnel Preset` | select | Applies grouped style presets. |
| `path` (flow only) | `Custom SVG Path` | textarea | Flow-specific geometry. |
| `labelPos.x` (flow only) | `Label X` | number input | Flow label position. |
| `labelPos.y` (flow only) | `Label Y` | number input | Flow label position. |
| `reason` (blocked only) | `Reason` | text input | Blocked-link reason text. |
| `layer` | `Plane` | select | Layer assignment. |
| `zOrder` | `Stack` | button group (`Back`, `-1`, `+1`, `Front`) | Arrange actions. |
| delete action | `Delete Link` | button | Destructive action. |

### 3.3 Anchor properties (`renderAnchorProps`)

| Field name in code | Label shown to user | Control type | Notes |
|---|---|---|---|
| anchor id | `ID` | text input | Renamable. |
| `hideId` | `Hide ID` | checkbox | Boolean toggle. |
| `label` | `Label` | text input | Anchor label. |
| `color` | `Label Color` | text input | Freeform color string. |
| `labelOffsetX` | `Label Position X` | number input | Numeric label offset. |
| `labelOffsetY` | `Label Position Y` | number input | Numeric label offset. |
| `x` | `X` | number input | Anchor position. |
| `y` | `Y` | number input | Anchor position. |
| delete action | `Delete Anchor` | button | Destructive action. |

### 3.4 Canvas / topology properties

| Field name in code | Label shown to user | Control type | Notes |
|---|---|---|---|
| `title` | `Title` | text input (toolbar Properties menu) | Topology metadata. |
| `subtitle` | `Subtitle` | text input (toolbar Properties menu) | Topology metadata. |
| `viewBox` | `ViewBox` | text input (toolbar Properties menu) | Canvas extents string. |
| `snapEnabled/snapSize` | `Grid: 12px` / `Grid: Off` (View menu item) | menu action toggle | Single snap toggle; size displayed, not edited inline here. |
| `previewMode` | `Editor Preview` | menu action toggle | Preview mode toggle from View menu. |
| `isometricTilt` | `Isometric Tilt` | menu action toggle | Perspective effect toggle. |
| zoom state | `+`, `-`, `Fit` (canvas controls) | button controls | No numeric preset dropdown observed. |

## 4. Commands and menus inventory

### 4.1 Toolbar & dropdown menus

#### File menu
- Save as HTML
- Save as JSON
- Import HTML
- Import JSON
- Diagram-as-Code ▸ Import
- Diagram-as-Code ▸ Export
- Open in View
- Preview as Standalone
- Export Animated GIF
- Export as PNG
- Export as SVG
- Export as PDF
- Export Standalone HTML
- Copy Embed Code
- Load Demo
- Templates
- Save as Template
- Theme ▸
- User Manual
- Show Walkthrough
- Clear All

#### Mode toggle
- Design
- Animate

#### Core tool buttons
- Select
- + Node ▾ (palette)
- + Link
- Hand
- ⚡ Flow Path (shown in animate mode)
- Shapes (Node Type Browser)

#### Insert menu
- Multi-Point Link
- Anchor Point
- Text Label
- New Act
- New Step
- Zone Annotation
- Horizontal Guide
- Vertical Guide

#### View menu
- Toggle Guides
- Grid snap toggle (`Grid: 12px` / `Grid: Off`)
- Editor Preview
- Choreographer Builder
- Line style quick set (`straight`, `orthogonal`, `curved`)
- Auto Layout
- Isometric Tilt

#### Select menu (dynamic)
- All Nodes & Anchors
- All by node type (dynamic)
- Color group selections (dynamic)
- Connected to Selected
- Invert Selection

#### Always-visible toolbar controls
- Undo (click + long-press history)
- Redo (click + long-press history)
- ✨ AI Assist
- Theme toggle (light/dark)
- Properties menu (`Title`, `Subtitle`, `ViewBox`)

#### Batch/align bar (selection-driven)
- Align: Left / Center / Right / Top / Middle / Bottom
- Distribute: Horiz / Vert
- Group
- Ungroup
- Lock
- Clear selection

### 4.2 Menu bar
- No separate desktop-style top menu bar (`File/Edit/View/...`) outside the toolbar dropdown groups.
- A small site navigation bar exists (`Design`, `View`, `Manual`, `API Docs`) but it is navigation, not an editor command menu.

### 4.3 Right-click context menu

#### On element hit (node/link/etc.)
- Edit Properties
- Connect to… (nodes)
- Copy
- Duplicate
- Copy Format
- Paste Format (enabled/disabled based on copied format)
- Bring to Front
- Bring Forward
- Send Backward
- Send to Back
- Move to Layer ▶ (submenu)
- Select-all variants by type/color (contextual)
- Link-only: Straight / Orthogonal / Curved
- Link-only: Toggle 3D Tunnel
- Preview-mode contextual: Add to Focus / Remove from Focus
- Create Zone from Selection
- Delete

#### On canvas (no hit)
- Paste
- Select All
- Select all by node type (dynamic)
- Select all links
- Select links by color/type (dynamic)
- Zoom to Fit
- Toggle Grid Snap

### 4.4 Keyboard shortcuts (from keydown handler + cheatsheet)

#### Editing / selection
- `Ctrl/Cmd+Z` Undo
- `Ctrl/Cmd+Shift+Z` Redo
- `Ctrl/Cmd+A` Select all nodes + anchors
- `Ctrl/Cmd+C` Copy
- `Ctrl/Cmd+V` Paste
- `Ctrl/Cmd+Shift+C` Copy format
- `Ctrl/Cmd+Shift+V` Paste format
- `Ctrl/Cmd+D` Duplicate selection
- `Ctrl/Cmd+G` Group selection into zone
- `Ctrl/Cmd+Shift+G` Ungroup zone
- `Ctrl/Cmd+L` Lock/Unlock selection
- `Delete` / `Backspace` Delete selection
- `Esc` cancel active operation / clear selection

#### Navigation / manipulation
- Arrow keys move selected node/anchor by 1px
- `Shift` + Arrow keys move selected node/anchor by 10px
- `+` / `=` zoom in
- `-` zoom out
- `0` zoom to fit
- Hold `Space` to pan mode while held

#### Tools and view
- `V` select tool
- `N` add-node tool + palette
- `Shift+N` node type browser
- `L` add-link tool
- `M` multi-point link tool
- `A` anchor tool
- `T` text-node insertion shortcut
- `H` hand tool
- `F` flow-path tool (animate mode only)
- `G` toggle grid snap
- `R` toggle guides
- `P` toggle editor preview
- `Shift+C` open choreographer builder
- `1/2/3` line style shortcuts (straight/orthogonal/curved)
- `Ctrl/Cmd+]` bring to front
- `Ctrl/Cmd+[` send to back
- `]` bring forward
- `[` send backward
- `?` or `Shift+?` show shortcuts help/cheatsheet

## 5. Cinematic boundary and leak points

The core cinematic model is defined by Acts, Steps, and Phases plus playback methods in the engine (`act`, `addStep`, phase evaluation, `play/pause/present/next/prev/goTo`). In the editor, cinematic editing is anchored in the bottom “Choreography — Steps & Phases” panel and related builder overlays. The base drawing surface (select/add/move node/link/anchor, arrange, align, property edits) is presented in the same page and toolbar. Cinematic concepts leak into baseline editing touchpoints in several places: (1) Insert menu includes `New Act` and `New Step` beside structural insertions, (2) View menu includes `Choreographer Builder`, and (3) the right property panel includes controls like `Animate Flow`, `Flow Speed`, `Flow Particles`, `Reverse Dir`, and `3D Tunnel` in default link editing. Context menus also expose preview-specific focus actions when preview mode is enabled.

## 6. Roadmap summary

### Roadmap-like file(s) found
- `QA-UAT-ROADMAP.md` found (dated 2026-04-06).
- `ROADMAP.md` not found.

### Summary (≤10 bullets)
- Positions QA risk as mismatch between strong engine tests and weaker browser workflow validation.
- Calls for Playwright browser suite as required release gate (Phase 1, P0).
- Defines core browser workflow gates: editor authoring, viewer playback, export validation.
- Requires failure artifact capture (screenshots, traces, console logs, downloads).
- Expands to scenario-based UAT packs (authoring, presentation, distribution, interop).
- Enumerates canonical UAT fixtures (SD-WAN, ZTNA, campus, data center, cloud, dense stress).
- Plans visual regression snapshots for key pages/state combinations.
- Targets cross-browser coverage with Chromium + WebKit.
- Adds mobile automation goals (touch interactions, mobile layout behavior).
- Adds accessibility/performance depth goals in later phases.

### TODO/FIXME density check
- No TODO/FIXME hotspots observed in `design-system/editor.html` or `design-system/topology-ds.js` from quick scan.
- TODOs observed mainly in e2e tests (`tests-e2e/import-export.spec.js`, `tests-e2e/uat-interop.spec.js`, `tests-e2e/viewer.spec.js`) and in `REVIEW.md` commentary references.

## Gaps

- No `README.md` found at repository root.
- No `ROADMAP.md` and no `CHANGELOG.md` found at repository root.
- No pre-existing top-level `docs/` content was found.
- The “canvas/topology” inspector exists as a toolbar Properties dropdown rather than a right-panel object type; interpreted here as the topology/canvas property surface.
- Multi-select node property editing exists indirectly via the batch toolbar, but no dedicated multi-node property inspector form was found.
- “Menu bar” in classic desktop sense is not present; inventories are based on toolbar dropdown groups and context menus.
