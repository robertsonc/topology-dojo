const fs = require('fs');
const path = require('path');
const assert = require('assert');

global.window = { matchMedia: () => ({ matches: false }) };
global.document = {
  getElementById: () => null,
  createElementNS: () => ({ innerHTML: '', firstChild: null }),
};

const TopologyDesigner = require('../design-system/topology-ds.js');

const OUT_DIR = path.join(__dirname, '..', 'uat', 'generated');
fs.mkdirSync(OUT_DIR, { recursive: true });

const SCENARIOS = [
  {
    slug: 'small-3site-hubspoke',
    title: 'AI Stress · Small SD-WAN',
    subtitle: '1 hub · 2 spokes · secure private + SaaS access',
    hubs: 1,
    spokes: 2,
    width: 1200,
    height: 820,
    phaseMs: 650,
  },
  {
    slug: 'medium-10site-dualhub',
    title: 'AI Stress · Medium SD-WAN',
    subtitle: '2 hubs · 8 spokes · regional overlay + policy layers',
    hubs: 2,
    spokes: 8,
    width: 1400,
    height: 900,
    phaseMs: 550,
  },
  {
    slug: 'large-36site-quadhub',
    title: 'AI Stress · Large SD-WAN',
    subtitle: '4 hubs · 32 spokes · overlay mesh + layered traffic flows',
    hubs: 4,
    spokes: 32,
    width: 1700,
    height: 1080,
    phaseMs: 420,
  },
];

function makeNode(type, x, y, label, extra = {}) {
  return { type, x, y, label, ...extra };
}

function makeLink(type, from, to, extra = {}) {
  return { type, from, to, ...extra };
}

function chunks(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function buildScenario(cfg) {
  const { slug, title, subtitle, hubs, spokes, width, height, phaseMs } = cfg;
  const nodes = {};
  const links = {};
  const acts = [];
  const steps = [];
  const glossary = [
    { t: 'Hub', d: 'Primary SD-WAN transit site that aggregates branch tunnels and anchors policy enforcement.' },
    { t: 'Spoke', d: 'Remote branch site that uses overlay tunnels to reach shared services.' },
    { t: 'Flow Layer', d: 'Animated overlay paths that show real traffic movement across the topology.' },
    { t: 'Policy Layer', d: 'Security and routing decisions rendered as badges over relevant control points.' },
    { t: 'Isometric Tilt', d: '3D presentation mode that tilts the SVG canvas for cinematic screen recordings.' },
    { t: 'Ghosting', d: 'Previous-act infrastructure remains faintly visible to preserve spatial context.' },
  ];

  const layers = [
    { id: 'physical', name: 'Physical', type: 'physical', visible: true, opacity: 1, locked: false, color: '#01a982', order: 0 },
    { id: 'overlay', name: 'Overlay Flows', type: 'flow', visible: true, opacity: 0, locked: false, color: '#65aef9', order: 1 },
    { id: 'policy', name: 'Policy', type: 'policy', visible: true, opacity: 0, locked: false, color: '#deb146', order: 2 },
  ];

  const flowPaths = [];
  const policyMarkers = [];
  const zones = [];

  const coreY = 78;
  nodes.INTERNET = makeNode('cloud', width * 0.5, coreY, 'Internet', { color: '#b1b9be' });
  nodes.IDENTITY = makeNode('idcard', width * 0.18, coreY + 10, 'Identity', { sublabel: 'IdP / MFA', color: '#7764fc' });
  nodes.NETGATE = makeNode('firewall', width * 0.38, coreY + 120, 'Network Gate', { sublabel: 'Inspect · route · decrypt', color: '#fc6161' });
  nodes.APPGATE = makeNode('firewall', width * 0.62, coreY + 120, 'Application Gate', { sublabel: 'ZTNA policy', color: '#deb146' });
  nodes.PRIVEDGE = makeNode('router', width * 0.5, coreY + 250, 'Private Edge', { sublabel: 'Private transport', color: '#01a982' });
  nodes.PRIVATE_APP = makeNode('apps', width * 0.35, coreY + 250, 'Private Apps', { sublabel: 'ERP · CRM · Git', color: '#01a982' });
  nodes.SAAS = makeNode('saas', width * 0.76, coreY + 250, 'SaaS', { sublabel: 'M365 · ServiceNow', color: '#65aef9' });

  links.internet_netgate = makeLink('line', 'INTERNET', 'NETGATE', { color: '#b1b9be', label: 'Public WAN' });
  links.internet_appgate = makeLink('line', 'INTERNET', 'APPGATE', { color: '#b1b9be', label: 'Secure ingress' });
  links.id_netgate = makeLink('line', 'IDENTITY', 'NETGATE', { color: '#7764fc', dashed: true, label: 'Auth context' });
  links.netgate_appgate = makeLink('tunnel', 'NETGATE', 'APPGATE', { color: '#fc6161', label: 'Service chain', dots: true });
  links.netgate_privedge = makeLink('line', 'NETGATE', 'PRIVEDGE', { color: '#01a982', label: 'Policy handoff' });
  links.appgate_private = makeLink('line', 'APPGATE', 'PRIVATE_APP', { color: '#deb146', label: 'ZTNA allow' });
  links.appgate_saas = makeLink('line', 'APPGATE', 'SAAS', { color: '#65aef9', label: 'SaaS breakout' });
  links.privedge_private = makeLink('wireguard', 'PRIVEDGE', 'PRIVATE_APP', { color: '#01a982', label: 'Private fabric', dots: true });

  const hubIds = [];
  const spokeIds = [];
  const hubX = hubs === 1 ? [width * 0.5] : Array.from({ length: hubs }, (_, i) => width * (0.2 + (0.6 * i / (hubs - 1))));
  const hubY = height * 0.46;

  for (let i = 0; i < hubs; i++) {
    const id = `HUB${i + 1}`;
    hubIds.push(id);
    nodes[id] = makeNode('ec', hubX[i], hubY, `Hub ${i + 1}`, {
      sublabel: i === 0 ? 'Primary aggregation' : 'Regional aggregation',
      color: '#01a982',
      layer: 'physical',
      variant: 'physical',
    });
    links[`hub${i + 1}_netgate`] = makeLink('tunnel', id, 'NETGATE', {
      color: '#01a982',
      label: i === 0 ? 'Core overlay' : 'Regional overlay',
      dots: true,
    });
    links[`hub${i + 1}_appgate`] = makeLink('wireguard', id, 'APPGATE', {
      color: '#65aef9',
      label: 'App access',
      dots: true,
    });
    policyMarkers.push([`pm_encrypt_${id}`, {
      nodeId: id,
      type: 'encrypt',
      color: '#01a982',
      label: 'IPsec',
      layer: 'policy',
    }]);
  }

  for (let i = 0; i < hubs; i++) {
    for (let j = i + 1; j < hubs; j++) {
      links[`hubmesh_${i + 1}_${j + 1}`] = makeLink('tunnel', `HUB${i + 1}`, `HUB${j + 1}`, {
        color: '#7764fc',
        label: 'Hub mesh',
        dots: true,
      });
    }
  }

  const cols = Math.min(8, Math.max(2, Math.ceil(Math.sqrt(spokes))));
  const rows = Math.ceil(spokes / cols);
  const rowYStart = height * 0.67;
  const rowGap = Math.min(130, Math.max(92, (height * 0.22) / Math.max(1, rows - 1 || 1)));
  const colGap = (width * 0.78) / Math.max(1, cols - 1);
  const colStart = width * 0.11;

  const regionNodes = Array.from({ length: hubs }, () => []);
  for (let i = 0; i < spokes; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const id = `SPK${String(i + 1).padStart(2, '0')}`;
    const primaryHub = `HUB${(i % hubs) + 1}`;
    const x = colStart + col * colGap;
    const y = rowYStart + row * rowGap;
    spokeIds.push(id);
    regionNodes[(i % hubs)].push(id);
    nodes[id] = makeNode('ec', x, y, `Spoke ${String(i + 1).padStart(2, '0')}`, {
      sublabel: `Primary ${primaryHub}`,
      color: '#65aef9',
      layer: 'physical',
      variant: 'virtual',
    });
    links[`underlay_${id}`] = makeLink('line', id, 'INTERNET', {
      color: '#7d8a92',
      dashed: true,
      label: 'Broadband/LTE',
    });
    links[`overlay_${id}`] = makeLink('tunnel', id, primaryHub, {
      color: '#01a982',
      label: 'Primary tunnel',
      dots: true,
    });
    if (hubs > 1 && i % 3 === 0) {
      const backupHub = `HUB${((i + 1) % hubs) + 1}`;
      links[`backup_${id}`] = makeLink('wireguard', id, backupHub, {
        color: '#65aef9',
        label: 'Backup',
        dots: true,
      });
    }
  }

  zones.push(['z_core_services', {
    label: 'Security & App Fabric',
    sublabel: 'Shared policy plane',
    nodes: ['NETGATE', 'APPGATE', 'PRIVEDGE', 'PRIVATE_APP', 'SAAS'],
    color: '#deb146',
    padding: 60,
  }]);

  regionNodes.forEach((siteIds, idx) => {
    zones.push([`z_region_${idx + 1}`, {
      label: `Region ${idx + 1}`,
      sublabel: `Hub ${idx + 1} and attached branches`,
      nodes: [`HUB${idx + 1}`, ...siteIds],
      color: ['#01a982', '#65aef9', '#7764fc', '#deb146'][idx % 4],
      padding: 42,
    }]);
  });

  flowPaths.push(['fp_private_app', {
    waypoints: [spokeIds[0], hubIds[0], 'NETGATE', 'APPGATE', 'PRIVEDGE', 'PRIVATE_APP'],
    color: '#01a982',
    animation: 'particles',
    speed: 1.8,
    direction: 'forward',
    width: 3,
    opacity: 1,
    label: 'Private App Flow',
    layer: 'overlay',
    name: 'Private App Flow',
  }]);
  flowPaths.push(['fp_saas', {
    waypoints: [spokeIds[Math.min(1, spokeIds.length - 1)], hubIds[Math.min(0, hubIds.length - 1)], 'NETGATE', 'APPGATE', 'SAAS'],
    color: '#65aef9',
    animation: 'particles',
    speed: 2.2,
    direction: 'forward',
    width: 3,
    opacity: 0.95,
    label: 'SaaS Breakout',
    layer: 'overlay',
    name: 'SaaS Breakout',
  }]);
  if (hubIds.length > 1) {
    flowPaths.push(['fp_hub_replication', {
      waypoints: hubIds,
      color: '#7764fc',
      animation: 'dashed',
      speed: 2.8,
      direction: 'bidirectional',
      width: 2.5,
      opacity: 0.8,
      label: 'Hub Sync',
      layer: 'overlay',
      name: 'Hub Sync',
    }]);
  }

  policyMarkers.push(['pm_inspect', {
    nodeId: 'NETGATE',
    type: 'inspect',
    color: '#fc6161',
    label: 'DPI',
    flowPathId: 'fp_private_app',
    layer: 'policy',
  }]);
  policyMarkers.push(['pm_allow', {
    nodeId: 'APPGATE',
    type: 'allow',
    color: '#deb146',
    label: 'ZTNA Allow',
    flowPathId: 'fp_private_app',
    layer: 'policy',
  }]);
  policyMarkers.push(['pm_log', {
    nodeId: 'PRIVEDGE',
    type: 'log',
    color: '#65aef9',
    label: 'Telemetry',
    flowPathId: 'fp_saas',
    layer: 'policy',
  }]);

  acts.push(
    { id: 'a1', label: 'Act 1 · Estate', color: '#b1b9be', intro: ['Reveal shared controls, hubs, and branches by region.'] },
    { id: 'a2', label: 'Act 2 · Overlay', color: '#01a982', intro: ['Turn on encrypted tunnels and hub-to-hub mesh.'] },
    { id: 'a3', label: 'Act 3 · Experience', color: '#65aef9', intro: ['Animate user traffic and render policy decisions on dedicated layers.'] },
  );

  const coreVisible = ['INTERNET', 'IDENTITY', 'NETGATE', 'APPGATE', 'PRIVEDGE', 'PRIVATE_APP', 'SAAS', 'internet_netgate', 'internet_appgate', 'id_netgate', 'netgate_appgate', 'netgate_privedge', 'appgate_private', 'appgate_saas', 'privedge_private'];
  steps.push({
    id: 'core-services',
    act: 'a1',
    name: 'Shared Service Plane',
    goal: 'Show the common internet, identity, security, and private application control points.',
    focus: ['NETGATE', 'APPGATE', 'PRIVEDGE', 'PRIVATE_APP', 'SAAS'],
    layerVisibility: { overlay: { opacity: 0 }, policy: { opacity: 0 } },
    phases: [
      { show: coreVisible, diff: 'Internet, identity, security gates, and private app fabric are online.' },
    ],
  });

  regionNodes.forEach((siteIds, idx) => {
    const regionShow = [`HUB${idx + 1}`, `hub${idx + 1}_netgate`, `hub${idx + 1}_appgate`, ...siteIds.flatMap(id => [id, `underlay_${id}`])];
    steps.push({
      id: `region-${idx + 1}`,
      act: 'a1',
      name: `Region ${idx + 1}`,
      goal: `Reveal hub ${idx + 1} and its directly attached branches.`,
      focus: [`HUB${idx + 1}`, ...siteIds.slice(0, Math.min(3, siteIds.length))],
      layerVisibility: { overlay: { opacity: 0 }, policy: { opacity: 0 } },
      phases: [
        { show: regionShow, diff: `Hub ${idx + 1} and ${siteIds.length} branches are connected to the internet underlay.` },
      ],
    });
  });

  const overlayIds = Object.keys(links).filter(id => id.startsWith('overlay_') || id.startsWith('backup_') || id.startsWith('hubmesh_'));
  steps.push({
    id: 'overlay-fabric',
    act: 'a2',
    name: 'Overlay Fabric',
    goal: 'Bring up branch-to-hub tunnels, backup paths, and inter-hub mesh.',
    focus: [...hubIds, ...spokeIds.slice(0, Math.min(4, spokeIds.length))],
    layerVisibility: { overlay: { opacity: 0.35 }, policy: { opacity: 0 } },
    phases: [
      { show: overlayIds, diff: 'Encrypted tunnels are established between spokes and hubs, with selective backup paths.' },
    ],
  });

  steps.push({
    id: 'app-experience',
    act: 'a3',
    name: 'Layered User Experience',
    goal: 'Show flow paths, enforcement points, and telemetry overlays for private and SaaS access.',
    focus: [spokeIds[0], hubIds[0], 'NETGATE', 'APPGATE', 'PRIVATE_APP', 'SAAS'],
    layerVisibility: { overlay: { opacity: 1 }, policy: { opacity: 1 } },
    phases: [
      { show: [], diff: 'Private app flow, SaaS breakout, and policy badges are rendered on dedicated overlay layers.' },
    ],
  });

  const data = {
    title,
    subtitle,
    viewBox: `0 0 ${width} ${height}`,
    phaseMs,
    drawDuration: 650,
    fadeDuration: 320,
    nodes,
    anchors: {},
    links,
    acts,
    steps,
    glossary,
    layers,
    flowPaths,
    policyMarkers,
    zones,
    persistentElements: [],
  };

  validateScenario(data, cfg);
  writeArtifacts(data, cfg);

  return {
    slug,
    nodeCount: Object.keys(nodes).length,
    linkCount: Object.keys(links).length,
    stepCount: steps.length,
    flowCount: flowPaths.length,
    policyCount: policyMarkers.length,
  };
}

function validateScenario(data, cfg) {
  const topo = new TopologyDesigner({ ghosting: true, blastRadiusHops: 3 });
  topo.fromJSON(data);
  const json = topo.toJSON();
  assert.equal(Object.keys(json.nodes).length, Object.keys(data.nodes).length, `${cfg.slug}: node count mismatch`);
  assert.equal(Object.keys(json.links).length, Object.keys(data.links).length, `${cfg.slug}: link count mismatch`);
  assert.equal(json.steps.length, data.steps.length, `${cfg.slug}: step count mismatch`);
  assert.equal(json.flowPaths.length, data.flowPaths.length, `${cfg.slug}: flow path mismatch`);
  assert.equal(json.policyMarkers.length, data.policyMarkers.length, `${cfg.slug}: policy marker mismatch`);

  const appPath = topo.validatePath('SPK01', 'PRIVATE_APP', { requireTypes: ['firewall'], forbidDirect: true });
  assert.equal(appPath.valid, true, `${cfg.slug}: expected a valid protected path from first spoke to private app`);

  const blast = topo.getBlastRadius('NETGATE', 2);
  assert(blast.has('APPGATE'), `${cfg.slug}: blast radius should include APPGATE`);
  assert(blast.has('PRIVATE_APP') || blast.has('PRIVEDGE'), `${cfg.slug}: blast radius should include downstream service nodes`);
}

function buildHtml(data, cfg) {
  const json = JSON.stringify(data, null, 2);
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>${cfg.title}</title>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../design-system/topology-ds.css">
  <style>
    html, body { margin: 0; padding: 0; height: 100%; background: #1d1f27; }
    #app { height: 100%; }
  </style>
</head>
<body>
<div id="app"></div>
<script src="../../design-system/topology-ds.js"></script>
<script src="../../design-system/core/graph.js"></script>
<script>
  const topologyData = ${json};
  const topo = new TopologyDesigner({ ghosting: true, blastRadiusHops: 3 });
  topo.fromJSON(topologyData).mount('app');
  topo.toggleIsometric(true);
</script>
</body>
</html>`;
}

function writeArtifacts(data, cfg) {
  fs.writeFileSync(path.join(OUT_DIR, `${cfg.slug}.json`), JSON.stringify(data, null, 2));
  fs.writeFileSync(path.join(OUT_DIR, `${cfg.slug}.html`), buildHtml(data, cfg));
}

const summary = SCENARIOS.map(buildScenario);
console.log(JSON.stringify(summary, null, 2));
