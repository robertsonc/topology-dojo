/**
 * Topology Design System — REST API Wrapper
 *
 * Exposes the TopologyDesigner engine as a RESTful API with
 * OpenAPI 3.0 documentation served via Swagger UI.
 *
 * Usage:  node api/server.js
 * Swagger: http://localhost:3000/api-docs
 */

const express = require('express');
const cors = require('cors');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const { v4: uuidv4 } = require('uuid');

// ── Headless shim: TopologyDesigner expects `window` / `matchMedia` ──
if (typeof window === 'undefined') {
  global.window = {
    matchMedia: () => ({ matches: false }),
  };
  global.document = {
    getElementById: () => null,
    createElementNS: () => ({ innerHTML: '', firstChild: null }),
  };
}

const TopologyDesigner = require('../design-system/topology-ds.js');

// ═══════════════════════════════════════════════════════════════
//  In-memory topology store
// ═══════════════════════════════════════════════════════════════
const store = new Map(); // topologyId -> TopologyDesigner instance
const storeMeta = new Map(); // topologyId -> { createdAt, updatedAt }
const TOPOLOGY_TTL_MS = Number(process.env.TOPOLOGY_TTL_MS || 24 * 60 * 60 * 1000);

function markTopology(id) {
  const now = Date.now();
  const meta = storeMeta.get(id) || { createdAt: now, updatedAt: now };
  meta.updatedAt = now;
  storeMeta.set(id, meta);
}

function pruneExpiredTopologies() {
  if (!Number.isFinite(TOPOLOGY_TTL_MS) || TOPOLOGY_TTL_MS <= 0) return;
  const now = Date.now();
  for (const [id, meta] of storeMeta) {
    if (now - meta.updatedAt > TOPOLOGY_TTL_MS) {
      store.delete(id);
      storeMeta.delete(id);
    }
  }
}

function getTopology(id) {
  pruneExpiredTopologies();
  const td = store.get(id);
  if (td) markTopology(id);
  return td;
}

function requireTopology(req, res) {
  const td = getTopology(req.params.topologyId);
  if (!td) {
    res.status(404).json({ error: 'Topology not found', id: req.params.topologyId });
    return null;
  }
  return td;
}

// ═══════════════════════════════════════════════════════════════
//  Express App
// ═══════════════════════════════════════════════════════════════
const app = express();

const CORS_ORIGINS = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map(origin => origin.trim())
  .filter(Boolean);
const JSON_BODY_LIMIT = process.env.API_BODY_LIMIT || '1mb';
const RATE_LIMIT_WINDOW_MS = Number(process.env.API_RATE_LIMIT_WINDOW_MS || 60_000);
const RATE_LIMIT_MAX = Number(process.env.API_RATE_LIMIT_MAX || 600);
const rateBuckets = new Map();

app.use((req, res, next) => {
  req.id = req.headers['x-request-id'] || uuidv4();
  res.setHeader('X-Request-Id', req.id);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const started = Date.now();
  res.on('finish', () => {
    console.log(JSON.stringify({
      level: res.statusCode >= 500 ? 'error' : 'info',
      msg: 'api_request',
      requestId: req.id,
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      durationMs: Date.now() - started,
    }));
  });
  next();
});

app.use(cors({
  origin(origin, callback) {
    if (CORS_ORIGINS.length === 0 || !origin || CORS_ORIGINS.includes(origin)) {
      return callback(null, true);
    }
    return callback(null, false);
  },
}));

app.use('/api', (req, res, next) => {
  if (!Number.isFinite(RATE_LIMIT_WINDOW_MS) || !Number.isFinite(RATE_LIMIT_MAX) || RATE_LIMIT_MAX <= 0) return next();
  const now = Date.now();
  const key = req.ip || req.socket?.remoteAddress || 'unknown';
  const bucket = rateBuckets.get(key) || { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
  if (now > bucket.resetAt) {
    bucket.count = 0;
    bucket.resetAt = now + RATE_LIMIT_WINDOW_MS;
  }
  bucket.count += 1;
  rateBuckets.set(key, bucket);
  res.setHeader('X-RateLimit-Limit', String(RATE_LIMIT_MAX));
  res.setHeader('X-RateLimit-Remaining', String(Math.max(0, RATE_LIMIT_MAX - bucket.count)));
  res.setHeader('X-RateLimit-Reset', String(Math.ceil(bucket.resetAt / 1000)));
  if (bucket.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ error: 'Too many requests', requestId: req.id });
  }
  next();
});

app.use('/api', (req, res, next) => {
  const apiKey = process.env.API_KEY;
  if (!apiKey || ['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const auth = req.get('authorization') || '';
  const bearer = auth.toLowerCase().startsWith('bearer ') ? auth.slice(7) : '';
  const supplied = req.get('x-api-key') || bearer;
  if (supplied !== apiKey) {
    return res.status(401).json({ error: 'Unauthorized', requestId: req.id });
  }
  next();
});

app.use(express.json({ limit: JSON_BODY_LIMIT }));

// ═══════════════════════════════════════════════════════════════
//  OpenAPI 3.0 Specification (via swagger-jsdoc)
// ═══════════════════════════════════════════════════════════════
const swaggerDefinition = require('./openapi-definition');

const swaggerSpec = swaggerJsdoc({
  definition: swaggerDefinition,
  apis: [__filename], // Read JSDoc annotations from this file
});

// Serve Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  customCss: '.swagger-ui .topbar { display: none }',
  customSiteTitle: 'Topology DS — API Docs',
}));

// Serve raw spec
app.get('/openapi.json', (req, res) => res.json(swaggerSpec));

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Topologies
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies:
 *   get:
 *     tags: [Topologies]
 *     summary: List all topologies
 *     responses:
 *       200:
 *         description: Array of topology summaries
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/TopologySummary'
 */
app.get('/api/topologies', (req, res) => {
  pruneExpiredTopologies();
  const list = [];
  for (const [id, td] of store) {
    list.push({
      id,
      title: td.title,
      subtitle: td.subtitle,
      nodeCount: td._nodes.size,
      linkCount: td._links.size,
      stepCount: td._steps.length,
    });
  }
  res.json(list);
});

/**
 * @openapi
 * /api/topologies:
 *   post:
 *     tags: [Topologies]
 *     summary: Create a new topology
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/TopologyConfig'
 *     responses:
 *       201:
 *         description: Created topology
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TopologySummary'
 */
app.post('/api/topologies', (req, res) => {
  const id = uuidv4();
  const td = new TopologyDesigner(req.body || {});
  store.set(id, td);
  markTopology(id);
  res.status(201).json({
    id,
    title: td.title,
    subtitle: td.subtitle,
    nodeCount: 0,
    linkCount: 0,
    stepCount: 0,
  });
});

/**
 * @openapi
 * /api/topologies/{topologyId}:
 *   get:
 *     tags: [Topologies]
 *     summary: Get full topology export (toJSON)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Full topology data
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TopologyExport'
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
app.get('/api/topologies/:topologyId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const data = td.toJSON();
  data.id = req.params.topologyId;
  res.json(data);
});

/**
 * @openapi
 * /api/topologies/{topologyId}:
 *   put:
 *     tags: [Topologies]
 *     summary: Replace entire topology (fromJSON)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/TopologyExport'
 *     responses:
 *       200:
 *         description: Updated topology
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TopologySummary'
 *       404:
 *         description: Topology not found
 */
app.put('/api/topologies/:topologyId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.fromJSON(req.body);
  res.json({
    id: req.params.topologyId,
    title: td.title,
    subtitle: td.subtitle,
    nodeCount: td._nodes.size,
    linkCount: td._links.size,
    stepCount: td._steps.length,
  });
});

/**
 * @openapi
 * /api/topologies/{topologyId}:
 *   delete:
 *     tags: [Topologies]
 *     summary: Delete a topology
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       204:
 *         description: Deleted
 *       404:
 *         description: Topology not found
 */
app.delete('/api/topologies/:topologyId', (req, res) => {
  pruneExpiredTopologies();
  if (!store.has(req.params.topologyId)) {
    return res.status(404).json({ error: 'Topology not found' });
  }
  store.delete(req.params.topologyId);
  storeMeta.delete(req.params.topologyId);
  res.status(204).send();
});

/**
 * @openapi
 * /api/topologies/import:
 *   post:
 *     tags: [Topologies]
 *     summary: Create topology from full JSON export
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/TopologyExport'
 *     responses:
 *       201:
 *         description: Imported topology
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TopologySummary'
 */
app.post('/api/topologies/import', (req, res) => {
  const id = uuidv4();
  const td = new TopologyDesigner();
  td.fromJSON(req.body);
  store.set(id, td);
  markTopology(id);
  res.status(201).json({
    id,
    title: td.title,
    subtitle: td.subtitle,
    nodeCount: td._nodes.size,
    linkCount: td._links.size,
    stepCount: td._steps.length,
  });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Nodes
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes:
 *   get:
 *     tags: [Nodes]
 *     summary: List all nodes
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Map of node ID to config
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties:
 *                 $ref: '#/components/schemas/NodeConfig'
 *       404:
 *         description: Topology not found
 */
app.get('/api/topologies/:topologyId/nodes', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(Object.fromEntries(td._nodes));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}:
 *   get:
 *     tags: [Nodes]
 *     summary: Get a single node
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     responses:
 *       200:
 *         description: Node config
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NodeConfig'
 *       404:
 *         description: Not found
 */
app.get('/api/topologies/:topologyId/nodes/:nodeId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const node = td._nodes.get(req.params.nodeId);
  if (!node) return res.status(404).json({ error: 'Node not found', id: req.params.nodeId });
  res.json(node);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}:
 *   put:
 *     tags: [Nodes]
 *     summary: Create or update a node
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/NodeConfig'
 *     responses:
 *       200:
 *         description: Node created/updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NodeConfig'
 */
app.put('/api/topologies/:topologyId/nodes/:nodeId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.node(req.params.nodeId, req.body);
  res.json(td._nodes.get(req.params.nodeId));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}:
 *   delete:
 *     tags: [Nodes]
 *     summary: Delete a node (and connected links)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     responses:
 *       200:
 *         description: Node deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: boolean }
 *                 removedLinks: { type: array, items: { type: string } }
 *       404:
 *         description: Node not found
 */
app.delete('/api/topologies/:topologyId/nodes/:nodeId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (td._graph) {
    const deleted = td._graph.removeNode(req.params.nodeId);
    if (!deleted) return res.status(404).json({ error: 'Node not found' });
    res.json({ deleted: true });
  } else {
    if (!td._nodes.has(req.params.nodeId)) {
      return res.status(404).json({ error: 'Node not found' });
    }
    td._nodes.delete(req.params.nodeId);
    res.json({ deleted: true });
  }
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}/neighbors:
 *   get:
 *     tags: [Nodes]
 *     summary: Get neighbor node IDs
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     responses:
 *       200:
 *         description: Neighbor node IDs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 nodeId: { type: string }
 *                 neighbors: { type: array, items: { type: string } }
 *                 degree: { type: integer }
 *       404:
 *         description: Not found
 */
app.get('/api/topologies/:topologyId/nodes/:nodeId/neighbors', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  if (!td._nodes.has(req.params.nodeId)) {
    return res.status(404).json({ error: 'Node not found' });
  }
  const neighbors = [...td._graph.getNeighbors(req.params.nodeId)];
  res.json({
    nodeId: req.params.nodeId,
    neighbors,
    degree: td._graph.degree(req.params.nodeId),
  });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}/blast-radius:
 *   get:
 *     tags: [Analysis]
 *     summary: Compute blast radius of a node failure
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     responses:
 *       200:
 *         description: Blast radius result
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BlastRadius'
 */
app.get('/api/topologies/:topologyId/nodes/:nodeId/blast-radius', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  const result = td._graph.blastRadius(req.params.nodeId);
  res.json({
    isolated: [...result.isolated],
    affected: [...result.affected],
  });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/nodes/{nodeId}/positions:
 *   put:
 *     tags: [Nodes]
 *     summary: Set node position keyframes for choreography animation
 *     description: |
 *       **Limited REST compatibility.** Position keyframes define where a node
 *       moves to at each step for smooth animation. This is a visual/choreography
 *       feature that only takes effect during DOM-based rendering.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/nodeId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/PositionKeyframes'
 *     responses:
 *       200:
 *         description: Keyframes applied
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 nodeId: { type: string }
 *                 keyframes: { $ref: '#/components/schemas/PositionKeyframes' }
 */
app.put('/api/topologies/:topologyId/nodes/:nodeId/positions', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._nodes.has(req.params.nodeId)) {
    return res.status(404).json({ error: 'Node not found' });
  }
  td.setNodePositions(req.params.nodeId, req.body);
  res.json({ nodeId: req.params.nodeId, keyframes: req.body });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Links
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/links:
 *   get:
 *     tags: [Links]
 *     summary: List all links
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Map of link ID to config
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties:
 *                 $ref: '#/components/schemas/LinkConfig'
 */
app.get('/api/topologies/:topologyId/links', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(Object.fromEntries(td._links));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/links/{linkId}:
 *   get:
 *     tags: [Links]
 *     summary: Get a single link
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/linkId'
 *     responses:
 *       200:
 *         description: Link config
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LinkConfig'
 *       404:
 *         description: Not found
 */
app.get('/api/topologies/:topologyId/links/:linkId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const link = td._links.get(req.params.linkId);
  if (!link) return res.status(404).json({ error: 'Link not found', id: req.params.linkId });
  res.json(link);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/links/{linkId}:
 *   put:
 *     tags: [Links]
 *     summary: Create or update a link
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/linkId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LinkConfig'
 *     responses:
 *       200:
 *         description: Link created/updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LinkConfig'
 */
app.put('/api/topologies/:topologyId/links/:linkId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.link(req.params.linkId, req.body);
  res.json(td._links.get(req.params.linkId));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/links/{linkId}:
 *   delete:
 *     tags: [Links]
 *     summary: Delete a link
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/linkId'
 *     responses:
 *       204:
 *         description: Deleted
 *       404:
 *         description: Not found
 */
app.delete('/api/topologies/:topologyId/links/:linkId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (td._graph) {
    if (!td._graph.removeLink(req.params.linkId)) {
      return res.status(404).json({ error: 'Link not found' });
    }
  } else {
    if (!td._links.has(req.params.linkId)) {
      return res.status(404).json({ error: 'Link not found' });
    }
    td._links.delete(req.params.linkId);
  }
  res.status(204).send();
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Anchors
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/anchors:
 *   get:
 *     tags: [Anchors]
 *     summary: List all anchors
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Map of anchor ID to position
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties:
 *                 $ref: '#/components/schemas/AnchorPosition'
 */
app.get('/api/topologies/:topologyId/anchors', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(Object.fromEntries(td._anchors));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/anchors/{anchorId}:
 *   get:
 *     tags: [Anchors]
 *     summary: Get an anchor
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/anchorId'
 *     responses:
 *       200:
 *         description: Anchor position
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AnchorPosition'
 *       404:
 *         description: Not found
 */
app.get('/api/topologies/:topologyId/anchors/:anchorId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const anchor = td._anchors.get(req.params.anchorId);
  if (!anchor) return res.status(404).json({ error: 'Anchor not found', id: req.params.anchorId });
  res.json(anchor);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/anchors/{anchorId}:
 *   put:
 *     tags: [Anchors]
 *     summary: Create or update an anchor
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/anchorId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AnchorPosition'
 *     responses:
 *       200:
 *         description: Anchor created/updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AnchorPosition'
 */
app.put('/api/topologies/:topologyId/anchors/:anchorId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.anchor(req.params.anchorId, req.body);
  res.json(td._anchors.get(req.params.anchorId));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/anchors/{anchorId}:
 *   delete:
 *     tags: [Anchors]
 *     summary: Delete an anchor (and connected links)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - $ref: '#/components/parameters/anchorId'
 *     responses:
 *       200:
 *         description: Anchor deleted with list of removed links
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: boolean }
 *                 removedLinks: { type: array, items: { type: string } }
 *       404:
 *         description: Not found
 */
app.delete('/api/topologies/:topologyId/anchors/:anchorId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._anchors.has(req.params.anchorId)) {
    return res.status(404).json({ error: 'Anchor not found' });
  }
  if (td._graph) {
    const removedLinks = td._graph.removeAnchor(req.params.anchorId);
    res.json({ deleted: true, removedLinks });
  } else {
    td.__anchors.delete(req.params.anchorId);
    res.json({ deleted: true, removedLinks: [] });
  }
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Acts
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/acts:
 *   get:
 *     tags: [Acts]
 *     summary: List all acts
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of acts
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 allOf:
 *                   - type: object
 *                     properties:
 *                       id: { type: string }
 *                   - $ref: '#/components/schemas/ActConfig'
 */
app.get('/api/topologies/:topologyId/acts', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(td._acts.map(a => ({
    id: a.id,
    label: a.label,
    color: a.color,
    intro: a.intro,
    stepCount: a.steps ? a.steps.length : 0,
  })));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/acts/{actId}:
 *   put:
 *     tags: [Acts]
 *     summary: Create or update an act
 *     description: |
 *       Acts are ordered; new acts are appended. Updating an existing act
 *       modifies it in place. **Note:** acts cannot be reordered via REST —
 *       use PUT on the full topology to reorder.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: actId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ActConfig'
 *     responses:
 *       200:
 *         description: Act updated
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/ActConfig' }
 *       201:
 *         description: Act created
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/ActConfig' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.put('/api/topologies/:topologyId/acts/:actId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const existing = td._acts.find(a => a.id === req.params.actId);
  if (existing) {
    Object.assign(existing, req.body, { id: req.params.actId });
    res.json(existing);
  } else {
    td.act(req.params.actId, req.body);
    res.status(201).json(td._acts[td._acts.length - 1]);
  }
});

/**
 * @openapi
 * /api/topologies/{topologyId}/acts/{actId}:
 *   delete:
 *     tags: [Acts]
 *     summary: Delete an act
 *     description: |
 *       Removes the act but does NOT remove its steps. Orphaned steps
 *       remain and can be reassigned to another act.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: actId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       204:
 *         description: Deleted
 *       404:
 *         description: Not found
 */
app.delete('/api/topologies/:topologyId/acts/:actId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const idx = td._acts.findIndex(a => a.id === req.params.actId);
  if (idx === -1) return res.status(404).json({ error: 'Act not found' });
  td._acts.splice(idx, 1);
  td._buildIndex();
  res.status(204).send();
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Steps
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/steps:
 *   get:
 *     tags: [Steps]
 *     summary: List all steps
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Ordered array of steps
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 allOf:
 *                   - type: object
 *                     properties:
 *                       id: { type: string }
 *                       index: { type: integer }
 *                   - $ref: '#/components/schemas/StepConfig'
 */
app.get('/api/topologies/:topologyId/steps', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(td._steps.map((s, i) => ({
    id: s.id,
    index: i,
    act: s.act,
    name: s.name,
    goal: s.goal,
    focus: s.focus,
    phases: s.phases ? s.phases.map(p => ({ show: p.show, diff: p.diff })) : [],
  })));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/steps/{stepId}:
 *   put:
 *     tags: [Steps]
 *     summary: Create or update a step
 *     description: |
 *       New steps are appended to the end. Existing steps are updated in place.
 *       **Note:** The `onRender` and `phase.custom` callback properties from the
 *       JS API are NOT supported — they require JavaScript functions which cannot
 *       be serialized over REST.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: stepId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/StepConfig'
 *     responses:
 *       200:
 *         description: Step updated
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/StepConfig' }
 *       201:
 *         description: Step created
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/StepConfig' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.put('/api/topologies/:topologyId/steps/:stepId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const existing = td._steps.find(s => s.id === req.params.stepId);
  if (existing) {
    Object.assign(existing, req.body, { id: req.params.stepId });
    td._buildIndex();
    res.json(existing);
  } else {
    td.addStep(req.params.stepId, req.body);
    td._buildIndex();
    res.status(201).json(td._steps[td._steps.length - 1]);
  }
});

/**
 * @openapi
 * /api/topologies/{topologyId}/steps/{stepId}:
 *   delete:
 *     tags: [Steps]
 *     summary: Delete a step
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: stepId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       204:
 *         description: Deleted
 *       404:
 *         description: Not found
 */
app.delete('/api/topologies/:topologyId/steps/:stepId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const idx = td._steps.findIndex(s => s.id === req.params.stepId);
  if (idx === -1) return res.status(404).json({ error: 'Step not found' });
  const step = td._steps[idx];
  td._steps.splice(idx, 1);
  // Remove from parent act's step list
  const act = td._acts.find(a => a.id === step.act);
  if (act && act.steps) {
    const actStepIdx = act.steps.findIndex(s => s.id === req.params.stepId);
    if (actStepIdx !== -1) act.steps.splice(actStepIdx, 1);
  }
  td._buildIndex();
  res.status(204).send();
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Glossary
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/glossary:
 *   get:
 *     tags: [Glossary]
 *     summary: Get glossary terms
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of glossary terms
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/GlossaryTerm'
 */
app.get('/api/topologies/:topologyId/glossary', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(td._glossary);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/glossary:
 *   put:
 *     tags: [Glossary]
 *     summary: Replace all glossary terms
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: array
 *             items:
 *               $ref: '#/components/schemas/GlossaryTerm'
 *     responses:
 *       200:
 *         description: Glossary updated
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/GlossaryTerm'
 */
app.put('/api/topologies/:topologyId/glossary', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.glossary(req.body);
  res.json(td._glossary);
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Analysis
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/analysis:
 *   get:
 *     tags: [Analysis]
 *     summary: Run full topology analysis
 *     description: |
 *       Identifies single points of failure, bridge links, isolated nodes,
 *       and disconnected components.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of findings
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/AnalysisFinding'
 *       501:
 *         description: Graph module not loaded
 */
app.get('/api/topologies/:topologyId/analysis', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  res.json(td._graph.analyze());
});

/**
 * @openapi
 * /api/topologies/{topologyId}/paths:
 *   get:
 *     tags: [Analysis]
 *     summary: Find shortest path between two nodes
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: from
 *         in: query
 *         required: true
 *         schema: { type: string }
 *       - name: to
 *         in: query
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Shortest path result
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PathResult'
 *       400:
 *         description: Missing from/to query parameters
 */
app.get('/api/topologies/:topologyId/paths', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'Missing "from" and "to" query parameters' });
  const path = td._graph.shortestPath(from, to);
  res.json({ from, to, path, length: path.length > 0 ? path.length - 1 : -1 });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/components:
 *   get:
 *     tags: [Analysis]
 *     summary: Find connected components
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of connected components (each an array of node IDs)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 count: { type: integer }
 *                 components:
 *                   type: array
 *                   items:
 *                     type: array
 *                     items: { type: string }
 */
app.get('/api/topologies/:topologyId/components', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  const comps = td._graph.connectedComponents().map(s => [...s]);
  res.json({ count: comps.length, components: comps });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/bridges:
 *   get:
 *     tags: [Analysis]
 *     summary: Find bridge links (single points of failure)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of bridge link IDs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 bridges: { type: array, items: { type: string } }
 */
app.get('/api/topologies/:topologyId/bridges', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  res.json({ bridges: td._graph.bridges() });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/articulation-points:
 *   get:
 *     tags: [Analysis]
 *     summary: Find articulation points (nodes whose removal disconnects the graph)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of articulation point node IDs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 articulationPoints: { type: array, items: { type: string } }
 */
app.get('/api/topologies/:topologyId/articulation-points', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  res.json({ articulationPoints: td._graph.articulationPoints() });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/bfs:
 *   get:
 *     tags: [Analysis]
 *     summary: Breadth-first search traversal from a node
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: start
 *         in: query
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: BFS traversal order
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 start: { type: string }
 *                 order: { type: array, items: { type: string } }
 */
app.get('/api/topologies/:topologyId/bfs', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  const { start } = req.query;
  if (!start) return res.status(400).json({ error: 'Missing "start" query parameter' });
  res.json({ start, order: td._graph.bfs(start) });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/subgraph:
 *   post:
 *     tags: [Analysis]
 *     summary: Extract a subgraph for the given node IDs
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [nodeIds]
 *             properties:
 *               nodeIds:
 *                 type: array
 *                 items: { type: string }
 *     responses:
 *       200:
 *         description: Extracted subgraph
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 nodes: { type: object, additionalProperties: { $ref: '#/components/schemas/NodeConfig' } }
 *                 links: { type: object, additionalProperties: { $ref: '#/components/schemas/LinkConfig' } }
 *                 anchors: { type: object, additionalProperties: { $ref: '#/components/schemas/AnchorPosition' } }
 */
app.post('/api/topologies/:topologyId/subgraph', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._graph) return res.status(501).json({ error: 'Graph module not loaded' });
  const { nodeIds } = req.body;
  if (!nodeIds || !Array.isArray(nodeIds)) {
    return res.status(400).json({ error: 'Request body must include nodeIds array' });
  }
  const sub = td._graph.subgraph(nodeIds);
  res.json({
    nodes: Object.fromEntries(sub.nodes),
    links: Object.fromEntries(sub.links),
    anchors: Object.fromEntries(sub.anchors),
  });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Playback (Limited REST compatibility)
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/playback:
 *   get:
 *     tags: [Playback]
 *     summary: Get current playback state
 *     description: |
 *       **Limited REST compatibility.** Playback is inherently stateful and
 *       time-based. This endpoint exposes the current step and mode, but
 *       real-time play/pause requires a WebSocket connection (not provided).
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Current playback state
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PlaybackState'
 */
app.get('/api/topologies/:topologyId/playback', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json({
    step: td.step,
    totalSteps: td._steps.length,
    playing: td.playing,
    mode: td.mode,
    speedMs: td.speedMs,
  });
});

/**
 * @openapi
 * /api/topologies/{topologyId}/playback:
 *   put:
 *     tags: [Playback]
 *     summary: Set playback state (step, mode)
 *     description: |
 *       **Limited REST compatibility.** Can set the current step number and mode,
 *       but continuous play/pause/animation timing cannot be driven via REST.
 *       The `playing` field is read-only in this context.
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               step: { type: integer, description: 'Jump to step number' }
 *               mode:
 *                 type: string
 *                 enum: [manual, auto, presenter]
 *               speedMs: { type: number }
 *     responses:
 *       200:
 *         description: Updated playback state
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/PlaybackState'
 */
app.put('/api/topologies/:topologyId/playback', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (req.body.step !== undefined) {
    td.step = Math.max(0, Math.min(req.body.step, td._steps.length));
  }
  if (req.body.mode) td.mode = req.body.mode;
  if (req.body.speedMs) td.speedMs = req.body.speedMs;
  res.json({
    step: td.step,
    totalSteps: td._steps.length,
    playing: td.playing,
    mode: td.mode,
    speedMs: td.speedMs,
  });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Export
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/export:
 *   get:
 *     tags: [Export]
 *     summary: Export topology as JSON (same as GET topology, explicit export intent)
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Full topology JSON
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TopologyExport'
 */
app.get('/api/topologies/:topologyId/export', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(td.toJSON());
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Meta / System
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/meta/node-types:
 *   get:
 *     tags: [Meta]
 *     summary: List all registered node types (built-in + plugins)
 *     responses:
 *       200:
 *         description: Array of node type names
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 nodeTypes: { type: array, items: { type: string } }
 */
app.get('/api/meta/node-types', (req, res) => {
  try {
    const types = TopologyDesigner.getRegisteredNodeTypes();
    res.json({ nodeTypes: types });
  } catch {
    // Fallback: return known built-in types
    res.json({
      nodeTypes: [
        'ec', 'switch', 'switchEnterprise', 'cloud', 'host', 'connector',
        'apps', 'saas', 'server', 'router', 'firewall', 'database',
        'idcard', 'ap', 'overlayCloud', 'text',
        'shapeArrow', 'shapeSquare', 'shapeRectangle', 'shapeTriangle',
        'shapeCircle', 'shapeEllipse', 'shapeDiamond', 'shapePentagon',
        'shapeHexagon', 'shapeStar', 'shapeCross',
      ],
    });
  }
});

/**
 * @openapi
 * /api/meta/link-types:
 *   get:
 *     tags: [Meta]
 *     summary: List all registered link types (built-in + plugins)
 *     responses:
 *       200:
 *         description: Array of link type names
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 linkTypes: { type: array, items: { type: string } }
 */
app.get('/api/meta/link-types', (req, res) => {
  try {
    const types = TopologyDesigner.getRegisteredLinkTypes();
    res.json({ linkTypes: types });
  } catch {
    res.json({
      linkTypes: ['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'],
    });
  }
});

/**
 * @openapi
 * /api/health:
 *   get:
 *     tags: [Health]
 *     summary: Health check
 *     description: |
 *       Returns a snapshot of service health and the count of topologies
 *       currently held in the in-memory store. Note that the in-memory store
 *       does not persist across restarts.
 *     responses:
 *       200:
 *         description: Service status
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/HealthStatus' }
 */
app.get('/api/health', (req, res) => {
  pruneExpiredTopologies();
  res.json({ status: 'ok', topologyCount: store.size });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Layers
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/layers:
 *   get:
 *     tags: [Layers]
 *     summary: List all layers
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Array of layer objects
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items: { $ref: '#/components/schemas/Layer' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.get('/api/topologies/:topologyId/layers', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(td._layers);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/layers/{layerId}:
 *   put:
 *     tags: [Layers]
 *     summary: Create or update a layer
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: layerId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Layer' }
 *     responses:
 *       200:
 *         description: Updated layer
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Layer' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.put('/api/topologies/:topologyId/layers/:layerId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.layer(req.params.layerId, req.body);
  const layer = td._layers.find(l => l.id === req.params.layerId);
  res.json(layer);
});

/**
 * @openapi
 * /api/topologies/{topologyId}/layers/{layerId}:
 *   delete:
 *     tags: [Layers]
 *     summary: Delete a layer
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: layerId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Layer deleted
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/DeleteResult' }
 *       404:
 *         description: Layer not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.delete('/api/topologies/:topologyId/layers/:layerId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  const idx = td._layers.findIndex(l => l.id === req.params.layerId);
  if (idx < 0) return res.status(404).json({ error: 'Layer not found', id: req.params.layerId });
  td._layers.splice(idx, 1);
  res.json({ deleted: req.params.layerId });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Flow Paths
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/flow-paths:
 *   get:
 *     tags: [FlowPaths]
 *     summary: List all flow paths
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Map of flow path entries keyed by ID
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties: { $ref: '#/components/schemas/FlowPath' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.get('/api/topologies/:topologyId/flow-paths', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(Object.fromEntries(td._flowPaths));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/flow-paths/{flowPathId}:
 *   put:
 *     tags: [FlowPaths]
 *     summary: Create or update a flow path
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: flowPathId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/FlowPath' }
 *     responses:
 *       200:
 *         description: Updated flow path
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/FlowPath' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.put('/api/topologies/:topologyId/flow-paths/:flowPathId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.flowPath(req.params.flowPathId, req.body);
  res.json(td._flowPaths.get(req.params.flowPathId));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/flow-paths/{flowPathId}:
 *   delete:
 *     tags: [FlowPaths]
 *     summary: Delete a flow path
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: flowPathId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Flow path deleted
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/DeleteResult' }
 *       404:
 *         description: Flow path not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.delete('/api/topologies/:topologyId/flow-paths/:flowPathId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._flowPaths.has(req.params.flowPathId)) {
    return res.status(404).json({ error: 'Flow path not found', id: req.params.flowPathId });
  }
  td._flowPaths.delete(req.params.flowPathId);
  res.json({ deleted: req.params.flowPathId });
});

// ═══════════════════════════════════════════════════════════════
//  ROUTES — Policy Markers
// ═══════════════════════════════════════════════════════════════

/**
 * @openapi
 * /api/topologies/{topologyId}/policy-markers:
 *   get:
 *     tags: [PolicyMarkers]
 *     summary: List all policy markers
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *     responses:
 *       200:
 *         description: Map of policy marker entries keyed by ID
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties: { $ref: '#/components/schemas/PolicyMarker' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.get('/api/topologies/:topologyId/policy-markers', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  res.json(Object.fromEntries(td._policyMarkers));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/policy-markers/{markerId}:
 *   put:
 *     tags: [PolicyMarkers]
 *     summary: Create or update a policy marker
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: markerId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/PolicyMarker' }
 *     responses:
 *       200:
 *         description: Updated policy marker
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PolicyMarker' }
 *       404:
 *         description: Topology not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.put('/api/topologies/:topologyId/policy-markers/:markerId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  td.policyMarker(req.params.markerId, req.body);
  res.json(td._policyMarkers.get(req.params.markerId));
});

/**
 * @openapi
 * /api/topologies/{topologyId}/policy-markers/{markerId}:
 *   delete:
 *     tags: [PolicyMarkers]
 *     summary: Delete a policy marker
 *     parameters:
 *       - $ref: '#/components/parameters/topologyId'
 *       - name: markerId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Policy marker deleted
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/DeleteResult' }
 *       404:
 *         description: Policy marker not found
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
app.delete('/api/topologies/:topologyId/policy-markers/:markerId', (req, res) => {
  const td = requireTopology(req, res);
  if (!td) return;
  if (!td._policyMarkers.has(req.params.markerId)) {
    return res.status(404).json({ error: 'Policy marker not found', id: req.params.markerId });
  }
  td._policyMarkers.delete(req.params.markerId);
  res.json({ deleted: req.params.markerId });
});

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err?.type === 'entity.too.large' ? 413 : (err?.status || err?.statusCode || 500);
  const publicMessage = status === 413
    ? 'Payload too large'
    : status === 400
      ? 'Invalid request'
      : 'Internal server error';
  console.error(JSON.stringify({
    level: 'error',
    msg: 'api_error',
    requestId: req.id,
    method: req.method,
    path: req.originalUrl,
    status,
    error: err?.message,
  }));
  res.status(status).json({ error: publicMessage, requestId: req.id });
});

// ═══════════════════════════════════════════════════════════════
//  Start Server
// ═══════════════════════════════════════════════════════════════
const PORT = process.env.PORT || 3000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Topology DS API running on http://localhost:${PORT}`);
    console.log(`Swagger UI:           http://localhost:${PORT}/api-docs`);
    console.log(`OpenAPI spec:         http://localhost:${PORT}/openapi.json`);
  });
}

module.exports = app;
