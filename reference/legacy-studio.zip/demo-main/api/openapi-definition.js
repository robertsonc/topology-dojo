/**
 * OpenAPI 3.0.3 definition shared between the Express server
 * and the static spec generator.
 */
module.exports = {
  openapi: '3.0.3',
  info: {
    title: 'Topology Design System API',
    version: '1.0.0',
    description:
      'RESTful API wrapper for the Topology Design System — a cinematic ' +
      'network topology visualization engine. Provides CRUD operations for ' +
      'topologies, nodes, links, anchors, acts, steps, and glossary terms, ' +
      'plus graph analysis endpoints. Includes opt-in API key authentication, ' +
      'per-IP rate limiting, topology TTL expiration, request ID correlation, ' +
      'and security response headers.',
    contact: { name: 'Topology DS Team' },
    license: { name: 'ISC' },
  },
  servers: [{ url: 'http://localhost:3000', description: 'Local dev' }],
  tags: [
    { name: 'Topologies', description: 'Topology lifecycle (create, list, get, delete)' },
    { name: 'Nodes', description: 'Network node CRUD' },
    { name: 'Links', description: 'Connection/link CRUD' },
    { name: 'Anchors', description: 'Invisible anchor point CRUD' },
    { name: 'Acts', description: 'Presentation act management' },
    { name: 'Steps', description: 'Choreography step management' },
    { name: 'Glossary', description: 'Glossary term management' },
    { name: 'Analysis', description: 'Graph analysis & algorithms' },
    { name: 'Playback', description: 'Playback state control (limited REST compat)' },
    { name: 'Export', description: 'Serialization & export' },
    { name: 'Layers', description: 'Visual layer management (physical, flow, policy)' },
    { name: 'FlowPaths', description: 'Animated overlay flow paths through the topology' },
    { name: 'PolicyMarkers', description: 'Policy action badges on nodes' },
    { name: 'Meta', description: 'Registered types & system info' },
    { name: 'Health', description: 'Service health and liveness checks' },
  ],
  components: {
    schemas: {
      Error: {
        type: 'object',
        properties: {
          error: { type: 'string' },
          id: { type: 'string' },
          requestId: { type: 'string', format: 'uuid', description: 'Correlates with the X-Request-Id response header' },
        },
        required: ['error'],
      },
      TopologyConfig: {
        type: 'object',
        properties: {
          title: { type: 'string', example: 'SD-WAN Network' },
          subtitle: { type: 'string', example: 'Branch Architecture' },
          viewBox: { type: 'string', example: '0 0 1050 700' },
          phaseMs: { type: 'number', example: 600 },
          drawDuration: { type: 'number', example: 0.7 },
          fadeDuration: { type: 'number', example: 0.55 },
          mode: { type: 'string', enum: ['manual', 'auto', 'presenter'], default: 'manual' },
          speedMs: { type: 'number', example: 4000 },
          routing: { type: 'boolean', default: true },
        },
      },
      TopologySummary: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          title: { type: 'string' },
          subtitle: { type: 'string' },
          nodeCount: { type: 'integer' },
          linkCount: { type: 'integer' },
          stepCount: { type: 'integer' },
        },
      },
      TopologyExport: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          subtitle: { type: 'string' },
          viewBox: { type: 'string' },
          phaseMs: { type: 'number' },
          drawDuration: { type: 'number' },
          fadeDuration: { type: 'number' },
          nodes: { type: 'object', additionalProperties: { $ref: '#/components/schemas/NodeConfig' } },
          anchors: { type: 'object', additionalProperties: { $ref: '#/components/schemas/AnchorPosition' } },
          links: { type: 'object', additionalProperties: { $ref: '#/components/schemas/LinkConfig' } },
          acts: { type: 'array', items: { $ref: '#/components/schemas/ActConfig' } },
          steps: { type: 'array', items: { $ref: '#/components/schemas/StepConfig' } },
          glossary: { type: 'array', items: { $ref: '#/components/schemas/GlossaryTerm' } },
        },
      },
      NodeConfig: {
        type: 'object',
        required: ['type', 'x', 'y'],
        properties: {
          type: {
            type: 'string',
            enum: [
              'ec', 'switch', 'switchEnterprise', 'cloud', 'host', 'connector',
              'apps', 'saas', 'server', 'router', 'firewall', 'database',
              'idcard', 'ap', 'overlayCloud', 'text',
              'shapeArrow', 'shapeSquare', 'shapeRectangle', 'shapeTriangle',
              'shapeCircle', 'shapeEllipse', 'shapeDiamond', 'shapePentagon',
              'shapeHexagon', 'shapeStar', 'shapeCross',
            ],
          },
          x: { type: 'number', example: 200 },
          y: { type: 'number', example: 300 },
          label: { type: 'string', example: 'Seattle DC' },
          sublabel: { type: 'string' },
          labelColor: { type: 'string', example: '#e6e8e9' },
          labelOffset: { type: 'number', example: 24 },
          labelY: { type: 'number' },
          color: { type: 'string', example: '#01a982' },
          variant: {
            type: 'string',
            enum: ['generic', 'virtual', 'physical', 'aws', 'azure', 'gcp', 'oracle'],
            description: 'EC node variant only',
          },
          vrrp: { type: 'string', enum: ['active', 'standby'] },
          sub1: { type: 'string', description: 'Cloud sub-label 1' },
          sub2: { type: 'string', description: 'Cloud sub-label 2' },
          innerClouds: { type: 'string', enum: ['both', 'left', 'right'] },
          managed: { type: 'boolean' },
          agent: { type: 'boolean' },
          spans: {
            type: 'array',
            items: { type: 'string' },
            description: 'Node IDs for overlayCloud spanning',
          },
          sideLabel: {
            type: 'object',
            properties: {
              x: { type: 'number' },
              y: { type: 'number' },
              label: { type: 'string' },
              sublabel: { type: 'string' },
              color: { type: 'string' },
              anchor: { type: 'string' },
            },
          },
          zoneIndicator: { type: 'string', enum: ['left', 'right'] },
          zoneLabel: {
            type: 'object',
            properties: {
              text: { type: 'string' },
              color: { type: 'string' },
            },
          },
        },
      },
      LinkConfig: {
        type: 'object',
        required: ['type', 'from', 'to'],
        properties: {
          type: {
            type: 'string',
            enum: ['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'],
          },
          from: { type: 'string', description: 'Source node or anchor ID' },
          to: { type: 'string', description: 'Destination node or anchor ID' },
          color: { type: 'string', example: '#01a982' },
          label: { type: 'string' },
          path: { type: 'string', description: 'Custom SVG path (flow type)' },
          labelPos: {
            type: 'object',
            properties: {
              x: { type: 'number' },
              y: { type: 'number' },
            },
          },
          dashed: { type: 'boolean' },
          dots: { type: 'boolean', default: true },
          fromLabel: { type: 'string', description: 'Port label at source' },
          toLabel: { type: 'string', description: 'Port label at destination' },
          sublabel: { type: 'string' },
          reason: { type: 'string', description: 'Reason for blocked link' },
        },
      },
      AnchorPosition: {
        type: 'object',
        required: ['x', 'y'],
        properties: {
          x: { type: 'number', example: 400 },
          y: { type: 'number', example: 250 },
        },
      },
      ActConfig: {
        type: 'object',
        required: ['label'],
        properties: {
          label: { type: 'string', example: 'Network Foundation' },
          color: { type: 'string', example: '#01a982' },
          intro: {
            type: 'array',
            items: { type: 'string' },
            description: 'Introduction lines shown at act start',
          },
        },
      },
      Phase: {
        type: 'object',
        properties: {
          show: {
            type: 'array',
            items: { type: 'string' },
            description: 'Element IDs to reveal',
          },
          diff: { type: 'string', description: 'Narrator text for this phase' },
        },
      },
      StepConfig: {
        type: 'object',
        required: ['act'],
        properties: {
          act: { type: 'string', description: 'Parent act ID' },
          name: { type: 'string', example: 'The Network' },
          goal: { type: 'string', description: 'Description of what this step shows' },
          focus: {
            type: 'array',
            items: { type: 'string' },
            description: 'Element IDs to spotlight (empty = all)',
          },
          phases: {
            type: 'array',
            items: { $ref: '#/components/schemas/Phase' },
          },
        },
      },
      GlossaryTerm: {
        type: 'object',
        required: ['t', 'd'],
        properties: {
          t: { type: 'string', description: 'Term', example: 'SD-WAN' },
          d: { type: 'string', description: 'Definition', example: 'Software-Defined WAN' },
        },
      },
      AnalysisFinding: {
        type: 'object',
        properties: {
          type: {
            type: 'string',
            enum: ['single-point-of-failure', 'bridge-link', 'isolated-node', 'disconnected-graph'],
          },
          severity: { type: 'string', enum: ['critical', 'warning', 'info'] },
          message: { type: 'string' },
          elements: { type: 'array', items: { type: 'string' } },
        },
      },
      BlastRadius: {
        type: 'object',
        properties: {
          isolated: { type: 'array', items: { type: 'string' }, description: 'Nodes completely cut off' },
          affected: { type: 'array', items: { type: 'string' }, description: 'Nodes with degraded connectivity' },
        },
      },
      PathResult: {
        type: 'object',
        properties: {
          from: { type: 'string' },
          to: { type: 'string' },
          path: { type: 'array', items: { type: 'string' } },
          length: { type: 'integer' },
        },
      },
      PlaybackState: {
        type: 'object',
        properties: {
          step: { type: 'integer' },
          totalSteps: { type: 'integer' },
          playing: { type: 'boolean' },
          mode: { type: 'string', enum: ['manual', 'auto', 'presenter'] },
          speedMs: { type: 'number' },
        },
      },
      PositionKeyframes: {
        type: 'object',
        additionalProperties: {
          type: 'object',
          properties: {
            x: { type: 'number' },
            y: { type: 'number' },
          },
        },
        description: 'Map of step number to {x, y} position',
        example: { '1': { x: 200, y: 300 }, '5': { x: 500, y: 300 } },
      },
      Layer: {
        type: 'object',
        description: 'A visual layer for organizing physical, flow, and policy elements',
        properties: {
          id: { type: 'string', description: 'Layer identifier' },
          name: { type: 'string', example: 'Physical Topology' },
          type: {
            type: 'string',
            enum: ['physical', 'flow', 'policy'],
            description: 'Layer category controlling default rendering treatment',
          },
          visible: { type: 'boolean', default: true },
          opacity: { type: 'number', minimum: 0, maximum: 1, default: 1 },
          locked: { type: 'boolean', default: false },
          color: { type: 'string', description: 'Layer accent color (hex)' },
          order: { type: 'number', description: 'Z-order; higher renders on top' },
        },
      },
      FlowPath: {
        type: 'object',
        description: 'An animated overlay path traced through the topology',
        properties: {
          id: { type: 'string', description: 'Flow path identifier' },
          name: { type: 'string' },
          waypoints: {
            type: 'array',
            items: { type: 'string' },
            description: 'Ordered node/anchor IDs the flow traverses',
          },
          color: { type: 'string', example: '#01a982' },
          animation: {
            type: 'string',
            enum: ['particles', 'dashed', 'pulse'],
            description: 'Animation style applied to the overlay',
          },
          speed: { type: 'number', description: 'Animation speed multiplier' },
          direction: {
            type: 'string',
            enum: ['forward', 'reverse', 'bidirectional'],
            default: 'forward',
          },
          width: { type: 'number', description: 'Stroke width in px' },
          opacity: { type: 'number', minimum: 0, maximum: 1 },
          label: { type: 'string' },
          layer: { type: 'string', description: 'Owning layer ID' },
        },
      },
      PolicyMarker: {
        type: 'object',
        description: 'A policy action badge attached to a node or flow path',
        required: ['nodeId', 'type'],
        properties: {
          id: { type: 'string', description: 'Marker identifier' },
          nodeId: { type: 'string', description: 'Host node ID for the marker' },
          type: {
            type: 'string',
            enum: ['inspect', 'allow', 'deny', 'redirect', 'encrypt', 'decrypt', 'nat', 'load-balance', 'log'],
            description: 'Policy action represented by the marker',
          },
          color: { type: 'string', description: 'Override accent color (hex)' },
          label: { type: 'string', description: 'Short text label shown on the badge' },
          flowPathId: {
            type: 'string',
            description: 'Optional flow path ID this marker is associated with',
          },
          layer: { type: 'string', description: 'Owning layer ID' },
        },
      },
      DeleteResult: {
        type: 'object',
        description: 'Standard 200 response for successful resource deletions',
        required: ['deleted'],
        properties: {
          deleted: { type: 'string', description: 'ID of the resource that was deleted' },
        },
      },
      HealthStatus: {
        type: 'object',
        description: 'Service health snapshot returned by GET /api/health',
        required: ['status'],
        properties: {
          status: { type: 'string', example: 'ok' },
          topologyCount: { type: 'integer', description: 'Number of topologies in the in-memory store' },
        },
      },
    },
    securitySchemes: {
      ApiKeyAuth: {
        type: 'apiKey',
        in: 'header',
        name: 'x-api-key',
        description: 'Set API_KEY env var to enable. Mutating methods (POST/PUT/DELETE) require this header or a Bearer token.',
      },
      BearerAuth: {
        type: 'http',
        scheme: 'bearer',
        description: 'Alternative to x-api-key — pass the same API_KEY value as a Bearer token.',
      },
    },
    parameters: {
      topologyId: {
        name: 'topologyId',
        in: 'path',
        required: true,
        schema: { type: 'string', format: 'uuid' },
        description: 'Topology UUID',
      },
      nodeId: {
        name: 'nodeId',
        in: 'path',
        required: true,
        schema: { type: 'string' },
        description: 'Node identifier',
      },
      linkId: {
        name: 'linkId',
        in: 'path',
        required: true,
        schema: { type: 'string' },
        description: 'Link identifier',
      },
      anchorId: {
        name: 'anchorId',
        in: 'path',
        required: true,
        schema: { type: 'string' },
        description: 'Anchor identifier',
      },
    },
  },
};
