#!/usr/bin/env node
/**
 * Generate a static openapi.json from the shared definition + JSDoc routes.
 * Usage: node api/generate-spec.js
 * Output: design-system/openapi.json
 */
const path = require('path');
const fs = require('fs');

// Headless shim
if (typeof window === 'undefined') {
  global.window = { matchMedia: () => ({ matches: false }) };
  global.document = {
    getElementById: () => null,
    createElementNS: () => ({ innerHTML: '', firstChild: null }),
  };
}

const swaggerJsdoc = require('swagger-jsdoc');
const definition = require('./openapi-definition');

const spec = swaggerJsdoc({
  definition,
  apis: [path.join(__dirname, 'server.js')],
});

const outPath = path.join(__dirname, '..', 'design-system', 'openapi.json');
fs.writeFileSync(outPath, JSON.stringify(spec, null, 2));
console.log(`OpenAPI spec written to ${outPath}`);
console.log(`  Paths: ${Object.keys(spec.paths).length}`);
console.log(`  Schemas: ${Object.keys(spec.components.schemas).length}`);
