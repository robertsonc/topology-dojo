# Topology Studio — QA / UAT Roadmap

Last updated: 2026-05-10

## Executive Summary

Topology Studio now behaves like **two products**:

1. **Core rendering engine / API**
2. **Interactive editor + viewer application**

The current automated coverage is strong on the engine side, but still underweight on **real browser workflows**. That mismatch is now the main QA risk.

Recent export/preview bugs proved the point: unit and jsdom tests were green while user-visible browser behavior was broken.

## Current State

### Passing coverage (as of 2026-05-10)
- **1756 tests passing** across **45 Vitest files** (up from 1,478 / 33)
- Coverage: **89% statements / 76% branches** overall, with engine modules at 97–98%:
  - `core/graph.js`: 98% stmt / 86% branch
  - `modules/layout-engine.js`: 98% / 87%
  - `modules/template-parser.js`: 97% / 93%
  - `modules/theme-engine.js`: 98% / 91%
  - `topology-ds.js`: 86% / 73% (largest file; remaining gaps in `importFromText` NLP edge paths and module-environment shims)
  - `api/server.js`: 90% / 67% (remaining gaps are catch blocks in `/api/meta/*` and the bottom-of-file `app.listen()` block)
- The OpenAPI spec test gate (`tests/openapi-spec.test.js`) **runs** under the
  Node test environment and covers schema/route consistency, $ref integrity,
  tag declarations, and the new Layer / FlowPath / PolicyMarker / DeleteResult
  / HealthStatus schemas (21 schemas, 35 paths).

### Passing coverage (historical baseline)
- **1478+ tests** (2026-04-06)
- **1198+ tests** (earlier baseline)
- **33 Vitest files**
- Strong coverage in:
  - Rendering primitives
  - Choreography / phase logic
  - Serialization (round-trip fidelity validated)
  - Theme/layout/template integration
  - Regression scenarios
  - UAT-oriented scenario tests
  - Presentation mode
  - Zone annotations
  - Link waypoints & orthogonal routing
  - Export paths (PNG, SVG, PDF, standalone HTML)
  - `removeNode()`, `removeLink()`, `off()` APIs
  - Dark/light theme toggle
  - Enterprise templates (SD-WAN, ZTNA, campus, data center, cloud, starter)
  - Mobile Safari compatibility fixes

### Remaining gaps
- Browser-first validation (Playwright) is not yet a release gate
- Full end-to-end editor → viewer → standalone → export round-trip needs Playwright coverage
- Mobile / WebKit browser automation not yet implemented
- Failure artifacts (trace/screenshots/downloads) are not first-class in the QA loop
- Accessibility automation (`aria-pressed` state on toggles, focus trap in
  modals, ARIA live region for step changes, reduced-motion) not yet covered
  by spec files
- Performance / scale tests (100+ nodes, 200+ links, render and export timing
  thresholds) not yet covered by spec files
- Several public APIs are exercised in code but lack dedicated, end-to-end
  Playwright coverage (see QA-MATRIX `◻` cells for the canonical list)

## North Star

QA should verify **what the user actually does**, not just what the engine internally computes.

That means:
- **Browser automation is mandatory**
- **Workflow tests beat implementation-detail tests**
- **Every export/import/share path gets end-to-end coverage**
- **Visual and interaction regressions are caught before release**

---

# Phase 1 — Browser Baseline (P0)

## Goal
Establish Playwright-driven browser validation as a required QA lane.

## Deliverables

### 1. Introduce a dedicated browser suite
Recommended structure:

```text
tests-e2e/
  editor-basic.spec.js
  export.spec.js
  viewer.spec.js
  import-export.spec.js
  choreography.spec.js
  mobile.spec.js
```

### 2. Gate critical workflows in browser

#### Editor
- Load editor successfully
- Create nodes and links
- Edit labels and properties
- Create acts / steps / phases
- Undo / redo
- Multi-select and alignment
- Zone creation / editing
- Save / load JSON

#### Viewer
- Load from editor handoff
- Navigate steps
- Auto-play / pause
- Presenter mode pause points
- Presentation mode (fullscreen, auto-advance, presenter notes) ← NEW
- Narrator show/hide
- Glossary open/close
- Dark/light theme toggle ← NEW

#### Export
- Export PNG downloads and is non-empty
- Export SVG downloads and contains expected labels / topology content
- Export PDF downloads and is structurally valid
- Preview as standalone opens and renders
- Export standalone HTML opens independently and replays correctly

### 3. Capture artifacts on every browser failure
Required artifacts:
- Screenshot
- Playwright trace
- Console log
- Downloaded files
- Standalone HTML payload when relevant

### 4. Add browser smoke tests to cron QA
Minimum browser smoke per scheduled QA run:
- Open editor
- Seed a simple topology
- Preview standalone
- Export PNG / SVG / PDF
- Verify viewer handoff

---

# Phase 2 — UAT Expansion (P1)

## Goal
Move from primitive validation to realistic authoring and presentation scenarios.

## Scenario packs

### Scenario Pack A — Authoring
- Greenfield topology creation from blank editor
- Drag/drop + property editing
- Timeline / choreography authoring
- Layer visibility changes
- Zone definition

### Scenario Pack B — Presentation
- Multi-act viewer playback
- Focus / blur correctness
- Narrator content correctness
- Act transitions and presenter pauses

### Scenario Pack C — Distribution
- Save as JSON → reload
- Editor → Viewer handoff
- Standalone preview → standalone export → open exported file
- Export PNG / SVG / PDF bundle

### Scenario Pack D — Interop
- Import JSON
- Import HTML
- draw.io XML import
- Round-trip fidelity after edits

## Representative UAT topologies
Maintain a stable set of canonical UAT fixtures:
- SD-WAN branch topology ← enterprise template available
- ZTNA user-to-app flow ← enterprise template available
- Campus network topology ← enterprise template available
- Data center topology ← enterprise template available
- Cloud architecture ← enterprise template available
- Firewall inspection / blocked flow
- Multi-layer physical + flow + policy diagram
- Executive multi-act presentation topology (with zones and waypoints)
- Dense topology stress case

---

# Phase 3 — Depth, Fidelity, and Confidence (P1/P2)

## 1. Visual regression snapshots
High-value pages only:
- Landing page
- Editor blank state
- Populated editor
- Viewer step 1 / mid / final
- Export samples
- Wizard / modal states
- Mobile layouts

## 2. Cross-browser coverage
Required:
- Chromium
- WebKit

Nice to add later:
- Firefox

## 3. Mobile browser automation
- Narrow viewport editor usability
- Touch target sanity
- Tap/drag interactions
- Viewer playback on mobile layout
- iPhone/Safari-specific regression coverage

## 4. Accessibility automation
- Keyboard-only navigation
- Focus visibility
- Modal focus trap
- Reduced-motion behavior
- ARIA sanity for interactive controls

## 5. Performance and scale tests
Stress topologies should measure:
- Initial render time
- Step transition latency
- Export completion time
- Standalone load time
- Behavior with 100+ nodes / 200+ links / large phase counts

---

# Coverage Priorities

## P0 — Must have
- Playwright smoke suite
- Export/download validation
- Standalone preview/export validation
- Editor → Viewer handoff tests
- Chromium + WebKit automation
- Trace/screenshot retention

## P1 — Next wave
- Scenario-based UAT packs
- Visual regression snapshots
- Mobile automation
- Round-trip fidelity tests
- Import pipeline coverage

## P2 — Scale / hardening
- Accessibility automation
- Performance thresholds
- Fuzz testing around import/export
- Long-session stability testing

---

# Recommended Test Policy

## Release gate
A change is not “green” unless all of these pass:
- Vitest suite
- Playwright browser smoke
- Export workflow checks
- Viewer round-trip checks

## Artifact policy
Every browser failure should produce enough evidence to debug without rerunning immediately.

## Test design rules
- Prefer user-visible behavior over implementation details
- Prefer stable workflows over brittle selector hacks
- Reuse canonical UAT fixtures instead of inventing ad hoc topologies
- Keep at least one browser smoke pack in cron at all times

---

# First Implementation Slice

## Proposed first PR after this roadmap
1. Add Playwright config for Chromium + WebKit
2. Add `tests-e2e/export.spec.js`
3. Add `tests-e2e/viewer.spec.js`
4. Add one seeded-editor helper
5. Wire smoke suite into cron QA output

## Initial browser smoke should cover
- Editor loads
- Simple topology seeded
- Viewer opens
- Standalone preview opens
- PNG export works
- SVG export works
- PDF export works

---

# Success Criteria

You know this roadmap worked when:
- Browser regressions stop slipping through “green” builds
- Export/share/viewer bugs get caught pre-merge
- QA runs produce actionable artifacts, not vague failures
- Mobile/WebKit regressions stop being surprises
- UAT reflects real customer/demo workflows rather than just engine correctness

---

# Coverage Surface Inventory (2026-05-10)

The matrix below is the authoritative cross-reference between the **Key
Concepts** in `CLAUDE.md` and the layers of automated coverage. It is updated
alongside QA-MATRIX whenever a new feature lands.

| Concept | Vitest | Playwright | OpenAPI | UAT fixture | User Manual |
|---|---:|---:|---:|---:|---:|
| Nodes | ✅ | ✅ | ✅ NodeConfig | ✅ | §4 |
| Links | ✅ | ✅ | ✅ LinkConfig | ✅ | §5 |
| Anchors | ✅ | ◻ | ✅ AnchorPosition | ✅ | §6, §56 |
| Acts | ✅ | ◻ | ✅ ActConfig | ✅ | §7 |
| Steps | ✅ | ✅ | ✅ StepConfig | ✅ | §7 |
| Phases | ✅ | ◻ | ✅ Phase | ✅ | §7 |
| Focus / Spotlight | ✅ | ✅ | n/a | ✅ | §9 |
| Zones | ✅ | ✅ | n/a (engine only) | ✅ | §41 |
| Waypoints | ✅ | ◻ | n/a (engine only) | ✅ | §40 |
| Layers | ✅ | ◻ | ✅ Layer **(new)** | ✅ | §37 |
| Flow Paths | ✅ | ✅ | ✅ FlowPath **(new)** | ✅ | §35 |
| Policy Markers | ✅ | ◻ | ✅ PolicyMarker **(new)** | ✅ | §36 |
| Presentation Mode | ✅ | ✅ | n/a | ✅ | §51 |
| Templates Gallery | ✅ | ✅ | n/a | ✅ | §53 |
| Dark/Light Theme | ✅ | ✅ | n/a | ✅ | §52 |
| Layout Edit Mode | ✅ | ◻ | n/a | ◻ | §50 |
| AI Assist | ✅ | ◻ | n/a (Worker) | ◻ | §48 |
| Analytics | ✅ | ◻ | n/a | ◻ | §49 |
| Standalone Export | ✅ | ✅ | n/a | ✅ | §47 |
| PNG / SVG / PDF Export | ✅ | ✅ | ✅ TopologyExport | ✅ | §38 |
| Health endpoint | ✅ | n/a | ✅ HealthStatus **(new)** | n/a | §55 |

`✅` = covered, `◻` = explicit gap with a row in QA-MATRIX, `n/a` = not applicable
in that layer (e.g. UI-only feature has no OpenAPI surface).

### Definition of "complete coverage"
A feature is **fully covered** for release-gate purposes when:
1. It has at least one Vitest test exercising the public API path.
2. It has either a Playwright spec, a manual UAT fixture, or an explicit `◻` in
   QA-MATRIX with a roadmap entry that references it.
3. It is described in USER-MANUAL.md with a code example.
4. If it is exposed via REST it has an `@openapi` JSDoc block on the route, the
   request/response bodies use named schemas (no inline schemas), and
   `tests/openapi-spec.test.js` covers the route + schema integrity.
