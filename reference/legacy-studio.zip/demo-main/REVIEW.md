# Topology Studio — Full Technical Review
**Date:** 2026-04-08  
**Reviewer:** Jerome C. Morrow (Lead Dev / SQA / UAT)  
**Scope:** Codebase, documentation, API, user manual, test suite, architecture, UX

---

## Executive Summary

Topology Studio is a genuinely impressive piece of software. It punches above its weight: a cinematic, interactive network topology presentation engine built in pure vanilla JS/SVG with zero runtime dependencies, rich choreography, a full visual editor, a REST API, a well-structured test suite, and thoughtful documentation.

**What's real and works:**
- 1,560 Vitest unit/integration tests — **100% pass** (all 35 files, confirmed live)
- E2E Playwright suite structured and substantive
- Core engine API is stable, well-documented, and well-tested
- REST API is complete with proper OpenAPI 3.0 spec
- Architecture docs are unusually self-aware and honest about limitations

**What's not yet solid:**
- One test file (`openapi-spec.test.js`) **fails to run** due to a module bundler environment mismatch — a broken release gate
- Dev dependencies were **not committed** to `package-lock.json` correctly — `npm install` only installs prod deps without `--include=dev`
- Playwright E2E is structurally complete but **not executable in CI** without browser install
- `other/TEST-COVERAGE-ANALYSIS.md` was written describing *zero* test coverage, but the codebase now has 1,560 tests — this document is stale and misleading
- Several security vulnerabilities in dependencies need patching
- Key architecture constraints are documented but have no mitigation roadmap items

---

## 1. Lead Developer Assessment

### Code Quality: **B+**

The core engine (`topology-ds.js` ~6,300 lines) is well-organized for its monolithic nature. The plugin system, lifecycle hooks, backward-compatible graph accessors, and serialization API are solid engineering. The SVG diffing engine is a smart optimization.

**Issues:**

**CRITICAL — Broken test gate:**
```
FAIL tests/openapi-spec.test.js
Error: No such built-in module: node:
```
`openapi-spec.test.js` imports `fs` and `path` as Node built-ins, but Vitest's environment is `jsdom` (browser). The test passes `require()` calls but Vite externalizes them, then the `node:` protocol prefix fails. This test currently runs **zero tests** and is silently counted as a "passed suite" at exit code 0. That means the OpenAPI spec consistency check — verifying all routes are documented and the static `openapi.json` matches — is **never actually run.**

Fix:
```js
// vitest.config.js — add environment override for the openapi test
test: {
  environmentMatchGlobs: [
    ['tests/openapi-spec.test.js', 'node']
  ]
}
```

**HIGH — `package.json` devDependency install issue:**
`npm install` (no flags) only installs production dependencies. `vitest`, `jsdom`, `@vitest/coverage-v8`, `@playwright/test`, and `serve` are `devDependencies` and are missing unless `--include=dev` is explicitly passed. In CI, this silently makes `npm test` fail with `vitest: not found`. The lock file is also missing dev tree entries. Fix: commit a proper lock file; ensure CI uses `npm ci` not `npm install`.

**MEDIUM — `removeNode` bypasses graph API:**
```js
removeNode(id) {
  if (this._graph) {
    this._graph.rawNodes.delete(id);  // Direct Map mutation
    for (const [linkId, linkCfg] of this._graph.rawLinks) {
      if (linkCfg.from === id || linkCfg.to === id) {
        this._graph.rawLinks.delete(linkId);  // Direct Map mutation
      }
    }
  }
}
```
This bypasses `TopologyGraph`'s adjacency index entirely. After `removeNode()`, the graph's adjacency structure is stale — neighbor queries, path queries, and blast radius analysis will return incorrect results until re-initialized. Fix: expose a `graph.removeNode()` method that updates adjacency.

**MEDIUM — `new Function()` usage in import path:**
The diagram-as-code (text import) parser uses `new Function()` for template evaluation. This is a documented concern in `ARCH_REVIEW.md`. It presents an XSS risk if user-supplied text ever reaches this code path via the REST API (e.g., maliciously crafted `importFromText` calls on the server). The REST API currently does not expose `importFromText` directly, but this is a landmine for future additions.

**LOW — 2 npm dependency vulnerabilities:**
- `brace-expansion <1.1.13` — moderate (process hang via ReDoS)
- `path-to-regexp 8.0.0-8.3.0` — **high** (ReDoS via sequential optional groups — this is in Express 5.x)

Fix: `npm audit fix`

**LOW — Stale documentation:**
`other/TEST-COVERAGE-ANALYSIS.md` describes a state of "zero test coverage" and was last updated 2026-03-13. The codebase now has 1,560 tests across 35 files. This document creates incorrect expectations for new contributors. It should be archived or rewritten as a historical baseline.

### Architecture: **B**

The self-authored `ARCHITECTURE-VISION.md` is one of the most honest architecture reviews I've seen a project write about itself. The six structural constraints (C1–C6) are accurately identified:

- **C1 (innerHTML string rendering)** — real ceiling on interactive fidelity, animation continuity
- **C2 (monolithic class)** — already partially mitigated by graph.js + modules/; needs continued extraction
- **C3 (no graph data model)** — partially solved by `core/graph.js`, but graph is not consistently used (see `removeNode` above)
- **C4 (linear choreography)** — `ROADMAP.md` has no Phase 5+ item addressing this
- **C5 (no reactive binding)** — acknowledged, no roadmap item
- **C6 (fixed coordinate system)** — acknowledged, no roadmap item

The phased extraction (physical layer → `core/graph.js`, algorithms → `modules/layout-engine.js`, themes → `modules/theme-engine.js`) is the right direction. The ARCH_REVIEW's proposed `model / commands / renderer / interaction / animation / io` decomposition should be tracked as a formal roadmap item, not just a vision document.

---

## 2. UI/UX Assessment

### Visual Design: **A**

The glassmorphism dark theme is polished and differentiated. The cinematic rendering quality (focus halos, ambient atmosphere, depth-of-field) is the product's strongest visual differentiator. Light theme is functional and complete.

### Interaction Design: **C+**

The UX Review (`design-system/UX-REVIEW.md`) is thorough and accurate. Confirming the most critical issues:

**P1 issues still present:**

1. **No visible overall progress indicator** — pips show phase-within-step, not step N/M. On mobile pips disappear entirely. A presenter doing a 14-step topology has no spatial awareness.

2. **Play/Pause button deflates when most critical** — the pause button loses its green gradient and becomes visually indistinct from other toolbar buttons when it should be the most prominent element.

3. **Toolbar cognitive overload** — 4 range sliders (phase delay, draw speed, fade, speed), 2 feature toggles, mode selector, glossary button, AI assist button, keyboard hints, mode indicator all rendered at equal visual weight in one row. New users cannot identify primary controls.

4. **Narrator collapse breaks on mobile** — user closes narrator, responsive breakpoint forces it back open, preference lost.

5. **Keyboard shortcuts undiscoverable** — raw text span `Space · ←/→ · Home/End · I · N` looks like debug output. `G`, `Escape`, editor-specific shortcuts missing.

**P2 issues:**

6. **Security mode has invisible UX** — toggling security mode shows a red border but no instruction. Click a node = blast radius analysis but there's zero affordance indicating this. Looks broken.

7. **Act collapse has no chevron** — no standard expand/collapse visual affordance.

8. **End-of-presentation is silent** — auto-play stops with no completion state. Dead moment in live demos.

**Editor-specific:**

9. **Editor toolbar has `data-structural` dimming in animate mode** — good pattern, but the mode toggle button label "Design / Animate" isn't intuitive for network engineers who don't think in animation terms. Consider "Build / Present" or "Edit / Preview."

10. **Properties panel requires double-click to open** — not discoverable. Single-click selection + auto-open panel would match modern editor conventions (Figma, Excalidraw).

### Mobile: **B-**

Mobile Safari fixes are in place and confirmed in test coverage. Touch targets enlarged. However:
- No swipe gesture for step navigation (documented gap)
- Mobile quick-edit mode is listed as "not yet started" in roadmap
- Narrator override on narrow breakpoint ignores user preference

### Accessibility: **C**

ARIA attributes exist on modals. Keyboard navigation is functional. Focus rings present. Reduced-motion respected. Gaps:
- Toggle buttons (`isometric`, `security`) lack `aria-pressed`
- No announced state changes when step advances (no ARIA live region on step counter)
- Color-only state differentiation in some UI elements (step row active state is green glow only)

---

## 3. Backend / API Assessment

### REST API: **A-**

The Express API (`api/server.js`) is well-designed:
- Full CRUD for topologies, nodes, links, anchors, acts, steps, layers, flow paths, policy markers
- Graph analysis endpoints (BFS, shortest path, components, blast radius, articulation points)
- Proper 404/400 error responses with consistent `{ error }` JSON body
- OpenAPI 3.0 spec fully annotated with JSDoc
- Swagger UI served at `/api-docs`
- Health endpoint

**Issues:**

**MEDIUM — In-memory store has no persistence:**
All topologies are stored in `const store = new Map()`. Server restart = all data lost. Fine for a demo/CI tool. Not acceptable for production use or any workflow where the server could restart. Needs documentation that explicitly calls this out, or a file-backed persistence option.

**MEDIUM — No input validation on node/link PUT:**
```js
app.put('/api/topologies/:topologyId/nodes/:nodeId', (req, res) => {
  td.node(nodeId, req.body);
  ...
```
`req.body` is passed directly to `td.node()`. No schema validation, no sanitization. Combined with the `new Function()` risk in `importFromText`, this is an avenue for server-side issues if the API is ever exposed publicly.

**LOW — `path-to-regexp` high-severity CVE in Express 5.x:**
Express 5 uses `path-to-regexp` 8.x which has a high-severity ReDoS vulnerability. Fix: `npm audit fix`

**LOW — Static `openapi.json` sync is manual:**
The spec is regenerated with `npm run api:spec`. The test that validates sync between live spec and static file is currently broken (see CRITICAL issue above). Until that's fixed, spec drift will go undetected.

### OpenAPI Spec: **A**

Schema coverage is thorough: `TopologyConfig`, `TopologyExport`, `NodeConfig`, `LinkConfig`, `AnchorPosition`, `ActConfig`, `StepConfig`, `Phase`, `GlossaryTerm`, `AnalysisFinding`, `BlastRadius`, `PathResult`, `PlaybackState`, `PositionKeyframes`, `Error`. All 40+ routes documented with summaries, tags, and response schemas.

---

## 4. SQA Assessment

### Test Suite Health

| Layer | Count | Status |
|---|---|---|
| Vitest unit/integration | 1,560 tests / 35 files | ✅ 100% pass |
| Vitest `openapi-spec.test.js` | 0 tests run | ❌ Broken — env mismatch |
| Playwright E2E | 9 spec files, ~200+ scenarios | ⚠️ Requires browser install |
| Coverage threshold | ≥75% on 5 key files | Not measured in this run |

### What the test suite covers well:
- Core engine registration API (node, link, anchor, act, step)
- Serialization round-trip (`toJSON`/`fromJSON`)
- All 9 link types and 18+ node types
- Choreography: phases, steps, acts, focus logic
- Layout algorithms (force-directed, hierarchical, circular, grid, magnetic north)
- Template system (7 templates + diagram-as-code parser)
- Theme engine (WCAG contrast, palette generation)
- REST API (all 40+ endpoints, error paths, edge cases)
- Import/export (PNG, SVG, PDF, standalone HTML)
- Enterprise templates (SD-WAN, ZTNA, campus, data center, cloud, starter)
- Presentation mode, dark/light theme toggle, zone annotations, link waypoints
- UAT scenario validation (73 scenario tests)

### Coverage gaps:
1. `openapi-spec.test.js` — zero tests actually execute due to env bug
2. SVG rendering snapshot tests — no visual regression baseline
3. `editor.html` JavaScript — editor state machine is entirely untested by Vitest (it's a browser-only file); coverage is exclusively Playwright
4. Undo/redo depth and branching — only 5 tests; the QA matrix shows many Playwright coverage gaps (◻) for undo/redo across link types, zones, steps
5. Autosave restore — explicitly marked ◻ in QA matrix
6. Step reorder — Playwright coverage marked ◻
7. `removeNode` adjacency correctness — no test validates graph state after node removal

### Test infrastructure issues:
- Playwright needs `npx playwright install` before first run — not documented in README
- No CI workflow file (`.github/workflows/`) exists in the repo — automated test runs are not wired up
- `npm test` fails with fresh `npm install` (dev deps issue noted above)

### Bug-to-test policy:
The QA matrix and QA-UAT-ROADMAP document this well. The "mutation family template" pattern (`assertUndoableMutation`) is a good pattern but not yet used consistently — `editor-undo-redo-mutations.test.js` has only 5 tests against what should be a comprehensive family.

---

## 5. UAT Assessment

### UAT Readiness: **C+**

The product is well-structured for UAT — 6 fixture files, 4 UAT spec files (authoring, presentation, distribution, interop), and 73 Vitest UAT validation tests.

**What's UAT-ready:**
- Fixture library covers real-world scenarios (SD-WAN branch, ZTNA user-to-app, firewall blocked flow, dense topology, executive multi-act)
- Playwright UAT specs cover the full authoring and presentation workflow
- Standalone HTML export produces self-contained files (verified)
- Viewer step navigation, auto-play, narrator all have Playwright coverage

**UAT blockers:**
1. **Playwright browsers not installed** — E2E tests cannot run without `npx playwright install chromium webkit`. This is not in the README.
2. **No CI gate** — There's no `.github/workflows/ci.yml`. UAT and Playwright suites don't automatically run on push/PR. Every "green" merge could be untested in browser.
3. **Glossary UAT is explicitly skipped** — `viewer.spec.js` has a `test.skip` for glossary open/close with a TODO. The seeded topology has no glossary terms so the button never renders.
4. **Mobile UAT is zero** — `other/QA-UAT-ROADMAP.md` lists mobile automation as Phase 3 but no spec file exists.

### Acceptance Criteria — Live Demo Readiness:

| Scenario | Ready? | Notes |
|---|---|---|
| Present a multi-act SD-WAN topology | ✅ | Fixture + Playwright coverage |
| Navigate steps with keyboard | ✅ | Covered in viewer.spec.js |
| Export standalone HTML for sharing | ✅ | Export spec validates content |
| Import existing topology JSON | ✅ | Round-trip validated |
| Draw.io import | ✅ | Covered in Vitest |
| Presentation mode (fullscreen, auto-advance) | ✅ | Vitest + Playwright coverage |
| Dark/light theme toggle | ✅ | Covered |
| Mobile Safari rendering | ✅ | Fixes in place, Vitest coverage |
| Glossary in viewer | ⚠️ | UAT explicitly skipped |
| Undo/redo comprehensive coverage | ⚠️ | Gaps in QA matrix |
| Mobile swipe navigation | ❌ | Not implemented |
| Auto-save restore | ⚠️ | No Playwright coverage |

---

## 6. Prioritized Findings

### 🔴 Critical / Fix Before Ship

| # | Finding | Area | Fix |
|---|---|---|---|
| C1 | `openapi-spec.test.js` runs 0 tests — broken release gate | SQA | Add `environmentMatchGlobs` in `vitest.config.js` |
| C2 | `npm install` without `--include=dev` skips all test tooling | DevOps | Fix lock file; document `npm ci` in README |
| C3 | No CI workflow — tests never auto-run | DevOps | Add `.github/workflows/ci.yml` |
| C4 | `path-to-regexp` high CVE in Express 5 dependency | Security | `npm audit fix` |

### 🟠 High / Fix in Next Sprint

| # | Finding | Area | Fix |
|---|---|---|---|
| H1 | `removeNode` bypasses graph adjacency index | Engine | Add `graph.removeNode()` that updates adjacency |
| H2 | No input validation on REST API node/link PUT | API | Add JSON schema validation (ajv or joi) |
| H3 | In-memory store loses all data on restart | API | Document limitation prominently; add optional file persistence |
| H4 | Playwright browsers not documented in README | SQA/Docs | Add setup section: `npx playwright install chromium webkit` |
| H5 | Play/Pause button loses prominence when active | UX | Retain green gradient + add pause icon in active state |
| H6 | Toolbar is overwhelming — no visual hierarchy | UX | Group controls into tiers; hide tuning sliders behind toggle |
| H7 | No overall progress indicator (Step N/M) | UX | Add counter label in toolbar; thin progress bar |

### 🟡 Medium / Planned Work

| # | Finding | Area | Fix |
|---|---|---|---|
| M1 | Glossary UAT test is skipped | SQA | Seed a topology with glossary terms in fixture |
| M2 | Undo/redo mutation family incomplete (5 tests vs needed ~40) | SQA | Expand `editor-undo-redo-mutations.test.js` |
| M3 | Security mode has no UX affordance | UX | Add instruction banner + crosshair cursor when active |
| M4 | Act collapse missing chevron | UX | Add ▸/▾ indicator |
| M5 | End-of-presentation is silent | UX | Add "Complete" state with Replay CTA |
| M6 | Stale `TEST-COVERAGE-ANALYSIS.md` | Docs | Archive or rewrite as historical baseline |
| M7 | `ARCHITECTURE-VISION.md` constraints have no roadmap items | Planning | Map C4/C5/C6 to Phase 5+ roadmap |
| M8 | `new Function()` in import path | Security | Replace with safe eval-free parser |
| M9 | `aria-pressed` missing on toggle buttons | Accessibility | Add to isometric + security toggles |

### 🟢 Low / Polish

| # | Finding | Area | Fix |
|---|---|---|---|
| L1 | Step row font size 8.5px (below readability threshold) | UX | Increase to 10px |
| L2 | Narrator collapse preference lost on mobile | UX | Respect collapse state across breakpoints |
| L3 | Keyboard shortcut list looks like debug output | UX | Replace with `?` modal |
| L4 | Mobile swipe navigation missing | UX | Add horizontal swipe on canvas |
| L5 | `brace-expansion` moderate CVE | Security | `npm audit fix` |
| L6 | `scrollTo() not implemented` spam in jsdom tests | SQA | Add `window.scrollTo = () => {}` in test setup |
| L7 | Properties panel requires double-click | UX | Consider single-click auto-open |

---

## 7. Recommended Immediate Actions (Ordered)

1. **`npm audit fix`** — patches the high CVE in Express right now, 2 minutes
2. **Fix `vitest.config.js`** — add `environmentMatchGlobs` to make openapi-spec.test.js actually run
3. **Fix `package-lock.json`** — run `npm install --include=dev` and commit the full lock file
4. **Add `.github/workflows/ci.yml`** — minimum: `npm ci`, `npm test`, `npx playwright install`, `npm run test:e2e:smoke`
5. **Add `npx playwright install` to README** — unblock anyone trying to run E2E tests
6. **Fix `removeNode` adjacency** — add `graph.removeNode()` method
7. **Add toolbar UX quick wins** — progress counter and play/pause prominence are both small CSS/HTML changes with high demo impact

---

## 8. Overall Verdict

This is a production-quality demo-grade product with a strong engine, solid test coverage, and honest self-documentation. The gaps are mostly DevOps scaffolding (CI, lock file, Playwright setup) and UX polish — not fundamental product problems.

**Readiness assessment:**

| Context | Verdict |
|---|---|
| Customer demo | ✅ Ready with minor UX fixes |
| Developer handoff | ⚠️ Fix CI + docs first |
| Production SaaS | ❌ Needs persistence, input validation, CI gate |
| Open source release | ⚠️ Fix the broken test gate and lock file first |

The product thesis is sound. The choreography model is genuinely differentiated. The architecture self-awareness is a strong signal the team knows what technical debt they're carrying.

---
*Review generated 2026-04-08 by Jerome C. Morrow*
