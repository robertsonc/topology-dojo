/**
 * Cloudflare Pages Function: /api/ai-assist
 *
 * Handles AI-assisted topology generation via Cloudflare Workers AI.
 * The AI binding (env.AI) is configured in the Cloudflare Pages dashboard
 * under Settings → Functions → AI Bindings (variable name: AI).
 *
 * Local dev note: When running with `wrangler pages dev`, the AI binding
 * requires a Cloudflare account. Without it, the function returns fallback:true
 * so the browser gracefully falls back to local keyword parsing.
 */

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

const SYSTEM_PROMPT = `You are a network topology generator. Given a plain English description, output ONLY valid JSON — no explanation, no markdown, no code fences.

The JSON must match this exact schema:
{
  "nodes": [
    { "id": "string", "type": "string", "label": "string", "x": number, "y": number }
  ],
  "links": [
    { "id": "string", "from": "string", "to": "string", "type": "string", "label": "string" }
  ]
}

Available node types: ec, switch, switchEnterprise, cloud, host, connector, apps, saas, server, router, firewall, database, idcard, ap, text
Available link types: line, tunnel, wireguard, flow, packet, blocked, wifi, poe, optical

Rules:
- Spread nodes across a 1050x700 viewBox (x: 50–1000, y: 50–650)
- Use meaningful IDs like "fw1", "sw1", "host1"
- Keep labels concise (1–4 words)
- Only output the JSON object, nothing else`;

/**
 * Attempt to extract a valid JSON object from the AI's raw text output.
 * Handles cases where the model wraps output in markdown fences.
 */
function extractJSON(raw) {
  if (!raw || typeof raw !== 'string') return null;

  // Strip markdown code fences if present
  const stripped = raw.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();

  // Try direct parse first
  try {
    return JSON.parse(stripped);
  } catch (_) {
    // Try to find the first {...} block
    const match = stripped.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch (_2) {
        return null;
      }
    }
    return null;
  }
}

/**
 * Validate that the parsed object has the expected shape.
 */
function validateTopology(obj) {
  if (!obj || typeof obj !== 'object') return false;
  if (!Array.isArray(obj.nodes) || !Array.isArray(obj.links)) return false;
  for (const n of obj.nodes) {
    if (!n.id || !n.type || typeof n.x !== 'number' || typeof n.y !== 'number') return false;
  }
  for (const l of obj.links) {
    if (!l.id || !l.from || !l.to) return false;
  }
  return true;
}

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

export async function onRequestGet(context) {
  const { env } = context;
  return new Response(JSON.stringify({
    status: 'ok',
    service: 'ai-assist',
    model: env.CF_AI_MODEL || '@cf/openai/gpt-oss-120b',
    aiBinding: !!env.AI,
  }), {
    status: 200,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;

  // Check AI binding is available
  if (!env.AI) {
    return new Response(
      JSON.stringify({ error: 'AI binding not configured', fallback: true }),
      {
        status: 200,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      }
    );
  }

  let prompt, debug;
  try {
    const body = await request.json();
    prompt = body?.prompt?.trim();
    debug = body?.debug === true;
  } catch (_) {
    return new Response(
      JSON.stringify({ error: 'Invalid JSON body', fallback: true }),
      {
        status: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      }
    );
  }

  if (!prompt) {
    return new Response(
      JSON.stringify({ error: 'prompt is required', fallback: true }),
      {
        status: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      }
    );
  }

  try {
    const model = env.CF_AI_MODEL || '@cf/openai/gpt-oss-120b';
    const aiResponse = await env.AI.run(model, {
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt },
      ],
      max_tokens: 2048,
      temperature: 0.3,
    });

    // Handle both Llama-style ({ response: '...' }) and OpenAI-style ({ choices: [{ message: { content: '...' } }] }) response formats
    const rawText =
      aiResponse?.response ??
      aiResponse?.result?.response ??
      aiResponse?.choices?.[0]?.message?.content ??
      aiResponse?.result?.choices?.[0]?.message?.content ??
      '';
    console.log('[ai-assist] aiResponse keys:', JSON.stringify(Object.keys(aiResponse || {})));
    console.log('[ai-assist] raw response (' + rawText.length + ' chars):', rawText.slice(0, 300));
    const parsed = extractJSON(rawText);

    if (!parsed || !validateTopology(parsed)) {
      const preview = rawText?.slice(0, 300) || '(empty)';
      console.error('[ai-assist] Invalid topology from AI:', preview);
      return new Response(
        JSON.stringify({ error: `Model output was not valid topology JSON`, rawOutput: preview, fallback: true }),
        {
          status: 200,
          headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        }
      );
    }

    const responsePayload = { nodes: parsed.nodes, links: parsed.links };
    if (debug) responsePayload._debug = { model, rawOutput: rawText };

    return new Response(JSON.stringify(responsePayload), {
      status: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('[ai-assist] Workers AI error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'AI call failed', fallback: true }),
      {
        status: 200,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      }
    );
  }
}
