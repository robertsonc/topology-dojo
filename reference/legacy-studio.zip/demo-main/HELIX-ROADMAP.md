# HELIX — Flow Intelligence Platform Roadmap

> **Code name:** HELIX
> **Metaphor:** Three strands (L1/L2 physical, L3 logical, L4-7 policy) wound around a single flow axis. Every packet leaves a triple-stranded trace; HELIX's job is to decode it.
> **Pivot:** Topology Studio (authoring tool) → HELIX (autonomous SNOC flow observability platform).

---

## 1. Strategic Framing

**Today:** Topology Studio is a world-class authoring engine — cinematic SVG rendering, choreography (acts/steps/phases), layered visualization (physical/flow/policy), and a nascent operational mode (`setTemporalMode`, `setElementState`) already sitting in `design-system/topology-ds.js:1252,1268`. It's built for humans crafting diagrams by hand or through diagram-as-code.

**Target:** A SNOC-facing Flow Intelligence Platform where a user types *"why is Finance-NYC's trade traffic to quant-db-01 dropping packets?"* and within seconds receives three choreographed, synchronized topologies (L1/L2 physical, L3 logical, L4-7 policy) decorated with hop-by-hop telemetry, ECMP fan-outs, and policy decision points — ready to screenshot into a forensic report.

The pivot is **not a rewrite**. The rendering engine, flow-path overlay system (`_flowPaths`), policy markers (`_policyMarkers`), layer visibility, and temporal twin mode are exactly the primitives a flow intelligence product needs. What's missing is the **data plane** that feeds them: discovery, flow lookup, path computation, telemetry aggregation, and automatic choreography generation from real traces. That's the roadmap.

---

## 2. Product Architecture Vision

```
┌─────────────────────────────────────────────────────────────┐
│  USER INTENT LAYER  (natural language | flow ID | 5-tuple)  │
├─────────────────────────────────────────────────────────────┤
│  HELIX FLOW INTELLIGENCE SERVICE                            │
│  ├─ Intent Parser (NL → structured query via LLM)           │
│  ├─ Endpoint Resolver (IPAM/DNS/identity)                   │
│  ├─ Path Tracer (routing + SDWAN fabric + SSE egress)       │
│  ├─ Telemetry Aggregator (per-hop loss/lat/jitter, ECMP)    │
│  └─ Layer Synthesizer (L1/L2, L3, L4-7 graph builders)      │
├─────────────────────────────────────────────────────────────┤
│  CONNECTOR MESH                                             │
│  SD-WAN Orch │ NetBox │ BGP/OSPF LSDB │ NetFlow/IPFIX       │
│  sFlow │ SNMP │ LLDP │ Firewall APIs │ SSE (Zscaler/Netskope│
│  /iboss) │ Kubernetes CNI │ Cloud VPC flow logs             │
├─────────────────────────────────────────────────────────────┤
│  TOPOLOGY STUDIO RENDERING CORE  (today's codebase)         │
│  topology-ds.js • choreography • focus • temporal twin      │
│  flow paths • policy markers • layered views                │
└─────────────────────────────────────────────────────────────┘
```

The existing codebase becomes the **presentation tier** of a multi-tier system. Everything above it is new.

---

## 3. The Workflow (North Star UX)

A single command bar is the entire UI for 90% of operators:

```
> trace finance-nyc-wks-042 → trading-db.internal now
> trace flow 0x8fa21c3e
> trace 10.14.22.17:51422 → 10.88.4.9:5432 tcp last 15m
> why is Sarah's Teams call dropping?
```

**System response (target: < 8 seconds):**

1. **Resolution card** — endpoints identified, site/VRF/identity annotated.
2. **Three synchronized topologies** appear in a 3-pane cinematic layout:
   - **L1/L2 Physical** — cables, switches, ports, patch panels, optical hops
   - **L3 Logical** — routed hops with AS/VRF boundaries, ECMP fan-outs
   - **L4-7 Policy** — firewall rules hit, SD-WAN business intent matched, SSE inspection, NAT, WAF verdict
3. **Choreographed playback** — auto-generated act sequence walks the operator hop-by-hop, highlighting the worst-performing segment first (the *anomaly-first narrator*).
4. **Live telemetry overlay** — per-hop latency, jitter, loss, ECMP distribution, plus three delay buckets: server↔network, network↔network, client↔network.
5. **Forensic artifact** — one click exports a signed, timestamped PDF + standalone HTML + JSON evidence bundle.

---

## 4. Roadmap — Six Phases

### Phase 0 — Foundation Hardening (prerequisite)

Close critical findings from `REVIEW.md` before adding automation:

- **C3** in `ARCHITECTURE-VISION.md`: fully integrate `design-system/core/graph.js` `TopologyGraph` with the rendering engine. Flow intelligence lives in graph operations — adjacency, shortest-path, ECMP, blast radius — and the flat Map storage has to go.
- Persistent backing store for `api/server.js` (replace in-memory Map → Postgres + Redis for hot path).
- REST input validation + authZ (operator RBAC; HELIX carries sensitive routing info).
- Fix broken `openapi-spec.test.js` and add CI (missing `.github/workflows/`).
- Upgrade Express / `path-to-regexp` CVE.

**Exit criteria:** rendering core is addressable as a service, graph model is authoritative, CI is green.

### Phase 1 — Discovery & Inventory ("what exists")

New `connectors/` directory, pluggable provider pattern:

- `connectors/netbox.js` — source-of-truth inventory (sites, racks, devices, cables, interfaces, IPs)
- `connectors/lldp-collector.js` — real-time neighbor graph (gNMI/SNMP/SSH fallback)
- `connectors/sdwan-orchestrator.js` — promote `sdwan-expert-skill/topology-map/SKILL.md` from designed-but-undeployed to a first-class connector. It already maps appliances/tunnels/overlays/BIOs to the node/link vocabulary.
- `connectors/cloud-vpc.js` — AWS/Azure/GCP VPC topology
- `connectors/k8s-cni.js` — Cilium Hubble / Calico for pod-level paths

**Unified Inventory Graph** — canonical internal model fed by all connectors, deduped by `(site, mgmt-ip, serial)`. Substrate every subsequent phase queries. Delta sync via webhooks/streaming.

**UX deliverable:** "Network Explorer" panel — a live, always-current inventory browser built on the existing editor chrome.

### Phase 2 — Routing & Forwarding Intelligence ("how packets move")

Compute the *actual* forwarding path the network would take right now — not a model of it.

- **RIB/FIB Ingestion:** BGP via BMP (preferred) or scraping fallback; OSPF/IS-IS LSDB parsing; static + PBR; EVPN/VXLAN type-2/type-5 → L2 stretch visualization.
- **ECMP Resolver:** given a 5-tuple, compute which of N equal-cost paths the hash function selects — and show other candidates dimmed for "what-if" context.
- **SD-WAN Path Logic:** orchestrator query for active business-intent overlay, bonded tunnel selection, brownout state, regional breakout. First-class `sdwanPath` decoration on the flow.
- **SSE / ZTNA Egress Path:** Zscaler / Netskope / Cloudflare / Palo Prisma / HPE SSE integration. L4-7 layer shows inspection chain (SSL decrypt → DLP → URL filter → CASB → re-encrypt → origin).

**UX deliverable:** "Trace this" button on any two endpoints. Output: static 3-layer diagram of the path — no telemetry yet, just correctness.

### Phase 3 — Flow Resolution & Intent Parsing ("what the operator meant")

- **5-tuple mode:** straight to Phase 2.
- **SD-WAN flow ID mode:** orchestrator's flow cache → 5-tuple + overlay + business intent → Phase 2.
- **Natural language mode:** `functions/api/ai-assist.js` graduates. Replace "generate topology from scratch" LLM call with structured extraction:
  - **In:** *"why is Finance-NYC's trade traffic to quant-db-01 dropping packets?"*
  - **Out:** `{src: {identity: "Finance-NYC*"}, dst: {hostname: "quant-db-01"}, app: "trading", concern: "loss", window: "now"}`
  - Then: identity → AD/Okta → workstation IPs; hostname → DNS/CMDB → server IP; app → port range; concern → prioritize loss in the anomaly narrator.
- **Endpoint Resolver Service:** IPAM + DNS + AD + MDM + CMDB fan-out. Handles ambiguity (ranked list; operator picks if confidence < threshold).

Existing Cloudflare AI binding and `.claude/skills/topology-editor.md` already demonstrate the LLM plumbing — repoint the prompt target.

### Phase 4 — Hop-by-Hop Telemetry Aggregation ("how is it performing")

- **Collectors:** NetFlow v9 / IPFIX / sFlow; gNMI/gRPC streaming for interface counters/queue depth/drops; synthetic probes (ThousandEyes / Catchpoint / iperf agents); RUM / client beacons; APM / kernel `ss -i` for server-side TCP RTT.
- **Per-Hop Attribution Engine:** timestamp-aligned correlation; jitter/loss/latency stacking per segment; ECMP hash attribution (which flow on which member link); brownout detection (p95/p99 vs 7-day baseline).
- **Three-Zone Delay Model** (directly answers the spec):
  - **Client→Network:** RUM + first-hop ingress timestamps
  - **Network→Network:** per-router/per-tunnel residence time
  - **Server→Network:** server NIC ingress → application accept
  - Each rendered as a distinct visual band on the flow path overlay.

`setElementState(elementId, {latency, jitter, loss})` in `topology-ds.js:1268` is already wired. Work is upstream aggregation, not rendering plumbing.

### Phase 5 — Layer Synthesis & Automatic Choreography ("make it beautiful")

This is where the current codebase shines and HELIX makes it cinematic.

- **`design-system/modules/layer-synthesizer.js`** (new):
  - **L1/L2 Physical:** filter inventory to physical devices + cables along the path. `magneticNorth` layout biased by rack/row coordinates from NetBox. Annotate optics, cable length, patch panels.
  - **L3 Logical:** collapse L2 domains into VRF/subnet clouds. Routed hops, BGP AS boundaries, ECMP fan-outs as multi-line flow links with width proportional to hash weight.
  - **L4-7 Policy:** abstract transport entirely. Security zones, firewall rule hits (reuse `_policyMarkers` at `topology-ds.js:155`), SD-WAN business intent chevrons, SSE inspection pipeline, NAT, LB VIPs.
- **Synchronized 3-Pane Layout:** new `design-system/viewer.html` mode — three canvases sharing a single step cursor. Advancing choreography in one pane advances all three. Hover a hop in L3 → highlights physical realization in L1 and policy decision in L4-7.
- **`generateTraceChoreography(trace, telemetry)`** — produces acts/steps/phases from real data:
  - **Act 1** "Endpoints" — reveal client + server with identity badges
  - **Act 2** "Path" — walk hop-by-hop along the worst layer first
  - **Act 3** "Policies Hit" — focus each firewall/SSE/SDWAN decision in sequence
  - **Act 4** "Performance" — heatmap reveal across the whole path
  - **Act 5** "Verdict" — healthy / degraded / broken + root cause
- **Anomaly Narrator:** LLM-generated SRE-style notes. *"Hop 3 — the Ashburn spine — is showing 4.2% loss, 11x the 7-day baseline; ECMP hash lands 80% of this flow on Eth5/1 which is queue-saturated."*

The "Semantic Choreography" T1 vision in `other/ARCHITECTURE-VISION.md` is exactly this, grounded in real trace data.

### Phase 6 — SNOC Workflows & Forensic Artifacts ("operationalize it")

- **Evidence Bundles:** one-click export of PDF + standalone HTML + JSON + raw telemetry sample, cryptographically signed and timestamped. Existing standalone HTML exporter + forensic mode embedding signed evidence.
- **Diff Over Time:** *"trace this flow now vs last Tuesday at 3pm"* — choreography gains a dissolve transition between two temporal snapshots. Extends design/operational/incident temporal modes already in place.
- **Continuous Watch:** pin a flow to a dashboard; telemetry streams in, diagram self-updates. SOC sees a ZTNA deny in real-time with full L1-L7 context.
- **Incident Timeline:** given a PagerDuty/Opsgenie incident window, auto-pick top-N degraded flows and generate traces. Ready-made forensic packet for every incident.
- **Audit Trail:** every trace logged with operator identity, query, resolved 5-tuple, endpoints, policies. SOC2 / PCI artifact.
- **API for Automation:** `POST /api/v1/traces` accepting any of the three input modes, returning full three-layer topology JSON + signed bundle URL. Embed in Slack alerts, Jira tickets, runbooks.

---

## 5. Visual Design Principles for SNOC

The brief: *beautiful as it is useful, immediately intelligible, visually interesting.* Concrete principles:

- **One anomaly, one color.** Worst-performing hop gets a single accent hue (existing focus halo). Everything else desaturated. Find the problem in under 2 seconds.
- **Layered synchronization is the killer feature.** Three topologies must feel like one object rotated through three lenses. Shared step cursor, shared hover state, shared color identity per entity.
- **Telemetry as texture, not text.** Jitter → link wiggle amplitude (existing SVG blur filter). Loss → particle dropout frequency on flow paths. Latency → particle speed. ECMP → parallel flow strands with weighted opacity. Operators *feel* state before they read a number.
- **Density hierarchy.** L4-7 sparser than L3 sparser than L1. Each layer answers a different question; don't pollute the policy narrative with cable clutter.
- **Dark mode is the default.** Existing glassmorphism dark theme is already correct for a 24/7 ops floor.
- **Screenshot-ready.** Every frame of the auto-choreography is print-quality. Forensic reports get pasted into PDFs and court documents.

---

## 6. Key Technical Bets

| Bet | Rationale |
|---|---|
| Graph model becomes authoritative (`design-system/core/graph.js`) | Flow intelligence is graph-theoretic: paths, ECMP, blast radius, adjacency. Flat Map storage is a dead end. |
| Connector mesh with uniform internal model | Every vendor has a different API; HELIX's value is normalization. Plugin architecture isolates vendor churn. |
| Structured LLM extraction, not LLM rendering | LLMs translate intent → query. Deterministic code handles routing, rendering, telemetry. Auditable. |
| Reuse the rendering core, extend it via data | Choreography, focus, temporal twin, flow paths, policy markers already exist. Adding a data plane is 10x cheaper than rewriting the view. |
| Anomaly-first narration | SNOC attention is scarce. Choreography must lead with the problem, not recapitulate the topology. |

---

## 7. Concrete First Sprint (what to build Monday)

Thin end-to-end slice to de-risk the vision:

1. Promote `sdwan-expert-skill/topology-map/SKILL.md` to a live connector. Deploy against a test fabric. Replace its "generate choreography" step with a real per-flow trace on a single hardcoded 5-tuple.
2. Add `POST /api/v1/trace` to `api/server.js` accepting `{srcIP, dstIP, srcPort, dstPort, proto}`. Stub returns hand-crafted JSON.
3. Build `generateThreeLayerTopology(trace)` taking the stub and emitting three `topology-ds.js` node/link configs.
4. Build `viewer-3pane.html` — three synchronized viewers sharing a step cursor.
5. Add synthetic telemetry to the stub (fake latency/jitter/loss per hop) and verify it feeds `setElementState` correctly.
6. Demo the thin slice to a SNOC engineer. Iterate on the workflow before wiring real collectors.

This proves the rendering bet and surfaces UX questions before the backend investment.

---

## 8. What HELIX Says No To

To keep the product sharp, HELIX explicitly does **not** chase:

- **General-purpose diagram authoring.** The existing editor stays for power users but is no longer the primary UX. Lucidchart is not the competition — **ThousandEyes, Kentik, NetBrain, Forward Networks, and Augtera are.**
- **Config management / change automation.** Read-only observability only. Ansible stays minimal. HELIX is not a NetOps controller.
- **Real-time multi-user collaborative editing** (Phase 5 in existing `ROADMAP.md`). SNOC users want correctness and speed, not Figma-style co-presence.
- **Mobile-first authoring.** SNOC is 40-inch dashboards and three-monitor workstations. Keep responsive viewer, drop mobile editor investment.

---

## 9. Success Metrics

| Metric | Target |
|---|---|
| **Time-to-diagnosis** (operator query → 3-layer diagram with root cause highlighted) | < 10s P50, < 30s P95 |
| **Attribution accuracy** (auto-identified worst hop matches analyst judgment) | > 90% |
| **Coverage** (production flows traceable end-to-end, no blind segments) | > 95% within 6 months |
| **Forensic adoption** (SOC/NOC tickets including a HELIX evidence bundle) | > 50% within 12 months |
| **Beauty-as-utility** (SNOC engineer NPS on diagram quality for incident reviews) | > 60 |

---

## Closing

The existing Topology Studio codebase is an unusually strong foundation for HELIX — most network observability vendors would kill for its rendering and choreography system. The roadmap's thesis: **preserve the view tier, build the data tier underneath it, and let the automatic choreography generator make real traces feel as cinematic as the hand-authored demos feel today.**

Three strands. One flow. Every packet leaves a triple-stranded trace, and HELIX decodes it.

The biggest risk is not technical — it's staying disciplined about the workflow. Every feature must make the operator's command-bar query faster, more accurate, or more forensically valuable. If a feature doesn't, it belongs in a different product.

**Next concrete step:** a one-week spike on the Section 7 thin slice, using the existing SD-WAN fabric as the first connector, validating the three-pane synchronized viewer with a real SNOC engineer before committing to the full connector mesh investment.
