# Project: Topology Studio

A cinematic network topology visualization engine with step-by-step choreography. Pure vanilla JavaScript + SVG + CSS — no build tools, no dependencies.

## Project Structure

- `design-system/topology-ds.js` — Core rendering engine (~6600 lines, declarative node/link/step API)
- `design-system/topology-ds.css` — Theme, animations, glassmorphism styles (dark/light theme support)
- `design-system/editor.html` — Visual drag-and-drop editor for building topologies
- `design-system/viewer.html` — Lightweight read-only topology viewer
- `design-system/core/graph.js` — Graph data model (adjacency, paths, analysis, blast radius)
- `design-system/modules/layout-engine.js` — Auto-layout algorithms (8 algorithms + overlap removal)
- `design-system/modules/template-parser.js` — Diagram-as-code parser + built-in templates
- `design-system/modules/theme-engine.js` — Color theme system with WCAG contrast checking
- `design-system/modules/iso3d-nodes.js` — Isometric 3D node plugin (iso:box, iso:server, iso:rack, etc.)
- `design-system/USER-MANUAL.md` — Comprehensive API documentation
- `design-system/index.html` — SD-WAN/ZTNA demo topology
- `design-system/demo-templates.html` — Template gallery showcase
- `api/server.js` — Express REST API (~1900 lines, 52 endpoints, opt-in API key auth, per-IP rate limiting, topology TTL expiration)
- `api/openapi-definition.js` — OpenAPI 3.0.3 spec definition (~417 lines)
- `functions/api/ai-assist.js` — Cloudflare Worker for AI topology generation
- `other/` — Additional demos (packet flow, reference architecture, narrative)
- `tests/` — 2278 tests across 55 files (Vitest)

## Key Concepts

- **Nodes**: Network devices (ec, switch, cloud, host, router, firewall, database, etc.)
- **Links**: Connections between nodes (line, tunnel, wireguard, flow, packet, blocked, wifi, poe, optical)
- **Anchors**: Invisible position markers for precise link endpoints
- **Acts**: Thematic groups of steps (presentation sections)
- **Steps**: Narrative units — one click/advance per step
- **Phases**: Timed sub-animations within a step (staggered reveals)
- **Focus**: Spotlight system — highlighted elements stay bright, others dim + blur
- **Zones**: Rectangular annotation regions that group nodes visually, with step-awareness for show/hide
- **Waypoints**: Intermediate control points on links for orthogonal routing and precise path control
- **Presentation Mode**: Fullscreen cinematic playback with auto-advance, presenter notes, and act-boundary pauses
- **Templates Gallery**: Visual card-based browser for enterprise templates (SD-WAN, ZTNA, campus, data center, cloud, starter)
- **Dark/Light Theme**: Full theme toggle with dark glassmorphism and light mode support
- **Layout Edit Mode**: Interactive node repositioning with coordinate readback for precision placement
- **AI Assist**: Local NLP-based topology generation from plain English descriptions
- **Analytics**: Engagement tracking with dwell times, completion rate, and glassmorphism dashboard
- **Standalone Export**: Self-contained single-file HTML export with embedded CSS/JS + iframe embed code
- **Export Formats**: PNG, SVG, PDF, standalone HTML

## Key APIs

- `mount(containerId)` — Mount topology to a DOM container and render
- `render()` — Force re-render of the SVG
- `play()` / `pause()` / `next()` / `prev()` / `goTo(n)` / `reset()` — Playback controls
- `showDuring(elementIds, range)` — Declare persistent visibility across a step range
- `removeNode(id)` — Remove a node and its connected links
- `removeLink(id)` — Remove a link by ID
- `off(event, callback)` — Unsubscribe from lifecycle events (beforeRender, afterRender, onStepChange)
- `on(event, callback)` — Subscribe to lifecycle events
- `toJSON()` / `fromJSON()` — Full state serialization
- `importFromText()` — Diagram-as-code import
- `importDrawio(xml)` — draw.io XML import
- `loadTemplate(name)` — Load built-in enterprise template
- `autoLayout(algorithm)` — Auto-layout (force-directed, hierarchical, circular, grid, magnetic north, network, spineLeaf, cluster)
- `topo.graph` — Access TopologyGraph for adjacency, shortest path, blast radius, analysis
- `topo.graph.resolvePosition(id)` — Return `{ x, y }` for a node or anchor ID (null if unknown)
- `validateTopology()` / `validatePath(from, to)` — Security and topology validation
- `getBlastRadius(nodeId)` / `setBlastRadiusNode(nodeId)` — Blast radius analysis
- `setTemporalMode(mode)` — Temporal digital twin mode (design, operational, incident)
- `setElementState(elementId, data)` / `setStateData(stateMap)` — Set operational/incident state on elements
- `setState(name, value)` / `getState(name)` — Conditional step logic state variables
- `pathThrough(...ids)` / `pathBetween(from, to, opts)` — SVG path generation for flow paths
- `TopologyDesigner.registerLinkType(name, plugin)` / `TopologyDesigner.registerNodeType(name, plugin)` — Custom type plugins (static)
- `setNodePositions(nodeId, positions)` — Position keyframes for choreography smoothing
- `zone(id, cfg)` / `removeZone(id)` / `setZones(entries)` / `getChildZones(zoneId)` — Zone annotations
- `removeAnchor(id)` — Remove an anchor and its connected links
- `addWaypoint(linkId, pos)` / `removeWaypoint(linkId, index)` / `clearWaypoints(linkId)` — Link waypoint control
- `setLinkRouting(linkId, style)` — Set link routing style (straight, orthogonal)
- `layer(id, cfg)` / `setLayers(layers)` — Visual layer management
- `setStepLayerVisibility(stepId, layerId, opacity)` — Per-step choreography layer show/dim/hide (0 hides, 1 shows, null clears; holds forward until overridden)
- `flowPath(id, cfg)` / `setFlowPaths(entries)` — Animated overlay flow paths
- `policyMarker(id, cfg)` / `setPolicyMarkers(entries)` — Policy action badges
- `exportPNG()` / `exportSVG()` / `exportPDF()` / `exportStandaloneHTML()` — Export formats
- `present()` / `exitPresentation()` — Presentation mode
- `enterLayoutEditMode()` / `exitLayoutEditMode()` / `toggleLayoutEditMode()` — Interactive node repositioning
- `getPositionSnippet()` — Get code snippet with current node coordinates
- `copyPositions()` — Copy current node positions to clipboard and return positions map
- `setTheme(theme)` / `getTheme()` / `applyTheme(theme)` — Theme management
- `toggleIsometric(enabled)` — Toggle isometric 3D tilt mode
- `toggleSecurityMode(enabled)` — Toggle security visualization mode
- `enableMobileQuickEdit()` / `disableMobileQuickEdit()` — Mobile quick-edit mode
- `copyEmbedCode()` — Copy iframe embed code to clipboard
- `getAnalytics()` / `showAnalyticsDashboard()` — Engagement analytics
- `showAIAssist()` — Open AI-assisted topology generation modal
- `TopologyDesigner.getNodeTypeCatalog()` / `TopologyDesigner.renderNodePreview(type)` — Node type browser (static)
- `TopologyDesigner.getRegisteredNodeTypes()` / `TopologyDesigner.getRegisteredLinkTypes()` — Type registry introspection (static)

## Skills

- `.claude/skills/topology-editor.md` — Generate topology visualizations with choreography

# Clean MCP

This project uses Clean for code search. Always prefer these MCP tools over built-in file search, grep, or directory listing:

- `search_code` — Semantic code search across all indexed repositories
- `get_file_tree` — Repository directory structure
- `get_source` — Read source files from indexed repos
- `expand_result` — Get full source for truncated search results

Do not fall back to grep or manual file reading when these tools are available.
