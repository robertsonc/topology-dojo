# UX Review: Topology Design System

> Navigation patterns, affordances, feedback states, and interaction quality
> Prioritized by impact on user experience for a design-focused audience

---

## P1 — High Impact

### 1. No visible progress indicator for overall presentation position

**Location**: `topology-ds.css:170-173`, `topology-ds.css:343`

The progress pips show phases *within* a step, not overall progress (e.g., "Step 5 of 14"). On mobile (<600px), even the pips are hidden.

**Why it matters**: In a presentation context, both presenter and audience need spatial awareness — "how far are we?" Without this, users feel untethered.

**Fix**: Add a step counter label (`5 / 14`) next to the controls. On mobile, this becomes the only progress indicator. Consider a thin progress bar spanning the toolbar width.

---

### 2. Play button doesn't clearly communicate current state

**Location**: `topology-ds.js:3042`, `topology-ds.css:239-244`

The play/pause toggle swaps text and CSS classes. But the `.pause` class merely changes the border to subtle red — the button loses its prominent green gradient and becomes visually identical to other grey buttons.

**Why it matters**: During auto-play, "stop" is the most important control. A button that deflates visually when it becomes most critical is backwards. Users can't instantly tell if the presentation is running.

**Fix**: Keep the pause button visually prominent — use a distinct background (amber or retain the green gradient with a pause icon). The active state should be *more* prominent than idle, not less.

---

### 3. Toolbar is overwhelming — too many controls at equal visual weight

**Location**: `topology-ds.js:3007-3017`, `topology-ds.css:177-186`

The toolbar packs mode selector, 4 range sliders, temporal selector, tilt button, security button, glossary button, mode indicator, and shortcut hints into one row — all with identical styling.

**Why it matters**: Creates decision paralysis. Primary actions (play mode) compete with advanced tuning (phase delay ms). New users don't know what matters.

**Fix**: Group into tiers. Primary (always visible): mode selector, speed. Secondary (behind a "Tuning" toggle): phase delay, draw speed, fade. Feature toggles (tilt, security, glossary) should be visually separated as icon-only buttons. Move keyboard hints to a `?` help modal.

---

### 4. Narrator panel collapse affordance is too subtle

**Location**: `topology-ds.css:255-259`, `topology-ds.css:274-278`, `topology-ds.css:329-333`

The narrator toggle is a 22×22px button. When collapsed, the 36px-wide panel shows no indication of what's hidden or how to restore it. On mobile, responsive overrides force it to re-expand, ignoring the user's preference.

**Why it matters**: Users who dismiss the panel may not find it again. Mobile override is confusing — "I closed this, why is it back?"

**Fix**: Add a visible label to collapsed state (rotated "Narrator" text or icon). Respect collapse preference across breakpoints. Add a slide-in animation on expand.

---

### 5. Keyboard shortcuts are undiscoverable

**Location**: `topology-ds.js:3017`, `topology-ds.js:3201-3213`

Shortcuts appear as a raw text span: `Space · ←/→ · Home/End · I · N`. No descriptions. `G` (glossary) and `Escape` (exit link mode) are missing from the list.

**Why it matters**: A raw shortcut list with no labels reads as debug output, not a user feature.

**Fix**: Replace the inline list with a `?` button opening a keyboard shortcut modal. List each shortcut with its action. Bind `?` to open it.

---

## P2 — Medium Impact

### 6. Act headers don't indicate expand/collapse state

**Location**: `topology-ds.css:125-133`

Sidebar act headers toggle `.collapsed` but have no chevron or arrow. The only cue is whether child steps are visible.

**Fix**: Add a chevron (▸/▾) that rotates on toggle — universal affordance for collapsible sections.

---

### 7. Security mode click interaction is invisible

**Location**: `topology-ds.js:3140-3147`

When security mode is active, clicking a node sets blast radius center. But there's no visual hint, no cursor change, no instructions.

**Why it matters**: Users toggle security mode, see the red border, then nothing happens. The feature appears broken.

**Fix**: Show instruction banner: "Click a node to visualize blast radius." Change node cursors to `crosshair`. Add subtle pulse on nodes.

---

### 8. Toggle buttons lack clear on/off state

**Location**: `topology-ds.js:3088-3102`

Isometric and security toggles use inline style changes for active state (border tint). No `.active` class, no background change.

**Why it matters**: Toggle buttons need unambiguous on/off states. Subtle border color on a glassmorphism aesthetic isn't enough.

**Fix**: Add `.active` class with background fill. Use `aria-pressed="true/false"`.

---

### 9. No feedback when reaching end of presentation

**Location**: `topology-ds.js:3226`

When auto-play reaches the last step, playback stops silently. No completion state, no prompt.

**Why it matters**: The presentation just stops. In live demos, this is an awkward dead moment.

**Fix**: Show "Presentation complete" message. Offer "Replay" as button label. Consider brief completion animation.

---

### 10. Sidebar perspective tilt is distracting

**Location**: `topology-ds.css:116-118`

Sidebar has a 3D perspective transform (0.6deg Y rotation) that flattens on hover — purely decorative movement during frequent click interactions.

**Fix**: Remove perspective transform from sidebar. Reserve 3D effects for canvas and intentional features.

---

## P3 — Polish

### 11. Step rows use 8.5px font — below readability threshold

**Location**: `topology-ds.css:139`, `topology-ds.css:126`

Step text is 8.5px, act headers 8px. Below the 10-11px minimum for UI text.

**Fix**: Increase to 10px (steps) and 9px (headers).

---

### 12. Range sliders mix units without context

Speed shows `3.5s`, phase delay shows `600ms`. Inconsistent units, no visual grouping.

**Fix**: Normalize to seconds or add clear labels. Group related timing controls.

---

### 13. Mode indicator looks like a keyboard hint, not a toggle

**Location**: `topology-ds.js:3016`

Uses `.tds-kbd` styling — same as static shortcut hints. Clickable but looks like text.

**Fix**: Style as segmented control or proper toggle button.

---

### 14. Glossary close target is too small

**Location**: `topology-ds.js:3033`

Close button is a `.tds-mini-btn` with text "Close". No × icon, no standard close affordance.

**Fix**: Add × icon, increase hit target to 32×32px minimum.

---

### 15. No swipe gestures for mobile step navigation

**Location**: `topology-ds.css:350-355`

Touch targets are enlarged but no swipe gesture support exists. Users must tap small prev/next buttons.

**Fix**: Add horizontal swipe detection on canvas for step advancement on touch devices.
