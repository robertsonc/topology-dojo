/* ═══════════════════════════════════════════════════════════════
   Layout Engine — Auto-layout algorithms for topology nodes
   Pure JS, no dependencies. Works standalone or as ES module.
   ═══════════════════════════════════════════════════════════════ */

class LayoutEngine {

  /* ── Force-Directed Layout ──
     Simple n-body simulation using Coulomb repulsion + Hooke attraction.
     Best for organic, mesh-like topologies.

     @param {Map|Array} nodes - Map<id, {x,y,...}> or [{id,x,y,...}]
     @param {Map|Array} links - Map<id, {from,to,...}> or [{from,to,...}]
     @param {object} options - { width, height, iterations, padding, strength }
     @returns {Map<string, {x:number, y:number}>} new positions
  */
  static forceDirected(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      iterations = 200,
      padding = 60,
      repulsion = 8000,
      attraction = 0.005,
      damping = 0.9,
      minDistance = 80,
    } = options;

    // Normalize input to arrays
    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);

    if (nodeArr.length === 0) return new Map();

    // Initialize positions (use existing or random)
    const cx = width / 2, cy = height / 2;
    const positions = new Map();
    const velocities = new Map();

    nodeArr.forEach((n, i) => {
      const angle = (2 * Math.PI * i) / nodeArr.length;
      const r = Math.min(width, height) * 0.3;
      positions.set(n.id, {
        x: n.x != null ? n.x : cx + r * Math.cos(angle),
        y: n.y != null ? n.y : cy + r * Math.sin(angle),
      });
      velocities.set(n.id, { vx: 0, vy: 0 });
    });

    // Build adjacency for quick lookups
    const adjacency = new Map();
    nodeArr.forEach(n => adjacency.set(n.id, new Set()));
    linkArr.forEach(l => {
      if (adjacency.has(l.from)) adjacency.get(l.from).add(l.to);
      if (adjacency.has(l.to)) adjacency.get(l.to).add(l.from);
    });

    // Simulation loop
    for (let iter = 0; iter < iterations; iter++) {
      const temp = 1 - iter / iterations; // cooling

      // Repulsion between all node pairs (Coulomb)
      for (let i = 0; i < nodeArr.length; i++) {
        for (let j = i + 1; j < nodeArr.length; j++) {
          const a = positions.get(nodeArr[i].id);
          const b = positions.get(nodeArr[j].id);
          let dx = b.x - a.x, dy = b.y - a.y;
          if (dx === 0 && dy === 0) {
            dx = (Math.random() - 0.5) * 0.1;
            dy = (Math.random() - 0.5) * 0.1;
          }
          let dist = Math.sqrt(dx * dx + dy * dy) || 0.01;
          if (dist < minDistance) dist = minDistance;

          const force = repulsion / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;

          const va = velocities.get(nodeArr[i].id);
          const vb = velocities.get(nodeArr[j].id);
          va.vx -= fx; va.vy -= fy;
          vb.vx += fx; vb.vy += fy;
        }
      }

      // Attraction along links (Hooke's spring)
      linkArr.forEach(l => {
        const a = positions.get(l.from);
        const b = positions.get(l.to);
        if (!a || !b) return;

        const dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = attraction * (dist - minDistance * 1.5);
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;

        const va = velocities.get(l.from);
        const vb = velocities.get(l.to);
        if (va) { va.vx += fx; va.vy += fy; }
        if (vb) { vb.vx -= fx; vb.vy -= fy; }
      });

      // Centering force
      nodeArr.forEach(n => {
        const p = positions.get(n.id);
        const v = velocities.get(n.id);
        v.vx += (cx - p.x) * 0.0005;
        v.vy += (cy - p.y) * 0.0005;
      });

      // Apply velocities with damping and cooling
      nodeArr.forEach(n => {
        const p = positions.get(n.id);
        const v = velocities.get(n.id);
        v.vx *= damping;
        v.vy *= damping;
        p.x += v.vx * temp;
        p.y += v.vy * temp;

        // Clamp to canvas bounds
        p.x = Math.max(padding, Math.min(width - padding, p.x));
        p.y = Math.max(padding, Math.min(height - padding, p.y));
      });
    }

    // Round to integers
    positions.forEach(p => { p.x = Math.round(p.x); p.y = Math.round(p.y); });
    return positions;
  }

  /* ── Hierarchical Layout ──
     Layered layout using topological sorting.
     Best for tree-like topologies (3-tier, spine-leaf).

     @param {Map|Array} nodes
     @param {Map|Array} links
     @param {object} options - { width, height, direction, layerSpacing, nodeSpacing }
     @returns {Map<string, {x:number, y:number}>}
  */
  static hierarchical(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      direction = 'TB', // TB, BT, LR, RL
      layerSpacing = 120,
      nodeSpacing = 100,
      padding = 60,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);

    if (nodeArr.length === 0) return new Map();

    // Build adjacency
    const children = new Map();
    const parents = new Map();
    const nodeSet = new Set(nodeArr.map(n => n.id));

    nodeArr.forEach(n => {
      children.set(n.id, new Set());
      parents.set(n.id, new Set());
    });

    linkArr.forEach(l => {
      if (nodeSet.has(l.from) && nodeSet.has(l.to)) {
        children.get(l.from).add(l.to);
        parents.get(l.to).add(l.from);
      }
    });

    // Find roots (no incoming edges)
    let roots = nodeArr.filter(n => parents.get(n.id).size === 0).map(n => n.id);
    if (roots.length === 0) roots = [nodeArr[0].id]; // fallback: pick first

    // BFS layer assignment
    const layers = new Map();
    const visited = new Set();
    const queue = roots.map(r => ({ id: r, layer: 0 }));
    roots.forEach(r => visited.add(r));

    while (queue.length > 0) {
      const { id, layer } = queue.shift();
      layers.set(id, layer);
      for (const child of children.get(id) || []) {
        if (!visited.has(child)) {
          visited.add(child);
          queue.push({ id: child, layer: layer + 1 });
        }
      }
    }

    // Assign unvisited nodes to layer 0
    nodeArr.forEach(n => {
      if (!layers.has(n.id)) layers.set(n.id, 0);
    });

    // Group by layer
    const layerGroups = new Map();
    layers.forEach((layer, id) => {
      if (!layerGroups.has(layer)) layerGroups.set(layer, []);
      layerGroups.get(layer).push(id);
    });

    const numLayers = Math.max(...layerGroups.keys()) + 1;
    const isHorizontal = direction === 'LR' || direction === 'RL';
    const isReversed = direction === 'BT' || direction === 'RL';

    // Compute positions
    const positions = new Map();
    const usableW = width - 2 * padding;
    const usableH = height - 2 * padding;

    layerGroups.forEach((ids, layer) => {
      const count = ids.length;
      ids.forEach((id, idx) => {
        let primaryAxis, secondaryAxis;

        if (isHorizontal) {
          primaryAxis = padding + (layer / Math.max(numLayers - 1, 1)) * usableW;
          secondaryAxis = padding + ((idx + 0.5) / count) * usableH;
          if (isReversed) primaryAxis = width - primaryAxis;
          positions.set(id, { x: Math.round(primaryAxis), y: Math.round(secondaryAxis) });
        } else {
          primaryAxis = padding + (layer / Math.max(numLayers - 1, 1)) * usableH;
          secondaryAxis = padding + ((idx + 0.5) / count) * usableW;
          if (isReversed) primaryAxis = height - primaryAxis;
          positions.set(id, { x: Math.round(secondaryAxis), y: Math.round(primaryAxis) });
        }
      });
    });

    return positions;
  }

  /* ── Circular Layout ──
     Nodes arranged on a circle. Good for mesh or ring topologies.

     @param {Map|Array} nodes
     @param {object} options - { width, height, padding }
     @returns {Map<string, {x:number, y:number}>}
  */
  static circular(nodes, options = {}) {
    const {
      width = 1050,
      height = 700,
      padding = 80,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    if (nodeArr.length === 0) return new Map();

    const cx = width / 2, cy = height / 2;
    const rx = (width - 2 * padding) / 2;
    const ry = (height - 2 * padding) / 2;
    const r = Math.min(rx, ry);

    const positions = new Map();
    nodeArr.forEach((n, i) => {
      const angle = (2 * Math.PI * i) / nodeArr.length - Math.PI / 2;
      positions.set(n.id, {
        x: Math.round(cx + r * Math.cos(angle)),
        y: Math.round(cy + r * Math.sin(angle)),
      });
    });

    return positions;
  }

  /* ── Grid Layout ──
     Nodes arranged on a regular grid.

     @param {Map|Array} nodes
     @param {object} options - { width, height, columns, padding }
     @returns {Map<string, {x:number, y:number}>}
  */
  static grid(nodes, options = {}) {
    const {
      width = 1050,
      height = 700,
      columns = 0, // 0 = auto
      padding = 80,
      spacing = 120,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    if (nodeArr.length === 0) return new Map();

    const cols = columns > 0 ? columns : Math.ceil(Math.sqrt(nodeArr.length));
    const rows = Math.ceil(nodeArr.length / cols);

    const usableW = width - 2 * padding;
    const usableH = height - 2 * padding;
    const cellW = Math.min(spacing, usableW / Math.max(cols - 1, 1));
    const cellH = Math.min(spacing, usableH / Math.max(rows - 1, 1));

    const startX = (width - (cols - 1) * cellW) / 2;
    const startY = (height - (rows - 1) * cellH) / 2;

    const positions = new Map();
    nodeArr.forEach((n, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      positions.set(n.id, {
        x: Math.round(startX + col * cellW),
        y: Math.round(startY + row * cellH),
      });
    });

    return positions;
  }

  /* ── Magnetic North Force-Directed Layout ──
     Type-aware force-directed layout where node types have gravitational
     preferences ("magnetic north"):
       - Clouds/SaaS gravitate to the top
       - Core infrastructure (switches, routers, firewalls) stays centered
       - Endpoints (hosts, databases, apps) gravitate to the bottom

     This prevents the "spaghetti" look common in standard force graphs.

     @param {Map|Array} nodes
     @param {Map|Array} links
     @param {object} options - { width, height, iterations, ... }
     @returns {Map<string, {x:number, y:number}>}
  */
  static magneticNorth(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      iterations = 250,
      padding = 70,
      repulsion = 10000,
      attraction = 0.004,
      damping = 0.88,
      minDistance = 90,
      magnetStrength = 0.008,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);

    if (nodeArr.length === 0) return new Map();

    // Type-to-zone mapping: 0 = top, 0.5 = center, 1 = bottom
    const typeZones = {
      cloud: 0.12,        // top
      overlayCloud: 0.08, // very top
      saas: 0.18,         // near top
      // Core infrastructure: center
      router: 0.45,
      firewall: 0.42,
      switch: 0.48,
      switchEnterprise: 0.48,
      connector: 0.50,
      ec: 0.55,
      server: 0.55,
      // Endpoints: bottom
      host: 0.82,
      database: 0.78,
      apps: 0.75,
      ap: 0.70,
      idcard: 0.88,
    };

    // Horizontal affinity: cloud types spread wide, core stays centered
    const typeXBias = {
      cloud: 0.5,    // center horizontally
      saas: 0.7,     // slightly right
      firewall: 0.5, // center
    };

    const cx = width / 2, cy = height / 2;
    const positions = new Map();
    const velocities = new Map();

    // Initialize with type-aware seeding
    nodeArr.forEach((n, i) => {
      const zone = typeZones[n.type] || 0.5;
      const targetY = padding + zone * (height - 2 * padding);
      // Spread nodes horizontally with some randomness
      const spread = (i / Math.max(nodeArr.length - 1, 1) - 0.5) * (width - 2 * padding) * 0.6;
      positions.set(n.id, {
        x: n.x != null ? n.x : cx + spread + (Math.random() - 0.5) * 40,
        y: n.y != null ? n.y : targetY + (Math.random() - 0.5) * 40,
      });
      velocities.set(n.id, { vx: 0, vy: 0 });
    });

    // Build adjacency
    const adjacency = new Map();
    nodeArr.forEach(n => adjacency.set(n.id, new Set()));
    linkArr.forEach(l => {
      if (adjacency.has(l.from)) adjacency.get(l.from).add(l.to);
      if (adjacency.has(l.to)) adjacency.get(l.to).add(l.from);
    });

    // Simulation loop
    for (let iter = 0; iter < iterations; iter++) {
      const temp = 1 - iter / iterations;

      // Repulsion between all node pairs
      for (let i = 0; i < nodeArr.length; i++) {
        for (let j = i + 1; j < nodeArr.length; j++) {
          const a = positions.get(nodeArr[i].id);
          const b = positions.get(nodeArr[j].id);
          let dx = b.x - a.x, dy = b.y - a.y;
          let dist = Math.sqrt(dx * dx + dy * dy) || 1;
          if (dist < minDistance) dist = minDistance;

          const force = repulsion / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;

          velocities.get(nodeArr[i].id).vx -= fx;
          velocities.get(nodeArr[i].id).vy -= fy;
          velocities.get(nodeArr[j].id).vx += fx;
          velocities.get(nodeArr[j].id).vy += fy;
        }
      }

      // Attraction along links
      linkArr.forEach(l => {
        const a = positions.get(l.from);
        const b = positions.get(l.to);
        if (!a || !b) return;
        const dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = attraction * (dist - minDistance * 1.5);
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        const va = velocities.get(l.from);
        const vb = velocities.get(l.to);
        if (va) { va.vx += fx; va.vy += fy; }
        if (vb) { vb.vx -= fx; vb.vy -= fy; }
      });

      // Magnetic north: gravitational pull toward type-preferred zones
      nodeArr.forEach(n => {
        const p = positions.get(n.id);
        const v = velocities.get(n.id);
        const zone = typeZones[n.type] || 0.5;
        const targetY = padding + zone * (height - 2 * padding);
        const xBias = typeXBias[n.type];
        const targetX = xBias != null ? padding + xBias * (width - 2 * padding) : cx;

        // Vertical magnetic pull (stronger)
        v.vy += (targetY - p.y) * magnetStrength;
        // Horizontal centering pull (weaker)
        v.vx += (targetX - p.x) * magnetStrength * 0.3;
      });

      // Light centering force
      nodeArr.forEach(n => {
        const p = positions.get(n.id);
        const v = velocities.get(n.id);
        v.vx += (cx - p.x) * 0.0003;
        v.vy += (cy - p.y) * 0.0002;
      });

      // Apply velocities with damping and cooling
      nodeArr.forEach(n => {
        const p = positions.get(n.id);
        const v = velocities.get(n.id);
        v.vx *= damping;
        v.vy *= damping;
        p.x += v.vx * temp;
        p.y += v.vy * temp;
        p.x = Math.max(padding, Math.min(width - padding, p.x));
        p.y = Math.max(padding, Math.min(height - padding, p.y));
      });
    }

    positions.forEach(p => { p.x = Math.round(p.x); p.y = Math.round(p.y); });
    return positions;
  }

  /* ── Network Layout ──
     WAN/LAN-aware layout for network topologies.
     Classifies links as WAN (site-to-site) or LAN (server-to-EC) and
     arranges nodes in semantic tiers:
       - Cloud tier (top): cloud, saas, overlayCloud
       - WAN tier (center row): ec, router, firewall
       - LAN tier (below each WAN node): server, host, database, apps, switch, ap

     @param {Map|Array} nodes
     @param {Map|Array} links
     @param {object} options - { width, height, padding, wanSpacing, lanSpacing, snapGrid }
     @returns {Map<string, {x:number, y:number}>}
  */
  static network(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      padding = 60,
      wanSpacing = 180,
      lanSpacing = 84,
      cloudOffset = 120,
      snapGrid = 12,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);

    if (nodeArr.length === 0) return new Map();

    const snap = (v) => Math.round(v / snapGrid) * snapGrid;

    // Classify node types into tiers
    const WAN_TYPES = new Set(['ec', 'router', 'firewall']);
    const CLOUD_TYPES = new Set(['cloud', 'saas', 'overlayCloud']);
    const LAN_TYPES = new Set(['server', 'host', 'database', 'apps', 'switch', 'switchEnterprise', 'ap', 'idcard']);

    const nodeMap = new Map();
    nodeArr.forEach(n => nodeMap.set(n.id, n));

    function getTier(n) {
      if (CLOUD_TYPES.has(n.type)) return 'cloud';
      if (WAN_TYPES.has(n.type)) return 'wan';
      return 'lan';
    }

    const cloudNodes = nodeArr.filter(n => getTier(n) === 'cloud');
    const wanNodes = nodeArr.filter(n => getTier(n) === 'wan');
    const lanNodes = nodeArr.filter(n => getTier(n) === 'lan');

    // Build adjacency per WAN node -> its LAN children
    const wanToLan = new Map();
    wanNodes.forEach(n => wanToLan.set(n.id, []));

    const assignedLan = new Set();

    // First pass: assign LAN nodes to their connected WAN node
    linkArr.forEach(l => {
      const fromNode = nodeMap.get(l.from);
      const toNode = nodeMap.get(l.to);
      if (!fromNode || !toNode) return;

      const fromTier = getTier(fromNode);
      const toTier = getTier(toNode);

      if (fromTier === 'wan' && toTier === 'lan' && !assignedLan.has(l.to)) {
        wanToLan.get(l.from).push(l.to);
        assignedLan.add(l.to);
      } else if (toTier === 'wan' && fromTier === 'lan' && !assignedLan.has(l.from)) {
        wanToLan.get(l.to).push(l.from);
        assignedLan.add(l.from);
      }
    });

    // Second pass: LAN nodes connected only to other LAN nodes that are
    // already assigned — group them with the same WAN parent
    lanNodes.forEach(n => {
      if (assignedLan.has(n.id)) return;
      // Find a LAN neighbor that's already assigned
      for (const l of linkArr) {
        let peer = null;
        if (l.from === n.id) peer = l.to;
        else if (l.to === n.id) peer = l.from;
        if (!peer || !assignedLan.has(peer)) continue;
        // Find which WAN node owns peer
        for (const [wanId, children] of wanToLan) {
          if (children.includes(peer)) {
            children.push(n.id);
            assignedLan.add(n.id);
            break;
          }
        }
        if (assignedLan.has(n.id)) break;
      }
    });

    // Unassigned LAN nodes go into a catch-all group
    const unassignedLan = lanNodes.filter(n => !assignedLan.has(n.id));

    // Position WAN tier: horizontal row centered on canvas
    const positions = new Map();
    const wanCount = wanNodes.length;
    const wanTotalWidth = (wanCount - 1) * wanSpacing;
    const wanStartX = (width - wanTotalWidth) / 2;
    const wanY = cloudNodes.length > 0 ? height * 0.4 : height * 0.3;

    wanNodes.forEach((n, i) => {
      positions.set(n.id, {
        x: snap(wanStartX + i * wanSpacing),
        y: snap(wanY),
      });
    });

    // Position cloud tier: centered above WAN tier
    const cloudCount = cloudNodes.length;
    const cloudTotalWidth = (cloudCount - 1) * wanSpacing;
    const cloudStartX = (width - cloudTotalWidth) / 2;
    const cloudY = wanY - cloudOffset;

    cloudNodes.forEach((n, i) => {
      positions.set(n.id, {
        x: snap(cloudStartX + i * wanSpacing),
        y: snap(cloudY),
      });
    });

    // Position LAN tiers: stack below each WAN node
    wanToLan.forEach((childIds, wanId) => {
      if (childIds.length === 0) return;
      const wanPos = positions.get(wanId);
      const colCount = childIds.length;
      // Center children below WAN parent
      const childTotalWidth = (colCount - 1) * lanSpacing;
      const startX = wanPos.x - childTotalWidth / 2;

      childIds.forEach((cid, i) => {
        positions.set(cid, {
          x: snap(startX + i * lanSpacing),
          y: snap(wanPos.y + lanSpacing + 12),
        });
      });

      // If there are more than a few, stack into rows
      if (colCount > 4) {
        const cols = Math.ceil(Math.sqrt(colCount));
        const childW = (cols - 1) * lanSpacing;
        const sX = wanPos.x - childW / 2;
        childIds.forEach((cid, i) => {
          const col = i % cols;
          const row = Math.floor(i / cols);
          positions.set(cid, {
            x: snap(sX + col * lanSpacing),
            y: snap(wanPos.y + lanSpacing + 12 + row * lanSpacing),
          });
        });
      }
    });

    // Unassigned LAN nodes: place in a row at the bottom
    if (unassignedLan.length > 0) {
      const bottomY = height - padding;
      const totalW = (unassignedLan.length - 1) * lanSpacing;
      const sX = (width - totalW) / 2;
      unassignedLan.forEach((n, i) => {
        positions.set(n.id, {
          x: snap(sX + i * lanSpacing),
          y: snap(bottomY),
        });
      });
    }

    // Handle any remaining nodes not yet positioned (e.g. connector, shape types)
    nodeArr.forEach(n => {
      if (!positions.has(n.id)) {
        // Place near center
        positions.set(n.id, {
          x: snap(width / 2),
          y: snap(height / 2),
        });
      }
    });

    return positions;
  }

  /* ── Apply Layout ──
     Applies computed positions to nodes on a TopologyDesigner instance.
     Optionally animates the transition.

     @param {TopologyDesigner} topo
     @param {Map<string, {x,y}>} positions
     @param {boolean} animate - whether to animate (smooth transition)
  */
  static apply(topo, positions, animate = false) {
    if (!animate) {
      positions.forEach(({ x, y }, id) => {
        const node = topo._nodes.get(id);
        if (node) { node.x = x; node.y = y; }
      });
      if (topo._mounted) topo.render();
      return;
    }

    // Animated transition over 500ms
    const startPositions = new Map();
    positions.forEach((_, id) => {
      const node = topo._nodes.get(id);
      if (node) startPositions.set(id, { x: node.x, y: node.y });
    });

    const duration = 500;
    const start = performance.now();

    function step(now) {
      const t = Math.min(1, (now - start) / duration);
      const ease = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // ease in-out

      positions.forEach(({ x, y }, id) => {
        const from = startPositions.get(id);
        const node = topo._nodes.get(id);
        if (from && node) {
          node.x = Math.round(from.x + (x - from.x) * ease);
          node.y = Math.round(from.y + (y - from.y) * ease);
        }
      });

      topo.render();
      if (t < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  }

  /* ── Spine-Leaf Layout (#146) ──
     Optimized for data-center spine-leaf topologies.
     Spine nodes (routers, switches with many connections) are placed on the
     top row; leaf nodes are arranged below in even columns.

     @param {Map|Array} nodes
     @param {Map|Array} links
     @param {object} options
     @returns {Map<string, {x:number, y:number}>}
  */
  static spineLeaf(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      padding = 80,
      spineY = 0.25,
      leafY = 0.7,
      minSpineConnections = 3,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);
    if (nodeArr.length === 0) return new Map();

    // Count connections per node
    const degreeMap = new Map();
    nodeArr.forEach(n => degreeMap.set(n.id, 0));
    linkArr.forEach(l => {
      if (degreeMap.has(l.from)) degreeMap.set(l.from, degreeMap.get(l.from) + 1);
      if (degreeMap.has(l.to)) degreeMap.set(l.to, degreeMap.get(l.to) + 1);
    });

    // Classify spine vs leaf: spine nodes have high degree or are core types
    const SPINE_TYPES = new Set(['router', 'switch', 'switchEnterprise', 'firewall']);
    const spineNodes = [];
    const leafNodes = [];

    nodeArr.forEach(n => {
      const degree = degreeMap.get(n.id) || 0;
      if ((SPINE_TYPES.has(n.type) && degree >= minSpineConnections) || degree >= 4) {
        spineNodes.push(n);
      } else {
        leafNodes.push(n);
      }
    });

    // If no clear spine, fall back to degree-based split
    if (spineNodes.length === 0) {
      const sorted = [...nodeArr].sort((a, b) => (degreeMap.get(b.id) || 0) - (degreeMap.get(a.id) || 0));
      const splitAt = Math.max(1, Math.ceil(sorted.length * 0.3));
      spineNodes.push(...sorted.slice(0, splitAt));
      leafNodes.length = 0;
      leafNodes.push(...sorted.slice(splitAt));
    }

    const positions = new Map();
    const usableW = width - 2 * padding;

    // Place spine row
    const sY = padding + spineY * (height - 2 * padding);
    spineNodes.forEach((n, i) => {
      const x = spineNodes.length === 1
        ? width / 2
        : padding + (i / (spineNodes.length - 1)) * usableW;
      positions.set(n.id, { x: Math.round(x), y: Math.round(sY) });
    });

    // Place leaf row, group by connected spine
    const lY = padding + leafY * (height - 2 * padding);
    if (leafNodes.length > 0) {
      // Sort leaves by their primary spine connection for visual grouping
      const spineSet = new Set(spineNodes.map(n => n.id));
      const leafSpineMap = new Map();
      leafNodes.forEach(n => {
        let bestSpine = null;
        for (const l of linkArr) {
          const peer = l.from === n.id ? l.to : (l.to === n.id ? l.from : null);
          if (peer && spineSet.has(peer)) { bestSpine = peer; break; }
        }
        leafSpineMap.set(n.id, bestSpine);
      });

      // Sort by spine x-position for visual alignment
      leafNodes.sort((a, b) => {
        const spA = leafSpineMap.get(a.id);
        const spB = leafSpineMap.get(b.id);
        const xA = spA && positions.has(spA) ? positions.get(spA).x : width / 2;
        const xB = spB && positions.has(spB) ? positions.get(spB).x : width / 2;
        return xA - xB;
      });

      leafNodes.forEach((n, i) => {
        const x = leafNodes.length === 1
          ? width / 2
          : padding + (i / (leafNodes.length - 1)) * usableW;
        positions.set(n.id, { x: Math.round(x), y: Math.round(lY) });
      });
    }

    return positions;
  }

  /* ── Cluster Layout (#146) ──
     Groups nodes by connected components and arranges each cluster
     using circular layout, with clusters positioned on a grid.

     @param {Map|Array} nodes
     @param {Map|Array} links
     @param {object} options
     @returns {Map<string, {x:number, y:number}>}
  */
  static cluster(nodes, links, options = {}) {
    const {
      width = 1050,
      height = 700,
      padding = 80,
      clusterPadding = 40,
    } = options;

    const nodeArr = LayoutEngine._toNodeArray(nodes);
    const linkArr = LayoutEngine._toLinkArray(links);
    if (nodeArr.length === 0) return new Map();

    // Build adjacency for component detection
    const adj = new Map();
    nodeArr.forEach(n => adj.set(n.id, new Set()));
    linkArr.forEach(l => {
      if (adj.has(l.from)) adj.get(l.from).add(l.to);
      if (adj.has(l.to)) adj.get(l.to).add(l.from);
    });

    // BFS to find connected components
    const visited = new Set();
    const clusters = [];
    nodeArr.forEach(n => {
      if (visited.has(n.id)) return;
      const component = [];
      const queue = [n.id];
      visited.add(n.id);
      while (queue.length > 0) {
        const cur = queue.shift();
        component.push(cur);
        for (const neighbor of (adj.get(cur) || [])) {
          if (!visited.has(neighbor)) {
            visited.add(neighbor);
            queue.push(neighbor);
          }
        }
      }
      clusters.push(component);
    });

    // Arrange clusters on a grid
    const clusterCount = clusters.length;
    const cols = Math.ceil(Math.sqrt(clusterCount));
    const rows = Math.ceil(clusterCount / cols);
    const cellW = (width - 2 * padding) / cols;
    const cellH = (height - 2 * padding) / rows;

    const positions = new Map();
    const nodeMap = new Map();
    nodeArr.forEach(n => nodeMap.set(n.id, n));

    clusters.forEach((cluster, ci) => {
      const col = ci % cols;
      const row = Math.floor(ci / cols);
      const cx = padding + (col + 0.5) * cellW;
      const cy = padding + (row + 0.5) * cellH;
      const r = Math.min(cellW, cellH) / 2 - clusterPadding;

      if (cluster.length === 1) {
        positions.set(cluster[0], { x: Math.round(cx), y: Math.round(cy) });
      } else {
        cluster.forEach((id, i) => {
          const angle = (2 * Math.PI * i) / cluster.length - Math.PI / 2;
          positions.set(id, {
            x: Math.round(cx + r * Math.cos(angle)),
            y: Math.round(cy + r * Math.sin(angle)),
          });
        });
      }
    });

    return positions;
  }

  /* ── Overlap Removal (#146) ──
     Post-processing pass: nudge overlapping nodes apart.
     Can be applied after any layout algorithm.

     @param {Map<string, {x,y}>} positions
     @param {object} options - { minDistance, iterations }
     @returns {Map<string, {x,y}>} adjusted positions
  */
  static removeOverlaps(positions, options = {}) {
    const {
      minDistance = 80,
      iterations = 50,
      width = 1050,
      height = 700,
      padding = 40,
    } = options;

    const ids = Array.from(positions.keys());
    for (let iter = 0; iter < iterations; iter++) {
      let moved = false;
      for (let i = 0; i < ids.length; i++) {
        for (let j = i + 1; j < ids.length; j++) {
          const a = positions.get(ids[i]);
          const b = positions.get(ids[j]);
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 0.1;
          if (dist < minDistance) {
            const push = (minDistance - dist) / 2;
            const nx = (dx / dist) * push;
            const ny = (dy / dist) * push;
            a.x = Math.round(Math.max(padding, Math.min(width - padding, a.x - nx)));
            a.y = Math.round(Math.max(padding, Math.min(height - padding, a.y - ny)));
            b.x = Math.round(Math.max(padding, Math.min(width - padding, b.x + nx)));
            b.y = Math.round(Math.max(padding, Math.min(height - padding, b.y + ny)));
            moved = true;
          }
        }
      }
      if (!moved) break;
    }
    return positions;
  }

  /* ── Helpers ── */

  static _toNodeArray(nodes) {
    if (nodes instanceof Map) {
      return Array.from(nodes.values()).map(n => ({ id: n.id, x: n.x, y: n.y, ...n }));
    }
    if (Array.isArray(nodes)) return nodes;
    return [];
  }

  static _toLinkArray(links) {
    if (links instanceof Map) {
      return Array.from(links.values());
    }
    if (Array.isArray(links)) return links;
    return [];
  }
}

// Support both module and global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = LayoutEngine;
} else if (typeof window !== 'undefined') {
  window.LayoutEngine = LayoutEngine;
}
