/* ═══════════════════════════════════════════════════════════════
   Iso3D Nodes — Pronounced isometric 3D node set
   Self-registers a family of `iso:*` node types via
   TopologyDesigner.registerNodeType, drawing real 3D cuboids
   and cylinders in SVG with 3-face shading (top/front/right).

   Usage:
     <script src="modules/iso3d-nodes.js"></script>
     then reference nodes as:
       { type: 'iso:server', x: 200, y: 200, label: 'web-01', color: '#01a982' }

   Types: iso:box, iso:server, iso:rack, iso:database, iso:cylinder,
          iso:switch, iso:router, iso:firewall, iso:ec, iso:host, iso:cloud
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  if (typeof TopologyDesigner === 'undefined') {
    console.warn('iso3d-nodes: TopologyDesigner not found; load topology-ds.js first');
    return;
  }

  const C30 = Math.cos(Math.PI / 6); // 0.8660254
  const S30 = Math.sin(Math.PI / 6); // 0.5

  /* ── Color helpers ─────────────────────────────────────────── */
  const clamp = (n) => Math.max(0, Math.min(255, n | 0));
  function parseHex(hex) {
    let h = (hex || '#888').replace('#', '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    const n = parseInt(h, 16);
    return { r: (n >> 16) & 0xff, g: (n >> 8) & 0xff, b: n & 0xff };
  }
  function toHex({ r, g, b }) {
    return '#' + ((1 << 24) | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b)).toString(16).slice(1);
  }
  function shade(hex, pct) {
    const { r, g, b } = parseHex(hex);
    const mix = (v) => (pct >= 0 ? v + (255 - v) * pct : v + v * pct);
    return toHex({ r: mix(r), g: mix(g), b: mix(b) });
  }

  /* ── Iso projection ────────────────────────────────────────── */
  // World axes: +wx lower-right, +wy lower-left, +wz up.
  // Observer at (+∞, +∞, +∞): front(+X), side(+Y), top(+Z) faces visible.
  function iso(cx, cy, wx, wy, wz) {
    return [cx + (wx - wy) * C30, cy + (wx + wy) * S30 - wz];
  }
  const f = (p) => p[0].toFixed(1) + ',' + p[1].toFixed(1);
  const poly = (...ps) => ps.map(f).join(' ');

  /* ── Build a 3-face cuboid ─────────────────────────────────── */
  // Box centered at (cx, cy) with world size W × D × H.
  // Returns { svg, top, front, right, corners } — corners in world-relative
  // world coords [wx, wy, wz] so callers can decorate specific faces.
  function box3d(cx, cy, W, D, H, opts = {}) {
    const base = opts.color || '#01a982';
    const topC = opts.top || shade(base, 0.35);
    const frontC = opts.front || shade(base, 0.05);
    const rightC = opts.right || shade(base, -0.3);
    const stroke = opts.stroke || shade(base, -0.6);
    const sw = opts.strokeWidth != null ? opts.strokeWidth : 0.8;
    const hw = W / 2, hd = D / 2, hh = H / 2;
    const P = (wx, wy, wz) => iso(cx, cy, wx, wy, wz);
    const BLF = P(-hw, -hd, -hh), BRF = P(+hw, -hd, -hh),
          BRB = P(+hw, +hd, -hh), BLB = P(-hw, +hd, -hh),
          TLF = P(-hw, -hd, +hh), TRF = P(+hw, -hd, +hh),
          TRB = P(+hw, +hd, +hh), TLB = P(-hw, +hd, +hh);

    // Subtle specular highlight strip along the top-front edge
    const hi = opts.highlight !== false;
    const hiStroke = hi
      ? `<polyline points="${f(TLF)} ${f(TRF)}" fill="none" stroke="${shade(base, 0.6)}" stroke-width="1" stroke-linecap="round" opacity=".75"/>`
      : '';

    const svg =
      `<polygon points="${poly(BLF, BRF, TRF, TLF)}" fill="${frontC}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>` +
      `<polygon points="${poly(BRF, BRB, TRB, TRF)}" fill="${rightC}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>` +
      `<polygon points="${poly(TLF, TRF, TRB, TLB)}" fill="${topC}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>` +
      hiStroke;

    return { svg, P, TLF, TRF, TRB, TLB, BLF, BRF, BRB, BLB, topC, frontC, rightC, stroke, base };
  }

  /* ── Build a 3D cylinder (e.g. database drum) ──────────────── */
  // Cylinder centered at (cx, cy) with radius R (in world x/y) and height H (z).
  function cyl3d(cx, cy, R, H, opts = {}) {
    const base = opts.color || '#deb146';
    const topC = opts.top || shade(base, 0.35);
    const sideC = opts.side || shade(base, -0.1);
    const shadowC = opts.shadow || shade(base, -0.45);
    const stroke = opts.stroke || shade(base, -0.6);
    // In isometric, a circle of radius R in the XY plane projects to an ellipse
    // with rx = R*cos(30°)*2? Actually: world circle (R cos t, R sin t, 0) maps to
    // screen ((R cos t − R sin t) * C30, (R cos t + R sin t) * S30).
    // That's an ellipse with semi-major R*C30*√2 along a 45° direction.
    // For simplicity we approximate as an axis-aligned ellipse (rx = R, ry = R/2)
    // — this reads convincingly as "iso cylinder top" and matches the rest of
    // the iso geometry at typical node sizes.
    const rx = R * C30 * Math.SQRT2 * 0.95;
    const ry = R * S30 * Math.SQRT2 * 0.95;
    const hh = H / 2;
    const topCY = cy - hh;
    const botCY = cy + hh;
    // Side: two vertical lines + gradient body path
    // Gradient (darker on right edge) via unique id
    const gid = 'iso3d-cyl-' + Math.random().toString(36).slice(2, 9);
    const defs =
      `<defs><linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="0">` +
      `<stop offset="0%" stop-color="${shade(base, 0.12)}"/>` +
      `<stop offset="45%" stop-color="${sideC}"/>` +
      `<stop offset="100%" stop-color="${shadowC}"/>` +
      `</linearGradient></defs>`;
    const svg =
      defs +
      // Bottom ellipse (hidden back half — just a dark arc)
      `<path d="M${(cx - rx).toFixed(1)},${botCY.toFixed(1)} A${rx.toFixed(1)},${ry.toFixed(1)} 0 0 0 ${(cx + rx).toFixed(1)},${botCY.toFixed(1)}" fill="none" stroke="${stroke}" stroke-width="0.8" opacity=".6"/>` +
      // Body
      `<path d="M${(cx - rx).toFixed(1)},${topCY.toFixed(1)} L${(cx - rx).toFixed(1)},${botCY.toFixed(1)} A${rx.toFixed(1)},${ry.toFixed(1)} 0 0 0 ${(cx + rx).toFixed(1)},${botCY.toFixed(1)} L${(cx + rx).toFixed(1)},${topCY.toFixed(1)} A${rx.toFixed(1)},${ry.toFixed(1)} 0 0 1 ${(cx - rx).toFixed(1)},${topCY.toFixed(1)} Z" fill="url(#${gid})" stroke="${stroke}" stroke-width="0.8" stroke-linejoin="round"/>` +
      // Top ellipse (lit)
      `<ellipse cx="${cx.toFixed(1)}" cy="${topCY.toFixed(1)}" rx="${rx.toFixed(1)}" ry="${ry.toFixed(1)}" fill="${topC}" stroke="${stroke}" stroke-width="0.8"/>` +
      // Highlight along upper-left of top
      `<path d="M${(cx - rx * 0.9).toFixed(1)},${(topCY + ry * 0.1).toFixed(1)} A${(rx * 0.9).toFixed(1)},${(ry * 0.9).toFixed(1)} 0 0 1 ${(cx - rx * 0.2).toFixed(1)},${(topCY - ry * 0.85).toFixed(1)}" fill="none" stroke="${shade(base, 0.55)}" stroke-width="0.9" opacity=".8"/>`;
    return { svg, rx, ry, topCY, botCY };
  }

  /* ── Label helper (sits below the node) ────────────────────── */
  function label(x, y, text, color, offset) {
    if (!text) return '';
    const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    return `<text x="${x}" y="${y + (offset || 46)}" text-anchor="middle" fill="${color || '#e6e8e9'}" font-size="10" font-weight="600" opacity=".9">${esc(text)}</text>`;
  }

  /* ═════════════════════════════════════════════════════════════
     NODE RENDERERS
     ═════════════════════════════════════════════════════════════ */

  /** Generic 3D box — configurable dimensions */
  function renderBox(x, y, cfg = {}) {
    const W = cfg.w || 48, D = cfg.d || 48, H = cfg.h || 48;
    const b = box3d(x, y, W, D, H, { color: cfg.color || '#65aef9' });
    return b.svg + label(x, y + H / 2, cfg.label, cfg.color, 16);
  }

  /** Tower server with LED strip and vents on top */
  function renderServer(x, y, cfg = {}) {
    const color = cfg.color || '#01a982';
    const W = cfg.w || 38, D = cfg.d || 44, H = cfg.h || 62;
    const b = box3d(x, y, W, D, H, { color });
    // Front-face details: LED strip. Front face plane = wy = -D/2.
    const ledY = 0.6 * (H / 2); // near top of front
    const led = (wx, on) => {
      const c = on ? shade(color, 0.7) : shade(color, -0.2);
      const [px, py] = iso(x, y, wx, -D / 2 - 0.3, ledY);
      return `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="1.6" fill="${c}" opacity="${on ? 0.95 : 0.5}"/>`;
    };
    const leds = [led(-W / 2 + 5, true), led(-W / 2 + 10, true), led(-W / 2 + 15, false)].join('');
    // Power button circle
    const [pbx, pby] = iso(x, y, W / 2 - 5, -D / 2 - 0.3, -H / 2 + 8);
    const power = `<circle cx="${pbx.toFixed(1)}" cy="${pby.toFixed(1)}" r="2.2" fill="none" stroke="${shade(color, 0.6)}" stroke-width="0.9"/>` +
      `<line x1="${pbx.toFixed(1)}" y1="${(pby - 1.8).toFixed(1)}" x2="${pbx.toFixed(1)}" y2="${(pby + 0.4).toFixed(1)}" stroke="${shade(color, 0.6)}" stroke-width="0.9"/>`;
    // Top vent grille (lines running along +wx on the top face)
    let vents = '';
    for (let i = -2; i <= 2; i++) {
      const [a1x, a1y] = iso(x, y, -W / 2 + 4, i * 4, H / 2 + 0.2);
      const [a2x, a2y] = iso(x, y, W / 2 - 4, i * 4, H / 2 + 0.2);
      vents += `<line x1="${a1x.toFixed(1)}" y1="${a1y.toFixed(1)}" x2="${a2x.toFixed(1)}" y2="${a2y.toFixed(1)}" stroke="${shade(color, -0.25)}" stroke-width="0.6" opacity=".6"/>`;
    }
    return b.svg + leds + power + vents + label(x, y + H / 2, cfg.label, color, 16);
  }

  /** Server rack (4U) with horizontal slots */
  function renderRack(x, y, cfg = {}) {
    const color = cfg.color || '#01a982';
    const W = cfg.w || 50, D = cfg.d || 56, H = cfg.h || 92;
    const b = box3d(x, y, W, D, H, { color: cfg.color || '#4a5566', front: '#2a2d38', top: '#3a3f4a', right: '#1d1f27' });
    // 4 server slots on front face
    let slots = '';
    const slotH = 15;
    for (let i = 0; i < 4; i++) {
      const zTop = H / 2 - 6 - i * (slotH + 2);
      const zBot = zTop - slotH;
      const p1 = iso(x, y, -W / 2 + 3, -D / 2 - 0.4, zTop);
      const p2 = iso(x, y, W / 2 - 3, -D / 2 - 0.4, zTop);
      const p3 = iso(x, y, W / 2 - 3, -D / 2 - 0.4, zBot);
      const p4 = iso(x, y, -W / 2 + 3, -D / 2 - 0.4, zBot);
      slots += `<polygon points="${poly(p1, p2, p3, p4)}" fill="${shade(color, -0.35)}" stroke="${shade(color, -0.55)}" stroke-width="0.5"/>`;
      // LED on right
      const [lx, ly] = iso(x, y, W / 2 - 6, -D / 2 - 0.5, (zTop + zBot) / 2);
      const on = i !== 2;
      slots += `<circle cx="${lx.toFixed(1)}" cy="${ly.toFixed(1)}" r="1.3" fill="${on ? '#05cc93' : '#deb146'}" opacity=".95"/>`;
    }
    return b.svg + slots + label(x, y + H / 2, cfg.label, color, 16);
  }

  /** 3D cylinder database with disk stripes */
  function renderDatabase(x, y, cfg = {}) {
    const color = cfg.color || '#deb146';
    const R = cfg.r || 24, H = cfg.h || 46;
    const c = cyl3d(x, y, R, H, { color });
    // Disk stripes — ellipses inside the body
    let stripes = '';
    const bands = 3;
    for (let i = 1; i <= bands; i++) {
      const yy = c.topCY + (H / (bands + 1)) * i;
      stripes += `<path d="M${(x - c.rx).toFixed(1)},${yy.toFixed(1)} A${c.rx.toFixed(1)},${c.ry.toFixed(1)} 0 0 0 ${(x + c.rx).toFixed(1)},${yy.toFixed(1)}" fill="none" stroke="${shade(color, -0.45)}" stroke-width="0.6" opacity=".65"/>`;
    }
    return c.svg + stripes + label(x, y + H / 2, cfg.label, color, 14);
  }

  /** Generic cylinder (no disk stripes) */
  function renderCylinder(x, y, cfg = {}) {
    const color = cfg.color || '#65aef9';
    const R = cfg.r || 22, H = cfg.h || 44;
    const c = cyl3d(x, y, R, H, { color });
    return c.svg + label(x, y + H / 2, cfg.label, color, 14);
  }

  /** Wide, short switch chassis with port openings on front */
  function renderSwitch(x, y, cfg = {}) {
    const color = cfg.color || '#00a4b3';
    const W = cfg.w || 82, D = cfg.d || 38, H = cfg.h || 18;
    const b = box3d(x, y, W, D, H, { color });
    const ports = cfg.ports || 12;
    const portW = (W - 14) / ports;
    let ps = '';
    for (let i = 0; i < ports; i++) {
      const wx0 = -W / 2 + 7 + i * portW;
      const wx1 = wx0 + portW * 0.78;
      const p1 = iso(x, y, wx0, -D / 2 - 0.4, -H / 2 + H * 0.25);
      const p2 = iso(x, y, wx1, -D / 2 - 0.4, -H / 2 + H * 0.25);
      const p3 = iso(x, y, wx1, -D / 2 - 0.4, H / 2 - H * 0.25);
      const p4 = iso(x, y, wx0, -D / 2 - 0.4, H / 2 - H * 0.25);
      const on = i % 3 !== 2;
      ps += `<polygon points="${poly(p1, p2, p3, p4)}" fill="${on ? shade(color, -0.55) : '#1d1f27'}" stroke="${shade(color, -0.7)}" stroke-width="0.4"/>`;
      if (on) {
        const [lx, ly] = iso(x, y, (wx0 + wx1) / 2, -D / 2 - 0.5, H / 2 - H * 0.12);
        ps += `<circle cx="${lx.toFixed(1)}" cy="${ly.toFixed(1)}" r="0.9" fill="#05cc93" opacity=".9"/>`;
      }
    }
    return b.svg + ps + label(x, y + H / 2, cfg.label, color, 14);
  }

  /** Router: flat box with two antennas on top */
  function renderRouter(x, y, cfg = {}) {
    const color = cfg.color || '#01a982';
    const W = cfg.w || 48, D = cfg.d || 48, H = cfg.h || 20;
    const b = box3d(x, y, W, D, H, { color });
    // Two antenna cylinders on top
    const antH = 18, antR = 1.6;
    const antennas = [[-W / 3, -D / 4], [W / 3, D / 4]].map(([ax, ay]) => {
      const [bx, by] = iso(x, y, ax, ay, H / 2);
      const [tx, ty] = iso(x, y, ax, ay, H / 2 + antH);
      return `<line x1="${bx.toFixed(1)}" y1="${by.toFixed(1)}" x2="${tx.toFixed(1)}" y2="${ty.toFixed(1)}" stroke="${shade(color, -0.3)}" stroke-width="${antR}" stroke-linecap="round"/>` +
        `<circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="1.8" fill="${shade(color, 0.4)}" stroke="${shade(color, -0.5)}" stroke-width="0.5"/>`;
    }).join('');
    // Front face directional chevrons
    const [fx, fy] = iso(x, y, 0, -D / 2 - 0.3, 0);
    const chev = `<text x="${fx.toFixed(1)}" y="${(fy + 3).toFixed(1)}" text-anchor="middle" fill="${shade(color, 0.5)}" font-size="9" font-weight="700" opacity=".85">&lt;/&gt;</text>`;
    return b.svg + antennas + chev + label(x, y + H / 2, cfg.label, color, 16);
  }

  /** Firewall: red chunky cuboid with brick pattern on front */
  function renderFirewall(x, y, cfg = {}) {
    const color = cfg.color || '#fc6161';
    const W = cfg.w || 48, D = cfg.d || 44, H = cfg.h || 54;
    const b = box3d(x, y, W, D, H, { color });
    // Brick grid on front face (wy = -D/2)
    let bricks = '';
    const rows = 4, cols = 4;
    for (let r = 0; r < rows; r++) {
      const offset = (r % 2) * (W / cols) * 0.5;
      for (let c = -1; c <= cols; c++) {
        const wx0 = -W / 2 + offset + c * (W / cols);
        const wx1 = wx0 + W / cols * 0.92;
        const wz1 = H / 2 - r * (H / rows) - 1;
        const wz0 = wz1 - (H / rows) * 0.85;
        if (wx1 < -W / 2 || wx0 > W / 2) continue;
        const cx0 = Math.max(wx0, -W / 2 + 0.5);
        const cx1 = Math.min(wx1, W / 2 - 0.5);
        if (cx1 - cx0 < 2) continue;
        const p1 = iso(x, y, cx0, -D / 2 - 0.4, wz1);
        const p2 = iso(x, y, cx1, -D / 2 - 0.4, wz1);
        const p3 = iso(x, y, cx1, -D / 2 - 0.4, wz0);
        const p4 = iso(x, y, cx0, -D / 2 - 0.4, wz0);
        bricks += `<polygon points="${poly(p1, p2, p3, p4)}" fill="none" stroke="${shade(color, -0.4)}" stroke-width="0.5" opacity=".8"/>`;
      }
    }
    // Flame glyph on top
    const [tx, ty] = iso(x, y, 0, 0, H / 2);
    const flame = `<text x="${tx.toFixed(1)}" y="${(ty + 4).toFixed(1)}" text-anchor="middle" font-size="12" opacity=".85">🔥</text>`;
    return b.svg + bricks + flame + label(x, y + H / 2, cfg.label, color, 14);
  }

  /** EdgeConnect appliance — flat chassis with green LEDs and HPE triangle */
  function renderEC(x, y, cfg = {}) {
    const variantColor = {
      generic: '#01a982', virtual: '#7764fc', physical: '#01a982',
      aws: '#ec8c25', azure: '#0078d4', gcp: '#4285f4', oracle: '#f80000',
    };
    const color = cfg.color || variantColor[cfg.variant] || '#01a982';
    const W = cfg.w || 64, D = cfg.d || 50, H = cfg.h || 22;
    const b = box3d(x, y, W, D, H, { color });
    // Front face: LEDs + HPE triangle
    const [l1x, l1y] = iso(x, y, -W / 2 + 7, -D / 2 - 0.3, 0);
    const [l2x, l2y] = iso(x, y, -W / 2 + 12, -D / 2 - 0.3, 0);
    const leds = `<circle cx="${l1x.toFixed(1)}" cy="${l1y.toFixed(1)}" r="1.7" fill="#05cc93" opacity=".95"/>` +
      `<circle cx="${l2x.toFixed(1)}" cy="${l2y.toFixed(1)}" r="1.7" fill="${shade(color, 0.4)}" opacity=".85"/>`;
    // HPE triangle (hollow) on front face
    const a = iso(x, y, 4, -D / 2 - 0.3, 5);
    const c = iso(x, y, -4, -D / 2 - 0.3, -5);
    const d = iso(x, y, 12, -D / 2 - 0.3, -5);
    const tri = `<polygon points="${poly(a, c, d)}" fill="none" stroke="${shade(color, 0.55)}" stroke-width="1.2" stroke-linejoin="round"/>`;
    // Variant badge on top face
    let badge = '';
    if (cfg.variant && cfg.variant !== 'generic') {
      const [bx, by] = iso(x, y, 0, 0, H / 2 + 0.2);
      badge = `<text x="${bx.toFixed(1)}" y="${(by + 3).toFixed(1)}" text-anchor="middle" fill="${shade(color, -0.5)}" font-size="6.5" font-weight="700" letter-spacing="1.2">${String(cfg.variant).toUpperCase()}</text>`;
    }
    return b.svg + leds + tri + badge + label(x, y + H / 2, cfg.label, color, 16);
  }

  /** Host / workstation: laptop shape (flat base + tilted screen) */
  function renderHost(x, y, cfg = {}) {
    const managed = cfg.managed;
    const color = cfg.color || (managed ? '#05cc93' : '#7d8a92');
    // Flat base
    const W = cfg.w || 46, D = cfg.d || 34, H = 4;
    const b = box3d(x, y, W, D, H, { color: '#2a2f3a', top: '#3a4050', front: '#1d1f27', right: '#14161c' });
    // Screen: standing plane at back (wy = +D/2), tilted slightly toward viewer.
    // We'll draw it as a parallelogram using 4 iso-projected corners.
    const sh = 28, sw = W - 6;
    const tilt = -2; // slight lean-forward (negative wy at top)
    const s1 = iso(x, y, -sw / 2, D / 2 - 2, H / 2);
    const s2 = iso(x, y, sw / 2, D / 2 - 2, H / 2);
    const s3 = iso(x, y, sw / 2, D / 2 - 2 + tilt, H / 2 + sh);
    const s4 = iso(x, y, -sw / 2, D / 2 - 2 + tilt, H / 2 + sh);
    const screenBack = `<polygon points="${poly(s1, s2, s3, s4)}" fill="${shade(color, -0.5)}" stroke="${shade(color, -0.7)}" stroke-width="0.8"/>`;
    // Screen bezel inset
    const ix = sw * 0.44, iz1 = H / 2 + 3, iz2 = H / 2 + sh - 3;
    const bz1 = iso(x, y, -ix, D / 2 - 2.2, iz1);
    const bz2 = iso(x, y, ix, D / 2 - 2.2, iz1);
    const bz3 = iso(x, y, ix, D / 2 - 2.2 + tilt * 0.9, iz2);
    const bz4 = iso(x, y, -ix, D / 2 - 2.2 + tilt * 0.9, iz2);
    const screen = `<polygon points="${poly(bz1, bz2, bz3, bz4)}" fill="${managed ? '#0a2a22' : '#0f1217'}" stroke="${shade(color, -0.2)}" stroke-width="0.5"/>`;
    // Glowing dot on screen
    const [gx, gy] = iso(x, y, 0, D / 2 - 2.4, H / 2 + sh / 2);
    const dot = `<circle cx="${gx.toFixed(1)}" cy="${gy.toFixed(1)}" r="2.5" fill="${color}" opacity=".9"/>`;
    return b.svg + screenBack + screen + dot + label(x, y + 24, cfg.label, color, 16);
  }

  /** Cloud: puffy 3D volume via stacked ellipses with light/shadow */
  function renderCloud(x, y, cfg = {}) {
    const color = cfg.color || '#65aef9';
    const scale = cfg.scale || 1;
    const rx = 48 * scale, ry = 30 * scale;
    const topC = shade(color, 0.25);
    const midC = shade(color, 0.0);
    const shadowC = shade(color, -0.45);
    const stroke = shade(color, -0.55);
    // Shadow (ground disk)
    const shadow = `<ellipse cx="${x}" cy="${(y + ry * 0.8).toFixed(1)}" rx="${(rx * 0.8).toFixed(1)}" ry="${(ry * 0.25).toFixed(1)}" fill="black" opacity=".18"/>`;
    // Bottom layer (darker)
    const bottom = `<ellipse cx="${x}" cy="${(y + 4).toFixed(1)}" rx="${rx.toFixed(1)}" ry="${(ry * 0.7).toFixed(1)}" fill="${shadowC}" stroke="${stroke}" stroke-width="0.8"/>`;
    // Midlayer puffs
    const mid =
      `<ellipse cx="${(x - rx * 0.35).toFixed(1)}" cy="${(y - ry * 0.1).toFixed(1)}" rx="${(rx * 0.45).toFixed(1)}" ry="${(ry * 0.55).toFixed(1)}" fill="${midC}" stroke="${stroke}" stroke-width="0.7"/>` +
      `<ellipse cx="${(x + rx * 0.3).toFixed(1)}" cy="${(y - ry * 0.15).toFixed(1)}" rx="${(rx * 0.5).toFixed(1)}" ry="${(ry * 0.6).toFixed(1)}" fill="${midC}" stroke="${stroke}" stroke-width="0.7"/>`;
    // Top highlight puffs (lit)
    const top =
      `<ellipse cx="${(x - rx * 0.15).toFixed(1)}" cy="${(y - ry * 0.45).toFixed(1)}" rx="${(rx * 0.38).toFixed(1)}" ry="${(ry * 0.45).toFixed(1)}" fill="${topC}" stroke="${stroke}" stroke-width="0.6"/>` +
      `<ellipse cx="${(x + rx * 0.12).toFixed(1)}" cy="${(y - ry * 0.55).toFixed(1)}" rx="${(rx * 0.32).toFixed(1)}" ry="${(ry * 0.38).toFixed(1)}" fill="${shade(color, 0.45)}" stroke="${stroke}" stroke-width="0.5"/>`;
    // Specular highlight arc
    const spec = `<path d="M${(x - rx * 0.35).toFixed(1)},${(y - ry * 0.55).toFixed(1)} Q${(x - rx * 0.1).toFixed(1)},${(y - ry * 0.8).toFixed(1)} ${(x + rx * 0.15).toFixed(1)},${(y - ry * 0.7).toFixed(1)}" fill="none" stroke="${shade(color, 0.7)}" stroke-width="1.1" opacity=".75" stroke-linecap="round"/>`;
    const lbl = cfg.label ? label(x, y + ry * 0.6, cfg.label, color, 14) : '';
    return shadow + bottom + mid + top + spec + lbl;
  }

  /* ═════════════════════════════════════════════════════════════
     Register all types
     ═════════════════════════════════════════════════════════════ */
  const TYPES = {
    'iso:box':       renderBox,
    'iso:server':    renderServer,
    'iso:rack':      renderRack,
    'iso:database':  renderDatabase,
    'iso:cylinder':  renderCylinder,
    'iso:switch':    renderSwitch,
    'iso:router':    renderRouter,
    'iso:firewall':  renderFirewall,
    'iso:ec':        renderEC,
    'iso:host':      renderHost,
    'iso:cloud':     renderCloud,
  };
  Object.keys(TYPES).forEach((name) => TopologyDesigner.registerNodeType(name, TYPES[name]));

  // Expose for external use / inspection
  TopologyDesigner.Iso3D = { box3d, cyl3d, iso, shade, TYPES };
})();
