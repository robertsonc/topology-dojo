/* ═══════════════════════════════════════════════════════════════
   Theme Engine — Color scheme generation and management
   Generates cohesive palettes from brand colors with WCAG checks.
   ═══════════════════════════════════════════════════════════════ */

class ThemeEngine {

  static PRESETS = {
    'default-dark': {
      name: 'Default Dark',
      bg: '#1d1f27', panel: '#22252e',
      text: '#e6e8e9', muted: '#7d8a92',
      green: '#01a982', blue: '#65aef9',
      purple: '#7764fc', gold: '#deb146',
      red: '#fc6161', teal: '#00a4b3',
    },
    'midnight': {
      name: 'Midnight Blue',
      bg: '#0f1729', panel: '#162040',
      text: '#e0e8f5', muted: '#6b7da0',
      green: '#00d4a1', blue: '#4da6ff',
      purple: '#8b5cf6', gold: '#f59e0b',
      red: '#ef4444', teal: '#06b6d4',
    },
    'charcoal': {
      name: 'Charcoal',
      bg: '#1a1a1a', panel: '#242424',
      text: '#e5e5e5', muted: '#888888',
      green: '#22c55e', blue: '#3b82f6',
      purple: '#a855f7', gold: '#eab308',
      red: '#ef4444', teal: '#14b8a6',
    },
    'corporate': {
      name: 'Corporate Blue',
      bg: '#f8fafc', panel: '#ffffff',
      text: '#1e293b', muted: '#64748b',
      green: '#059669', blue: '#2563eb',
      purple: '#7c3aed', gold: '#d97706',
      red: '#dc2626', teal: '#0891b2',
    },
    'warm-dark': {
      name: 'Warm Dark',
      bg: '#1c1917', panel: '#292524',
      text: '#e7e5e4', muted: '#a8a29e',
      green: '#34d399', blue: '#60a5fa',
      purple: '#c084fc', gold: '#fbbf24',
      red: '#f87171', teal: '#2dd4bf',
    },
  };

  /* ── Generate a palette from a primary color ──
     @param {string} primaryHex - Primary brand color in hex
     @param {object} options - { mode: 'dark'|'light', accentHex }
     @returns {object} Full theme object
  */
  static generateFromPrimary(primaryHex, options = {}) {
    const { mode = 'dark', accentHex } = options;
    const primary = ThemeEngine._hexToHSL(primaryHex);

    // Generate harmonious colors
    const complementary = { h: (primary.h + 180) % 360, s: primary.s, l: primary.l };
    const triadic1 = { h: (primary.h + 120) % 360, s: primary.s * 0.9, l: primary.l };
    const triadic2 = { h: (primary.h + 240) % 360, s: primary.s * 0.8, l: primary.l };
    const analogous = { h: (primary.h + 30) % 360, s: primary.s, l: primary.l };

    const green = ThemeEngine._hslToHex(primary);
    const blue = ThemeEngine._hslToHex(analogous);
    const purple = ThemeEngine._hslToHex(triadic1);
    const gold = ThemeEngine._hslToHex(complementary);
    const red = ThemeEngine._hslToHex({ h: 0, s: 80, l: mode === 'dark' ? 68 : 50 });
    const teal = ThemeEngine._hslToHex(triadic2);

    if (mode === 'dark') {
      return {
        name: 'Custom Dark',
        bg: '#1d1f27', panel: '#22252e',
        text: '#e6e8e9', muted: '#7d8a92',
        green, blue, purple, gold, red, teal,
      };
    } else {
      return {
        name: 'Custom Light',
        bg: '#f8fafc', panel: '#ffffff',
        text: '#1e293b', muted: '#64748b',
        green, blue, purple, gold, red, teal,
      };
    }
  }

  /* ── Apply theme to document ──
     @param {object} theme
  */
  static apply(theme) {
    const root = document.documentElement;
    const mapping = {
      bg: '--tds-bg', panel: '--tds-panel',
      text: '--tds-text', muted: '--tds-muted',
      green: '--tds-green', blue: '--tds-blue',
      purple: '--tds-purple', gold: '--tds-gold',
      red: '--tds-red', teal: '--tds-teal',
    };

    Object.entries(mapping).forEach(([key, prop]) => {
      if (theme[key]) root.style.setProperty(prop, theme[key]);
    });

    // Update glow colors
    if (theme.green) {
      const rgb = ThemeEngine._hexToRGB(theme.green);
      root.style.setProperty('--tds-glow-green', `rgba(${rgb.r},${rgb.g},${rgb.b},.35)`);
    }
    if (theme.purple) {
      const rgb = ThemeEngine._hexToRGB(theme.purple);
      root.style.setProperty('--tds-glow-purple', `rgba(${rgb.r},${rgb.g},${rgb.b},.25)`);
    }
    if (theme.blue) {
      const rgb = ThemeEngine._hexToRGB(theme.blue);
      root.style.setProperty('--tds-glow-blue', `rgba(${rgb.r},${rgb.g},${rgb.b},.2)`);
    }
  }

  /* ── WCAG contrast ratio check ──
     @param {string} fg - foreground hex
     @param {string} bg - background hex
     @returns {number} contrast ratio (1-21)
  */
  static contrastRatio(fg, bg) {
    const l1 = ThemeEngine._relativeLuminance(fg);
    const l2 = ThemeEngine._relativeLuminance(bg);
    const lighter = Math.max(l1, l2);
    const darker = Math.min(l1, l2);
    return (lighter + 0.05) / (darker + 0.05);
  }

  /* ── Check if a color pair passes WCAG AA ──
     @returns {boolean}
  */
  static passesWCAG_AA(fg, bg) {
    return ThemeEngine.contrastRatio(fg, bg) >= 4.5;
  }

  /* ── Export theme as CSS custom properties ── */
  static toCSS(theme) {
    let css = ':root {\n';
    const mapping = {
      bg: '--tds-bg', panel: '--tds-panel',
      text: '--tds-text', muted: '--tds-muted',
      green: '--tds-green', blue: '--tds-blue',
      purple: '--tds-purple', gold: '--tds-gold',
      red: '--tds-red', teal: '--tds-teal',
    };
    Object.entries(mapping).forEach(([key, prop]) => {
      if (theme[key]) css += `  ${prop}: ${theme[key]};\n`;
    });
    css += '}\n';
    return css;
  }

  /* ── Color conversion helpers ── */

  static _hexToRGB(hex) {
    hex = hex.replace('#', '');
    return {
      r: parseInt(hex.substr(0, 2), 16),
      g: parseInt(hex.substr(2, 2), 16),
      b: parseInt(hex.substr(4, 2), 16),
    };
  }

  static _hexToHSL(hex) {
    const { r, g, b } = ThemeEngine._hexToRGB(hex);
    const rn = r / 255, gn = g / 255, bn = b / 255;
    const max = Math.max(rn, gn, bn), min = Math.min(rn, gn, bn);
    let h, s, l = (max + min) / 2;

    if (max === min) {
      h = s = 0;
    } else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case rn: h = ((gn - bn) / d + (gn < bn ? 6 : 0)) / 6; break;
        case gn: h = ((bn - rn) / d + 2) / 6; break;
        case bn: h = ((rn - gn) / d + 4) / 6; break;
      }
    }

    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  static _hslToHex({ h, s, l }) {
    s /= 100; l /= 100;
    const a = s * Math.min(l, 1 - l);
    const f = n => {
      const k = (n + h / 30) % 12;
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
      return Math.round(255 * color).toString(16).padStart(2, '0');
    };
    return `#${f(0)}${f(8)}${f(4)}`;
  }

  static _relativeLuminance(hex) {
    const { r, g, b } = ThemeEngine._hexToRGB(hex);
    const [rs, gs, bs] = [r, g, b].map(c => {
      c /= 255;
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
  }
}

// Support both module and global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ThemeEngine;
} else if (typeof window !== 'undefined') {
  window.ThemeEngine = ThemeEngine;
}
