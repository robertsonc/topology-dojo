/* ═══════════════════════════════════════════════════════════════
   Template Parser — Import topologies from templates and text
   Supports JSON templates and Mermaid-inspired diagram-as-code.
   ═══════════════════════════════════════════════════════════════ */

class TemplateParser {

  /* ── Parse Mermaid-inspired text ──
     Syntax:
       topology TB|LR|BT|RL
       NodeID[Label]:::type
       NodeID -->|label| NodeID2
       NodeID -.->|label| NodeID2  (dashed)
       NodeID ==>|label| NodeID2  (tunnel)

     @param {string} text
     @returns {object} { nodes: [], links: [], direction: string }
  */
  static fromText(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#') && !l.startsWith('//'));
    const result = { nodes: [], links: [], direction: 'TB' };
    const nodeMap = new Map();

    for (const line of lines) {
      // Direction line
      const dirMatch = line.match(/^topology\s+(TB|BT|LR|RL)$/i);
      if (dirMatch) {
        result.direction = dirMatch[1].toUpperCase();
        continue;
      }

      // Link lines (must check before node to avoid false matches)
      // Patterns: --> , -.-> , ==> , ~~> , -x-> , ->> , with optional |label|
      const linkMatch = line.match(
        /^(\w+)\s*(-->|-.->|==>|~~>|-x->|->>)\s*(?:\|([^|]*)\|)?\s*(\w+)$/
      );
      if (linkMatch) {
        const [, from, arrow, label, to] = linkMatch;
        let type = 'line';
        if (arrow === '==>') type = 'tunnel';
        else if (arrow === '-.->') type = 'line'; // dashed
        else if (arrow === '~~>') type = 'flow';
        else if (arrow === '-x->') type = 'blocked';
        else if (arrow === '->>') type = 'packet';

        const link = { from, to, type };
        if (label) link.label = label.trim();
        if (arrow === '-.->') link.dashed = true;
        if (type === 'tunnel') link.color = '#65aef9';
        if (type === 'blocked') link.color = '#fc6161';

        result.links.push(link);

        // Auto-register nodes if not seen
        [from, to].forEach(id => {
          if (!nodeMap.has(id)) {
            nodeMap.set(id, { id, label: id, type: 'server' });
          }
        });
        continue;
      }

      // Node lines: ID[Label]:::type  or  ID[(Label)]:::type (database)  or  ID((Label)):::type (circle)
      const nodeMatch = line.match(
        /^(\w+)\s*(?:\[([^\]]*)\]|\(\[([^\]]*)\]\)|\[\(([^)]*)\)\]|\(\(([^)]*)\)\))?\s*(?:::(\w+))?$/
      );
      if (nodeMatch) {
        const [, id, labelBracket, labelRound, labelDB, labelCircle, type] = nodeMatch;
        const label = labelBracket || labelRound || labelDB || labelCircle || id;
        const nodeType = type || (labelDB ? 'database' : 'server');

        if (!nodeMap.has(id)) {
          nodeMap.set(id, { id, label, type: nodeType });
        } else {
          const existing = nodeMap.get(id);
          existing.label = label;
          existing.type = nodeType;
        }
        continue;
      }
    }

    result.nodes = Array.from(nodeMap.values());
    return result;
  }

  /* ── Apply parsed result to a TopologyDesigner ──
     @param {TopologyDesigner} topo
     @param {object} parsed - { nodes, links, direction }
     @param {object} options - { layout, width, height, clearFirst }
  */
  static applyToDesigner(topo, parsed, options = {}) {
    const { layout = 'hierarchical', width = 1050, height = 700, clearFirst = false } = options;

    if (clearFirst) {
      topo._nodes.clear();
      topo._links.clear();
      topo._anchors.clear();
      topo._acts = [];
      topo._steps = [];
    }

    // Register nodes (without positions initially)
    parsed.nodes.forEach(n => {
      topo.node(n.id, {
        type: n.type || 'server',
        x: 0, y: 0,
        label: n.label || n.id,
        ...n,
      });
    });

    // Register links
    parsed.links.forEach((l, i) => {
      const id = l.id || `link-${i + 1}`;
      topo.link(id, {
        type: l.type || 'line',
        from: l.from,
        to: l.to,
        label: l.label || '',
        color: l.color || '#01a982',
        dashed: l.dashed || false,
        ...l,
      });
    });

    // Auto-layout
    if (typeof LayoutEngine !== 'undefined') {
      const layoutFn = LayoutEngine[layout] || LayoutEngine.hierarchical;
      const positions = layoutFn(topo._nodes, topo._links, {
        width, height,
        direction: parsed.direction || 'TB',
      });
      LayoutEngine.apply(topo, positions, false);
    }

    // Auto-generate a basic choreography if none exists
    if (topo._acts.length === 0 && parsed.nodes.length > 0) {
      topo.act('auto', { label: 'Topology', color: '#01a982' });
      const phases = [];
      const nodeIds = parsed.nodes.map(n => n.id);
      const linkIds = parsed.links.map((l, i) => l.id || `link-${i + 1}`);

      // Phase 1: show all nodes
      phases.push({ show: nodeIds, diff: 'All nodes appear' });

      // Phase 2: show all links
      if (linkIds.length > 0) {
        phases.push({ show: linkIds, diff: 'All connections' });
      }

      topo.addStep('overview', {
        act: 'auto',
        name: 'Overview',
        goal: 'Complete topology view.',
        focus: [],
        phases,
      });
    }
  }

  /* ── Built-in Templates ── */

  static get TEMPLATES() {
    return {
      'hub-spoke': {
        name: 'Hub & Spoke',
        description: 'Central device with N branch connections',
        icon: '⊛',
        generate: (options = {}) => {
          const { branches = 4, hubType = 'router', spokeType = 'host' } = options;
          const nodes = [{ id: 'HUB', label: 'Hub', type: hubType }];
          const links = [];
          for (let i = 1; i <= branches; i++) {
            nodes.push({ id: `S${i}`, label: `Spoke ${i}`, type: spokeType });
            links.push({ from: 'HUB', to: `S${i}`, type: 'line' });
          }
          return { nodes, links, direction: 'TB' };
        },
      },

      '3-tier': {
        name: '3-Tier Architecture',
        description: 'Load balancer → App servers → Database',
        icon: '▦',
        generate: (options = {}) => {
          const { appServers = 2 } = options;
          const nodes = [
            { id: 'LB', label: 'Load Balancer', type: 'ec' },
            { id: 'DB', label: 'Database', type: 'database' },
          ];
          const links = [];
          for (let i = 1; i <= appServers; i++) {
            nodes.splice(i, 0, { id: `APP${i}`, label: `App Server ${i}`, type: 'server' });
            links.push({ from: 'LB', to: `APP${i}`, type: 'line', label: 'HTTPS' });
            links.push({ from: `APP${i}`, to: 'DB', type: 'line', label: 'SQL' });
          }
          return { nodes, links, direction: 'TB' };
        },
      },

      'mesh': {
        name: 'Full Mesh',
        description: 'Every node connected to every other',
        icon: '◈',
        generate: (options = {}) => {
          const { count = 4, nodeType = 'router' } = options;
          const nodes = [];
          const links = [];
          for (let i = 1; i <= count; i++) {
            nodes.push({ id: `N${i}`, label: `Node ${i}`, type: nodeType });
          }
          for (let i = 0; i < count; i++) {
            for (let j = i + 1; j < count; j++) {
              links.push({ from: `N${i + 1}`, to: `N${j + 1}`, type: 'tunnel', color: '#65aef9' });
            }
          }
          return { nodes, links, direction: 'TB' };
        },
      },

      'star': {
        name: 'Star Topology',
        description: 'Central switch with connected endpoints',
        icon: '✦',
        generate: (options = {}) => {
          const { endpoints = 6 } = options;
          const nodes = [{ id: 'SW', label: 'Core Switch', type: 'switch' }];
          const links = [];
          for (let i = 1; i <= endpoints; i++) {
            nodes.push({ id: `E${i}`, label: `Endpoint ${i}`, type: 'host' });
            links.push({ from: 'SW', to: `E${i}`, type: 'line' });
          }
          return { nodes, links, direction: 'TB' };
        },
      },

      'spine-leaf': {
        name: 'Spine-Leaf Fabric',
        description: 'Data center fabric with spine and leaf switches',
        icon: '▤',
        generate: (options = {}) => {
          const { spines = 2, leaves = 4 } = options;
          const nodes = [];
          const links = [];
          for (let i = 1; i <= spines; i++) {
            nodes.push({ id: `SP${i}`, label: `Spine ${i}`, type: 'switch', color: '#7764fc' });
          }
          for (let i = 1; i <= leaves; i++) {
            nodes.push({ id: `LF${i}`, label: `Leaf ${i}`, type: 'switch' });
            for (let j = 1; j <= spines; j++) {
              links.push({ from: `SP${j}`, to: `LF${i}`, type: 'line', color: '#01a982' });
            }
          }
          return { nodes, links, direction: 'TB' };
        },
      },

      'sdwan': {
        name: 'SD-WAN + ZTNA',
        description: 'Branch offices with cloud security and ZTNA',
        icon: '☁',
        generate: () => {
          return {
            nodes: [
              { id: 'INET', label: 'Internet', type: 'cloud', color: '#b1b9be' },
              { id: 'SSE', label: 'Cloud SSE', type: 'cloud', color: '#65aef9', sub1: 'SWG · ZTNA · CASB' },
              { id: 'HQ', label: 'HQ Gateway', type: 'ec' },
              { id: 'BR1', label: 'Branch 1', type: 'ec' },
              { id: 'BR2', label: 'Branch 2', type: 'ec' },
              { id: 'SW1', label: 'Switch', type: 'switch' },
              { id: 'SW2', label: 'Switch', type: 'switch' },
              { id: 'USER1', label: 'User 1', type: 'host' },
              { id: 'USER2', label: 'User 2', type: 'host' },
              { id: 'APPS', label: 'Private Apps', type: 'apps' },
            ],
            links: [
              { from: 'HQ', to: 'INET', type: 'line', color: '#b1b9be' },
              { from: 'BR1', to: 'INET', type: 'line', color: '#b1b9be' },
              { from: 'BR2', to: 'INET', type: 'line', color: '#b1b9be' },
              { from: 'HQ', to: 'BR1', type: 'tunnel', color: '#01a982', label: 'SD-WAN Overlay' },
              { from: 'HQ', to: 'BR2', type: 'tunnel', color: '#01a982', label: 'SD-WAN Overlay' },
              { from: 'BR1', to: 'SW1', type: 'line', color: '#01a982' },
              { from: 'BR2', to: 'SW2', type: 'line', color: '#01a982' },
              { from: 'SW1', to: 'USER1', type: 'line', color: '#01a982' },
              { from: 'SW2', to: 'USER2', type: 'line', color: '#01a982' },
              { from: 'HQ', to: 'APPS', type: 'line', color: '#deb146' },
            ],
            direction: 'TB',
          };
        },
      },

      'firewall-dmz': {
        name: 'Firewall + DMZ',
        description: 'Internet → Firewall → DMZ → Internal network',
        icon: '🔥',
        generate: () => {
          return {
            nodes: [
              { id: 'INET', label: 'Internet', type: 'cloud', color: '#b1b9be' },
              { id: 'FW', label: 'Firewall', type: 'firewall' },
              { id: 'DMZ_SW', label: 'DMZ Switch', type: 'switch' },
              { id: 'WEB1', label: 'Web Server 1', type: 'server' },
              { id: 'WEB2', label: 'Web Server 2', type: 'server' },
              { id: 'INT_SW', label: 'Internal Switch', type: 'switch' },
              { id: 'APP', label: 'App Server', type: 'server', color: '#deb146' },
              { id: 'DB', label: 'Database', type: 'database' },
            ],
            links: [
              { from: 'INET', to: 'FW', type: 'line', color: '#fc6161' },
              { from: 'FW', to: 'DMZ_SW', type: 'line', color: '#fc6161' },
              { from: 'DMZ_SW', to: 'WEB1', type: 'line', color: '#01a982' },
              { from: 'DMZ_SW', to: 'WEB2', type: 'line', color: '#01a982' },
              { from: 'FW', to: 'INT_SW', type: 'line', color: '#01a982' },
              { from: 'INT_SW', to: 'APP', type: 'line', color: '#deb146' },
              { from: 'APP', to: 'DB', type: 'line', color: '#deb146' },
            ],
            direction: 'TB',
          };
        },
      },

      /* ═══════════════════════════════════════════════════════════
         Enterprise Templates (#180)
         ═══════════════════════════════════════════════════════════ */

      'sd-wan': {
        name: 'SD-WAN Enterprise',
        description: 'Hub-and-spoke SD-WAN with cloud orchestrator, data centers, and branch sites',
        icon: '🌐',
        generate: () => {
          const nodes = [
            { id: 'ORCH', label: 'Cloud Orchestrator', type: 'cloud', color: '#7764fc' },
            { id: 'DC1', label: 'Data Center 1', type: 'ec', color: '#01a982', sub1: 'Edge Connect' },
            { id: 'DC2', label: 'Data Center 2', type: 'ec', color: '#01a982', sub1: 'Edge Connect' },
            { id: 'BR1', label: 'Branch 1', type: 'ec', sub1: 'Edge Connect' },
            { id: 'BR2', label: 'Branch 2', type: 'ec', sub1: 'Edge Connect' },
            { id: 'BR3', label: 'Branch 3', type: 'ec', sub1: 'Edge Connect' },
          ];
          const links = [
            { id: 'L1', from: 'ORCH', to: 'DC1', type: 'line', color: '#7764fc', label: 'Mgmt' },
            { id: 'L2', from: 'ORCH', to: 'DC2', type: 'line', color: '#7764fc', label: 'Mgmt' },
            { id: 'L3', from: 'DC1', to: 'DC2', type: 'tunnel', color: '#65aef9', label: 'DC Fabric' },
            { id: 'L4', from: 'DC1', to: 'BR1', type: 'tunnel', color: '#01a982', label: 'WAN Tunnel' },
            { id: 'L5', from: 'DC1', to: 'BR2', type: 'tunnel', color: '#01a982', label: 'WAN Tunnel' },
            { id: 'L6', from: 'DC2', to: 'BR3', type: 'tunnel', color: '#01a982', label: 'WAN Tunnel' },
            { id: 'L7', from: 'BR1', to: 'BR2', type: 'tunnel', color: '#65aef9', label: 'Branch Mesh', dashed: true },
            { id: 'L8', from: 'BR2', to: 'BR3', type: 'tunnel', color: '#65aef9', label: 'Branch Mesh', dashed: true },
          ];
          const acts = [
            { id: 'sdwan-deploy', label: 'SD-WAN Deployment', color: '#01a982' },
          ];
          const steps = [
            {
              id: 'overlay-build', act: 'sdwan-deploy', name: 'Overlay Build',
              goal: 'Establish SD-WAN overlay fabric between data centers.',
              focus: ['ORCH', 'DC1', 'DC2'],
              phases: [
                { show: ['ORCH', 'DC1', 'DC2'], diff: 'Deploy orchestrator and DC edge connects' },
                { show: ['L1', 'L2', 'L3'], diff: 'Management plane and DC-to-DC fabric tunnel' },
              ],
            },
            {
              id: 'branch-connect', act: 'sdwan-deploy', name: 'Branch Connect',
              goal: 'Connect branch sites to data center hubs via WAN tunnels.',
              focus: ['BR1', 'BR2', 'BR3'],
              phases: [
                { show: ['BR1', 'BR2', 'BR3'], diff: 'Deploy branch edge connects' },
                { show: ['L4', 'L5', 'L6'], diff: 'Establish WAN tunnels to DCs' },
              ],
            },
            {
              id: 'breakout-policy', act: 'sdwan-deploy', name: 'Breakout Policy',
              goal: 'Configure internet breakout and traffic policies.',
              focus: ['BR1', 'BR2', 'BR3', 'ORCH'],
              phases: [
                { show: ['L7', 'L8'], diff: 'Enable branch-to-branch mesh tunnels' },
              ],
            },
            {
              id: 'optimization', act: 'sdwan-deploy', name: 'Optimization',
              goal: 'Enable WAN optimization and path selection.',
              focus: ['ORCH', 'DC1', 'DC2', 'BR1', 'BR2', 'BR3'],
              phases: [
                { show: ['ORCH', 'DC1', 'DC2', 'BR1', 'BR2', 'BR3', 'L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8'], diff: 'Full SD-WAN fabric optimized' },
              ],
            },
          ];
          const zones = [
            { id: 'zone-dc', label: 'Data Centers', nodes: ['DC1', 'DC2'], color: '#01a982', borderStyle: 'solid' },
            { id: 'zone-branch', label: 'Branch Sites', nodes: ['BR1', 'BR2', 'BR3'], color: '#65aef9', borderStyle: 'dashed' },
          ];
          return { nodes, links, acts, steps, zones, direction: 'TB' };
        },
      },

      'ztna': {
        name: 'Zero Trust Network Access',
        description: 'Identity-driven segmented access with policy engine and ZTNA controls',
        icon: '🔒',
        generate: () => {
          const nodes = [
            { id: 'IDP', label: 'Identity Provider', type: 'cloud', color: '#7764fc', sub1: 'SSO / MFA' },
            { id: 'PE', label: 'Policy Engine', type: 'firewall', color: '#deb146', sub1: 'Zero Trust Broker' },
            { id: 'APP1', label: 'App Server 1', type: 'server', color: '#01a982' },
            { id: 'APP2', label: 'App Server 2', type: 'server', color: '#01a982' },
            { id: 'USR1', label: 'Remote User 1', type: 'host' },
            { id: 'USR2', label: 'Remote User 2', type: 'host' },
            { id: 'USR3', label: 'Remote User 3', type: 'host' },
          ];
          const links = [
            { id: 'L1', from: 'USR1', to: 'IDP', type: 'line', color: '#7764fc', label: 'Auth' },
            { id: 'L2', from: 'USR2', to: 'IDP', type: 'line', color: '#7764fc', label: 'Auth' },
            { id: 'L3', from: 'USR3', to: 'IDP', type: 'line', color: '#7764fc', label: 'Auth' },
            { id: 'L4', from: 'IDP', to: 'PE', type: 'line', color: '#deb146', label: 'Token' },
            { id: 'L5', from: 'PE', to: 'APP1', type: 'tunnel', color: '#01a982', label: 'Secure Access' },
            { id: 'L6', from: 'PE', to: 'APP2', type: 'tunnel', color: '#01a982', label: 'Secure Access' },
            { id: 'L7', from: 'USR1', to: 'PE', type: 'line', color: '#65aef9', label: 'Request', dashed: true },
            { id: 'L8', from: 'USR2', to: 'PE', type: 'line', color: '#65aef9', label: 'Request', dashed: true },
            { id: 'L9', from: 'USR3', to: 'PE', type: 'line', color: '#65aef9', label: 'Request', dashed: true },
          ];
          const acts = [
            { id: 'ztna-flow', label: 'ZTNA Access Flow', color: '#7764fc' },
          ];
          const steps = [
            {
              id: 'identity-verify', act: 'ztna-flow', name: 'Identity Verification',
              goal: 'Users authenticate via identity provider with MFA.',
              focus: ['USR1', 'USR2', 'USR3', 'IDP'],
              phases: [
                { show: ['USR1', 'USR2', 'USR3', 'IDP'], diff: 'Users and identity provider' },
                { show: ['L1', 'L2', 'L3'], diff: 'Authentication requests' },
              ],
            },
            {
              id: 'policy-eval', act: 'ztna-flow', name: 'Policy Evaluation',
              goal: 'Policy engine evaluates access based on identity, posture, and context.',
              focus: ['IDP', 'PE'],
              phases: [
                { show: ['PE'], diff: 'Policy engine online' },
                { show: ['L4'], diff: 'Identity token passed to policy engine' },
                { show: ['L7', 'L8', 'L9'], diff: 'User access requests evaluated' },
              ],
            },
            {
              id: 'secure-access', act: 'ztna-flow', name: 'Secure Access',
              goal: 'Authorized users gain segmented access to applications.',
              focus: ['PE', 'APP1', 'APP2'],
              phases: [
                { show: ['APP1', 'APP2'], diff: 'Application servers' },
                { show: ['L5', 'L6'], diff: 'Secure tunnels to applications' },
              ],
            },
          ];
          const zones = [
            { id: 'zone-users', label: 'User Endpoints', nodes: ['USR1', 'USR2', 'USR3'], color: '#65aef9', borderStyle: 'dashed' },
            { id: 'zone-apps', label: 'Application Segment', nodes: ['APP1', 'APP2'], color: '#01a982', borderStyle: 'solid' },
          ];
          return { nodes, links, acts, steps, zones, direction: 'LR' };
        },
      },

      'campus': {
        name: 'Campus Network',
        description: 'Three-tier campus: core router, distribution switches, access layer with APs and hosts',
        icon: '🏢',
        generate: () => {
          const nodes = [
            { id: 'CORE', label: 'Core Router', type: 'router', color: '#7764fc' },
            { id: 'DIST1', label: 'Distribution SW 1', type: 'switch', color: '#01a982' },
            { id: 'DIST2', label: 'Distribution SW 2', type: 'switch', color: '#01a982' },
            { id: 'ACC1', label: 'Access SW 1', type: 'switch' },
            { id: 'ACC2', label: 'Access SW 2', type: 'switch' },
            { id: 'ACC3', label: 'Access SW 3', type: 'switch' },
            { id: 'ACC4', label: 'Access SW 4', type: 'switch' },
            { id: 'AP1', label: 'AP 1', type: 'host', sub1: 'Wireless' },
            { id: 'AP2', label: 'AP 2', type: 'host', sub1: 'Wireless' },
            { id: 'AP3', label: 'AP 3', type: 'host', sub1: 'Wireless' },
            { id: 'AP4', label: 'AP 4', type: 'host', sub1: 'Wireless' },
            { id: 'H1', label: 'Host 1', type: 'host' },
            { id: 'H2', label: 'Host 2', type: 'host' },
            { id: 'H3', label: 'Host 3', type: 'host' },
            { id: 'H4', label: 'Host 4', type: 'host' },
          ];
          const links = [
            { id: 'L1', from: 'CORE', to: 'DIST1', type: 'line', color: '#7764fc', label: '10G' },
            { id: 'L2', from: 'CORE', to: 'DIST2', type: 'line', color: '#7764fc', label: '10G' },
            { id: 'L3', from: 'DIST1', to: 'ACC1', type: 'line', color: '#01a982', label: '1G' },
            { id: 'L4', from: 'DIST1', to: 'ACC2', type: 'line', color: '#01a982', label: '1G' },
            { id: 'L5', from: 'DIST2', to: 'ACC3', type: 'line', color: '#01a982', label: '1G' },
            { id: 'L6', from: 'DIST2', to: 'ACC4', type: 'line', color: '#01a982', label: '1G' },
            { id: 'L7', from: 'ACC1', to: 'AP1', type: 'line' },
            { id: 'L8', from: 'ACC1', to: 'H1', type: 'line' },
            { id: 'L9', from: 'ACC2', to: 'AP2', type: 'line' },
            { id: 'L10', from: 'ACC2', to: 'H2', type: 'line' },
            { id: 'L11', from: 'ACC3', to: 'AP3', type: 'line' },
            { id: 'L12', from: 'ACC3', to: 'H3', type: 'line' },
            { id: 'L13', from: 'ACC4', to: 'AP4', type: 'line' },
            { id: 'L14', from: 'ACC4', to: 'H4', type: 'line' },
          ];
          const acts = [
            { id: 'campus-deploy', label: 'Campus Deployment', color: '#7764fc' },
          ];
          const steps = [
            {
              id: 'core-layer', act: 'campus-deploy', name: 'Core Layer',
              goal: 'Deploy core routing infrastructure.',
              focus: ['CORE'],
              phases: [
                { show: ['CORE'], diff: 'Core router deployed' },
              ],
            },
            {
              id: 'distribution-layer', act: 'campus-deploy', name: 'Distribution Layer',
              goal: 'Deploy distribution switches and uplinks to core.',
              focus: ['DIST1', 'DIST2'],
              phases: [
                { show: ['DIST1', 'DIST2'], diff: 'Distribution switches deployed' },
                { show: ['L1', 'L2'], diff: '10G uplinks to core' },
              ],
            },
            {
              id: 'access-layer', act: 'campus-deploy', name: 'Access Layer',
              goal: 'Deploy access switches, APs, and end hosts.',
              focus: ['ACC1', 'ACC2', 'ACC3', 'ACC4'],
              phases: [
                { show: ['ACC1', 'ACC2', 'ACC3', 'ACC4'], diff: 'Access switches deployed' },
                { show: ['L3', 'L4', 'L5', 'L6'], diff: '1G downlinks from distribution' },
                { show: ['AP1', 'AP2', 'AP3', 'AP4', 'H1', 'H2', 'H3', 'H4'], diff: 'APs and hosts connected' },
                { show: ['L7', 'L8', 'L9', 'L10', 'L11', 'L12', 'L13', 'L14'], diff: 'Access port connections' },
              ],
            },
          ];
          const zones = [
            { id: 'zone-core', label: 'Core', nodes: ['CORE'], color: '#7764fc', borderStyle: 'solid' },
            { id: 'zone-dist', label: 'Distribution', nodes: ['DIST1', 'DIST2'], color: '#01a982', borderStyle: 'solid' },
            { id: 'zone-access', label: 'Access', nodes: ['ACC1', 'ACC2', 'ACC3', 'ACC4', 'AP1', 'AP2', 'AP3', 'AP4', 'H1', 'H2', 'H3', 'H4'], color: '#65aef9', borderStyle: 'dashed' },
          ];
          return { nodes, links, acts, steps, zones, direction: 'TB' };
        },
      },

      'data-center': {
        name: 'Data Center Spine-Leaf',
        description: 'Spine-leaf fabric with compute servers and shared storage',
        icon: '🏗️',
        generate: () => {
          const nodes = [
            { id: 'SP1', label: 'Spine 1', type: 'switch', color: '#7764fc' },
            { id: 'SP2', label: 'Spine 2', type: 'switch', color: '#7764fc' },
            { id: 'LF1', label: 'Leaf 1', type: 'switch', color: '#01a982' },
            { id: 'LF2', label: 'Leaf 2', type: 'switch', color: '#01a982' },
            { id: 'LF3', label: 'Leaf 3', type: 'switch', color: '#01a982' },
            { id: 'LF4', label: 'Leaf 4', type: 'switch', color: '#01a982' },
            { id: 'SRV1', label: 'Server 1', type: 'server' },
            { id: 'SRV2', label: 'Server 2', type: 'server' },
            { id: 'SRV3', label: 'Server 3', type: 'server' },
            { id: 'SRV4', label: 'Server 4', type: 'server' },
            { id: 'SRV5', label: 'Server 5', type: 'server' },
            { id: 'SRV6', label: 'Server 6', type: 'server' },
            { id: 'SRV7', label: 'Server 7', type: 'server' },
            { id: 'SRV8', label: 'Server 8', type: 'server' },
            { id: 'STOR', label: 'Storage Array', type: 'database', color: '#deb146', sub1: 'SAN / NAS' },
          ];
          const links = [
            // Spine-Leaf full mesh
            { id: 'L1', from: 'SP1', to: 'LF1', type: 'line', color: '#7764fc' },
            { id: 'L2', from: 'SP1', to: 'LF2', type: 'line', color: '#7764fc' },
            { id: 'L3', from: 'SP1', to: 'LF3', type: 'line', color: '#7764fc' },
            { id: 'L4', from: 'SP1', to: 'LF4', type: 'line', color: '#7764fc' },
            { id: 'L5', from: 'SP2', to: 'LF1', type: 'line', color: '#7764fc' },
            { id: 'L6', from: 'SP2', to: 'LF2', type: 'line', color: '#7764fc' },
            { id: 'L7', from: 'SP2', to: 'LF3', type: 'line', color: '#7764fc' },
            { id: 'L8', from: 'SP2', to: 'LF4', type: 'line', color: '#7764fc' },
            // Servers to leaves (2 per leaf)
            { id: 'L9', from: 'LF1', to: 'SRV1', type: 'line', color: '#01a982' },
            { id: 'L10', from: 'LF1', to: 'SRV2', type: 'line', color: '#01a982' },
            { id: 'L11', from: 'LF2', to: 'SRV3', type: 'line', color: '#01a982' },
            { id: 'L12', from: 'LF2', to: 'SRV4', type: 'line', color: '#01a982' },
            { id: 'L13', from: 'LF3', to: 'SRV5', type: 'line', color: '#01a982' },
            { id: 'L14', from: 'LF3', to: 'SRV6', type: 'line', color: '#01a982' },
            { id: 'L15', from: 'LF4', to: 'SRV7', type: 'line', color: '#01a982' },
            { id: 'L16', from: 'LF4', to: 'SRV8', type: 'line', color: '#01a982' },
            // Storage connectivity
            { id: 'L17', from: 'LF3', to: 'STOR', type: 'line', color: '#deb146', label: 'iSCSI' },
            { id: 'L18', from: 'LF4', to: 'STOR', type: 'line', color: '#deb146', label: 'iSCSI' },
          ];
          const acts = [
            { id: 'dc-build', label: 'Data Center Build', color: '#7764fc' },
          ];
          const steps = [
            {
              id: 'fabric-build', act: 'dc-build', name: 'Fabric Build',
              goal: 'Deploy spine-leaf switching fabric.',
              focus: ['SP1', 'SP2', 'LF1', 'LF2', 'LF3', 'LF4'],
              phases: [
                { show: ['SP1', 'SP2'], diff: 'Spine switches deployed' },
                { show: ['LF1', 'LF2', 'LF3', 'LF4'], diff: 'Leaf switches deployed' },
                { show: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8'], diff: 'Spine-leaf fabric interconnect' },
              ],
            },
            {
              id: 'compute-attach', act: 'dc-build', name: 'Compute Attach',
              goal: 'Connect compute servers to leaf switches.',
              focus: ['SRV1', 'SRV2', 'SRV3', 'SRV4', 'SRV5', 'SRV6', 'SRV7', 'SRV8'],
              phases: [
                { show: ['SRV1', 'SRV2', 'SRV3', 'SRV4', 'SRV5', 'SRV6', 'SRV7', 'SRV8'], diff: 'Compute servers deployed' },
                { show: ['L9', 'L10', 'L11', 'L12', 'L13', 'L14', 'L15', 'L16'], diff: 'Server-to-leaf connections' },
              ],
            },
            {
              id: 'storage-connect', act: 'dc-build', name: 'Storage Connectivity',
              goal: 'Connect shared storage array to fabric.',
              focus: ['STOR', 'LF3', 'LF4'],
              phases: [
                { show: ['STOR'], diff: 'Storage array deployed' },
                { show: ['L17', 'L18'], diff: 'iSCSI storage connections' },
              ],
            },
          ];
          const zones = [
            { id: 'zone-spine', label: 'Spine Tier', nodes: ['SP1', 'SP2'], color: '#7764fc', borderStyle: 'solid' },
            { id: 'zone-leaf', label: 'Leaf Tier', nodes: ['LF1', 'LF2', 'LF3', 'LF4'], color: '#01a982', borderStyle: 'solid' },
            { id: 'zone-compute', label: 'Compute', nodes: ['SRV1', 'SRV2', 'SRV3', 'SRV4', 'SRV5', 'SRV6', 'SRV7', 'SRV8'], color: '#65aef9', borderStyle: 'dashed' },
          ];
          return { nodes, links, acts, steps, zones, direction: 'TB' };
        },
      },

      'cloud-migration': {
        name: 'Cloud Migration',
        description: 'On-prem data center to cloud migration with hybrid VPN connectivity',
        icon: '☁️',
        generate: () => {
          const nodes = [
            // On-prem
            { id: 'RTR', label: 'On-Prem Router', type: 'router', color: '#7764fc' },
            { id: 'SW', label: 'On-Prem Switch', type: 'switch' },
            { id: 'SRV1', label: 'Server 1', type: 'server' },
            { id: 'SRV2', label: 'Server 2', type: 'server' },
            { id: 'SRV3', label: 'Server 3', type: 'server' },
            // Cloud
            { id: 'VPC', label: 'Cloud VPC', type: 'cloud', color: '#65aef9', sub1: 'Virtual Private Cloud' },
            { id: 'INST1', label: 'Cloud Instance 1', type: 'server', color: '#65aef9' },
            { id: 'INST2', label: 'Cloud Instance 2', type: 'server', color: '#65aef9' },
            { id: 'INST3', label: 'Cloud Instance 3', type: 'server', color: '#65aef9' },
          ];
          const links = [
            { id: 'L1', from: 'RTR', to: 'SW', type: 'line', color: '#7764fc' },
            { id: 'L2', from: 'SW', to: 'SRV1', type: 'line' },
            { id: 'L3', from: 'SW', to: 'SRV2', type: 'line' },
            { id: 'L4', from: 'SW', to: 'SRV3', type: 'line' },
            { id: 'L5', from: 'RTR', to: 'VPC', type: 'tunnel', color: '#01a982', label: 'VPN Tunnel' },
            { id: 'L6', from: 'VPC', to: 'INST1', type: 'line', color: '#65aef9' },
            { id: 'L7', from: 'VPC', to: 'INST2', type: 'line', color: '#65aef9' },
            { id: 'L8', from: 'VPC', to: 'INST3', type: 'line', color: '#65aef9' },
          ];
          const acts = [
            { id: 'migration', label: 'Cloud Migration', color: '#65aef9' },
          ];
          const steps = [
            {
              id: 'current-state', act: 'migration', name: 'Current State',
              goal: 'Document existing on-premises infrastructure.',
              focus: ['RTR', 'SW', 'SRV1', 'SRV2', 'SRV3'],
              phases: [
                { show: ['RTR', 'SW'], diff: 'On-prem network infrastructure' },
                { show: ['SRV1', 'SRV2', 'SRV3'], diff: 'On-prem servers' },
                { show: ['L1', 'L2', 'L3', 'L4'], diff: 'On-prem connectivity' },
              ],
            },
            {
              id: 'cloud-provision', act: 'migration', name: 'Cloud Provision',
              goal: 'Provision cloud VPC and compute instances.',
              focus: ['VPC', 'INST1', 'INST2', 'INST3'],
              phases: [
                { show: ['VPC'], diff: 'Cloud VPC provisioned' },
                { show: ['INST1', 'INST2', 'INST3'], diff: 'Cloud instances launched' },
                { show: ['L6', 'L7', 'L8'], diff: 'Cloud internal networking' },
              ],
            },
            {
              id: 'hybrid-connect', act: 'migration', name: 'Hybrid Connect',
              goal: 'Establish VPN tunnel between on-prem and cloud.',
              focus: ['RTR', 'VPC'],
              phases: [
                { show: ['L5'], diff: 'VPN tunnel established' },
              ],
            },
            {
              id: 'migrate-workloads', act: 'migration', name: 'Migrate Workloads',
              goal: 'Migrate workloads from on-prem servers to cloud instances.',
              focus: ['SRV1', 'SRV2', 'SRV3', 'INST1', 'INST2', 'INST3'],
              phases: [
                { show: ['RTR', 'SW', 'SRV1', 'SRV2', 'SRV3', 'VPC', 'INST1', 'INST2', 'INST3', 'L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8'], diff: 'Full hybrid topology — workloads migrating' },
              ],
            },
          ];
          const zones = [
            { id: 'zone-onprem', label: 'On-Premises DC', nodes: ['RTR', 'SW', 'SRV1', 'SRV2', 'SRV3'], color: '#7764fc', borderStyle: 'solid' },
            { id: 'zone-cloud', label: 'Cloud', nodes: ['VPC', 'INST1', 'INST2', 'INST3'], color: '#65aef9', borderStyle: 'solid' },
          ];
          return { nodes, links, acts, steps, zones, direction: 'LR' };
        },
      },

      'simple': {
        name: 'Simple Starter',
        description: 'Basic topology: router → switch → 3 hosts',
        icon: '⚡',
        generate: () => {
          const nodes = [
            { id: 'R1', label: 'Router', type: 'router', color: '#7764fc' },
            { id: 'SW1', label: 'Switch', type: 'switch', color: '#01a982' },
            { id: 'H1', label: 'Host 1', type: 'host' },
            { id: 'H2', label: 'Host 2', type: 'host' },
            { id: 'H3', label: 'Host 3', type: 'host' },
          ];
          const links = [
            { id: 'L1', from: 'R1', to: 'SW1', type: 'line', color: '#7764fc', label: 'Trunk' },
            { id: 'L2', from: 'SW1', to: 'H1', type: 'line', color: '#01a982' },
            { id: 'L3', from: 'SW1', to: 'H2', type: 'line', color: '#01a982' },
            { id: 'L4', from: 'SW1', to: 'H3', type: 'line', color: '#01a982' },
          ];
          const acts = [
            { id: 'setup', label: 'Network Setup', color: '#01a982' },
          ];
          const steps = [
            {
              id: 'infrastructure', act: 'setup', name: 'Infrastructure',
              goal: 'Deploy router and switch.',
              focus: ['R1', 'SW1'],
              phases: [
                { show: ['R1', 'SW1'], diff: 'Core infrastructure deployed' },
                { show: ['L1'], diff: 'Trunk link established' },
              ],
            },
            {
              id: 'endpoints', act: 'setup', name: 'Endpoints',
              goal: 'Connect end hosts to switch.',
              focus: ['H1', 'H2', 'H3'],
              phases: [
                { show: ['H1', 'H2', 'H3'], diff: 'Hosts connected' },
                { show: ['L2', 'L3', 'L4'], diff: 'Access port connections' },
              ],
            },
          ];
          return { nodes, links, acts, steps, direction: 'TB' };
        },
      },
    };
  }
}

// Support both module and global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TemplateParser;
} else if (typeof window !== 'undefined') {
  window.TemplateParser = TemplateParser;
}
