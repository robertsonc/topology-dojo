# Topology Studio — Product Roadmap

Last updated: 2026-04-06

## North Star

Topology Studio wins when it is both:

1. **Reliable** enough to trust in a live customer demo
2. **Fast to author** without forcing users into code-first workflows unless they want that power

The product already has a real differentiator: **network diagrams as presentation artifacts** with acts, steps, phases, focus, narration, and choreography.

---

## Strategic Priorities

### 1. Reliability & Fidelity
If preview, export, replay, import, and round-trip behavior are not dependable, every new feature sits on unstable ground.

### 2. Authoring UX
The biggest product friction is still authoring speed. The editor has grown powerful, but not yet consistently easy.

### 3. Distribution & Reach
Once reliability and authoring improve, the product needs stronger sharing, embedding, and consumption paths.

### 4. Differentiator Bets
Keep extending the capabilities that make Topology Studio unlike draw.io or Lucidchart.

---

# Phase 1 — Reliability & Fidelity ✅ COMPLETE

## Goal
Fix the bugs that directly damage trust in the product.

| Priority | Area | Status |
|---|---|---|
| P0 | Export reliability (PNG / SVG / PDF / standalone) | ✅ Fixed — all export paths working |
| P0 | Editor / Viewer parity | ✅ Unified runtime paths |
| P0 | Import / export round-trip fidelity | ✅ Round-trip fidelity validated |
| P0 | Safari / iPhone compatibility | ✅ Mobile Safari rendering fixed |
| P0 | Error handling and recovery | ✅ Failure toasts and diagnostics added |

## Completed work
- Unified export/runtime generation paths
- All share and replay paths validated
- Standalone HTML generation hardened
- Mobile Safari blank-state/render issues fixed on key demo pages
- Standardized failure toasts / diagnostics for import/export actions
- 1478+ automated tests across 33 files

---

# Phase 2 — Authoring UX ✅ COMPLETE

## Goal
Remove the friction that makes the editor feel slower than general-purpose diagram tools.

| Priority | Feature | Status |
|---|---|---|
| P1 | Node type browser | ✅ Shipped — visual card-based browser |
| P1 | Link waypoints + orthogonal routing | ✅ Shipped — draggable waypoints, right-angle routing |
| P1 | Step thumbnail previews | ✅ Shipped |
| P1 | Drag-to-reposition labels / coordinate readback | ✅ Shipped — layout edit mode with X/Y readback |
| P1 | Better multi-select ergonomics | ✅ Shipped — Shift+click, align H/V, distribute H/V, group-into-zone |
| P1 | Auto-layout improvements | ✅ Shipped — 5 algorithms (force-directed, hierarchical, circular, grid, magnetic north) |
| P1 | draw.io import | ✅ Shipped |
| P1 | On-canvas inline editing expansion | ✅ Shipped — double-click inline editing |

---

# Phase 3 — Distribution & Reach ✅ MOSTLY COMPLETE

## Goal
Make topologies easier to share, embed, reuse, and validate outside the editor.

| Priority | Feature | Status |
|---|---|---|
| P1 | Self-contained HTML export | ✅ Shipped — standalone single-file HTML |
| P1 | Viewer reliability polish | ✅ Shipped — dedicated viewer.html |
| P1 | Embed flow cleanup | ✅ Shipped — iframe embed code generation |
| P2 | Analytics | ✅ Shipped — engagement tracking with dwell times, completion rate, glassmorphism dashboard |
| P2 | Mobile quick-edit mode | 🔲 Not yet started |

---

# Phase 4 — Differentiator Bets ✅ IN PROGRESS

## Goal
Invest in the things competitors do not really do.

| Priority | Feature | Status |
|---|---|---|
| P2 | Presentation mode | ✅ Shipped — fullscreen, auto-advance, presenter notes, act-boundary pauses |
| P2 | Enterprise templates | ✅ Shipped — SD-WAN, ZTNA, campus, data center, cloud, starter |
| P2 | Dark/light theme toggle | ✅ Shipped — full theme system with persistence |
| P2 | Zone annotations | ✅ Shipped — step-aware rectangular zones |
| P2 | Rich choreography tooling | ✅ Shipped — timeline UI, drag-to-reorder, declarative phases |
| P2 | AI-assisted authoring | Partially shipped — local NLP-based generation |
| P2 | Presentation analytics | ✅ Shipped — engagement dashboard |
| P2 | Deeper narrative tooling | ✅ Shipped — narrator panel, glossary, acts/steps/phases |

## Current differentiators to protect
- Acts / steps / phases choreography
- Focus spotlight system
- Built-in presentation mode (fullscreen cinematic playback)
- Glossary system for mixed audiences
- Zone annotations with step-awareness
- Enterprise template gallery
- Dark/light theme with glassmorphism
- Policy / flow / layer concepts that map to network storytelling

---

# Immediate Product Backlog — Status

## P0 — ✅ All complete
1. ~~Stabilize export/share/replay paths~~ ✅
2. ~~Fix mobile Safari / iPhone rendering issues~~ ✅
3. ~~Remove duplicated runtime/export logic where it drifts~~ ✅
4. ~~Improve import/export diagnostics~~ ✅
5. ~~Add browser-driven release validation for all critical paths~~ ✅

## P1 — ✅ All complete
6. ~~Node type browser polish~~ ✅
7. ~~Waypoints / orthogonal routing~~ ✅
8. ~~Step thumbnails~~ ✅
9. ~~Better selection + batch editing ergonomics~~ ✅
10. ~~Auto-layout improvements~~ ✅
11. ~~draw.io import hardening~~ ✅
12. ~~Label repositioning / coordinate tools~~ ✅

## P2 — Mostly complete
13. AI assist with actual backend — partially shipped (local NLP)
14. ~~Analytics and engagement reporting~~ ✅
15. Mobile quick-edit mode — not yet started
16. ~~Additional storytelling/presentation features~~ ✅

---

# Future Roadmap

## Phase 5 — Collaboration & Integration

| Priority | Feature | Notes |
|---|---|---|
| P1 | Real-time multi-user collaboration | WebSocket-based concurrent editing |
| P1 | Topology diffing | Visual diff between topology versions, change tracking |
| P1 | Undo/redo in editor (deep) | Full state-based undo with branching history |
| P2 | Custom node type plugins | User-authored node types via plugin SDK |
| P2 | PWA support | Offline-capable, installable progressive web app |
| P2 | Netbox import | Import topologies from Netbox DCIM/IPAM |
| P2 | Infrastructure-as-Code visualization | Render Terraform/Ansible/Pulumi as topology diagrams |
| P3 | RBAC & sharing permissions | Role-based access for shared topologies |
| P3 | Version history & snapshots | Git-like versioning for topology files |

## Phase 6 — Platform & Ecosystem

| Priority | Feature | Notes |
|---|---|---|
| P2 | REST API server | Headless topology generation and export |
| P2 | CI/CD integration | Auto-generate diagrams from infrastructure definitions |
| P3 | Marketplace for templates | Community-contributed template library |
| P3 | White-label / OEM embedding | Rebrandable viewer for vendor integration |

---

# Not Doing (for now)

These are deliberately out of scope for the near-term roadmap:
- Broad non-network diagram categories (UML/BPMN/ERD)
- Native mobile app
- Visio/OmniGraffle export as a major investment area

---

# Product Thesis

Topology Studio should not try to become "draw.io, but slightly different."

It should become:
- the fastest way to create a **network/security architecture story**
- the most reliable way to **present** that story
- and the easiest way to **export/share** that story without breakage

That means reliability first, authoring second, differentiation third — not because differentiation is unimportant, but because it only matters if the product is trustworthy.
