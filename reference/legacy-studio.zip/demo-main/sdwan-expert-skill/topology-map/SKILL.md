---
name: topology-map
description: >
  Generate visual SD-WAN topology maps from live fabric data using the
  Topology Design System. Use when the user asks to visualize the fabric,
  generate a topology diagram, map the network, or create a topology
  walkthrough from Orchestrator data.
tools:
  - Bash
  - Read
  - Write
  - Grep
  - Glob
---

# Topology Map Generator

## Purpose

Query live SD-WAN fabric data from the Orchestrator and generate a cinematic,
choreographed topology visualization using the Topology Design System engine.
Produces a standalone HTML file that renders an animated, step-by-step network
map of the fabric.

## Scope

- **IN scope**: Querying appliance inventory, tunnel peering, overlay/BIO
  config, and region assignments; mapping that data to topology nodes, links,
  acts, and steps; generating a complete standalone HTML topology file
- **OUT of scope**: Troubleshooting alarms or tunnel issues (hand off to
  `alarm-triage` / `tunnel-health`), brownout analysis (hand off to
  `brownout-analysis`), routing diagnostics (hand off to `routing-diagnostics`)

## Prerequisites

- Orchestrator connectivity via `core.orchestrator.OrchestratorClient`
- Valid `config/config.json` with `orchestrator_host` and `api_key`
- Always use `python3` (not `python`)
- The Topology Design System files (`topology-ds.js`, `topology-ds.css`) must
  be accessible at the output path (or use absolute/hosted URLs)

## Step 1: Collect Fabric Data

Query these endpoints to build the topology data model:

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `appliance` | GET | All appliances (hostname, model, role, platform, site, state) |
| `tunnels2/bonded` | GET | Bonded tunnels with peer mapping and status |
| `gms/overlays/config` | GET | Business Intent Overlay configurations |
| `regions/appliances` | GET | Region assignments (dict keyed by nePk) |

### Data Collection Script

```python
python3 -c "
import json, logging
logging.disable(logging.CRITICAL)

from core.orchestrator import OrchestratorClient
from core.utils import load_config

config = load_config()
with OrchestratorClient(
    host=config['orchestrator_host'],
    api_key=config['api_key'],
    verify_ssl=config.get('verify_ssl', True)
) as client:

    # 1. All appliances
    appliances = client.get('appliance')

    # 2. Bonded tunnels (fabric-wide)
    tunnels = client.get('tunnels2/bonded', params={
        'limit': 1000,
        'operStatus': True,
        'alias': True,
        'srcNePk': True,
        'destNePk': True,
        'tag': True
    })

    # 3. Overlays / BIOs
    overlays = client.get('gms/overlays/config')

    # 4. Region assignments
    regions = client.get('regions/appliances')

    print(json.dumps({
        'appliances': appliances,
        'tunnels': tunnels,
        'overlays': overlays,
        'regions': regions
    }, indent=2))
"
```

### Key Appliance Fields

| Field | Description | Topology Use |
|-------|-------------|--------------|
| `hostName` | Device hostname | Node `label` |
| `site` | Site name/tag | Grouping / layout |
| `state` | 0=Unknown, 1=Normal, 2=Unreachable | Node color (red if unreachable) |
| `networkRole` | 0=spoke, 1=hub, 2=mesh | Layout position (hubs center, spokes perimeter) |
| `platform` | "Amazon EC2", "Microsoft Azure", "Dell R340", etc. | EC `variant` |
| `model` | "EC-V", "EC-M", "EC-XL", etc. | Node `sublabel` |
| `id.nePk` | Unique ID (e.g., "16.NE") | Internal reference for tunnel mapping |

### Tunnel Response Structure

`GET /tunnels2/bonded` returns a dict keyed by source appliance nePk:

```python
{
  "16.NE": {
    "bondedTunnel_109": {
      "operStatus": "Up - Active",
      "alias": "to_peer-hostname_OverlayName",
      "destNePk": "4.NE",
      "tag": "BIO-Name"
    }
  }
}
```

Iterate with: `for src_pk, tunnels in response.items(): for tid, t in tunnels.items():`

### Tunnel Alias Pattern

`to_<peer>_<localLabel>-<remoteLabel>(tunnel_N)`

Example: `to_london-ec-1_INET1-INET1(tunnel_135)` — this underlay connects
to `london-ec-1` using `INET1` on both ends.

## Step 2: Map Fabric Data to Topology Elements

### Node Mapping

| Fabric Entity | Node `type` | Config |
|---------------|-------------|--------|
| EC appliance (Amazon EC2) | `ec` | `variant: 'aws'` |
| EC appliance (Microsoft Azure) | `ec` | `variant: 'azure'` |
| EC appliance (Google Cloud) | `ec` | `variant: 'gcp'` |
| EC appliance (Oracle Cloud) | `ec` | `variant: 'oracle'` |
| EC appliance (physical / Dell / other) | `ec` | `variant: 'physical'` |
| EC appliance (generic virtual) | `ec` | `variant: 'virtual'` |
| Internet / WAN transport cloud | `cloud` | `color: '#b1b9be'`, `label: 'Internet'` |
| Business Intent Overlay | `overlayCloud` | `spans: [member appliance IDs]` |

#### Platform Detection

```python
platform = appliance.get('platform', '').lower()
if 'amazon' in platform or 'aws' in platform or 'ec2' in platform:
    variant = 'aws'
elif 'azure' in platform or 'microsoft' in platform:
    variant = 'azure'
elif 'google' in platform or 'gcp' in platform:
    variant = 'gcp'
elif 'oracle' in platform:
    variant = 'oracle'
elif 'virtual' in platform or model == 'EC-V':
    variant = 'virtual'
else:
    variant = 'physical'
```

#### Role Detection

```python
role_map = {0: 'spoke', 1: 'hub', 2: 'mesh'}
role = role_map.get(appliance.get('networkRole', 0), 'spoke')
```

#### HA Pair Detection

Appliances at the same site are HA pairs. Detect by matching `site` field.
Place side-by-side with 80px horizontal separation:

```python
# Group appliances by site
sites = {}
for app in appliances:
    site = app.get('site', 'Unknown')
    sites.setdefault(site, []).append(app)

# For HA pairs at the same site
for site, apps in sites.items():
    if len(apps) == 2:
        # ec-1: vrrp 'active', ec-2: vrrp 'standby'
        # Place ec-1 at (x, y), ec-2 at (x+80, y)
```

### Link Mapping

| Fabric Connection | Link `type` | Config |
|-------------------|-------------|--------|
| Bonded tunnel (Up) | `tunnel` | `color: '#01a982'`, `dots: true`, `label: overlay_name` |
| Bonded tunnel (Down) | `blocked` | `reason: 'Tunnel Down'` |
| Underlay to Internet | `line` | `color: '#b1b9be'` |
| BIO overlay flow | `flow` | BIO color, curved `path` between hub sites |

#### Deduplicating Tunnels

Bonded tunnels appear from both sides (A→B and B→A). Deduplicate by sorting
the nePk pair and keeping only one direction:

```python
seen_pairs = set()
for src_pk, tunnels in tunnel_data.items():
    for tid, t in tunnels.items():
        dest_pk = t.get('destNePk', '')
        pair = tuple(sorted([src_pk, dest_pk]))
        if pair in seen_pairs:
            continue
        seen_pairs.add(pair)
        # Process this tunnel
```

#### Tunnel-to-Link ID Convention

Use: `tun-{src_hostname}-{dest_hostname}` (shortened, lowercase, hyphens).

### Anchor Placement

Place anchors 12px from EC node edges for tunnel endpoint attachment:

```javascript
// For an EC node at (x, y), place anchors at:
topo.anchor('EC1-top',  { x: x,    y: y-22 });  // top edge
topo.anchor('EC1-bot',  { x: x,    y: y+22 });  // bottom edge
topo.anchor('EC1-left', { x: x-30, y: y    });  // left edge
topo.anchor('EC1-right',{ x: x+30, y: y    });  // right edge
```

## Step 3: Auto-Layout

### Layout Strategy

Default viewBox: `0 0 1050 700`. Adjust wider for large fabrics.

#### By Role

| Role | Y Band | Description |
|------|--------|-------------|
| Cloud / Internet | y: 40–80 | Transport clouds at the top |
| Hub appliances | y: 200–280 | Core of the fabric, center of canvas |
| Spoke appliances | y: 400–520 | Perimeter / bottom half |

#### By Region / Platform

Group appliances by region or platform to create visual clusters:

| Region/Platform | X Position | Example |
|-----------------|------------|---------|
| Azure Europe | x: 150–400 | `azr-*` sites |
| AWS Europe | x: 550–800 | `london-*`, `stockholm-*`, `paris-*` |
| Physical US | x: 900+ (or bottom-left) | `kscyks-*` |

#### Spacing Rules

- Minimum 120px horizontal between nodes
- Minimum 100px vertical between nodes
- HA pairs: 80px apart horizontally, same Y
- Hub sites: more central; spoke sites: more peripheral

#### Auto-Position Algorithm

```python
# Sort sites: hubs first, then spokes
hub_sites = [s for s in sites if s['role'] == 'hub']
spoke_sites = [s for s in sites if s['role'] == 'spoke']

# Distribute hubs evenly across center band
hub_spacing = 800 / (len(hub_sites) + 1)
for i, site in enumerate(hub_sites):
    site['x'] = 125 + (i + 1) * hub_spacing
    site['y'] = 240

# Distribute spokes in lower band
spoke_spacing = 800 / (len(spoke_sites) + 1)
for i, site in enumerate(spoke_sites):
    site['x'] = 125 + (i + 1) * spoke_spacing
    site['y'] = 460
```

## Step 4: Generate Choreography

### Standard Act Structure

| Act | Label | Color | Content |
|-----|-------|-------|---------|
| `a1` | Act 1 · Infrastructure | `#b1b9be` | Internet cloud, transport underlay |
| `a2` | Act 2 · Hub Sites | `#01a982` | Deploy hub EC appliances + uplinks |
| `a3` | Act 3 · Spoke Sites | `#65aef9` | Deploy spoke EC appliances + uplinks |
| `a4` | Act 4 · SD-WAN Overlay | `#01a982` | Bonded tunnels between all sites |
| `a5` | Act 5 · Fabric Health | `#fc6161` | Highlight any down tunnels or unreachable appliances |

**Note:** Act 5 (Fabric Health) should only be included if there are actual
issues to highlight. If the fabric is fully healthy, omit it.

### Step Generation Rules

1. **Infrastructure step**: Show Internet cloud + any shared transport nodes.
   - `focus: []` (everything visible is bright)
   - Phases: one per transport cloud node

2. **One step per hub site**: Show EC appliance(s) + uplinks to Internet.
   - `focus: [site_ec_ids]`
   - Phase 1: primary EC + its uplink
   - Phase 2: secondary EC (HA) + its uplink (if HA pair)

3. **One step per spoke site**: Same pattern as hub sites.

4. **Overlay steps**: Group tunnels by overlay/BIO name.
   - One step per overlay, or one step per hub if many tunnels
   - Show tunnel links with `focus` on the connected appliances
   - Use `flow` type with curved paths for visual clarity

5. **Health step** (conditional): Show blocked links for down tunnels,
   red-highlighted nodes for unreachable appliances.

### Phase Grouping

- 2–5 phases per step
- Each phase reveals one logical unit (a node + its connecting link)
- Generate `diff` text from fabric metadata:
  - `"seattle-hub-ec-1 (EC-V, Azure, Hub)"` for node reveals
  - `"Overlay tunnel to london-hub (BIO: CriticalApps, Up)"` for link reveals

### Focus Strategy

- Each step focuses on the elements being introduced
- Hub steps: focus on that hub's EC nodes
- Spoke steps: focus on that spoke's EC nodes
- Overlay steps: focus on all nodes connected by that overlay
- Health step: focus on problem nodes/links

## Step 5: Generate HTML Output

### Output Template

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>SD-WAN Fabric Topology</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="topology-ds.css">
</head>
<body>
<div id="app"></div>
<script src="topology-ds.js"></script>
<script>
const topo = new TopologyDesigner({
  title: 'SD-WAN Fabric Topology',
  subtitle: 'Generated from Orchestrator · {timestamp}',
  viewBox: '0 0 1050 700',
  phaseMs: 600,
});

// ── Nodes ──
// {generated node registrations}

// ── Anchors ──
// {generated anchor registrations}

// ── Links ──
// {generated link registrations}

// ── Glossary ──
topo.glossary([
  { t: 'EC', d: 'EdgeConnect: SD-WAN gateway appliance.' },
  { t: 'BIO', d: 'Business Intent Overlay: policy-based overlay network.' },
  { t: 'VRRP', d: 'Virtual Router Redundancy Protocol: HA failover.' },
  { t: 'Hub', d: 'Central aggregation site in hub-spoke topology.' },
  { t: 'Spoke', d: 'Branch site connecting to hub(s).' },
]);

// ── Acts ──
// {generated act registrations}

// ── Steps ──
// {generated step registrations}

topo.mount('app');
</script>
</body>
</html>
```

### Output Location

Save the generated HTML file to the Topology Design System directory so that
relative paths to `topology-ds.js` and `topology-ds.css` resolve:

```
{topology-design-system-repo}/design-system/fabric-topology.html
```

If the Topology Design System repo is not available locally, use hosted URLs
or absolute paths to the JS/CSS files.

## Step 6: Validation Checklist

Before delivering the topology HTML, verify:

- [ ] Every element in a `show[]` array has a corresponding `node()`, `link()`, or `anchor()` registration
- [ ] Every element ID appears in exactly **one** phase's `show[]` across all steps
- [ ] Every `link.from` and `link.to` references a registered node or anchor ID
- [ ] Every `step.act` references a registered act ID
- [ ] `focus` arrays only contain IDs of elements already visible at that step
- [ ] Node positions don't overlap (minimum ~80px apart)
- [ ] Flow paths use valid SVG path syntax (`M`, `C`, `L`, `Q` commands)
- [ ] Colors use hex strings from the standard palette
- [ ] HA pairs are placed side-by-side, not overlapping
- [ ] Tunnel links are deduplicated (only one direction per bonded tunnel pair)
- [ ] Unreachable appliances use `color: '#fc6161'` to indicate problem state

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Green | `#01a982` | EC nodes, SD-WAN overlay, healthy |
| Blue | `#65aef9` | Tunnels, SSE, spoke accent |
| Purple | `#7764fc` | NAC, identity services |
| Gold | `#deb146` | Apps, database |
| Red | `#fc6161` | Blocked, unreachable, down |
| Teal | `#00a4b3` | Switches |
| Gray | `#b1b9be` | Internet cloud, neutral |
| PE Green | `#068667` | Private Edge |

## Decision Tree

```
User asks to visualize the fabric
  ├─ "Show me my topology" → Collect data (Step 1), generate full topology
  ├─ "Map just the hubs" → Collect data, filter to hub role, generate
  ├─ "Show tunnel connectivity" → Collect tunnels, generate overlay-focused map
  ├─ "Show what's down" → Collect data, generate health-focused map (Act 5 only)
  └─ "Update the topology" → Re-collect data, regenerate HTML
```

## Investigation Steps

1. Collect fabric data using the data collection script (Step 1)
2. Parse and normalize: group appliances by site, detect HA pairs, map platforms
3. Build node list with auto-layout positions (Step 3)
4. Build link list from deduplicated tunnel data (Step 2)
5. Generate choreography: acts, steps, phases (Step 4)
6. Assemble HTML from template (Step 5)
7. Validate all cross-references (Step 6)
8. Save to `design-system/fabric-topology.html`

## Output Format

Present results as:
- Summary: `Generated topology with X nodes, Y links, Z steps across N acts`
- File path to the generated HTML
- Any issues found (unreachable appliances, down tunnels) highlighted

## Handoff

- `appliance-inventory` — when need deeper appliance detail during data collection
- `tunnel-health` — when tunnel data reveals connectivity issues to investigate
- `alarm-triage` — when unreachable appliances have associated alarms
- `brownout-analysis` — when overlay health coloring needs brownout context
- Parent `ec-sdwan-expert` — for complex multi-domain topology questions

## Changelog

| Date | Change |
|------|--------|
| 2026-03-15 | Initial creation |
