# Topology Design System — Comprehensive Redesign

## 1. Summary of Current Solution

### What's Good
- **Zero-dependency architecture** — Pure vanilla JS + SVG + CSS. No build tools. Single HTML files include everything. This is a major strength for portability and embedding.
- **Declarative API** — Fluent, chainable `topo.node().link().act().addStep()` pattern is clean, readable, and LLM-friendly.
- **Cinematic rendering** — Glassmorphism, SVG glow filters, ambient light leaks, depth-of-field blur, and animated particles create a polished, modern look that rivals professional tools.
- **Phase-based choreography** — Acts → Steps → Phases with staggered reveals, focus/blur spotlight, and custom render hooks provide a sophisticated storytelling system.
- **14 built-in node types** — Each with detailed SVG rendering (EC, switch, cloud, host, connector, apps, SaaS, server, router, firewall, database, idcard, AP, overlayCloud).
- **7 link types** — Line, tunnel, WireGuard, flow, packet, blocked, wifi — each with unique visual treatment.
- **Visual editor** — Full drag-and-drop with node palette, link drawing, waypoints, choreography panel, preview mode, export/import, undo/redo, alignment tools, guides, minimap, and context menus.
- **Accessibility baseline** — Reduced motion detection, keyboard navigation, semantic HTML structure.
- **URL state persistence** — Playback position saved to URL for sharing.

### What's Broken / Weak
- **God class** — `TopologyDesigner` (1654 lines) handles rendering, lifecycle, UI, interactivity, and state in a single class.
- **Editor is a monolith** — 3789 lines of inline JS in a single HTML file. Extremely difficult to maintain, test, or extend.
- **No auto-layout** — Every node position must be manually specified with x/y coordinates. This is the #1 barrier for non-technical users.
- **Choreography editing is table-based** — Adding phases requires clicking tiny `+` buttons and typing element IDs. There's no visual timeline or drag-and-drop for step sequencing.
- **SVG string concatenation** — All rendering uses template literal string building. Fragile, hard to refactor, no type safety.
- **No template system** — Users must build every topology from scratch. No presets for common patterns (star, mesh, 3-tier, hub-spoke).
- **Limited mobile UX** — Touch gestures for canvas pan/zoom are minimal. The editor is desktop-only in practice.
- **No diagram-as-code** — Can't paste a text definition and get a topology. Must use the API or editor manually.
- **Shallow error handling** — Missing element IDs in phases silently render nothing. No validation warnings in the viewer.
- **No theme builder** — Colors are hardcoded CSS tokens. Can't generate palettes from brand colors.
- **No export to image/video** — Can export HTML but not PNG, SVG standalone, or GIF/video.

### High-Level Opportunities
1. **Auto-layout** would make topology creation accessible to non-technical users.
2. **Visual timeline editor** would make choreography intuitive (like After Effects or Keynote).
3. **Template gallery** would provide instant-start topologies.
4. **Diagram-as-code** would enable LLM-driven workflow.
5. **Modular architecture** would enable the codebase to grow sustainably.
6. **Theme system** would enable corporate branding.

---

## 2. Proposed Overhaul Plan

### 2.1 Architecture: Modular Engine

Split the monolithic `topology-ds.js` into focused modules while preserving the zero-dependency, no-build-tool philosophy:

```
design-system/
├── topology-ds.js          ← Main class (slim orchestrator, ~400 lines)
├── modules/
│   ├── node-renderers.js   ← All node type SVG renderers
│   ├── link-renderers.js   ← All link type renderers
│   ├── svg-filters.js      ← Filter/gradient definitions
│   ├── layout-engine.js    ← Auto-layout algorithms
│   ├── choreography.js     ← Act/step/phase management
│   ├── playback.js         ← Play/pause/advance/URL state
│   ├── narrator.js         ← Narrator panel rendering
│   └── theme.js            ← Color scheme/theme management
├── topology-ds.css         ← Theme & layout (enhanced)
├── editor/
│   ├── editor.html         ← Shell + layout only
│   ├── editor-core.js      ← State management, canvas rendering
│   ├── editor-tools.js     ← Tool system (select, add, draw, hand)
│   ├── editor-choreo.js    ← Timeline/choreography panel
│   ├── editor-props.js     ← Properties panel
│   ├── editor-io.js        ← Import/export, preview, autosave
│   └── editor.css          ← Editor-specific styles
├── index.html              ← SD-WAN demo (unchanged API)
└── templates/
    ├── hub-spoke.json      ← Template topologies
    ├── 3-tier.json
    ├── mesh.json
    └── star.json
```

Loading strategy: ES modules with `<script type="module">` for the editor, and a single concatenated `topology-ds.js` for standalone usage.

### 2.2 UX Flow: Editor Redesign

```
┌─────────────────────────────────────────────────────────────────────────┐
│ TOOLBAR                                                                  │
│ [Select▾][+ Node▾][+ Link][Anchor][Hand] │ [Templates▾][Import][Export] │
│ [Undo][Redo] │ [Grid][Snap][Guides] │ [Preview] │ [Theme▾]              │
├──────────┬──────────────────────────────────┬───────────────────────────┤
│          │                                  │  PROPERTIES PANEL         │
│  NODE    │     CANVAS                       │  (context-sensitive)      │
│  PALETTE │     (SVG + interactive)          │                           │
│          │                                  │  ┌─ When node selected:   │
│  ○ EC    │     ┌──────────────────┐         │  │  Type, Position,       │
│  ○ Switch│     │                  │         │  │  Label, Color,         │
│  ○ Cloud │     │  [Topology]      │         │  │  Side Label, Zone      │
│  ○ Host  │     │                  │         │  └─                       │
│  ○ Router│     │                  │         │                           │
│  ○ ...   │     └──────────────────┘         │  ┌─ When link selected:   │
│          │                                  │  │  Type, From→To,        │
│  LINK    │     Zoom: [−][100%][+][Fit]      │  │  Label, Ports,         │
│  TYPES   │     Minimap: [▪]                 │  │  Color, Style          │
│  ─ Line  │                                  │  └─                       │
│  ═ Tunnel│                                  │                           │
│  ┈ WG    │                                  │  ┌─ When nothing:         │
│  → Flow  │                                  │  │  Topology Settings,    │
│  • Packet│                                  │  │  ViewBox, Title,       │
│  ✕ Block │                                  │  │  Quick Actions         │
│  ~ Wifi  │                                  │  └─                       │
├──────────┴──────────────────────────────────┴───────────────────────────┤
│ TIMELINE / CHOREOGRAPHY                                                  │
│                                                                          │
│ Act 1: Infrastructure          Act 2: Endpoints          Act 3: ...      │
│ ┌──────────┬──────────┐       ┌──────────┬──────────┐                   │
│ │ Step 1   │ Step 2   │       │ Step 3   │ Step 4   │                   │
│ │ Network  │ Security │       │ Users    │ Apps     │                   │
│ │ ┌──┬──┐  │ ┌──┬──┐  │       │ ┌──┬──┐  │ ┌──┬──┐  │                   │
│ │ │P1│P2│  │ │P1│P2│  │       │ │P1│P2│  │ │P1│P2│  │                   │
│ │ └──┴──┘  │ └──┴──┘  │       │ └──┴──┘  │ └──┴──┘  │                   │
│ └──────────┴──────────┘       └──────────┴──────────┘                   │
│                                                                          │
│ [+ Act] [+ Step] [+ Phase]   Drag to reorder   Click phase to edit      │
└──────────────────────────────────────────────────────────────────────────┘
```

### 2.3 Auto-Layout Engine

Three layout algorithms, all pure JS:

1. **Force-directed** — For organic, mesh-like topologies. Nodes repel each other, links attract connected nodes. Good default.
2. **Hierarchical/dagre** — For tree-like topologies (3-tier, spine-leaf). Arranges in layers with minimal crossings.
3. **Grid** — For uniform arrangements. Snaps nodes to a regular grid with configurable spacing.

Implementation: Simple physics simulation (no external library needed) with ~200 lines of code:
- Repulsion: Coulomb's law between all node pairs
- Attraction: Hooke's law for linked nodes
- Centering: Pull all nodes toward canvas center
- Collision: Prevent overlap
- Iterate until energy falls below threshold

### 2.4 Visual Timeline Editor

Replace the table-based choreography panel with a visual timeline:

- **Horizontal tracks** per act, with step blocks arranged left-to-right
- **Phase lanes** within each step block showing element badges
- **Drag-and-drop** to reorder steps or move elements between phases
- **Click to select** a phase and see it highlighted on canvas
- **Right-click context menu** for add/delete/duplicate
- **Scrubber** that plays through the timeline with animation preview

### 2.5 Template System

Pre-built topology templates users can start from:

- **Hub-and-Spoke** — Central device (router/firewall) with N branches
- **3-Tier Architecture** — LB → App Servers → Database
- **Mesh Network** — Fully connected nodes
- **Star Topology** — Central switch with endpoints
- **Spine-Leaf** — Data center fabric
- **SD-WAN** — The existing demo topology as a template

Templates are JSON files containing node/link/act/step definitions with relative coordinates. The template system applies auto-layout to adapt to canvas size.

### 2.6 Diagram-as-Code

A text parser that accepts Mermaid-inspired syntax:

```
topology TB
  LB[Load Balancer]:::ec
  APP1[App Server 1]:::server
  APP2[App Server 2]:::server
  DB[(Database)]:::database

  LB -->|HTTPS| APP1
  LB -->|HTTPS| APP2
  APP1 -->|SQL| DB
  APP2 -->|SQL| DB
```

The parser produces node/link definitions, then auto-layout places them on canvas. The editor then allows adding choreography and styling.

---

## 3. Refactored Code Structure

### 3.1 Core Engine (topology-ds.js) — Slim Orchestrator

```javascript
class TopologyDesigner {
  constructor(cfg) { /* Config + registries + state */ }

  // Registration API (unchanged — backward compatible)
  node(id, cfg) { }
  anchor(id, pos) { }
  link(id, cfg) { }
  act(id, cfg) { }
  addStep(id, cfg) { }
  glossary(terms) { }

  // Lifecycle
  mount(containerId) { }
  render() { }

  // Delegates to modules
  _renderSVG() { /* calls NodeRenderers + LinkRenderers */ }
  _layout(algorithm) { /* calls LayoutEngine */ }
  _playback() { /* calls Playback module */ }
}
```

### 3.2 Layout Engine (modules/layout-engine.js)

```javascript
class LayoutEngine {
  static forceDirected(nodes, links, options) {
    // Simple n-body simulation
    // Returns Map<nodeId, {x, y}>
  }

  static hierarchical(nodes, links, options) {
    // Layered layout with rank assignment
    // Returns Map<nodeId, {x, y}>
  }

  static grid(nodes, options) {
    // Regular grid placement
    // Returns Map<nodeId, {x, y}>
  }

  static circular(nodes, links, options) {
    // Nodes on a circle, useful for mesh
    // Returns Map<nodeId, {x, y}>
  }
}
```

### 3.3 Template Parser

```javascript
class TemplateParser {
  static fromMermaid(text) {
    // Parse Mermaid-like syntax → { nodes, links, direction }
  }

  static fromJSON(json) {
    // Parse template JSON → { nodes, links, acts, steps }
  }

  static applyToDesigner(topo, template, layout) {
    // Register nodes/links/acts/steps on a TopologyDesigner instance
  }
}
```

---

## 4. Implementation Steps

### Phase 1: Foundation (Core Refactoring)
1. Extract node renderers into `modules/node-renderers.js`
2. Extract link renderers into `modules/link-renderers.js`
3. Extract SVG filter definitions into `modules/svg-filters.js`
4. Add `modules/layout-engine.js` with force-directed layout
5. Update `topology-ds.js` to import from modules
6. Ensure backward compatibility — existing demos must work unchanged

### Phase 2: Editor UX Overhaul
1. Add persistent left sidebar with node palette and link type selector
2. Replace choreography table with visual timeline
3. Add drag-and-drop for timeline elements
4. Add element search/filter in properties panel
5. Improve canvas interaction (better zoom, pan, selection)
6. Add command palette (Ctrl+K) for quick actions

### Phase 3: Templates & Import
1. Create template JSON format and 4+ built-in templates
2. Add template gallery modal in editor
3. Implement Mermaid-inspired text parser
4. Add "Import from Text" modal with live preview
5. Add auto-layout button that runs on imported structures

### Phase 4: Polish & Accessibility
1. ARIA labels on all SVG elements
2. Screen reader announcements for step changes
3. High contrast mode
4. Touch gesture support for mobile
5. Export to standalone SVG and PNG
6. Performance optimization for large topologies (>100 nodes)

### Potential Pitfalls
- **SVG innerHTML rewrite** — The full SVG re-render on each step is simple but expensive. For >100 nodes, consider incremental DOM updates.
- **Module loading** — Without a bundler, ES modules require a server (no `file://`). Provide a build script to concatenate for standalone use.
- **Backward compatibility** — The existing API (`topo.node().link().mount()`) must continue to work.
- **Editor state management** — The current global `state` object works but will get unwieldy. Consider an event-bus or simple pub-sub pattern.

---

## 5. Mockup & Demo Ideas

### Quick Prototypes
1. **Auto-layout demo** — A standalone HTML page that takes a node/link list and shows force-directed layout animating into position.
2. **Timeline editor prototype** — A focused prototype of just the choreography timeline with drag-and-drop, independent of the topology canvas.
3. **Template gallery** — A visual gallery page showing all templates as thumbnail previews with one-click "Open in Editor."
4. **Diagram-as-code playground** — Split-pane with text input on the left and live topology preview on the right.

### Visualization Excellence
- **Traffic flow heat maps** — Color-code links by bandwidth/latency with gradient overlays
- **Failure simulation** — Click a node/link to simulate failure and watch traffic reroute with animation
- **Time travel** — Scrub through topology changes over time (infrastructure evolution)
- **Collaborative editing** — WebSocket-based real-time multi-user editing (stretch goal)
