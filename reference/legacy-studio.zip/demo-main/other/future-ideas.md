# Future Ideas

> **Note:** Several ideas previously listed here have been implemented. See the sections marked ✅ below.

## ✅ Implemented Features

The following concepts have been built into the core engine:

### Temporal Digital Twin
Nodes and links now support three temporal observation modes — **Design** (planned), **Operational** (live metrics), and **Incident** (historical) — with real-time metric overlays (latency, jitter, loss) and visual SVG filter effects (jitter displacement, desaturation, breach noise). See `setTemporalMode()`, `setElementState()` in the User Manual.

### Isometric Tilt Mode (Pseudo-3D)
A toggleable orthographic projection (`rotateX(45deg) rotateZ(-45deg)`) creates a SOC-dashboard aesthetic with counter-rotated text labels. See `toggleIsometric()` in the User Manual.

### Intelligence Layer (Security Analysis)
Path validation (`validatePath()`) flags missing firewalls and direct public-to-private connections. Blast radius visualization uses BFS to dim everything beyond N hops from a selected node. Activated via `toggleSecurityMode()`.

### Ghosting Engine
Previous act elements desaturate (15%) and blur instead of vanishing, maintaining spatial context during act transitions. Enabled by default, configurable via the `ghosting` constructor option.

### Conditional Step Logic (Diagram-as-Code 2.0)
State variables (`setState()`/`getState()`) enable conditional phase evaluation with `==`, `!=`, `>`, `<` operators. Phases can dynamically change link types, node configs, and trigger cascading state changes.

### Magnetic North Layout
A type-aware force-directed layout algorithm (`LayoutEngine.magneticNorth()`) where clouds gravitate to the top, core infrastructure stays centered, and endpoints sink to the bottom.

---

## Color Scheme Builder

### Overview
A rebranding tool that lets users define a corporate design system and automatically generates a cohesive color palette for topology diagrams. Targeted at scenarios where someone needs to align diagrams with brand guidelines.

### Core Features

**Primary & Accent Color Input**
- Color picker or hex/RGB input for primary brand color(s)
- Separate input for accent color(s)
- Optional: import from a CSS file, Figma tokens, or brand guidelines URL

**Automatic Gradient Generation**
- Given a primary color, generate a range of tints and shades across a gradient (e.g., 5-9 stops from light to dark)
- Support linear and perceptual color spaces (HSL, OKLCH) for more natural gradients
- Preview gradient swatches in real-time

**Contrast Color Picking**
- Auto-select complementary, split-complementary, or triadic colors based on the primary
- Ensure all generated colors meet WCAG contrast ratios against the dark canvas background
- Flag any color pairs that fail accessibility thresholds
- Generate distinct colors for different node types so they remain visually distinguishable

### UX Concept

**Panel or Modal**
- Accessible from the toolbar ("Theme" or "Brand" button)
- Left side: input fields for primary/accent colors with live color pickers
- Right side: auto-generated palette preview showing nodes, links, labels, and backgrounds with the new scheme

**Preset Themes**
- Ship with a few built-in themes (e.g., Default Dark, Light Mode, Corporate Blue, Monochrome)
- Users can save/load custom themes as JSON

**Apply & Export**
- One-click apply to the current topology
- Export theme as a standalone CSS variables file or JSON token set for use in other tools
- Undo-able: reverting the theme restores previous colors on all elements

### Technical Considerations
- All current colors are defined via CSS custom properties (`--accent`, `--blue`, `--purple`, etc.) and inline on nodes/links, so a theme system would need to remap both
- Node renderers in `topology-ds.js` use hardcoded color values in SVG output — these would need to accept color overrides from a theme config
- SVG filters (glow, bloom) reference specific colors and would need parameterization
- Consider generating the palette in OKLCH color space for perceptually uniform gradients

### Stretch Goals
- Import palette from an image (extract dominant colors)
- Dark/light mode toggle with automatic palette inversion
- Per-node-type color assignment with drag-and-drop from the palette
- Live preview as colors are adjusted (no "apply" step needed)

---

## Diagram-as-Code / Mermaid Compatibility

### Overview
Support a text-based diagram definition format (compatible with or inspired by Mermaid) so that node topologies with links and labels can be authored as code. This enables an LLM-driven workflow: an LLM generates the structural topology (nodes, links, labels, types) from a text description, and then a human operator layers on the artistic elements — choreography steps, focus/blur, animations, and visual styling — using the visual editor.

### Workflow Vision
1. **LLM generates structure** — Given a prompt like "3-tier web app with load balancer, two app servers, and a database cluster", an LLM outputs a Mermaid-like text block defining nodes, links, labels, and node types
2. **Import into editor** — Paste or load the text definition; the editor parses it and places nodes on the canvas with auto-layout
3. **Human refines** — The operator adjusts positions, adds choreography acts/steps, sets focus groups, tunes colors, enables 3D tunnels, etc.
4. **Round-trip export** — Export back to the text format (structure only) or to the full JSON (structure + choreography + styling)

### Supported Syntax (Proposal)
```
topology LR
  LB[Load Balancer]:::ec
  APP1[App Server 1]:::server
  APP2[App Server 2]:::server
  DB[(Database)]:::database

  LB -->|HTTP| APP1
  LB -->|HTTP| APP2
  APP1 -->|SQL| DB
  APP2 -->|SQL| DB
```

Key elements:
- `topology LR` — direction hint for auto-layout (LR, TB, etc.)
- `[Label]` — node label
- `:::type` — maps to existing node types (ec, switch, cloud, host, server, database, etc.)
- `-->|label|` — link with optional label
- `-.->` — dashed link
- `==>` — tunnel/thick link

### What the Text Format Covers
- Node definitions (id, label, type)
- Link definitions (from, to, label, line style)
- Layout direction hints
- Node grouping/subgraphs (maps to visual clusters)

### What Remains Human-Driven
- Choreography (acts, steps, phases, focus groups)
- Animation effects (blur, depth-of-field, glow)
- Fine-grained positioning and spacing
- 3D tunnel styling, color overrides
- Step preview sequencing

### Technical Considerations
- Parser could support a subset of Mermaid `graph` syntax for familiarity
- Auto-layout engine needed for initial node placement (dagre, ELK, or a simple force-directed approach)
- Import should be additive (merge into existing canvas) or replace (clear and load)
- The existing JSON export already captures full state; the text format is a lightweight structural subset
- Consider a split-pane "code + canvas" mode for live editing

### Stretch Goals
- Bidirectional sync: edits on canvas reflect back in the text pane
- Support Mermaid `subgraph` for visual grouping/zones
- CLI tool that takes a `.topo` file and renders to SVG without the editor
- GitHub/GitLab rendering integration (like Mermaid blocks in markdown)
- LLM prompt template library for common topology patterns (hub-and-spoke, mesh, tiered, etc.)

---

## MCP Server / Agent-to-Agent Integration

### Overview
Expose the topology design system as an MCP (Model Context Protocol) server and/or agent-to-agent tool so that any LLM — Claude, GPT, etc. — can programmatically generate beautiful, production-quality network diagrams through natural language. Instead of an LLM producing ugly ASCII boxes or static Mermaid, it calls into this system and gets back polished, animated SVG topology diagrams styled by the design system.

### Why This Matters
Today when an LLM is asked "show me this network architecture," the best it can do is text art or a basic Mermaid block. With an MCP tool or A2A endpoint, the LLM becomes capable of producing visuals that match what a human designer would create — proper node icons, styled links, glow effects, dark canvas — all without the LLM needing to understand SVG internals.

### MCP Server Approach

**Exposed Tools**
- `create_topology` — accepts a topology definition (nodes, links, types, labels) and returns a rendered SVG or a URL to the interactive viewer
- `add_node` / `add_link` — incremental building for conversational flows ("now add a database behind that")
- `apply_template` — apply a predefined choreography/style template (e.g., "3-tier", "hub-and-spoke", "mesh")
- `export` — export current topology as SVG, PNG, or interactive HTML
- `list_node_types` — returns available node types (ec, switch, cloud, host, server, database, etc.) so the LLM knows what it can use

**MCP Resources**
- `topology://current` — the current canvas state as structured JSON
- `topology://templates` — available layout and style templates
- `topology://node-types` — catalog of node renderers with previews

### Agent-to-Agent (A2A) Approach

**Topology Agent Card**
- Advertises capabilities: topology generation, SVG rendering, choreography
- Accepts natural language ("draw a 3-tier web app with redundant DB") or structured topology definitions
- Returns rendered output plus the editable project file

**Conversation Flow**
1. Orchestrator agent receives user request involving a network diagram
2. Orchestrator delegates to the topology agent via A2A protocol
3. Topology agent generates structure, applies auto-layout and default styling
4. Returns rendered SVG + project file URL for human refinement
5. Human can open the project file in the visual editor to add choreography

### Hybrid: MCP + A2A
- MCP for tool-use scenarios (LLM calling functions directly)
- A2A for multi-agent orchestration (topology agent as a specialist in a team)
- Both share the same rendering engine and node type registry
- Both support the Mermaid-compatible text format as an input option

### Example MCP Interaction
```json
{
  "tool": "create_topology",
  "input": {
    "nodes": [
      {"id": "lb", "label": "Load Balancer", "type": "ec"},
      {"id": "app1", "label": "App Server 1", "type": "server"},
      {"id": "app2", "label": "App Server 2", "type": "server"},
      {"id": "db", "label": "Database", "type": "database"}
    ],
    "links": [
      {"from": "lb", "to": "app1", "label": "HTTPS"},
      {"from": "lb", "to": "app2", "label": "HTTPS"},
      {"from": "app1", "to": "db", "label": "SQL"},
      {"from": "app2", "to": "db", "label": "SQL"}
    ],
    "layout": "TB",
    "template": "corporate-dark"
  }
}
```

### Technical Considerations
- MCP server wraps the existing rendering pipeline (node renderers, link drawing, SVG filters) behind a JSON API
- Headless rendering mode needed — generate SVG without a browser/canvas (e.g., using jsdom or a server-side SVG builder)
- Auto-layout is essential since the LLM won't specify coordinates
- Template system bridges the gap between LLM-generated structure and human-quality aesthetics
- Authentication/scoping for multi-tenant scenarios if hosted as a service

### Stretch Goals
- Streaming mode: LLM builds the topology incrementally, user sees nodes appear in real-time
- Style transfer: "make it look like the Cisco diagram style" / "use AWS architecture icons"
- Diagram diffing: compare two topologies and highlight what changed (useful for infrastructure-as-code reviews)
- Integration with infrastructure tools: import from Terraform, CloudFormation, or Kubernetes manifests and render as a styled topology
- Claude Desktop integration: topology diagrams appear inline in Claude conversations
