# Architecture Review & Platform Vision

## Topology Design System — From Tool to Category-Defining Platform

---

## 1. Current Architecture Assessment

### What Exists

The Topology Design System is a ~3,000-line monolithic class (`TopologyDesigner`) that implements a declarative, cinematic network topology visualization engine. Zero dependencies. No build tools. Pure vanilla JavaScript generating SVG strings.

**Core Pipeline:**
```
node()/link()/anchor() → act()/addStep() → mount() → _buildIndex() → _renderSVG() → innerHTML
     Registration              Choreography        DOM Scaffold      String Concat    Paint
```

**What it does well — genuinely well:**

1. **Cinematic SVG rendering.** The filter stack (bloom, depth-of-field blur, focus halos, ambient scan lines, floating data bits, radar pulses) produces a visual quality that most teams would reach for WebGL/Canvas to achieve. Doing this in declarative SVG is architecturally elegant — it means the output is inspectable, printable, and accessible.

2. **The Acts/Steps/Phases choreography model.** This is the system's most original contribution. The three-tier temporal hierarchy (Act = thematic section, Step = narrative beat, Phase = timed sub-animation) maps cleanly to how humans present complex systems. The `focus[]` spotlight system that dims + blurs unfocused elements while lifting focused ones with depth shadows creates genuine cinematic depth-of-field in 2D.

3. **The plugin architecture.** `registerNodeType()` and `registerLinkType()` with formal plugin interfaces (render, defaults, hitBox, validate, meta) is well-designed. The lifecycle hooks (`beforeRender`, `afterRender`, `onStepChange`) provide clean extension points without subclassing.

4. **Serialization.** `toJSON()`/`fromJSON()` round-trips the entire topology state, enabling save/load, version control, and portability.

5. **AI-assisted generation via the Claude skill.** The `.claude/skills/topology-editor.md` skill effectively turns natural language into complete topology HTML files. This is already a peek at the future.

6. **Node type richness.** 16 built-in node types with variant systems (EC nodes alone have 7 variants: generic, virtual, physical, AWS, Azure, GCP, Oracle), VRRP state indicators, port-level detail on enterprise switches. Plus 11 basic shapes. This isn't clip art — it's domain-specific visual vocabulary.

### Architecture Internals Worth Noting

| Subsystem | Implementation | Lines | Notes |
|---|---|---|---|
| SVG Diffing | `_computeDirtyElements()` + `_incrementalRender()` | ~90 | Virtual-DOM-lite: patches individual elements when <60% dirty, falls back to full re-render |
| Link Routing | `_routeLink()` with AABB collision + Bezier detours | ~80 | Cohen-Sutherland intersection test, quadratic curve detours around obstructions |
| Position Interpolation | `_interpolateStep()` + `_interpolatePositionInline()` | ~80 | rAF-driven cubic ease, CSS transform fallback for single-step transitions |
| Focus System | `_dimFor()` + `_focusWrap()` + depth-lift filters | ~40 | Physically "lifts" focused nodes with layered shadow + bloom + rim light |
| Phase Timing | `_ph()` + `_pw()` + CSS custom properties | ~30 | Staggered delays via `animation-delay`, tunable via toolbar sliders |

---

## 2. Biggest Constraints

These are not bugs. They are **structural limitations** that define the ceiling of what the system can become without architectural changes.

### C1: String-Based SVG Rendering (The InnerHTML Tax)

Every render call concatenates thousands of SVG string fragments, then sets `innerHTML` on the diagram element. The incremental diffing engine (`_incrementalRender`) mitigates this for single-step transitions, but:

- **No persistent DOM identity.** Every full re-render destroys and recreates all SVG elements. CSS transitions applied to individual elements are lost. Hover states vanish. Interactive widgets (tooltips, popovers) are destroyed.
- **No animation continuity.** `animateMotion` elements (the flowing dots on tunnels/flows) restart from their beginning on every render. This creates visible "jumps" when stepping.
- **No event delegation on elements.** Click handlers are bound to container-level event delegation (checking `data-tds-node`/`data-tds-link` attributes), which works but prevents element-level lifecycle hooks.

This is the single biggest architectural constraint. It prevents: persistent interactive overlays, smooth continuous animation, element-level state machines, and drag-and-drop of nodes (not just anchors).

### C2: Monolithic Class Architecture

Everything lives in one class with one file. The `TopologyDesigner` class is constructor, registry, renderer, animator, state machine, event handler, DOM builder, and URL manager. This prevents:

- **Tree-shakeable builds.** A simple "show a static topology" use case pulls in the entire narrator, glossary, playback engine, editor mode, and routing system.
- **Independent module testing.** The test coverage analysis (`TEST-COVERAGE-ANALYSIS.md`) already identified this — zero test coverage exists because the architecture resists unit testing.
- **Composable deployment.** You can't embed just the rendering engine in a dashboard widget without the full UI shell.

### C3: No Graph Data Model

Nodes and links are stored as flat `Map<id, config>` with no graph-theoretic structure. There's no adjacency list, no edge list, no concept of neighborhoods, paths, or subgraphs. This prevents:

- **Topological queries** ("What's the shortest path from SEA to LAX?", "Which nodes are reachable from the firewall?")
- **Automatic layout algorithms** that need graph structure (force-directed, hierarchical, spectral)
- **Semantic operations** ("Isolate this subnet", "Show the blast radius of this node failure")
- **Diff/merge of topologies** (what changed between version A and version B?)

### C4: Linear-Only Choreography

The step model is strictly linear: step 1, step 2, step 3. There's no branching, no conditional logic, no audience-response-driven paths. The `presenter` mode pauses at act boundaries but doesn't enable alternative narrative branches. This prevents:

- **Interactive exploration** ("What happens if this link fails?" → branch to failure scenario)
- **Audience-driven presentations** (poll-based path selection)
- **Simulation playback** (show me the network under load condition A vs. B)

### C5: No Reactive Data Binding

Changing a node's position, color, or label requires calling `render()`, which triggers a full re-render cycle. There's no observable model, no change detection, no fine-grained reactivity. This prevents:

- **Real-time operational dashboards** (live metric overlays that update at 1Hz without full re-render)
- **Smooth interactive editing** (drag a node and see links update in real-time without frame drops)
- **External data source integration** (bind node color to an API health check endpoint)

### C6: Fixed Coordinate System

All node positions are absolute pixel coordinates in a fixed viewBox (default 1050x700). There's no concept of relative positioning, constraint-based layout, or responsive reflow. The `autoLayout()` method delegates to an external `LayoutEngine` module that isn't included.

---

## 3. Top Transformative Ideas

### T1: Semantic Choreography Engine — "Intent, Not Instructions"

**The problem:** Today, choreography requires manually specifying which elements appear in which phase of which step, with focus arrays, diff descriptions, and precise ordering. The skill file has a 14-point validation checklist that even an LLM can get wrong.

**The invention:** Replace imperative phase lists with a **semantic choreography DSL** that expresses *narrative intent*:

```javascript
// Today (imperative)
td.addStep('tunnels', {
  act: 'a2', name: 'Overlay Tunnels',
  focus: ['SEA', 'LAX', 'tunSEA_LAX'],
  phases: [
    { show: ['tunSEA_LAX'], diff: 'IPsec tunnel between Seattle and LA' },
    { show: ['tunLabel'], diff: 'Tunnel label appears' }
  ]
});

// Future (semantic)
td.narrate('a2', 'Overlay Tunnels')
  .reveal('tunSEA_LAX')                     // auto-focuses endpoints
  .explain('IPsec tunnel forms between Seattle and LA')
  .then.annotate('tunSEA_LAX', 'Encrypted overlay — 50ms RTT')
  .withCamera({ zoom: 1.4, center: 'tunSEA_LAX' })  // cinematic framing
  .transition('dissolve');                    // inter-step transition style
```

The engine would **automatically compute**: which elements to focus (the endpoints of a revealed link), optimal phase timing (based on visual distance and element count), camera movements (zoom to the action), and diff descriptions (from the element metadata).

**Key architectural change:** Separate the choreography *intent model* from the *render plan*. The intent model is what authors write. The render plan is what the engine computes. Between them sits a **choreography compiler** that optimizes timing, resolves focus sets, plans camera moves, and generates the phase arrays that the current renderer already understands.

This is the highest-leverage change. It makes the system 10x easier to author while enabling capabilities (camera, transitions, auto-focus) that are impossible with manual phase arrays.

### T2: Live Operational Twin Mode

**The problem:** Topologies today are static illustrations. Beautiful, but frozen.

**The invention:** A **real-time data binding layer** that connects topology elements to live operational data:

```javascript
// Bind node health to an API endpoint
td.bind('SEA', {
  source: '/api/devices/sea/health',
  interval: 5000,
  map: (data) => ({
    color: data.status === 'up' ? '#01a982' : '#fc6161',
    sublabel: `CPU: ${data.cpu}% | Mem: ${data.mem}%`,
    vrrpState: data.vrrp,
  })
});

// Bind link metrics to streaming data
td.bind('tunSEA_LAX', {
  source: new WebSocket('wss://metrics/tunnel/sea-lax'),
  map: (msg) => ({
    label: `${msg.bandwidth}Mbps — ${msg.latency}ms`,
    color: msg.latency > 100 ? '#fc6161' : '#01a982',
    dots: msg.packets_per_sec > 0,
  })
});
```

**Architectural requirements:**
- **Fine-grained element updates.** This demands solving C1 (innerHTML tax). Individual SVG elements need persistent DOM identity so that changing a single node's color doesn't re-render the entire diagram.
- **Observable model layer.** Proxy-based or setter-based change detection on node/link configs. When `node.color` changes, only that node's SVG group updates.
- **Data source abstraction.** REST polling, WebSocket streams, Server-Sent Events, and manual push — all through a unified binding interface.
- **Metric overlays.** Small sparkline charts, gauge indicators, or numeric badges rendered as SVG sub-components attached to nodes.

This transforms the system from a presentation tool into an **operational visibility platform** — the topology becomes a live control surface for network operations.

### T3: AI Topology Generation & Reasoning Engine

**The problem:** The Claude skill (`.claude/skills/topology-editor.md`) generates topologies from natural language, but it's a one-shot generation process. There's no feedback loop, no iterative refinement, no semantic understanding of the generated topology.

**The invention:** A **bidirectional AI topology interface**:

**Generation direction (natural language → topology):**
```
"Create a hub-and-spoke SD-WAN with 3 branch offices connecting
 through regional cloud gateways to a central data center.
 Each branch has redundant EdgeConnect with VRRP.
 Show the failure scenario when the Seattle primary link goes down."
```

The AI generates not just the topology, but the full choreography — including a failure scenario branch (see T1's semantic choreography).

**Analysis direction (topology → insight):**
```javascript
td.analyze()  // AI examines the current topology
// Returns:
// - "Single point of failure: the LAX-DC link has no redundancy"
// - "The Seattle branch VRRP pair shares an upstream switch — a switch failure takes out both"
// - "Suggested improvement: add a direct tunnel between SEA and NYC for geographic redundancy"
```

**Interactive refinement:**
```
User: "Add redundancy for the LAX-DC link"
AI: [adds a second link via a different path, updates the choreography
     to include a new step showing the redundant path, adds a failure
     scenario demonstrating automatic failover]
```

**Architectural requirements:**
- **Graph-theoretic model** (solving C3) so the AI can reason about paths, redundancy, and failure domains
- **Topology schema** that the AI can validate against (the skill already has validation rules — formalize them)
- **Undo/redo stack** so AI modifications can be reviewed and reverted
- **Diff visualization** — show what the AI changed, highlighted on the topology itself

### T4: Branching Narrative & Simulation Engine

**The problem:** Linear choreography (C4) can only tell one story. Real network operations involve "what if" scenarios.

**The invention:** A **narrative graph** that replaces the linear step array:

```javascript
td.narrate('baseline')
  .reveal('fullTopology')
  .branch({
    'Normal Operation': td.narrate('normal')
      .highlight('allTunnels', { label: 'All tunnels healthy' })
      .showMetrics({ latency: '< 50ms', bandwidth: '1Gbps' }),

    'Primary Link Failure': td.narrate('failure')
      .animate('tunSEA_DC', { style: 'blocked', reason: 'Fiber cut' })
      .then.animate('tunSEA_LAX_backup', { style: 'flow', label: 'Failover active' })
      .showMetrics({ latency: '120ms', bandwidth: '500Mbps' })
      .explain('Traffic reroutes through LA gateway — latency increases'),

    'DDoS Attack': td.narrate('ddos')
      .animate('SEA', { pulse: 'red', label: 'Under attack' })
      .then.reveal('ddosMitigation')
      .explain('SSE cloud absorbs attack traffic before it reaches the branch')
  });
```

The viewer sees a **branch selector** at decision points. In presenter mode, the speaker (or audience poll) chooses which scenario to explore. In embedded/dashboard mode, different branches can represent different operational conditions loaded from real data.

**Key insight:** This converts the choreography engine from a **slideshow** into a **state machine**. Each branch is a subgraph of the narrative graph. The viewer navigates the graph, not a list.

### T5: Collaborative Design Surface

**The problem:** Topologies are authored by one person at a time, saved as monolithic HTML files.

**The invention:** Real-time collaborative topology editing with operational awareness:

```
                  ┌──────────────┐
                  │  CRDT State  │ ← Conflict-free replicated data type
                  │  (Y.js/Liveblocks) │
                  └──────┬───────┘
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
    ┌───────────┐  ┌───────────┐  ┌───────────┐
    │ Designer A│  │ Designer B│  │   Viewer   │
    │ (editing) │  │ (editing) │  │ (readonly) │
    └───────────┘  └───────────┘  └───────────┘
```

**What this enables:**
- Multiple engineers build a topology together in real-time (like Figma for network diagrams)
- Cursors show who is editing what
- Change history with attribution
- Comment threads anchored to specific nodes/links
- Review mode: propose changes that others must approve before they merge into the canonical topology

**Architectural requirements:**
- **CRDT-based state model.** The `toJSON()`/`fromJSON()` serialization is the foundation — wrap it in a CRDT document (Y.js, Automerge, or Liveblocks) for conflict-free concurrent editing.
- **Operational transforms for choreography.** Two authors editing the same step's phase list need merge semantics.
- **Presence layer.** Show other users' cursor positions and selection states on the SVG canvas.

### T6: Predictive & Simulation-Driven UX

**The invention:** The topology isn't just a diagram — it's a **simulation model**:

```javascript
// Define capacity constraints
td.model('tunSEA_LAX', { maxBandwidth: '1Gbps', latency: '45ms' });
td.model('tunSEA_DC', { maxBandwidth: '10Gbps', latency: '12ms' });

// Run traffic simulation
const sim = td.simulate({
  traffic: [
    { from: 'hostSEA', to: 'appsDC', bandwidth: '800Mbps', protocol: 'HTTPS' },
    { from: 'hostLAX', to: 'saasO365', bandwidth: '200Mbps', protocol: 'HTTPS' },
  ],
  failures: [
    { element: 'tunSEA_DC', at: 3000 }  // fails at t=3s
  ]
});

// Replay simulation as choreography
td.playSimulation(sim);
// Automatically generates steps showing:
// 1. Normal traffic flow (animated particles showing bandwidth proportional to flow)
// 2. Link failure (blocked animation)
// 3. Rerouting (new path illuminates, metrics update)
// 4. Convergence (new steady-state with degraded metrics)
```

The simulation engine computes traffic paths using the graph model, applies capacity constraints, injects failures, and **automatically generates the choreography** to visualize the results. The topology becomes a runnable model, not just a picture.

---

## 4. Near-Term Improvements (0-3 Months)

These improve the system within its current architecture without requiring fundamental rewrites.

### N1: Persistent SVG Elements with Keyed Updates

Replace `innerHTML = this._renderSVG()` with a keyed reconciliation approach:

```javascript
// Instead of:
document.getElementById('tds-diagram').innerHTML = this._renderSVG();

// Use:
this._reconcileSVG(document.getElementById('tds-diagram'));
```

The reconciler creates elements once, then updates attributes/transforms in place. SVG animation elements (`animateMotion`, `animate`) persist across renders. Hover states survive. CSS transitions work.

This is a ~500-line change that unlocks: smooth interactive editing, persistent animations, and element-level event handlers.

**Priority: Critical.** Almost every future feature depends on this.

### N2: Extract Core Modules

Split the monolith into composable modules:

```
topology-ds/
├── core/
│   ├── graph.js          # Graph data model (adjacency, paths, subgraphs)
│   ├── renderer.js       # SVG rendering engine
│   ├── choreography.js   # Acts/Steps/Phases state machine
│   └── events.js         # Event bus + element interaction
├── renderers/
│   ├── nodes/            # One file per node type
│   └── links/            # One file per link type
├── ui/
│   ├── shell.js          # Sidebar, toolbar, narrator scaffold
│   ├── playback.js       # Play/pause/step controls
│   └── editor.js         # Properties panel, mode switching
├── plugins/
│   ├── routing.js        # Smart link routing
│   ├── layout.js         # Auto-layout algorithms
│   └── themes.js         # Theme engine
└── topology-ds.js        # Facade class that composes everything
```

Each module is independently testable. The facade class composes them. Users who only need rendering can import `core/renderer.js` without the UI shell.

### N3: Undo/Redo Stack

Wrap the state model in a command pattern:

```javascript
class CommandStack {
  execute(cmd) { cmd.do(); this._undoStack.push(cmd); this._redoStack = []; }
  undo() { const cmd = this._undoStack.pop(); cmd.undo(); this._redoStack.push(cmd); }
  redo() { const cmd = this._redoStack.pop(); cmd.do(); this._undoStack.push(cmd); }
}
```

Every mutation (move node, edit link, add step) becomes a reversible command. This is prerequisite for AI-assisted editing (T3) — users need to undo AI changes.

### N4: Pan/Zoom Canvas

The SVG canvas is currently fixed at the viewBox dimensions. Add:
- Scroll-wheel zoom with smooth interpolation
- Click-and-drag pan
- Zoom-to-fit button
- Minimap overview (small inset showing the full topology with a viewport indicator)

This is essential for large topologies that don't fit in the default 1050x700 viewport.

### N5: Node Drag-and-Drop

Currently only anchors are draggable. Extend dragging to all nodes:
- Mousedown on node starts drag
- Mousemove updates node position + re-renders connected links
- Mouseup commits the new position (as an undoable command)
- Snap-to-grid option

This requires N1 (persistent SVG elements) to be performant.

### N6: Export Pipeline

Add export capabilities:
- **SVG export** — current step rendered as a standalone SVG file
- **PNG/PDF export** — rasterize via `canvas.toDataURL()` or a print stylesheet
- **Animated GIF/MP4** — record the full choreography playback as video (via MediaRecorder API on a canvas mirror)
- **Mermaid/D2 interop** — export topology structure as Mermaid or D2 diagram code

---

## 5. Long-Term Platform Vision

### The Topology Operating System

The long-term vision is to transform this from a visualization tool into a **topology operating system** — a platform where network topologies are living, interactive, collaborative, intelligent objects rather than static diagrams.

```
┌─────────────────────────────────────────────────────────────────────┐
│                     TOPOLOGY OPERATING SYSTEM                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    APPLICATION LAYER                         │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │   │
│  │  │ Cinematic │  │ Live Ops │  │ Collab   │  │ Capacity │   │   │
│  │  │ Presenter│  │ Dashboard│  │ Designer │  │ Planner  │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    INTELLIGENCE LAYER                        │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │   │
│  │  │ AI Gen   │  │ Semantic │  │ Failure   │  │ Traffic  │   │   │
│  │  │ & Reason │  │ Choreo   │  │ Analysis │  │ Sim      │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                      ENGINE LAYER                            │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │   │
│  │  │ Graph    │  │ Renderer │  │ Choreo   │  │ Data     │   │   │
│  │  │ Model    │  │ (SVG/GL) │  │ Engine   │  │ Binding  │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    PLATFORM LAYER                            │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │   │
│  │  │ Plugin   │  │ CRDT     │  │ State    │  │ Event    │   │   │
│  │  │ Registry │  │ Sync     │  │ Machine  │  │ Bus      │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**Four application modes from one engine:**

1. **Cinematic Presenter.** What exists today, but elevated with semantic choreography, branching narratives, camera system, and AI-generated storylines. The premier tool for explaining network architectures to any audience.

2. **Live Ops Dashboard.** The same topology, but bound to real-time data sources. Node colors reflect health. Link animations show actual traffic flow. Click a node to see its metrics. The topology is the control surface for network operations.

3. **Collaborative Designer.** Multi-user real-time editing with AI assistance. "Add a redundant path" → AI proposes the design → team reviews → merge into the canonical topology. Version-controlled with Git-native serialization.

4. **Capacity Planner.** The topology as a simulation model. Inject traffic loads, introduce failures, test capacity limits. The simulation generates choreography automatically, showing the network's behavior under stress.

### Why This Architecture Wins

The key insight is that **the choreography engine is the differentiator**. Other tools can draw network diagrams. Other tools can show live metrics. But no tool combines:
- Cinema-quality rendering
- Narrative choreography with acts/steps/phases
- AI-assisted generation and analysis
- Live operational data binding
- Collaborative editing
- Simulation and prediction

...in a zero-dependency, browser-native package.

The rendering quality is already there. The choreography model is already there. What's needed is the architectural foundation (graph model, reactive state, persistent DOM, module system) to build the intelligence and collaboration layers on top.

---

## 6. Prioritized Roadmap

### Phase 1: Foundation (Months 1-3)
*Goal: Solve the structural constraints that block everything else.*

| # | Work Item | Constraint Solved | Enables |
|---|---|---|---|
| 1.1 | **Keyed SVG reconciler** — replace innerHTML with persistent element updates | C1 (innerHTML tax) | Smooth editing, persistent animations, element events |
| 1.2 | **Graph data model** — adjacency list, path finding, subgraph extraction | C3 (no graph model) | AI analysis, simulation, auto-layout, failure domain detection |
| 1.3 | **Module extraction** — split monolith into composable units | C2 (monolith) | Testing, tree-shaking, embeddable renderer |
| 1.4 | **Undo/redo command stack** | — | Safe AI editing, collaborative design |
| 1.5 | **Pan/zoom canvas** | C6 (fixed coordinates) | Large topologies, cinematic camera moves |
| 1.6 | **Node drag-and-drop** | — | Interactive editing |

### Phase 2: Intelligence (Months 3-6)
*Goal: Make the system smart.*

| # | Work Item | Idea | Impact |
|---|---|---|---|
| 2.1 | **Semantic choreography DSL** | T1 | 10x easier authoring, auto-focus, camera system |
| 2.2 | **Choreography compiler** | T1 | Converts semantic intent to optimized render plans |
| 2.3 | **AI topology analysis** | T3 | Redundancy detection, SPOF identification, optimization suggestions |
| 2.4 | **AI iterative refinement** | T3 | Conversational topology editing ("add redundancy here") |
| 2.5 | **Branching narrative engine** | T4 | What-if scenarios, audience-driven paths |
| 2.6 | **Camera system** | T1 | Zoom, pan, focus transitions as part of choreography |

### Phase 3: Operational (Months 6-9)
*Goal: Connect to the real world.*

| # | Work Item | Idea | Impact |
|---|---|---|---|
| 3.1 | **Reactive data binding layer** | T2 | Fine-grained updates from external data sources |
| 3.2 | **Data source adapters** | T2 | REST, WebSocket, SSE, MQTT, Prometheus, SNMP |
| 3.3 | **Metric overlay components** | T2 | Sparklines, gauges, badges attached to nodes |
| 3.4 | **Alert/event integration** | T2 | Topology elements flash/pulse when alerts fire |
| 3.5 | **Traffic simulation engine** | T6 | Model traffic flows, inject failures, compute paths |
| 3.6 | **Simulation → choreography** | T6 | Auto-generate narrative from simulation results |

### Phase 4: Collaborative (Months 9-12)
*Goal: Make it multiplayer.*

| # | Work Item | Idea | Impact |
|---|---|---|---|
| 4.1 | **CRDT state model** | T5 | Conflict-free concurrent editing |
| 4.2 | **Presence layer** | T5 | See other users' cursors and selections |
| 4.3 | **Comment threads on elements** | T5 | Discussion anchored to specific nodes/links |
| 4.4 | **Change proposals / review mode** | T5 | Approve/reject topology changes before merge |
| 4.5 | **Version history with visual diff** | T5 | See what changed between topology versions, highlighted on the diagram |
| 4.6 | **Export pipeline** (SVG, PNG, PDF, video, Mermaid) | — | Share outside the platform |

---

## Closing Thought

This system already has something most visualization tools never achieve: **a point of view**. The cinematic rendering, the narrative choreography, the glassmorphism aesthetic — these aren't features, they're a design philosophy. The philosophy says: network topology should be beautiful, understandable, and alive.

The architecture changes proposed here don't change that philosophy. They build the foundation for it to scale — from a single-author presentation tool to a platform where AI, humans, and live operational data collaborate to make network infrastructure visible, understandable, and manageable.

The technology to build all of this exists today, in the browser, without dependencies. The hardest part — the rendering engine and the choreography model — is already built and working. What remains is the plumbing to connect it to intelligence, data, and people.
