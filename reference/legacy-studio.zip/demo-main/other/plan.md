# Editor Enhancement Plan — Topology Design System Visual Editor

## Current State Analysis

The editor (`design-system/editor.html`, ~1111 lines) is a functional SVG-based topology editor with:
- Node placement via palette dropdown (11 types)
- Simple 2-point links (from → to) with 6 types (line, tunnel, wireguard, flow, packet, blocked)
- Right-side properties panel for selected element
- Bottom choreography panel with acts/steps/phases table
- Basic drag-and-drop for nodes and anchors
- Export to standalone HTML + live preview

**Key gaps identified from the user's requirements and UX review:**

1. Links are point-to-point only — no multi-waypoint routing
2. Link endpoints snap to node center — no ability to position them on the node perimeter
3. No line geometry options (only straight lines; flows use raw SVG path strings)
4. The choreography/layer workflow for blur+focus is buried in a dense table
5. No undo/redo system
6. No zoom/pan on the canvas
7. No snap-to-grid for node placement
8. No keyboard shortcuts for common actions
9. No visual feedback for link attachment points
10. No way to visually preview blur/focus per step without full export+preview

---

## Enhancement Plan

### Phase 1: Link Attachment Points (Node Perimeter Anchoring)

**Goal:** Physical links should terminate at configurable points on the node shape perimeter, not always at the center.

**Changes to `editor.html`:**

1. **Add connection ports to nodes** — When a node is selected or hovered during link creation, render 4–8 port indicators around the node perimeter (N, NE, E, SE, S, SW, W, NW). Store the chosen port as `fromPort` / `toPort` on the link config (e.g., `"fromPort": "E"`, `"toPort": "W"`).

2. **Port position resolver** — Add a `getPortPos(nodeId, port)` function that calculates the actual (x,y) position for a port given the node's type geometry. Example: For an EC node at (500,280), port "E" returns `(530, 280)`, port "N" returns `(500, 260)`.

3. **Draggable link endpoints** — After a link is created, show small drag handles at each endpoint. Dragging a handle snaps it to the nearest port on the connected node, updating `fromPort`/`toPort`.

4. **Properties panel update** — Add port selectors (dropdown: N/NE/E/SE/S/SW/W/NW) in the link properties panel.

5. **Export update** — Include `fromPort`/`toPort` in generated code.

**Files changed:** `editor.html` (rendering, interaction, properties, export)

---

### Phase 2: Multi-Point Routing for Logical Links

**Goal:** Tunnels, data flows, and other logical links should support A→B→C→D→...→Z multi-waypoint paths.

**Changes to `editor.html`:**

1. **Waypoint data model** — Links gain an optional `waypoints` array: `[{x, y}, {x, y}, ...]`. The path goes: `from` → waypoint[0] → waypoint[1] → ... → `to`.

2. **Waypoint creation mode** — When creating a flow/tunnel link, instead of just clicking start+end, each click adds a waypoint. Double-click or pressing Enter finalizes the last point as the endpoint. Visual feedback shows the growing polyline in real time.

3. **Waypoint editing** — Selected multi-point links show draggable handles at each waypoint. Handles can be:
   - Dragged to reposition
   - Double-clicked to delete
   - Right-click (or button) to insert a new waypoint between two existing ones

4. **SVG path generation** — Convert waypoints array into SVG `<polyline>` or `<path>` data automatically based on the line style setting (see Phase 3).

5. **Properties panel** — Show waypoint list with X/Y fields and add/remove buttons.

6. **Export update** — Include `waypoints` in generated link config.

**Files changed:** `editor.html`

---

### Phase 3: Line Geometry Styles (Straight, Angled, Rounded)

**Goal:** Support three routing modes for links: straight segments, orthogonal (right-angle) segments, and smooth curved segments.

**Changes to `editor.html`:**

1. **`lineStyle` property on links** — Values: `"straight"` (default), `"orthogonal"`, `"curved"`.

2. **Straight** — Direct point-to-point segments (current behavior). For multi-waypoint links, this creates a polyline.

3. **Orthogonal** — Segments only travel horizontally or vertically, with 90-degree corners. Auto-routes around the shortest orthogonal path between points.

4. **Curved** — Uses cubic Bézier curves with configurable corner radius. For simple 2-point links, a single smooth arc. For multi-waypoint links, generates smooth curves through all waypoints using Catmull-Rom → Bézier conversion.

5. **Radius control** — For curved mode, add a `cornerRadius` slider (1–50px, default 20). For orthogonal mode, optionally round the corners with a smaller radius.

6. **Properties panel** — Add line style dropdown and radius slider in link properties.

7. **Toolbar shortcut** — Line style toggle button group in the toolbar for quick switching during link creation.

8. **SVG path builder** — New `buildLinkPath(from, waypoints, to, lineStyle, radius)` utility that returns the SVG path `d` attribute string.

**Files changed:** `editor.html`

---

### Phase 4: Layer & Focus Workflow (Step Choreography UX Overhaul)

**Goal:** Make the step-by-step blur/focus design intuitive with visual layer management instead of the current dense table.

**Changes to `editor.html`:**

1. **Step Preview Mode** — Add a "Preview Step" toggle that applies blur/focus to the canvas in real time as you select steps in the choreography panel. Focused elements render at full opacity; unfocused elements get CSS blur + dimming. No need to export — see it live in the editor.

2. **Visual Phase Timeline** — Replace the choreography table with a horizontal timeline strip at the bottom:
   - Each act is a colored section
   - Each step is a card within the act section
   - Each phase is a dot/chip within the step card
   - Click a step to preview its blur/focus state on canvas
   - Drag steps to reorder within an act
   - Drag-and-drop elements from canvas to step cards to add them to phases

3. **Focus Painter** — When in step preview mode, clicking a canvas element toggles it in/out of the current step's focus array. Visual indicator (glow ring vs. dim) updates instantly.

4. **Phase Builder** — For the selected step, show a mini panel with phase slots. Drag elements from the canvas or from a sidebar list into phase slots. Each slot shows its `show[]` and `diff` text.

5. **Quick Layer Toggle** — Each node/link in the right panel gets a small eye icon per step to quickly toggle visibility in that step's phases.

**Files changed:** `editor.html`

---

### Phase 5: Canvas Interaction Improvements

**Goal:** Essential UX improvements for productive editing.

**Changes to `editor.html`:**

1. **Zoom & Pan** — Mouse wheel zoom + middle-button/space+drag pan. Update the SVG `viewBox` dynamically. Show zoom level in status bar. Add zoom-to-fit and zoom reset buttons.

2. **Snap-to-Grid** — Optional grid snapping (toggle in toolbar). Default 12px grid. Hold Shift to temporarily disable snap.

3. **Undo/Redo** — Command pattern history stack. Capture state snapshots on every mutation (node add/move/delete, link add/delete, property change). Ctrl+Z undo, Ctrl+Shift+Z redo. Show undo count in status bar.

4. **Multi-select** — Shift+click to add to selection. Drag-select rectangle. Move multiple selected elements together.

5. **Copy/Paste** — Ctrl+C copies selected elements. Ctrl+V pastes with offset. Useful for duplicating node groups.

6. **Context Menu** — Right-click on canvas/node/link shows contextual actions (delete, duplicate, bring to front, add to current step, etc.).

7. **Keyboard Shortcuts Panel** — `?` key opens a shortcuts reference overlay.

8. **Auto-save to localStorage** — Periodically save state. Prompt to restore on page load if saved state exists.

---

### Phase 6: 3D Tunnel Visualization Mode

**Goal:** Toggle links into 3D semi-translucent tunnel rendering to visually reinforce the concept of encrypted tunnels, VPN corridors, and data pipes.

**Changes to `editor.html`:**

1. **`tunnel3d` toggle on links** — Boolean property. When enabled, the link renders as a 3D-looking translucent tube instead of a flat line/dash.

2. **SVG 3D Tunnel Rendering** — Composite SVG elements to create the illusion of a 3D tube:
   - **Outer shell** — Wide stroke (~18–24px) with low opacity (0.08–0.12) in the link color, rounded linecaps
   - **Inner gradient** — Medium stroke (~10–14px) with a gradient from lighter (top highlight) to darker (bottom shadow) using `linearGradient` rotated to match the path angle
   - **Core glow** — Narrow stroke (~4–6px) at higher opacity with the link color and a subtle glow filter
   - **Specular highlight** — Very narrow stroke (~2px) offset slightly above center with white at 0.15 opacity to simulate light reflection along the top of the tube
   - All layers follow the same path (straight, curved, or multi-waypoint)

3. **Translucency & Depth** — SVG `opacity` and `filter` effects:
   - Apply a subtle `feGaussianBlur` to the outer shell for soft depth
   - Use `mix-blend-mode: screen` on the highlight layer
   - When elements cross behind a tunnel, they remain visible through the translucent tube

4. **Animated flow particles (optional)** — When `tunnel3d` is active and the link also has `dots: true`, render small glowing particles that travel along the tunnel path to show data flow direction. Uses `<animateMotion>` along the path.

5. **Tunnel diameter control** — `tunnelWidth` slider (8–40px, default 18) in properties panel to adjust the visual thickness of the 3D tube.

6. **Preset tunnel styles** — Quick-apply presets in a dropdown:
   - **IPsec** — Green tube with lock icon at midpoint
   - **WireGuard** — Purple tube with "WG" badge
   - **GRE** — Blue tube, slightly more transparent
   - **Data Flow** — Gold tube with animated particles
   - **Blocked** — Red tube with X overlay and crack effect

7. **SVG filter definitions** — Add reusable SVG `<defs>` for tunnel glow, inner shadow, and specular highlight filters.

**Files changed:** `editor.html`

---

### Phase 7: Additional UX Polish

1. **Node Labels Inline Editing** — Double-click a node label on canvas to edit it in-place (contenteditable overlay) instead of only via properties panel.

2. **Minimap** — Small overview window in corner showing the full topology with a viewport rectangle for orientation during zoom.

3. **Link Labels on Path** — For curved/multi-point links, position the label along the path midpoint with auto-rotation to follow the path angle.

4. **Alignment Guides** — Smart guides that appear when dragging nodes near horizontal/vertical alignment with other nodes.

5. **Import/Load JSON** — In addition to loading the SD-WAN demo, support importing a previously exported topology from JSON or the generated HTML.

6. **Dark/Light Theme Toggle** — Offer a light theme variant for the editor.

7. **Touch Support** — Basic touch events for tablet use (single-finger drag, two-finger zoom).

---

## Implementation Order & Priority

| Priority | Phase | Effort | Impact |
|----------|-------|--------|--------|
| P0 | Phase 1: Link Attachment Points | Medium | High — directly requested |
| P0 | Phase 2: Multi-Point Routing | Medium | High — directly requested |
| P0 | Phase 3: Line Geometry Styles | Medium | High — directly requested |
| P0 | Phase 4: Layer & Focus Workflow | High | High — directly requested |
| P1 | Phase 5: Canvas Interactions | High | High — essential UX |
| P0 | Phase 6: 3D Tunnel Visualization | Medium | High — directly requested |
| P2 | Phase 7: UX Polish | Medium | Medium — quality of life |

**Implementation strategy:** All changes are confined to `editor.html` (self-contained single-file editor). The core engine `topology-ds.js` and its CSS do NOT need changes — the editor generates code that the engine consumes, and all new link features (waypoints, ports, line styles) are stored as data that the export function translates into the appropriate `path` attributes and node configs.

**Estimated scope:** ~2500–3500 lines of new/modified code across all phases, primarily JavaScript within `editor.html`.
