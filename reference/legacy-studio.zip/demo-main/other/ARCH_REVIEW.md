# Topology Tool Product + Architecture Review

This document captures a pragmatic UX and engineering review of the current topology editor (`editor.html`) and playback engine (`topology-ds.js`).

## 1) Executive Summary

The current tool already provides substantial capability: node/link authoring, multiple link styles, templates, auto-layout, choreography steps/phases, preview playback, and an attractive visual language.

Biggest opportunities:
- Simplify novice workflow into a guided “Build → Animate → Present” progression.
- Separate data/state/renderer/interaction so the app scales without fragile coupling.
- Move from full-SVG re-render per interaction to incremental updates for large graphs.
- Introduce a real timeline/keyframe model for animation authoring.

## 2) Current System Analysis

- **Data model:** Rich but loosely typed runtime objects in `Map` + arrays.
- **Rendering:** Manual SVG string assembly and `innerHTML` replacement.
- **Animation:** Step/phase reveal model with focus and opacity dimming.
- **Interaction:** Strong direct manipulation support but concentrated in one large file.
- **Editor vs presentation:** Distinct contexts exist but share concepts and duplicate schema logic.
- **Maintainability risk:** Parsing and import rely on regex + `new Function`, and many behaviors are hand-wired.

## 3) Recommended Product Redesign

- Introduce a clear primary flow:
  1. Build topology (palette, smart defaults, connect mode)
  2. Annotate and group (labels, layers, alignment)
  3. Animate (timeline tracks, reusable effects)
  4. Present/export (clean viewer mode)
- Add progressive disclosure: basic mode for most users, advanced mode for precision controls.

## 4) Recommended Technical Architecture

- Core modules:
  - `model` (schema + validators)
  - `commands` (undo/redo)
  - `renderer` (scene graph + SVG adapter)
  - `interaction` (tools and gestures)
  - `animation` (timeline and playback)
  - `io` (JSON, templates, import/export)
- Keep SVG renderer initially, but isolate it behind a renderer boundary.

## 5) Keep / Refactor / Replace

- **Keep:** Visual style language, choreography concept, layout/template modules.
- **Refactor:** State management, editor code organization, import/export contracts.
- **Replace:** Regex/code-eval import path and monolithic interaction wiring.

## 6) Phased Implementation Plan

- **Phase 1:** UX quick wins + guardrails.
- **Phase 2:** State/command architecture extraction.
- **Phase 3:** Timeline and storytelling overhaul.
- **Phase 4:** Performance and accessibility hardening.

## 7) Pseudocode and Interfaces

Add typed interfaces for `TopologyDocument`, `SceneTimeline`, `AnimationTrack`, and command APIs for all mutating operations.

## 8) Prototype Ideas

1. Guided “first topology in 60 seconds” flow.
2. Timeline prototype with keyframes + scrubbing.
3. Failover simulator prototype with active/standby path transitions.
4. Large-topology stress test harness (1k nodes / 2k links).
