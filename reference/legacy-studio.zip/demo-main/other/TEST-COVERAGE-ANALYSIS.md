# Test Coverage Analysis

**Date:** 2026-03-13
**Current state:** Zero test coverage — no test files, no test framework, no coverage tooling.

The project is ~4,000+ lines of production JavaScript across 4 source files with no automated verification.

## Recommended Test Framework

**Vitest** — lightweight, fast, works with vanilla JS out of the box, built-in coverage reporting. No build tools or transpilation needed.

## Priority Areas for Testing

### 1. ThemeEngine color utilities (High priority, easy)

`design-system/modules/theme-engine.js`

- `_hexToRGB()`, `_hexToHSL()`, `_hslToHex()` — Pure math functions, trivially testable
- `contrastRatio()` / `passesWCAG_AA()` — Accessibility correctness depends on these; test against known WCAG reference values
- `generateFromPrimary()` — Verify generated palettes have valid hex colors and meet contrast requirements

### 2. TemplateParser text parsing (High priority, medium difficulty)

`design-system/modules/template-parser.js`

- `fromText()` — Parses Mermaid-inspired DSL into topology objects; many edge cases with link syntaxes (`-->`, `-.->`, `==>`, `~~>`), labels, node types
- Round-trip: `fromText()` output fed to `applyToDesigner()` should produce valid topologies

### 3. LayoutEngine algorithms (High priority, medium difficulty)

`design-system/modules/layout-engine.js`

- `forceDirected()` — Verify no overlap, within bounds, connected nodes closer than unconnected
- `hierarchical()` — Verify topological ordering and no layer collisions
- `circular()` / `grid()` — Verify even spacing and boundary constraints

### 4. TopologyDesigner registration API (High priority, medium difficulty)

`design-system/topology-ds.js`

- `node()`, `link()`, `anchor()` — State map correctness, duplicate ID handling, required field validation
- `act()` / `addStep()` — Choreography data structure correctness, step indexing, phase ordering
- `toJSON()` / `fromJSON()` — Round-trip serialization integrity (critical for editor save/load)

### 5. Choreography & phase logic (Medium priority)

`design-system/topology-ds.js`

- `_ph()`, `_phAttr()`, `_pw()`, `_findShowPhase()` — Phase timing and visibility calculations
- `_getFocus()`, `_dimFor()`, `_isFocused()` — Focus/spotlight logic
- `next()`, `prev()`, `goTo()`, `reset()` — Step navigation boundary conditions

### 6. SVG rendering correctness (Medium priority)

`design-system/topology-ds.js`

- Node type renderers — Snapshot tests for valid SVG markup
- Link type renderers — Path geometry correctness for various positions
- `_svgDefs()` — Filter/gradient/marker definitions

### 7. URL state persistence (Lower priority)

`design-system/topology-ds.js`

- `_loadURL()` / `_updateURL()` — Step state round-trip through URL parameters

## Recommended Implementation Order

1. **ThemeEngine** — Smallest module, pure functions, highest test-to-effort ratio
2. **TemplateParser** — Parser bugs are subtle and hard to debug without tests
3. **LayoutEngine** — Pure algorithms, easy to assert on output positions
4. **TopologyDesigner API** — Registration + serialization (needs DOM mocking for `mount()`)
5. **Choreography logic** — Phase/focus calculations
6. **SVG rendering** — Snapshot tests for regression detection

## Risk Assessment

| Risk | Impact | Likelihood |
|------|--------|------------|
| Color conversion math errors | Inaccessible themes, broken palettes | Medium |
| Parser fails on edge-case syntax | Silent data loss when importing | High |
| Layout produces overlapping nodes | Unusable visualizations | Medium |
| JSON round-trip loses data | Editor save/load corrupts work | High |
| Phase calculations off-by-one | Wrong elements at wrong steps | Medium |
| Invalid SVG string concatenation | Browser-specific rendering failures | Medium |
