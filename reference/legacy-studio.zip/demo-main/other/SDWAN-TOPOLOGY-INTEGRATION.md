# SD-WAN Expert → Topology Design System Integration Outline

Connecting a live SD-WAN fabric (via the EC SD-WAN Expert skill) to the Topology Design System to auto-generate visual topology maps.

---

## 1. Data Collection Layer — What to Pull from the Fabric

The SD-WAN Expert skill needs to query the Orchestrator/fabric APIs and produce a normalized data model. Key data sources:

### 1a. Appliances & Sites
- **Endpoint:** Orchestrator REST API (`/gms/rest/appliance`, `/gms/rest/sites`)
- **Data needed:** Appliance hostname, site name, role (hub/spoke/mesh), model (physical/virtual/cloud), WAN interfaces, LAN interfaces, HA/VRRP status (active/standby), geo coordinates or site tags
- **Maps to:** `topo.node()` with `type: 'ec'` and appropriate `variant` (`physical`, `virtual`, `aws`, `azure`, `gcp`)

### 1b. Overlay Tunnels & Underlay Links
- **Endpoint:** `/gms/rest/tunnels2/state`, `/gms/rest/overlayStats`
- **Data needed:** Tunnel source/destination appliance, tunnel state (up/down), underlay transport (MPLS, Internet, LTE), BFD status, jitter/loss/latency
- **Maps to:** `topo.link()` with `type: 'tunnel'` or `type: 'flow'` for overlay, `type: 'line'` for underlay

### 1c. WAN Transports & Internet Breakout
- **Endpoint:** `/gms/rest/internetBreakout`, interface status APIs
- **Data needed:** Transport labels (MPLS, Internet-1, LTE), breakout policy, interface up/down
- **Maps to:** `topo.node('INET', { type: 'cloud' })` per transport, `topo.link()` from EC to cloud

### 1d. Business Intent Overlays (BIOs)
- **Endpoint:** `/gms/rest/businessIntentOverlay`
- **Data needed:** Overlay name, color, member appliances, application policies, priority
- **Maps to:** `topo.node({ type: 'overlayCloud', spans: [...] })` or flow links with BIO labels

### 1e. Security Zones & Segmentation
- **Endpoint:** Zone/segmentation APIs
- **Data needed:** Zone names (LAN, WAN, DMZ), VLAN mappings, firewall rules
- **Maps to:** `zoneLabel` and `zoneIndicator` properties on EC nodes

### 1f. Connected Infrastructure (Optional)
- Switches, firewalls, hosts discovered via LLDP/CDP
- Maps to: `switch`, `firewall`, `host`, `router` node types

---

## 2. Data Normalization — The Intermediate Schema

Define a JSON schema that the SD-WAN Expert produces and the topology generator consumes:

```jsonc
{
  "fabric": {
    "name": "Production SD-WAN",
    "orchestrator": "orch.example.com"
  },
  "sites": [
    {
      "id": "site-seattle",
      "name": "Seattle HQ",
      "role": "hub",              // hub | spoke | mesh
      "appliances": [
        {
          "id": "SEA-EC1",
          "hostname": "sea-ec1.corp",
          "model": "EC-V",        // physical | virtual | aws | azure | gcp
          "ha": "active",         // active | standby | null
          "wanInterfaces": [
            { "name": "wan0", "transport": "internet", "state": "up" },
            { "name": "wan1", "transport": "mpls", "state": "up" }
          ],
          "lanInterfaces": [
            { "name": "lan0", "vlan": 100, "zone": "LAN" }
          ]
        }
      ]
    }
  ],
  "tunnels": [
    {
      "id": "tun-sea-lax",
      "from": "SEA-EC1",
      "to": "LAX-EC1",
      "transport": "internet",    // internet | mpls | lte
      "state": "up",
      "metrics": { "latency": 12, "jitter": 1.2, "loss": 0.0 }
    }
  ],
  "overlays": [
    {
      "id": "bio-voice",
      "name": "Voice BIO",
      "color": "#01a982",
      "members": ["SEA-EC1", "LAX-EC1", "DEN-EC1"]
    }
  ],
  "transports": [
    { "id": "inet", "type": "internet", "label": "Internet" },
    { "id": "mpls", "type": "mpls", "label": "MPLS WAN" }
  ]
}
```

---

## 3. Topology Generator — Translating Fabric Data to Design System Code

A JavaScript module that takes the normalized schema and produces topology API calls.

### 3a. Layout Engine
- **Auto-placement algorithm:** Assign x/y coordinates based on site role and count
  - Hub sites → center of the canvas
  - Spoke sites → arranged radially or in rows around hubs
  - Cloud/Internet nodes → top of canvas (y: 30–80)
  - Endpoints/services → bottom (y: 450–600)
- **Scaling:** Adjust `viewBox` based on node count (small fabrics: `0 0 900 600`, large: `0 0 1400 900`)
- **Collision avoidance:** Ensure minimum 120px horizontal, 100px vertical spacing

### 3b. Node Mapping Rules
| Fabric Entity | Node Type | Config |
|--------------|-----------|--------|
| EC appliance (physical) | `ec` | `variant: 'physical'`, VRRP status |
| EC appliance (virtual) | `ec` | `variant: 'virtual'` |
| EC appliance (AWS/Azure/GCP) | `ec` | `variant: 'aws'` / `'azure'` / `'gcp'` |
| Internet transport | `cloud` | `color: '#b1b9be'` |
| MPLS transport | `cloud` | `color: '#01a982'`, `label: 'MPLS'` |
| LTE transport | `cloud` | `color: '#ec8c25'`, `label: 'LTE/5G'` |
| Business Intent Overlay | `overlayCloud` | `spans: [member IDs]` |
| LAN switch (LLDP) | `switch` | `color: '#00a4b3'` |
| Firewall (LLDP) | `firewall` | `color: '#fc6161'` |

### 3c. Link Mapping Rules
| Fabric Connection | Link Type | Config |
|------------------|-----------|--------|
| Overlay tunnel (up) | `tunnel` | `color: '#01a982'`, `dots: true` |
| Overlay tunnel (down) | `blocked` | `reason: 'Tunnel Down'` |
| Underlay to Internet | `line` | `color: '#b1b9be'` |
| Underlay to MPLS | `line` | `color: '#01a982'`, `dashed: true` |
| LAN connection | `line` | `color: '#00a4b3'` |
| BIO flow path | `flow` | BIO color, curved path between members |

### 3d. Anchor Generation
- Auto-place anchors 12px from EC node edges for tunnel endpoints
- Position anchors so tunnels don't overlap visually

---

## 4. Choreography Generator — Auto-Building the Narrative

Automatically generate acts/steps/phases that tell the fabric story:

### Act Structure
| Act | Content | Color |
|-----|---------|-------|
| **Act 1 · Transport** | Internet, MPLS, LTE clouds + underlay links | `#b1b9be` |
| **Act 2 · Sites** | Deploy each site's EC appliances | `#01a982` |
| **Act 3 · Overlay** | SD-WAN tunnels between sites | `#65aef9` |
| **Act 4 · Business Intent** | BIO overlays + application policies | `#deb146` |
| **Act 5 · Health** | Highlight any down tunnels or degraded paths | `#fc6161` |

### Step Generation Logic
1. **Transport step:** Show all cloud/transport nodes
2. **Per-site steps:** One step per site — show EC + underlay links, focus on that site
3. **Overlay steps:** Group tunnels by hub — show all tunnels from each hub
4. **BIO steps:** One step per Business Intent Overlay — show overlay cloud + member focus
5. **Health step:** If any tunnels are down, show blocked links with reasons

### Phase Grouping
- Each phase reveals one logical unit (a node + its connecting link)
- Keep 2–5 phases per step
- Generate `diff` text from fabric metadata (e.g., `"SEA-EC1 connects to Internet (wan0, up)"`)

---

## 5. Integration Architecture

```
┌──────────────────────┐     ┌───────────────────────┐     ┌──────────────────────┐
│  SD-WAN Expert Skill │     │  Topology Generator   │     │  Topology Design     │
│                      │     │                       │     │  System              │
│  • Query Orch API    │────▸│  • Layout engine      │────▸│  • topology-ds.js    │
│  • Normalize data    │     │  • Node/link mapper   │     │  • topology-ds.css   │
│  • Produce JSON      │     │  • Choreography gen   │     │  • Rendered HTML     │
│                      │     │  • HTML template       │     │                      │
└──────────────────────┘     └───────────────────────┘     └──────────────────────┘
        ▲                              │
        │                              ▼
   Orchestrator               design-system/*.html
   REST API                   (standalone output)
```

### Option A: Skill-to-Skill Pipeline (Recommended)
The SD-WAN Expert skill collects fabric data, then invokes the topology-editor skill with a structured prompt containing the normalized JSON. The topology-editor skill generates the HTML file.

**Flow:**
1. User asks: *"Show me my SD-WAN topology"*
2. SD-WAN Expert queries Orchestrator APIs → produces normalized JSON
3. SD-WAN Expert formats a prompt: *"Generate a topology from this fabric data: {json}"*
4. Topology editor skill generates the HTML file
5. User opens the HTML file in a browser

### Option B: Standalone Generator Module
A dedicated `fabric-to-topology.js` module that directly converts the normalized JSON to TopologyDesigner API calls and writes a complete HTML file.

**Flow:**
1. SD-WAN Expert queries Orchestrator → produces JSON file
2. Generator script reads JSON → writes `design-system/fabric-topology.html`
3. No skill chaining needed — single script handles end-to-end

---

## 6. Chosen Approach: `topology-map` Mini-Skill

After reviewing the SD-WAN Expert's architecture, the skill-to-skill pipeline
was replaced with a **dedicated `topology-map` mini-skill** inside the SD-WAN
Expert repo (`EC_SD-WAN_Expert/.claude/skills/mini-skills/topology-map/SKILL.md`).

### Why Mini-Skill Over Skill-to-Skill

1. **Follows existing architecture** — the Expert already has 13 mini-skills
   with clean handoff patterns via `manifest.json`
2. **Self-contained context** — Claude loads only the mapping rules it needs,
   not the full topology-editor + full SD-WAN Expert documents
3. **Reusable mapping logic** — platform detection, HA pair grouping, tunnel
   deduplication, and layout rules are encoded once and reused every invocation
4. **Clean handoff** — references `tunnel-health`, `alarm-triage`, etc. for
   issues discovered during data collection

### What the Mini-Skill Contains

| Section | Purpose |
|---------|---------|
| Data Collection (Step 1) | Which API endpoints to query, inline Python script |
| Node Mapping (Step 2) | platform → EC variant, role → position, HA pair detection |
| Link Mapping (Step 2) | Tunnel state → link type, deduplication logic |
| Auto-Layout (Step 3) | Role-based Y bands, region-based X clustering |
| Choreography (Step 4) | Standard 5-act structure, step/phase generation rules |
| HTML Output (Step 5) | Complete template with topology-ds.js/css references |
| Validation (Step 6) | Cross-reference checklist before delivery |

### Trigger Phrases

Registered in `manifest.json` with triggers:
`topology`, `map`, `diagram`, `visualize`, `network map`, `fabric map`,
`generate topology`, `show topology`, `draw network`

---

## 7. Implementation Status

| Item | Status | Location |
|------|--------|----------|
| `topology-map/SKILL.md` | Created | `EC_SD-WAN_Expert/.claude/skills/mini-skills/topology-map/` |
| `manifest.json` updated | Done | `EC_SD-WAN_Expert/.claude/skills/mini-skills/manifest.json` |
| Topology Design System | Existing | `demo/design-system/topology-ds.js` + `.css` |
| Topology Editor Skill | Existing | `demo/.claude/skills/topology-editor.md` |

### Next Steps

- [ ] Test end-to-end: run data collection script against live Orchestrator
- [ ] Generate first real fabric topology and validate output
- [ ] Tune layout algorithm for the specific fabric (8 sites, 16 appliances)
- [ ] Add to SD-WAN Expert's main SKILL.md references section
- [ ] Consider adding a `topology` subcommand to `scripts/sdwan_query.py`
