# AI Stress Report

## Live hosted AI assist (`https://demo-xyp.pages.dev/api/ai-assist`)

Using the exact prompts requested:

- `small 3 sites - 1 Hub and 2 spoke` → **9 nodes / 8 links**, valid JSON returned
- `medium 10 sites - 2 hub 8 spoke` → **fallback**, invalid topology JSON
- `large 4 hub 32 spoke` → **fallback**, invalid topology JSON

Status endpoint:

- model: `@cf/openai/gpt-oss-120b`
- `aiBinding: true`

## Local editor-side AI parser fallback

Using the same exact prompts through `topo._parseAITopologyDescription()`:

- small → **3 nodes / 2 links**
- medium → **3 nodes / 2 links**
- large → **3 nodes / 2 links**

This confirms the local fallback parser is currently too shallow for requested SD-WAN scale prompts.

## Generated stress fixtures

These were generated as deterministic high-fidelity fixtures to push the renderer, choreography, layers, flow paths, and policy markers harder than the current AI flow can:

- `small-3site-hubspoke.html` / `.json`
  - 10 nodes, 14 links, 4 steps, 2 flow paths, 4 policy markers
- `medium-10site-dualhub.html` / `.json`
  - 17 nodes, 32 links, 5 steps, 3 flow paths, 5 policy markers
- `large-36site-quadhub.html` / `.json`
  - 43 nodes, 97 links, 7 steps, 3 flow paths, 7 policy markers

## Included feature coverage

- isometric tilt enabled on load
- tunnel + WireGuard overlay links
- layered flow paths
- policy markers
- zones
- acts + steps + ghosting-friendly choreography
- security-path validation and blast-radius validation in generation checks

## Generator

Source generator script:

- `demo/scripts/generate-ai-stress-topologies.js`
