/**
 * Middleware & error-handler tests for api/server.js.
 *
 * Covers middleware behaviour (security headers, request IDs, rate-limit
 * headers), the Express error handler (413 payload-too-large), and edge-case
 * routes that are not exercised by the main api-server.test.js suite.
 */
import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';

const app = require('../api/server.js');

let server;
let base;

/**
 * Lightweight request helper matching the existing test pattern.
 * Returns { status, body } with parsed JSON.
 */
async function req(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(`${base}${path}`, opts);
  let data = null;
  if (r.status !== 204) {
    const text = await r.text();
    data = text ? JSON.parse(text) : null;
  }
  return { status: r.status, body: data };
}

/**
 * Raw fetch helper that returns the full Response so callers can inspect
 * individual headers.
 */
async function rawFetch(method, path, opts = {}) {
  const fetchOpts = { method, headers: { ...opts.headers } };
  if (opts.body !== undefined) {
    fetchOpts.body = opts.body;
    if (!fetchOpts.headers['Content-Type']) {
      fetchOpts.headers['Content-Type'] = 'application/json';
    }
  }
  return fetch(`${base}${path}`, fetchOpts);
}

function sampleTopology() {
  return {
    title: 'Middleware Test',
    subtitle: 'middleware',
    viewBox: '0 0 1000 600',
    phaseMs: 500,
  };
}

async function createTopology(cfg = sampleTopology()) {
  const r = await req('POST', '/api/topologies', cfg);
  expect(r.status).toBe(201);
  expect(r.body.id).toBeDefined();
  return r.body.id;
}

beforeAll(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      base = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

afterAll(async () => {
  await new Promise((resolve) => server.close(() => resolve()));
});

// ═══════════════════════════════════════════════════════════════
//  Security & request-ID headers
// ═══════════════════════════════════════════════════════════════
describe('Middleware — Security headers', () => {
  it('returns X-Request-Id on every response', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.headers.get('X-Request-Id')).toBeTruthy();
  });

  it('echoes a client-supplied X-Request-Id', async () => {
    const customId = 'test-req-id-12345';
    const res = await rawFetch('GET', '/api/health', {
      headers: { 'X-Request-Id': customId },
    });
    expect(res.headers.get('X-Request-Id')).toBe(customId);
  });

  it('returns X-Content-Type-Options: nosniff', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.headers.get('X-Content-Type-Options')).toBe('nosniff');
  });

  it('returns X-Frame-Options: DENY', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.headers.get('X-Frame-Options')).toBe('DENY');
  });

  it('returns Referrer-Policy: no-referrer', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.headers.get('Referrer-Policy')).toBe('no-referrer');
  });
});

// ═══════════════════════════════════════════════════════════════
//  Rate-limit headers
// ═══════════════════════════════════════════════════════════════
describe('Middleware — Rate-limit headers', () => {
  it('returns X-RateLimit-Limit on /api routes', async () => {
    const res = await rawFetch('GET', '/api/health');
    const limit = res.headers.get('X-RateLimit-Limit');
    expect(limit).toBeTruthy();
    expect(Number(limit)).toBeGreaterThan(0);
  });

  it('returns X-RateLimit-Remaining on /api routes', async () => {
    const res = await rawFetch('GET', '/api/health');
    const remaining = res.headers.get('X-RateLimit-Remaining');
    expect(remaining).toBeTruthy();
    expect(Number(remaining)).toBeGreaterThanOrEqual(0);
  });

  it('returns X-RateLimit-Reset as a Unix timestamp', async () => {
    const res = await rawFetch('GET', '/api/health');
    const reset = res.headers.get('X-RateLimit-Reset');
    expect(reset).toBeTruthy();
    // Should be a Unix timestamp in seconds, roughly near now
    const ts = Number(reset);
    expect(ts).toBeGreaterThan(Math.floor(Date.now() / 1000) - 10);
  });

  it('decrements X-RateLimit-Remaining across consecutive requests', async () => {
    const res1 = await rawFetch('GET', '/api/health');
    const remaining1 = Number(res1.headers.get('X-RateLimit-Remaining'));
    const res2 = await rawFetch('GET', '/api/health');
    const remaining2 = Number(res2.headers.get('X-RateLimit-Remaining'));
    expect(remaining2).toBeLessThan(remaining1);
  });
});

// ═══════════════════════════════════════════════════════════════
//  Error handler — 413 payload too large
// ═══════════════════════════════════════════════════════════════
describe('Error handler — 413 Payload Too Large', () => {
  it('rejects a body larger than the JSON_BODY_LIMIT (default 1 mb)', async () => {
    // Build a payload slightly over 1 MB
    const bigString = 'x'.repeat(1.1 * 1024 * 1024);
    const res = await rawFetch('POST', '/api/topologies', {
      body: JSON.stringify({ title: bigString }),
    });
    expect(res.status).toBe(413);
    const data = await res.json();
    expect(data.error).toBe('Payload too large');
    expect(data.requestId).toBeTruthy();
  });
});

// ═══════════════════════════════════════════════════════════════
//  Steps with no phases
// ═══════════════════════════════════════════════════════════════
describe('Steps — listing with no phases property', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('returns empty phases array when step has no phases', async () => {
    // Create an act first, then a step without phases
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/nophase`, {
      act: 'a1',
      name: 'No Phases Step',
      goal: 'Testing phaseless',
    });

    const r = await req('GET', `/api/topologies/${id}/steps`);
    expect(r.status).toBe(200);
    const step = r.body.find(s => s.id === 'nophase');
    expect(step).toBeDefined();
    expect(step.name).toBe('No Phases Step');
    expect(step.phases).toEqual([]);
  });

  it('returns mapped phases when step has phases', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/withphase`, {
      act: 'a1',
      name: 'With Phases',
      phases: [{ show: ['R1'], diff: 'added' }],
    });

    const r = await req('GET', `/api/topologies/${id}/steps`);
    expect(r.status).toBe(200);
    const step = r.body.find(s => s.id === 'withphase');
    expect(step).toBeDefined();
    expect(step.phases).toHaveLength(1);
    expect(step.phases[0]).toEqual({ show: ['R1'], diff: 'added' });
  });
});

// ═══════════════════════════════════════════════════════════════
//  Anchor edge-cases (404 paths on valid topology)
// ═══════════════════════════════════════════════════════════════
describe('Anchors — 404 edge cases', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('GET /anchors/:anchorId returns 404 for non-existent anchor', async () => {
    const r = await req('GET', `/api/topologies/${id}/anchors/does-not-exist`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Anchor not found');
  });

  it('DELETE /anchors/:anchorId returns 404 for non-existent anchor', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/anchors/does-not-exist`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Anchor not found');
  });
});

// ═══════════════════════════════════════════════════════════════
//  Error handler — request ID propagation on errors
// ═══════════════════════════════════════════════════════════════
describe('Error handler — requestId propagation', () => {
  it('includes requestId in 413 error response', async () => {
    const customId = 'err-req-id-999';
    const bigString = 'x'.repeat(1.1 * 1024 * 1024);
    const res = await rawFetch('POST', '/api/topologies', {
      headers: { 'X-Request-Id': customId },
      body: JSON.stringify({ title: bigString }),
    });
    expect(res.status).toBe(413);
    const data = await res.json();
    expect(data.requestId).toBe(customId);
  });
});
