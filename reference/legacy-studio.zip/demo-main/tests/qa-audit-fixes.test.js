import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: create a basic topo with nodes, links, acts, and steps.
 */
function buildBasicTopo() {
  const topo = new TopologyDesigner({ title: 'QA Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 250, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 600, y: 250, label: 'Node B' });
  topo.link('link1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show elements',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'All visible' }],
  });
  topo._buildIndex();
  topo.step = 1;
  return topo;
}

// ─── C-1: Standalone export uses mount('topology-container') not '#topology-container' ───
describe('C-1: exportStandaloneHTML mount ID', () => {
  it('should use mount("topology-container") without # prefix in export template', async () => {
    const topo = buildBasicTopo();
    // Read the source code of exportStandaloneHTML to verify the fix
    const src = topo.exportStandaloneHTML.toString();
    expect(src).toContain("topo.mount('topology-container')");
    expect(src).not.toContain("topo.mount('#topology-container')");
  });
});

// ─── C-2: _applyGeneratedTopology uses type: not style: ───
describe('C-2: _applyGeneratedTopology link type property', () => {
  it('should set type property on generated links, not style', () => {
    const topo = new TopologyDesigner({ title: 'AI Test' });
    const result = {
      nodes: [
        { id: 'n1', type: 'router', label: 'R1', x: 100, y: 100 },
        { id: 'n2', type: 'switch', label: 'S1', x: 400, y: 100 },
      ],
      links: [{ from: 'n1', to: 'n2', type: 'tunnel', label: 'test' }],
    };
    // Mount to a container so render() works
    const container = document.createElement('div');
    container.id = 'test-c2';
    document.body.appendChild(container);
    topo.mount('test-c2');
    topo._applyGeneratedTopology(result);
    const link = topo._links.get('n1__n2');
    expect(link).toBeTruthy();
    expect(link.type).toBe('tunnel');
    expect(link.style).toBeUndefined();
    document.body.removeChild(container);
  });
});

// ─── H-5: Playback method chaining ───
describe('H-5: Playback methods return this for chaining', () => {
  let topo;
  beforeEach(() => {
    topo = buildBasicTopo();
    const container = document.createElement('div');
    container.id = 'test-h5';
    document.body.appendChild(container);
    topo.mount('test-h5');
  });

  it('pause() returns this', () => {
    expect(topo.pause()).toBe(topo);
  });

  it('next() returns this', () => {
    topo.step = 0;
    expect(topo.next()).toBe(topo);
  });

  it('prev() returns this', () => {
    expect(topo.prev()).toBe(topo);
  });

  it('reset() returns this', () => {
    expect(topo.reset()).toBe(topo);
  });

  it('goTo() returns this', () => {
    expect(topo.goTo(0)).toBe(topo);
  });

  it('setMode() returns this', () => {
    expect(topo.setMode('select')).toBe(topo);
  });

  it('render() returns this', () => {
    expect(topo.render()).toBe(topo);
  });

  it('play() returns this when reducedMotion is active', () => {
    topo.reducedMotion = true;
    expect(topo.play()).toBe(topo);
  });

  it('supports chaining: pause().reset().next()', () => {
    const result = topo.pause().reset().next();
    expect(result).toBe(topo);
  });
});

// ─── fromJSON non-mutation ───
describe('fromJSON does not mutate input data', () => {
  it('should not mutate acts array entries', () => {
    const topo = new TopologyDesigner({ title: 'Mutation Test' });
    const data = topo.toJSON();
    // Add an act to serialize
    const topo2 = new TopologyDesigner({ title: 'With Acts' });
    topo2.node('A', { type: 'router', x: 100, y: 100, label: 'A' });
    topo2.act('a1', { label: 'Act 1' });
    topo2.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'test',
      phases: [{ show: ['A'], diff: 'show A' }],
    });
    const json = topo2.toJSON();
    const originalAct = json.acts[0];
    const originalActCopy = { ...originalAct };
    const originalStep = json.steps[0];
    const originalStepCopy = { ...originalStep };

    const topo3 = new TopologyDesigner({ title: 'Load' });
    topo3.fromJSON(json);

    // Original data should not have been mutated with extra properties
    // (act() adds 'steps' array, addStep() adds 'id')
    expect(originalAct.label).toBe(originalActCopy.label);
    expect(originalStep.name).toBe(originalStepCopy.name);
    // The original objects should not have gained a 'steps' property
    expect(originalAct).not.toHaveProperty('steps');
  });
});

// ─── M-1: removeNode / removeLink ───
describe('M-1: removeNode and removeLink', () => {
  it('removeNode removes node and dependent links', () => {
    const topo = buildBasicTopo();
    expect(topo._nodes.has('A')).toBe(true);
    expect(topo._links.has('link1')).toBe(true);
    const result = topo.removeNode('A');
    expect(result).toBe(topo); // chaining
    expect(topo._nodes.has('A')).toBe(false);
    expect(topo._links.has('link1')).toBe(false); // dependent link removed
  });

  it('removeLink removes only the link', () => {
    const topo = buildBasicTopo();
    const result = topo.removeLink('link1');
    expect(result).toBe(topo); // chaining
    expect(topo._links.has('link1')).toBe(false);
    expect(topo._nodes.has('A')).toBe(true); // nodes remain
    expect(topo._nodes.has('B')).toBe(true);
  });

  it('removeNode cleans up step phases', () => {
    const topo = buildBasicTopo();
    topo.removeNode('A');
    const phase = topo._steps[0].phases[0];
    expect(phase.show).not.toContain('A');
  });
});

// ─── M-2: off() method ───
describe('M-2: off() event unregistration', () => {
  it('off() removes a registered callback', () => {
    const topo = new TopologyDesigner({ title: 'Off Test' });
    let callCount = 0;
    const cb = () => { callCount++; };
    topo.on('beforeRender', cb);
    // Verify it was added
    expect(topo._pluginHooks.beforeRender).toContain(cb);
    topo.off('beforeRender', cb);
    expect(topo._pluginHooks.beforeRender).not.toContain(cb);
  });

  it('off() returns this for chaining', () => {
    const topo = new TopologyDesigner({ title: 'Chain Test' });
    const cb = () => {};
    expect(topo.off('beforeRender', cb)).toBe(topo);
  });
});

// ─── M-3: Label truncation ───
describe('M-3: Node label truncation at 24 chars', () => {
  it('truncates labels longer than 24 characters with ellipsis', () => {
    const topo = new TopologyDesigner({ title: 'Label Test' });
    const longLabel = 'This Is A Very Long Node Label Name';
    // Call _renderNodeLabel directly
    const svg = topo._renderNodeLabel(100, 200, longLabel);
    expect(svg).toContain('This Is A Very Long Node…');
    expect(svg).not.toContain(longLabel);
  });

  it('does not truncate labels of 24 chars or fewer', () => {
    const topo = new TopologyDesigner({ title: 'Label Test' });
    const shortLabel = 'Short Label';
    const svg = topo._renderNodeLabel(100, 200, shortLabel);
    expect(svg).toContain('Short Label');
  });
});

// ─── H-2: persistentElements round-trip ───
describe('H-2: persistentElements in toJSON/fromJSON', () => {
  it('serializes and restores persistentElements', () => {
    const topo = new TopologyDesigner({ title: 'PE Test' });
    topo.node('A', { type: 'router', x: 100, y: 100, label: 'A' });
    topo.showDuring(['A'], { from: 's1', until: 's2' });
    const json = topo.toJSON();
    expect(json.persistentElements).toHaveLength(1);
    expect(json.persistentElements[0].ids).toEqual(['A']);

    const topo2 = new TopologyDesigner({ title: 'Restore' });
    topo2.fromJSON(json);
    expect(topo2._persistentElements).toHaveLength(1);
  });
});

// ─── M-4: O(1) show-index ───
describe('M-4: _showIndex for O(1) lookup', () => {
  it('_findShowPhase uses _showIndex', () => {
    const topo = buildBasicTopo();
    expect(topo._showIndex).toBeInstanceOf(Map);
    expect(topo._showIndex.has('A')).toBe(true);
    const result = topo._findShowPhase('A');
    expect(result).toEqual({ stepId: 's1', phaseNum: 0 });
  });
});

// ─── L-3: toJSON strips redundant id ───
describe('L-3: toJSON strips redundant id from nodes/links', () => {
  it('node configs in toJSON should not have id property', () => {
    const topo = buildBasicTopo();
    const json = topo.toJSON();
    const nodeA = json.nodes['A'];
    expect(nodeA).toBeTruthy();
    expect(nodeA).not.toHaveProperty('id');
  });

  it('link configs in toJSON should not have id property', () => {
    const topo = buildBasicTopo();
    const json = topo.toJSON();
    const link = json.links['link1'];
    expect(link).toBeTruthy();
    expect(link).not.toHaveProperty('id');
  });
});

// ─── M-6: play() warns on reduced motion ───
describe('M-6: play() warns when reduced motion is active', () => {
  it('should log a warning and return this', () => {
    const topo = buildBasicTopo();
    topo.reducedMotion = true;
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.play();
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalledWith('Playback disabled: prefers-reduced-motion is active');
    warnSpy.mockRestore();
  });
});
