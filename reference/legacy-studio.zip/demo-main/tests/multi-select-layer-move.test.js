import { describe, it, expect, beforeEach, vi } from 'vitest';

/**
 * Tests for Issue #126: Editor — multi-select and move elements between layers.
 *
 * The editor is a monolithic HTML file so we extract and test the core logic
 * (moveSelectionToLayer, selectByType, selectByColor, selectLinksByColor,
 * selectLinksByType) by recreating the minimal state contract they rely on.
 */

// --- Minimal editor state mock ------------------------------------------

let state;
let undoStack;
let toastMessages;

function pushUndo() {
  undoStack.push(JSON.parse(JSON.stringify({
    nodes: [...state.nodes.entries()],
    links: [...state.links.entries()],
  })));
}

function showToast(msg) {
  toastMessages.push(msg);
}

function renderCanvas() {}
function renderLayerPanel() {}
function renderProps() {}

// --- Extracted functions from editor.html --------------------------------

function moveSelectionToLayer(layerId, fallbackId, fallbackType) {
  pushUndo();
  const idsToMove = state.selectedIds.size > 0 ? [...state.selectedIds] : [fallbackId];
  let moved = 0;
  idsToMove.forEach(eid => {
    const n = state.nodes.get(eid);
    if (n) { n.layer = layerId; moved++; return; }
    const l = state.links.get(eid);
    if (l) { l.layer = layerId; moved++; }
  });
  if (moved === 0 && fallbackId) {
    if (fallbackType === 'node') { const n = state.nodes.get(fallbackId); if (n) { n.layer = layerId; moved++; } }
    else if (fallbackType === 'link') { const l = state.links.get(fallbackId); if (l) { l.layer = layerId; moved++; } }
  }
  const layerName = (state.layers.find(l => l.id === layerId) || {}).name || layerId;
  showToast(`Moved ${moved} item${moved !== 1 ? 's' : ''} to "${layerName}"`);
  renderCanvas();
  renderLayerPanel();
  renderProps();
}

function selectByType(type) {
  state.selectedIds.clear();
  state.nodes.forEach((n, id) => {
    if (n.type === type) state.selectedIds.add(id);
  });
}

function selectByColor(color) {
  state.selectedIds.clear();
  state.nodes.forEach((n, id) => {
    if ((n.color || '#01a982') === color) state.selectedIds.add(id);
  });
}

function selectLinksByColor(color) {
  state.selectedIds.clear();
  state.links.forEach((l, id) => {
    if ((l.color || '#01a982') === color) state.selectedIds.add(id);
  });
}

function selectLinksByType(type) {
  state.selectedIds.clear();
  state.links.forEach((l, id) => {
    if (l.type === type) state.selectedIds.add(id);
  });
}

// --- Test setup ----------------------------------------------------------

function makeState() {
  return {
    nodes: new Map([
      ['R1', { type: 'router', x: 0, y: 0, color: '#01a982', layer: 'physical' }],
      ['R2', { type: 'router', x: 100, y: 0, color: '#01a982', layer: 'physical' }],
      ['SW1', { type: 'switch', x: 200, y: 0, color: '#ff8300', layer: 'physical' }],
      ['FW1', { type: 'firewall', x: 300, y: 0, color: '#ff0000', layer: 'physical' }],
    ]),
    links: new Map([
      ['l1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982', layer: 'physical' }],
      ['l2', { type: 'tunnel', from: 'R2', to: 'FW1', color: '#65aef9', layer: 'physical' }],
      ['l3', { type: 'line', from: 'SW1', to: 'FW1', color: '#01a982', layer: 'physical' }],
    ]),
    selectedIds: new Set(),
    layers: [
      { id: 'physical', name: 'Physical', color: '#01a982', visible: true, opacity: 1 },
      { id: 'overlay', name: 'Overlay', color: '#65aef9', visible: true, opacity: 1 },
      { id: 'mgmt', name: 'Management', color: '#ff8300', visible: true, opacity: 1 },
    ],
  };
}

beforeEach(() => {
  state = makeState();
  undoStack = [];
  toastMessages = [];
});

// --- Tests ---------------------------------------------------------------

describe('moveSelectionToLayer', () => {
  it('moves a single node via fallback when nothing selected', () => {
    moveSelectionToLayer('overlay', 'R1', 'node');
    expect(state.nodes.get('R1').layer).toBe('overlay');
    expect(state.nodes.get('R2').layer).toBe('physical'); // untouched
    expect(toastMessages[0]).toContain('1 item');
    expect(toastMessages[0]).toContain('Overlay');
  });

  it('moves a single link via fallback', () => {
    moveSelectionToLayer('mgmt', 'l1', 'link');
    expect(state.links.get('l1').layer).toBe('mgmt');
    expect(state.links.get('l2').layer).toBe('physical');
    expect(toastMessages[0]).toContain('1 item');
  });

  it('moves all multi-selected nodes to target layer', () => {
    state.selectedIds.add('R1');
    state.selectedIds.add('R2');
    state.selectedIds.add('SW1');
    moveSelectionToLayer('overlay', 'R1', 'node');
    expect(state.nodes.get('R1').layer).toBe('overlay');
    expect(state.nodes.get('R2').layer).toBe('overlay');
    expect(state.nodes.get('SW1').layer).toBe('overlay');
    expect(state.nodes.get('FW1').layer).toBe('physical'); // not selected
    expect(toastMessages[0]).toContain('3 items');
  });

  it('moves mixed selection (nodes + links) to target layer', () => {
    state.selectedIds.add('R1');
    state.selectedIds.add('l1');
    moveSelectionToLayer('mgmt', 'R1', 'node');
    expect(state.nodes.get('R1').layer).toBe('mgmt');
    expect(state.links.get('l1').layer).toBe('mgmt');
    expect(toastMessages[0]).toContain('2 items');
  });

  it('pushes undo before modifying', () => {
    moveSelectionToLayer('overlay', 'R1', 'node');
    expect(undoStack.length).toBe(1);
    // Undo snapshot should have original layer
    const snap = undoStack[0];
    const r1 = snap.nodes.find(([id]) => id === 'R1');
    expect(r1[1].layer).toBe('physical');
  });

  it('shows toast with layer name', () => {
    moveSelectionToLayer('mgmt', 'R1', 'node');
    expect(toastMessages[0]).toContain('Management');
  });

  it('falls back to layerId if layer not found', () => {
    moveSelectionToLayer('nonexistent', 'R1', 'node');
    expect(state.nodes.get('R1').layer).toBe('nonexistent');
    expect(toastMessages[0]).toContain('nonexistent');
  });
});

describe('selectByType', () => {
  it('selects all nodes of a given type', () => {
    selectByType('router');
    expect(state.selectedIds.size).toBe(2);
    expect(state.selectedIds.has('R1')).toBe(true);
    expect(state.selectedIds.has('R2')).toBe(true);
  });

  it('does not select nodes of other types', () => {
    selectByType('router');
    expect(state.selectedIds.has('SW1')).toBe(false);
    expect(state.selectedIds.has('FW1')).toBe(false);
  });

  it('clears previous selection', () => {
    state.selectedIds.add('FW1');
    selectByType('switch');
    expect(state.selectedIds.size).toBe(1);
    expect(state.selectedIds.has('SW1')).toBe(true);
    expect(state.selectedIds.has('FW1')).toBe(false);
  });

  it('returns empty set for nonexistent type', () => {
    selectByType('nonexistent');
    expect(state.selectedIds.size).toBe(0);
  });
});

describe('selectByColor', () => {
  it('selects all nodes matching a color', () => {
    selectByColor('#01a982');
    expect(state.selectedIds.size).toBe(2); // R1, R2
    expect(state.selectedIds.has('R1')).toBe(true);
    expect(state.selectedIds.has('R2')).toBe(true);
  });

  it('uses default color when node has no explicit color', () => {
    state.nodes.set('R3', { type: 'router', x: 0, y: 0, layer: 'physical' }); // no color
    selectByColor('#01a982');
    expect(state.selectedIds.has('R3')).toBe(true);
  });
});

describe('selectLinksByColor', () => {
  it('selects links by color', () => {
    selectLinksByColor('#01a982');
    expect(state.selectedIds.size).toBe(2); // l1, l3
    expect(state.selectedIds.has('l1')).toBe(true);
    expect(state.selectedIds.has('l3')).toBe(true);
  });
});

describe('selectLinksByType', () => {
  it('selects all links of a given type', () => {
    selectLinksByType('line');
    expect(state.selectedIds.size).toBe(2);
    expect(state.selectedIds.has('l1')).toBe(true);
    expect(state.selectedIds.has('l3')).toBe(true);
  });

  it('selects tunnel links', () => {
    selectLinksByType('tunnel');
    expect(state.selectedIds.size).toBe(1);
    expect(state.selectedIds.has('l2')).toBe(true);
  });
});

describe('selectByType + moveSelectionToLayer integration', () => {
  it('selects all routers then moves them to overlay', () => {
    selectByType('router');
    expect(state.selectedIds.size).toBe(2);

    moveSelectionToLayer('overlay', 'R1', 'node');
    expect(state.nodes.get('R1').layer).toBe('overlay');
    expect(state.nodes.get('R2').layer).toBe('overlay');
    expect(state.nodes.get('SW1').layer).toBe('physical');
    expect(state.nodes.get('FW1').layer).toBe('physical');
  });

  it('selects links by color then moves them', () => {
    selectLinksByColor('#01a982');
    moveSelectionToLayer('mgmt', 'l1', 'link');
    expect(state.links.get('l1').layer).toBe('mgmt');
    expect(state.links.get('l3').layer).toBe('mgmt');
    expect(state.links.get('l2').layer).toBe('physical'); // different color
  });
});

describe('context menu "Move to Layer" submenu generation', () => {
  // Simulates what showContextMenu builds for the submenu
  function buildMoveToLayerSubmenu(hit, selectedIds) {
    const items = [];
    if (state.layers && state.layers.length > 0) {
      const selCount = selectedIds.size;
      const moveLabel = selCount > 1 ? `Move ${selCount} items to Layer` : 'Move to Layer';
      items.push({ label: moveLabel, layers: state.layers.map(l => l.name) });
    }
    return items;
  }

  it('shows submenu with all layers for single element', () => {
    const result = buildMoveToLayerSubmenu({ id: 'R1', type: 'node' }, new Set());
    expect(result.length).toBe(1);
    expect(result[0].label).toBe('Move to Layer');
    expect(result[0].layers).toEqual(['Physical', 'Overlay', 'Management']);
  });

  it('shows count in label for multi-selection', () => {
    const sel = new Set(['R1', 'R2', 'SW1']);
    const result = buildMoveToLayerSubmenu({ id: 'R1', type: 'node' }, sel);
    expect(result[0].label).toBe('Move 3 items to Layer');
  });

  it('returns empty when no layers exist', () => {
    state.layers = [];
    const result = buildMoveToLayerSubmenu({ id: 'R1', type: 'node' }, new Set());
    expect(result.length).toBe(0);
  });
});

describe('context menu "Select all [type]" generation', () => {
  function buildSelectAllTypeItems(nodeId) {
    const items = [];
    const nodeData = state.nodes.get(nodeId);
    if (nodeData) {
      const typeCount = [...state.nodes.values()].filter(n => n.type === nodeData.type).length;
      if (typeCount > 1) {
        items.push({ label: `Select all ${nodeData.type}`, count: typeCount });
      }
    }
    return items;
  }

  it('shows "Select all routers" with count when multiple exist', () => {
    const items = buildSelectAllTypeItems('R1');
    expect(items.length).toBe(1);
    expect(items[0].label).toBe('Select all router');
    expect(items[0].count).toBe(2);
  });

  it('does not show when only one of that type exists', () => {
    const items = buildSelectAllTypeItems('FW1');
    expect(items.length).toBe(0); // only 1 firewall
  });
});
