import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock window.matchMedia for jsdom
window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: create a minimal topo with 2 nodes, 1 link of given type, mounted with a step showing them.
 */
function buildTopoWithLink(linkType, linkCfg = {}) {
  const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 250, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 600, y: 250, label: 'Node B' });
  topo.link('link1', { type: linkType, from: 'A', to: 'B', color: '#01a982', ...linkCfg });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show link',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'All visible' }],
  });
  topo._buildIndex();
  topo.step = 1;
  return topo;
}

describe('Link Renderers', () => {
  describe('_renderLine', () => {
    it('renders a line with stroke', () => {
      const topo = buildTopoWithLink('line');
      const svg = topo._renderLine('s1', 0, 100, 250, 600, 250, '#01a982', 1);
      expect(svg).toContain('line');
      expect(svg).toContain('x1="100"');
      expect(svg).toContain('x2="600"');
      expect(svg).toContain('#01a982');
    });

    it('renders dashed line variant', () => {
      const topo = buildTopoWithLink('line', { dashed: true });
      const svg = topo._renderLine('s1', 0, 100, 250, 600, 250, '#01a982', 1, true);
      expect(svg).toContain('stroke-dasharray="6 4"');
      expect(svg).toContain('tds-phase-in');
    });

    it('returns empty string when phase not shown', () => {
      const topo = buildTopoWithLink('line');
      topo.step = 0;
      const svg = topo._renderLine('s1', 0, 100, 250, 600, 250, '#01a982', 1);
      expect(svg).toBe('');
    });

    it('adds dof blur when dimmed', () => {
      const topo = buildTopoWithLink('line');
      const svg = topo._renderLine('s1', 0, 100, 250, 600, 250, '#01a982', 0.35);
      expect(svg).toContain('tds-dof-blur');
    });
  });

  describe('_renderTunnel', () => {
    it('renders tunnel with bloom, tube, filmic layers and draw', () => {
      const topo = buildTopoWithLink('tunnel');
      const svg = topo._renderTunnel('s1', 0, 'M100,250 L600,250', '#65aef9', 'IPsec', 350, 234, 1);
      expect(svg).toContain('stroke-width="24"');
      expect(svg).toContain('stroke-width="12"');
      expect(svg).toContain('stroke-width="2.5"');
      expect(svg).toContain('tds-tunnel-bloom');
      expect(svg).toContain('tds-tunnel-tube');
      expect(svg).toContain('tds-tunnel-filmic');
      expect(svg).toContain('IPsec');
      expect(svg).toContain('<path');
    });

    it('renders tunnel without dots', () => {
      const topo = buildTopoWithLink('tunnel');
      const svg = topo._renderTunnel('s1', 0, 'M100,250 L600,250', '#65aef9', null, null, null, 1, false);
      expect(svg).not.toContain('animateMotion');
    });

    it('renders tunnel without label', () => {
      const topo = buildTopoWithLink('tunnel');
      const svg = topo._renderTunnel('s1', 0, 'M100,250 L600,250', '#65aef9', null, null, null, 1);
      expect(svg).not.toContain('text-anchor');
    });
  });

  describe('_renderWG', () => {
    it('renders wireguard with blue color', () => {
      const topo = buildTopoWithLink('wireguard');
      const svg = topo._renderWG('s1', 0, 100, 250, 600, 250, 'WG Tunnel', 1);
      expect(svg).toContain('#65aef9');
      expect(svg).toContain('WG Tunnel');
      expect(svg).toContain('stroke-dasharray="5 3"');
    });
  });

  describe('_renderFlow', () => {
    it('renders flow path with particles', () => {
      const topo = buildTopoWithLink('flow');
      const path = 'M100,250 C350,100 550,100 600,250';
      const svg = topo._renderFlow('s1', 0, path, '#01a982', 'Overlay', 350, 100, 1);
      expect(svg).toContain(path);
      expect(svg).toContain('Overlay');
      expect(svg).toContain('tds-bloom');
    });

    it('renders flow without dots', () => {
      const topo = buildTopoWithLink('flow');
      const svg = topo._renderFlow('s1', 0, 'M0,0 L100,100', '#01a982', null, null, null, 1, false);
      expect(svg).not.toContain('animateMotion');
    });
  });

  describe('_renderPacket', () => {
    it('renders packet with label and sublabel', () => {
      const topo = buildTopoWithLink('packet');
      const svg = topo._renderPacket('s1', 0, 100, 250, 600, 250, '#deb146', 'RADIUS', '802.1X', 1);
      expect(svg).toContain('RADIUS');
      expect(svg).toContain('802.1X');
      expect(svg).toContain('#deb146');
    });

    it('renders packet without sublabel', () => {
      const topo = buildTopoWithLink('packet');
      const svg = topo._renderPacket('s1', 0, 100, 250, 600, 250, '#deb146', 'RADIUS', null, 1);
      expect(svg).toContain('RADIUS');
    });
  });

  describe('_renderBlocked', () => {
    it('renders blocked indicator with X and reason', () => {
      const topo = buildTopoWithLink('blocked');
      const svg = topo._renderBlocked('s1', 0, 100, 250, 600, 250, 'No tunnel');
      expect(svg).toContain('BLOCKED');
      expect(svg).toContain('No tunnel');
      expect(svg).toContain('#fc6161');
    });

    it('renders without reason text', () => {
      const topo = buildTopoWithLink('blocked');
      const svg = topo._renderBlocked('s1', 0, 100, 250, 600, 250, null);
      expect(svg).toContain('BLOCKED');
    });
  });

  describe('_renderWifi', () => {
    it('renders wifi with signal arcs', () => {
      const topo = buildTopoWithLink('wifi');
      const svg = topo._renderWifi('s1', 0, 100, 250, 600, 250, '#00a4b3', 'Wi-Fi 6', 1);
      expect(svg).toContain('#00a4b3');
    });
  });

  describe('_renderPoE', () => {
    it('renders PoE with lightning bolt', () => {
      const topo = buildTopoWithLink('poe');
      const svg = topo._renderPoE('s1', 0, 100, 250, 600, 250, '#deb146', 'PoE', 1);
      expect(svg).toContain('#deb146');
    });
  });

  describe('_renderOptical', () => {
    it('renders optical with laser icon', () => {
      const topo = buildTopoWithLink('optical');
      const svg = topo._renderOptical('s1', 0, 100, 250, 600, 250, '#fc6161', '10G', 1);
      expect(svg).toContain('#fc6161');
    });
  });

  describe('_renderLinkSVG', () => {
    it.each(['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'])(
      'renders %s link type', (type) => {
        const extra = type === 'blocked' ? { reason: 'Blocked' } : {};
        const topo = buildTopoWithLink(type, extra);
        const linkCfg = topo._links.get('link1');
        const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
        expect(svg.length).toBeGreaterThan(0);
      }
    );

    it('renders endpoint (port) labels', () => {
      const topo = buildTopoWithLink('line', { fromLabel: 'ge0/1', toLabel: 'eth0' });
      const linkCfg = topo._links.get('link1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg).toContain('ge0/1');
      expect(svg).toContain('eth0');
    });

    it('renders custom plugin link type', () => {
      TopologyDesigner.registerLinkType('testLink', {
        render(ctx) {
          return `<line x1="${ctx.x1}" y1="${ctx.y1}" x2="${ctx.x2}" y2="${ctx.y2}" stroke="${ctx.color}" />`;
        },
        defaults: { color: '#ff0000' },
      });
      const topo = buildTopoWithLink('testLink');
      const linkCfg = topo._links.get('link1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg).toContain('line');
    });

    it('falls back to line for unknown type', () => {
      const topo = buildTopoWithLink('unknownType');
      const linkCfg = topo._links.get('link1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg).toContain('line');
    });

    it('renders line with dashStyle preset', () => {
      const topo = buildTopoWithLink('line', { dashStyle: 'dotted' });
      const linkCfg = topo._links.get('link1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg.length).toBeGreaterThan(0);
    });

    it('renders line with animateFlow', () => {
      const topo = buildTopoWithLink('line', { animateFlow: true });
      const linkCfg = topo._links.get('link1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg.length).toBeGreaterThan(0);
    });
  });
});

describe('SVG Defs', () => {
  it('contains glow filters', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-glow');
    expect(defs).toContain('tds-glow-strong');
    expect(defs).toContain('tds-glow-green');
    expect(defs).toContain('tds-glow-blue');
    expect(defs).toContain('tds-glow-purple');
    expect(defs).toContain('tds-glow-red');
    expect(defs).toContain('tds-glow-gold');
    expect(defs).toContain('tds-bloom');
  });

  it('contains focus halo filters', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-focus-halo-green');
    expect(defs).toContain('tds-focus-halo-blue');
    expect(defs).toContain('tds-focus-halo-purple');
    expect(defs).toContain('tds-focus-halo-gold');
  });

  it('contains depth-of-field and depth lift filters', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-dof-blur');
    expect(defs).toContain('tds-depth-lift');
  });

  it('contains gradients', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-labelGlass');
    expect(defs).toContain('tds-ambientGreen');
    expect(defs).toContain('tds-ambientPurple');
    expect(defs).toContain('tds-ambientBlue');
    expect(defs).toContain('tds-vignette');
  });

  it('contains temporal filters', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-temporal-jitter');
    expect(defs).toContain('tds-temporal-down');
    expect(defs).toContain('tds-temporal-breach');
  });

  it('contains ghost filter', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-ghost');
  });

  it('contains blast ring filter', () => {
    const topo = new TopologyDesigner();
    const defs = topo._svgDefs();
    expect(defs).toContain('tds-blast-ring');
  });
});

describe('Smart Link Routing', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ routing: true });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.node('B', { type: 'router', x: 600, y: 250, label: 'B' });
    topo.node('MID', { type: 'switch', x: 350, y: 250, label: 'Mid' });
    topo.link('a-b', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Step', goal: '',
      phases: [{ show: ['A', 'B', 'MID', 'a-b'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
  });

  describe('_getNodeAABB', () => {
    it('returns bounding box for known types', () => {
      const aabb = topo._getNodeAABB({ type: 'router', x: 100, y: 200 });
      expect(aabb).toHaveProperty('x');
      expect(aabb).toHaveProperty('y');
      expect(aabb).toHaveProperty('w');
      expect(aabb).toHaveProperty('h');
      expect(aabb.w).toBe(40); // rx=20, w=40
    });

    it('returns default box for unknown type', () => {
      const aabb = topo._getNodeAABB({ type: 'unknown', x: 100, y: 200 });
      expect(aabb.w).toBe(40); // default rx=20
    });

    it('uses plugin hitBox if available', () => {
      TopologyDesigner.registerNodeType('bigNode', {
        render: (x, y) => `<rect x="${x}" y="${y}" />`,
        hitBox: { rx: 50, ry: 30 },
      });
      const aabb = topo._getNodeAABB({ type: 'bigNode', x: 100, y: 200 });
      expect(aabb.w).toBe(100);
      expect(aabb.h).toBe(60);
    });

    it('uses function hitBox', () => {
      TopologyDesigner.registerNodeType('dynNode', {
        render: (x, y) => `<rect x="${x}" y="${y}" />`,
        hitBox: (cfg) => ({ rx: cfg.size || 20, ry: cfg.size || 20 }),
      });
      const aabb = topo._getNodeAABB({ type: 'dynNode', x: 100, y: 200, size: 30 });
      expect(aabb.w).toBe(60);
    });
  });

  describe('_lineIntersectsAABB', () => {
    it('detects intersection when line crosses box', () => {
      const aabb = { x: 300, y: 230, w: 100, h: 40 };
      expect(topo._lineIntersectsAABB(100, 250, 600, 250, aabb)).toBe(true);
    });

    it('returns false when line misses box', () => {
      const aabb = { x: 300, y: 100, w: 40, h: 40 };
      expect(topo._lineIntersectsAABB(100, 250, 600, 250, aabb)).toBe(false);
    });

    it('handles vertical line', () => {
      const aabb = { x: 90, y: 100, w: 20, h: 20 };
      expect(topo._lineIntersectsAABB(100, 50, 100, 300, aabb)).toBe(true);
    });
  });

  describe('_routeLink', () => {
    it('returns null when no obstructions', () => {
      topo._nodes.get('MID').y = 500; // move out of way
      const path = topo._routeLink({ x: 100, y: 250 }, { x: 600, y: 250 }, 'a-b');
      expect(path).toBeNull();
    });

    it('returns a detour path when obstructed', () => {
      const path = topo._routeLink({ x: 100, y: 250 }, { x: 600, y: 250 }, 'a-b');
      expect(path).toBeTruthy();
      expect(path).toContain('Q'); // Quadratic bezier
    });

    it('caches the result', () => {
      topo._routeLink({ x: 100, y: 250 }, { x: 600, y: 250 }, 'a-b');
      expect(topo._routeCache.has('a-b')).toBe(true);
    });

    it('returns null when routing disabled', () => {
      topo._routingEnabled = false;
      const path = topo._routeLink({ x: 100, y: 250 }, { x: 600, y: 250 }, 'a-b');
      expect(path).toBeNull();
    });
  });

  describe('_clearRouteCache', () => {
    it('clears the route cache', () => {
      topo._routeCache.set('test', { key: 'k', path: 'M0,0' });
      topo._clearRouteCache();
      expect(topo._routeCache.size).toBe(0);
    });
  });
});

describe('Plugin System', () => {
  describe('registerNodeType', () => {
    it('registers a plain render function', () => {
      TopologyDesigner.registerNodeType('testPlain', (x, y) => `<circle cx="${x}" cy="${y}" r="10"/>`);
      expect(TopologyDesigner.getRegisteredNodeTypes()).toContain('testPlain');
    });

    it('registers a full plugin object', () => {
      TopologyDesigner.registerNodeType('testFull', {
        render: (x, y, cfg) => `<rect x="${x}" y="${y}" fill="${cfg.color}"/>`,
        defaults: { color: '#ff0000' },
        hitBox: { rx: 25, ry: 25 },
        validate: (cfg) => cfg.color ? true : 'Color required',
        meta: { label: 'Test', category: 'test' },
      });
      expect(TopologyDesigner.getRegisteredNodeTypes()).toContain('testFull');
      // Verify plugin defaults are merged
      const svg = TopologyDesigner.NODE_TYPES['testFull'](100, 200, {});
      expect(svg).toContain('#ff0000');
    });

    it('calls validate on render', () => {
      const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
      TopologyDesigner.registerNodeType('testVal', {
        render: (x, y, cfg) => '',
        validate: () => 'Error message',
      });
      TopologyDesigner.NODE_TYPES['testVal'](0, 0, {});
      expect(warnSpy).toHaveBeenCalled();
      warnSpy.mockRestore();
    });

    it('logs error for invalid plugin', () => {
      const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      TopologyDesigner.registerNodeType('badPlugin', { notRender: true });
      expect(errSpy).toHaveBeenCalled();
      errSpy.mockRestore();
    });
  });

  describe('registerLinkType', () => {
    it('registers a link plugin', () => {
      TopologyDesigner.registerLinkType('testLinkType', {
        render: (ctx) => `<line x1="${ctx.x1}" y1="${ctx.y1}" x2="${ctx.x2}" y2="${ctx.y2}"/>`,
        defaults: { color: '#00ff00' },
      });
      expect(TopologyDesigner.getRegisteredLinkTypes()).toContain('testLinkType');
    });

    it('registers a plain function', () => {
      TopologyDesigner.registerLinkType('plainLink', (ctx) => '');
      expect(TopologyDesigner.getRegisteredLinkTypes()).toContain('plainLink');
    });

    it('logs error for invalid plugin', () => {
      const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      TopologyDesigner.registerLinkType('badLink', { notRender: true });
      expect(errSpy).toHaveBeenCalled();
      errSpy.mockRestore();
    });
  });

  describe('on() lifecycle hooks', () => {
    it('registers beforeRender hook', () => {
      const topo = new TopologyDesigner();
      const cb = vi.fn();
      topo.on('beforeRender', cb);
      expect(topo._pluginHooks.beforeRender).toContain(cb);
    });

    it('registers afterRender hook', () => {
      const topo = new TopologyDesigner();
      const cb = vi.fn();
      topo.on('afterRender', cb);
      expect(topo._pluginHooks.afterRender).toContain(cb);
    });

    it('registers onStepChange hook', () => {
      const topo = new TopologyDesigner();
      const cb = vi.fn();
      topo.on('onStepChange', cb);
      expect(topo._pluginHooks.onStepChange).toContain(cb);
    });

    it('ignores unknown event names', () => {
      const topo = new TopologyDesigner();
      const result = topo.on('unknownEvent', () => {});
      expect(result).toBe(topo); // still returns this
    });

    it('returns this for chaining', () => {
      const topo = new TopologyDesigner();
      const result = topo.on('beforeRender', () => {});
      expect(result).toBe(topo);
    });
  });

  describe('getRegisteredNodeTypes', () => {
    it('returns array of built-in types', () => {
      const types = TopologyDesigner.getRegisteredNodeTypes();
      expect(types).toContain('ec');
      expect(types).toContain('switch');
      expect(types).toContain('cloud');
      expect(types).toContain('router');
      expect(types).toContain('firewall');
    });
  });

  describe('getRegisteredLinkTypes', () => {
    it('returns array of built-in types', () => {
      const types = TopologyDesigner.getRegisteredLinkTypes();
      expect(types).toContain('line');
      expect(types).toContain('tunnel');
      expect(types).toContain('wireguard');
      expect(types).toContain('flow');
      expect(types).toContain('packet');
      expect(types).toContain('blocked');
      expect(types).toContain('wifi');
      expect(types).toContain('poe');
      expect(types).toContain('optical');
    });
  });
});

describe('_renderNodeSVG', () => {
  it('renders known node type', () => {
    const topo = new TopologyDesigner();
    const svg = topo._renderNodeSVG({ type: 'router', x: 100, y: 200, label: 'R1' });
    expect(svg).toContain('circle');
  });

  it('uses custom render function', () => {
    const topo = new TopologyDesigner();
    const svg = topo._renderNodeSVG({
      type: 'custom',
      x: 100, y: 200,
      render: (x, y) => `<rect x="${x}" y="${y}" width="40" height="40"/>`,
    });
    expect(svg).toContain('rect');
  });

  it('warns and returns empty for unknown type without render', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const topo = new TopologyDesigner();
    const svg = topo._renderNodeSVG({ type: 'nonexistent', x: 0, y: 0 });
    expect(svg).toBe('');
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
  });
});

describe('Playback Control', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ mode: 'manual' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B' });
    topo.act('a1', { label: 'Act 1' });
    topo.act('a2', { label: 'Act 2' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: '', phases: [{ show: ['B'], diff: '' }] });
    topo.addStep('s3', { act: 'a2', name: 'S3', goal: '', phases: [{ show: ['ab'], diff: '' }] });
    topo._buildIndex();
  });

  describe('next/prev/goTo/reset', () => {
    it('next advances step', () => {
      topo.step = 0;
      topo.next();
      expect(topo.step).toBe(1);
    });

    it('prev goes back', () => {
      topo.step = 2;
      topo.prev();
      expect(topo.step).toBe(1);
    });

    it('prev does not go below 0', () => {
      topo.step = 0;
      topo.prev();
      expect(topo.step).toBe(0);
    });

    it('next does not exceed max step', () => {
      topo.step = topo._steps.length;
      topo.next();
      expect(topo.step).toBe(topo._steps.length);
    });

    it('goTo jumps to specific step', () => {
      topo.goTo(2);
      expect(topo.step).toBe(2);
    });

    it('goTo clamps to valid range', () => {
      topo.goTo(100);
      expect(topo.step).toBeLessThanOrEqual(topo._steps.length);
    });

    it('reset goes to step 0', () => {
      topo.step = 3;
      topo.reset();
      expect(topo.step).toBe(0);
    });
  });

  describe('_isActBound', () => {
    it('detects act boundaries', () => {
      // s3 is first step of a2 (index 2, so step number 3)
      const isBound = topo._isActBound(3);
      expect(typeof isBound).toBe('boolean');
    });
  });

  describe('setNodePositions', () => {
    it('stores position keyframes', () => {
      topo.setNodePositions('A', { 1: { x: 200, y: 300 }, 2: { x: 400, y: 300 } });
      const node = topo._nodes.get('A');
      expect(node._positions).toBeDefined();
      expect(node._positions[1]).toEqual({ x: 200, y: 300 });
    });

    it('returns this for chaining', () => {
      const result = topo.setNodePositions('A', {});
      expect(result).toBe(topo);
    });

    it('handles non-existent node gracefully', () => {
      const result = topo.setNodePositions('nonexistent', {});
      expect(result).toBe(topo);
    });
  });
});

describe('Render Context', () => {
  it('provides all expected helper methods', () => {
    const topo = buildTopoWithLink('line');
    let ctxCapture = null;
    // Add a step with onRender to capture ctx
    topo.addStep('s2', {
      act: 'a1', name: 'S2', goal: '',
      phases: [{ show: [], diff: '' }],
      onRender: (ctx) => { ctxCapture = ctx; return ''; },
    });
    topo._buildIndex();
    topo.step = 2;
    // Call _renderSVG to trigger onRender
    topo._renderSVG();
    expect(ctxCapture).not.toBeNull();
    expect(typeof ctxCapture.pos).toBe('function');
    expect(typeof ctxCapture.vis).toBe('function');
    expect(typeof ctxCapture.ph).toBe('function');
    expect(typeof ctxCapture.pw).toBe('function');
    expect(typeof ctxCapture.dim).toBe('function');
    expect(typeof ctxCapture.dimAll).toBe('function');
    expect(typeof ctxCapture.pathThrough).toBe('function');
    expect(typeof ctxCapture.pathBetween).toBe('function');
    expect(typeof ctxCapture.renderLine).toBe('function');
    expect(typeof ctxCapture.renderTunnel).toBe('function');
    expect(typeof ctxCapture.renderWG).toBe('function');
    expect(typeof ctxCapture.renderFlow).toBe('function');
    expect(typeof ctxCapture.renderBlocked).toBe('function');
    expect(typeof ctxCapture.renderCallout).toBe('function');
    expect(typeof ctxCapture.renderPoE).toBe('function');
    expect(typeof ctxCapture.renderOptical).toBe('function');
    expect(typeof ctxCapture.renderNode).toBe('function');
    expect(typeof ctxCapture.step).toBe('number');
    expect(typeof ctxCapture.stepId).toBe('string');
    expect(typeof ctxCapture.reducedMotion).toBe('boolean');
  });
});

describe('Declarative Phase Properties', () => {
  it('renders flow declarative property', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 500, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A', 'B'], diff: '',
        flow: { path: 'M100,200 L500,200', color: '#01a982', label: 'Traffic', labelPos: { x: 300, y: 180 } },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Traffic');
  });

  it('renders label declarative property', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        label: { at: 'A', text: 'My Label', color: '#ff0000' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('My Label');
  });

  it('renders badge declarative property', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        badge: { at: 'A', text: 'Badge', color: '#01a982' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Badge');
  });

  it('renders callout declarative property', () => {
    const topo = new TopologyDesigner();
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: [], diff: '',
        callout: { x: 200, y: 200, w: 180, h: 40, lines: [{ text: 'Hello' }], border: '#ff0000' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Hello');
  });

  it('renders blocked declarative property', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 500, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A', 'B'], diff: '',
        blocked: { from: 'A', to: 'B', reason: 'No access' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('BLOCKED');
  });

  it('renders rerender declarative property', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200, label: 'Before' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [
        { show: ['A'], diff: '' },
        { show: [], diff: '', rerender: { node: 'A', label: 'After', cfg: { color: '#ff0000' } } },
      ],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('After');
  });
});

describe('_renderSVG full pipeline', () => {
  it('produces valid SVG with defs, ambient, nodes, and links', () => {
    const topo = buildTopoWithLink('tunnel', { label: 'Test Tunnel', dots: true });
    const svg = topo._renderSVG();
    expect(svg).toContain('<defs>');
    expect(svg).toContain('tds-glow');
    expect(svg).toContain('Node A');
    expect(svg).toContain('Node B');
    expect(svg).toContain('Test Tunnel');
  });

  it('renders ambient atmosphere', () => {
    const topo = buildTopoWithLink('line');
    const svg = topo._renderSVG();
    expect(svg).toContain('tds-ambientGreen');
  });

  it('handles z-order sorting', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200, zOrder: 10 });
    topo.node('B', { type: 'switch', x: 400, y: 200, zOrder: 1 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A', 'B'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg.length).toBeGreaterThan(0);
  });
});
