/**
 * Coverage-E: Additional coverage for topology-ds.js uncovered lines.
 *
 * Targets:
 *  - removeNode / removeLink shim path (lines 251-255) and cascade cleanup
 *  - zone() edge cases (line 451: empty nodes)
 *  - addWaypoint / removeWaypoint / clearWaypoints / setLinkRouting edge cases (lines 516, 564)
 *  - on() / off() edge cases (lines 910-911, bad event names, duplicate listeners)
 *  - setState / getState edge cases (line 1602, mounted render trigger)
 *  - setTheme / getTheme edge cases (lines 1699-1708, DOM updates)
 *  - setTemporalMode edge cases (line 1272, callback + mounted render)
 *  - setNodePositions edge cases
 *  - toggleIsometric edge cases
 *  - _interpolateStep with actual animation frame callback (line 1215)
 *  - _routeLink with multiple obstructions triggering sort (line 1118)
 *  - removeZone / setZones
 *  - _getZoneNodesRecursive
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ── Helpers ── */

let _cid = 0;

function makeTopo(opts = {}) {
  const topo = new TopologyDesigner({
    title: opts.title || 'CovE Test',
    viewBox: opts.viewBox || '0 0 1050 700',
    ...opts,
  });
  return topo;
}

function makePopulatedTopo() {
  const topo = makeTopo();
  topo.node('A', { type: 'router', x: 100, y: 100, label: 'Router A' });
  topo.node('B', { type: 'switch', x: 400, y: 100, label: 'Switch B' });
  topo.node('C', { type: 'host', x: 700, y: 100, label: 'Host C' });
  topo.link('ab', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.link('bc', { type: 'line', from: 'B', to: 'C', color: '#ff6600' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show A and B',
    focus: [],
    phases: [{ show: ['A', 'B', 'ab'], diff: 'A-B visible' }],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Show C',
    focus: [],
    phases: [{ show: ['C', 'bc'], diff: 'C visible' }],
  });
  topo._buildIndex();
  return topo;
}

function mountTopo(topo) {
  const id = `tds-cove-${++_cid}`;
  const container = document.createElement('div');
  container.id = id;
  document.body.appendChild(container);
  topo.mount(id);
  return container;
}

/* ══════════════════════════════════════════
   removeNode — shim path (lines 251-255)
   ══════════════════════════════════════════ */

describe('removeNode shim path (no graph)', () => {
  it('removes node and dependent links via __nodes/__links when _graph is null', () => {
    const topo = makeTopo();
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    topo.node('X', { type: 'router', x: 100, y: 100 });
    topo.node('Y', { type: 'switch', x: 300, y: 100 });
    topo.link('xy', { type: 'line', from: 'X', to: 'Y' });

    expect(topo.__nodes.has('X')).toBe(true);
    expect(topo.__links.has('xy')).toBe(true);

    topo.removeNode('X');
    expect(topo.__nodes.has('X')).toBe(false);
    // Link should also be removed since it references X
    expect(topo.__links.has('xy')).toBe(false);
    // Y should remain
    expect(topo.__nodes.has('Y')).toBe(true);
  });

  it('removes node with multiple dependent links', () => {
    const topo = makeTopo();
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.node('B', { type: 'switch', x: 300, y: 100 });
    topo.node('C', { type: 'host', x: 500, y: 100 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B' });
    topo.link('ac', { type: 'line', from: 'A', to: 'C' });
    topo.link('bc', { type: 'line', from: 'B', to: 'C' });

    topo.removeNode('A');
    expect(topo.__nodes.has('A')).toBe(false);
    expect(topo.__links.has('ab')).toBe(false);
    expect(topo.__links.has('ac')).toBe(false);
    // bc should remain
    expect(topo.__links.has('bc')).toBe(true);
  });
});

/* ══════════════════════════════════════════
   removeNode — step phase cleanup
   ══════════════════════════════════════════ */

describe('removeNode step phase cleanup', () => {
  it('removes node ID from all step phases', () => {
    const topo = makePopulatedTopo();
    // Verify node A is in step 1 phases
    expect(topo._steps[0].phases[0].show).toContain('A');

    topo.removeNode('A');
    // Node A should be removed from step phases
    expect(topo._steps[0].phases[0].show).not.toContain('A');
    // B should still be there
    expect(topo._steps[0].phases[0].show).toContain('B');
  });

  it('handles steps with no phases gracefully', () => {
    const topo = makeTopo();
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: 'test' });
    topo._buildIndex();
    // Should not throw when step has no phases
    expect(() => topo.removeNode('A')).not.toThrow();
  });
});

/* ══════════════════════════════════════════
   removeLink — shim path and step cleanup
   ══════════════════════════════════════════ */

describe('removeLink shim path (no graph)', () => {
  it('removes link via __links when _graph is null', () => {
    const topo = makeTopo();
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.node('B', { type: 'switch', x: 300, y: 100 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B' });

    expect(topo.__links.has('ab')).toBe(true);
    topo.removeLink('ab');
    expect(topo.__links.has('ab')).toBe(false);
    // Nodes should remain
    expect(topo.__nodes.has('A')).toBe(true);
    expect(topo.__nodes.has('B')).toBe(true);
  });
});

describe('removeLink cleans up route cache', () => {
  it('deletes the link from route cache', () => {
    const topo = makePopulatedTopo();
    topo._routeCache.set('ab', { key: 'test', path: 'M0,0' });
    topo.removeLink('ab');
    expect(topo._routeCache.has('ab')).toBe(false);
  });
});

describe('removeLink step phase cleanup', () => {
  it('removes link ID from all step phases', () => {
    const topo = makePopulatedTopo();
    expect(topo._steps[0].phases[0].show).toContain('ab');
    topo.removeLink('ab');
    expect(topo._steps[0].phases[0].show).not.toContain('ab');
  });
});

/* ══════════════════════════════════════════
   zone() edge cases (line 451: empty nodes)
   ══════════════════════════════════════════ */

describe('zone() edge cases', () => {
  it('creates zone with defaults when no nodes/color/borderStyle/padding given', () => {
    const topo = makeTopo();
    topo.zone('z1', { label: 'Empty Zone' });
    const zone = topo._zones.get('z1');
    expect(zone.id).toBe('z1');
    expect(zone.nodes).toEqual([]);
    expect(zone.color).toBe('#7d8a92');
    expect(zone.borderStyle).toBe('dashed');
    expect(zone.padding).toBe(40);
  });

  it('preserves custom values when provided', () => {
    const topo = makeTopo();
    topo.zone('z2', { label: 'Custom', nodes: ['A'], color: '#ff0000', borderStyle: 'solid', padding: 20 });
    const zone = topo._zones.get('z2');
    expect(zone.nodes).toEqual(['A']);
    expect(zone.color).toBe('#ff0000');
    expect(zone.borderStyle).toBe('solid');
    expect(zone.padding).toBe(20);
  });

  it('zone() returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.zone('z1', { label: 'Z1' });
    expect(result).toBe(topo);
  });

  it('overwrites existing zone with same ID', () => {
    const topo = makeTopo();
    topo.zone('z1', { label: 'Original', nodes: ['A'] });
    topo.zone('z1', { label: 'Updated', nodes: ['B', 'C'] });
    const zone = topo._zones.get('z1');
    expect(zone.label).toBe('Updated');
    expect(zone.nodes).toEqual(['B', 'C']);
  });
});

/* ══════════════════════════════════════════
   removeZone / setZones
   ══════════════════════════════════════════ */

describe('removeZone', () => {
  it('removes a zone by ID', () => {
    const topo = makeTopo();
    topo.zone('z1', { label: 'Zone 1' });
    expect(topo._zones.has('z1')).toBe(true);
    const result = topo.removeZone('z1');
    expect(topo._zones.has('z1')).toBe(false);
    expect(result).toBe(topo);
  });

  it('is a no-op for non-existent zone', () => {
    const topo = makeTopo();
    expect(() => topo.removeZone('nonexistent')).not.toThrow();
  });
});

describe('setZones', () => {
  it('replaces all zones from entries', () => {
    const topo = makeTopo();
    topo.zone('old', { label: 'Old' });
    topo.setZones([
      ['z1', { label: 'Zone A', nodes: ['A'] }],
      ['z2', { label: 'Zone B', nodes: ['B'] }],
    ]);
    expect(topo._zones.has('old')).toBe(false);
    expect(topo._zones.has('z1')).toBe(true);
    expect(topo._zones.has('z2')).toBe(true);
  });

  it('handles null/undefined entries', () => {
    const topo = makeTopo();
    topo.zone('z1', { label: 'Z1' });
    topo.setZones(null);
    expect(topo._zones.size).toBe(0);
  });
});

/* ══════════════════════════════════════════
   _getZoneNodesRecursive
   ══════════════════════════════════════════ */

describe('_getZoneNodesRecursive', () => {
  it('returns all nodes from a zone and its children recursively', () => {
    const topo = makeTopo();
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.node('B', { type: 'switch', x: 300, y: 100 });
    topo.node('C', { type: 'host', x: 500, y: 100 });
    topo.zone('parent', { label: 'Parent', nodes: ['A'] });
    topo.zone('child', { label: 'Child', nodes: ['B'], parentZone: 'parent' });
    topo.zone('grandchild', { label: 'Grandchild', nodes: ['C'], parentZone: 'child' });

    const nodes = topo._getZoneNodesRecursive('parent');
    expect(nodes).toContain('A');
    expect(nodes).toContain('B');
    expect(nodes).toContain('C');
  });

  it('returns empty array for non-existent zone', () => {
    const topo = makeTopo();
    expect(topo._getZoneNodesRecursive('missing')).toEqual([]);
  });

  it('returns only own nodes for a leaf zone', () => {
    const topo = makeTopo();
    topo.zone('leaf', { label: 'Leaf', nodes: ['X', 'Y'] });
    const nodes = topo._getZoneNodesRecursive('leaf');
    expect(nodes).toEqual(['X', 'Y']);
  });
});

/* ══════════════════════════════════════════
   addWaypoint / removeWaypoint / clearWaypoints — edge cases
   ══════════════════════════════════════════ */

describe('addWaypoint edge cases', () => {
  it('returns this for non-existent link (line 516)', () => {
    const topo = makePopulatedTopo();
    const result = topo.addWaypoint('nonexistent', { x: 100, y: 100 });
    expect(result).toBe(topo);
  });

  it('initializes waypoints array if not present', () => {
    const topo = makePopulatedTopo();
    const link = topo._links.get('ab');
    delete link.waypoints;
    topo.addWaypoint('ab', { x: 200, y: 200 });
    expect(link.waypoints).toEqual([{ x: 200, y: 200 }]);
  });

  it('inserts at specific index within bounds', () => {
    const topo = makePopulatedTopo();
    topo.addWaypoint('ab', { x: 100, y: 100 });
    topo.addWaypoint('ab', { x: 300, y: 300 });
    topo.addWaypoint('ab', { x: 200, y: 200 }, 1);
    const link = topo._links.get('ab');
    expect(link.waypoints[1]).toEqual({ x: 200, y: 200 });
    expect(link.waypoints.length).toBe(3);
  });

  it('appends when index is out of bounds (negative)', () => {
    const topo = makePopulatedTopo();
    topo.addWaypoint('ab', { x: 100, y: 100 });
    topo.addWaypoint('ab', { x: 200, y: 200 }, -1);
    const link = topo._links.get('ab');
    expect(link.waypoints.length).toBe(2);
    expect(link.waypoints[1]).toEqual({ x: 200, y: 200 });
  });

  it('clears route cache for the link', () => {
    const topo = makePopulatedTopo();
    topo._routeCache.set('ab', { key: 'cached', path: 'M0,0' });
    topo.addWaypoint('ab', { x: 150, y: 150 });
    expect(topo._routeCache.has('ab')).toBe(false);
  });
});

describe('removeWaypoint edge cases', () => {
  it('returns this for non-existent link', () => {
    const topo = makePopulatedTopo();
    const result = topo.removeWaypoint('nonexistent', 0);
    expect(result).toBe(topo);
  });

  it('returns this when link has no waypoints', () => {
    const topo = makePopulatedTopo();
    const result = topo.removeWaypoint('ab', 0);
    expect(result).toBe(topo);
  });

  it('does not remove when index is out of bounds', () => {
    const topo = makePopulatedTopo();
    topo.addWaypoint('ab', { x: 100, y: 100 });
    topo.removeWaypoint('ab', 5);
    expect(topo._links.get('ab').waypoints.length).toBe(1);
  });

  it('does not remove when index is negative', () => {
    const topo = makePopulatedTopo();
    topo.addWaypoint('ab', { x: 100, y: 100 });
    topo.removeWaypoint('ab', -1);
    expect(topo._links.get('ab').waypoints.length).toBe(1);
  });
});

describe('clearWaypoints edge cases', () => {
  it('returns this for non-existent link', () => {
    const topo = makePopulatedTopo();
    const result = topo.clearWaypoints('nonexistent');
    expect(result).toBe(topo);
  });

  it('sets waypoints to empty array', () => {
    const topo = makePopulatedTopo();
    topo.addWaypoint('ab', { x: 100, y: 100 });
    topo.addWaypoint('ab', { x: 200, y: 200 });
    topo.clearWaypoints('ab');
    expect(topo._links.get('ab').waypoints).toEqual([]);
  });
});

/* ══════════════════════════════════════════
   setLinkRouting edge cases (line 564)
   ══════════════════════════════════════════ */

describe('setLinkRouting edge cases', () => {
  it('returns this for non-existent link (line 564)', () => {
    const topo = makePopulatedTopo();
    const result = topo.setLinkRouting('nonexistent', 'orthogonal');
    expect(result).toBe(topo);
  });

  it('sets lineStyle and clears route cache', () => {
    const topo = makePopulatedTopo();
    topo._routeCache.set('ab', { key: 'cached', path: 'M0,0' });
    topo.setLinkRouting('ab', 'curved');
    expect(topo._links.get('ab').lineStyle).toBe('curved');
    expect(topo._routeCache.has('ab')).toBe(false);
  });

  it('allows setting to straight', () => {
    const topo = makePopulatedTopo();
    topo.setLinkRouting('ab', 'orthogonal');
    topo.setLinkRouting('ab', 'straight');
    expect(topo._links.get('ab').lineStyle).toBe('straight');
  });
});

/* ══════════════════════════════════════════
   on() / off() edge cases (lines 910-911)
   ══════════════════════════════════════════ */

describe('on() edge cases', () => {
  it('initializes _pluginHooks if not present (lines 910-911)', () => {
    const topo = makeTopo();
    topo._pluginHooks = null;
    const cb = vi.fn();
    topo.on('beforeRender', cb);
    expect(topo._pluginHooks).toBeDefined();
    expect(topo._pluginHooks.beforeRender).toContain(cb);
  });

  it('silently ignores invalid event names', () => {
    const topo = makeTopo();
    const cb = vi.fn();
    const result = topo.on('invalidEvent', cb);
    expect(result).toBe(topo);
    // Should not add to any hook list
    expect(topo._pluginHooks.beforeRender).not.toContain(cb);
    expect(topo._pluginHooks.afterRender).not.toContain(cb);
    expect(topo._pluginHooks.onStepChange).not.toContain(cb);
  });

  it('allows registering multiple callbacks for the same event', () => {
    const topo = makeTopo();
    const cb1 = vi.fn();
    const cb2 = vi.fn();
    topo.on('afterRender', cb1);
    topo.on('afterRender', cb2);
    expect(topo._pluginHooks.afterRender).toContain(cb1);
    expect(topo._pluginHooks.afterRender).toContain(cb2);
    expect(topo._pluginHooks.afterRender.length).toBe(2);
  });

  it('allows duplicate registration of the same callback', () => {
    const topo = makeTopo();
    const cb = vi.fn();
    topo.on('onStepChange', cb);
    topo.on('onStepChange', cb);
    expect(topo._pluginHooks.onStepChange.length).toBe(2);
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.on('beforeRender', () => {});
    expect(result).toBe(topo);
  });
});

describe('off() edge cases', () => {
  it('removes only the first occurrence of a callback', () => {
    const topo = makeTopo();
    const cb = vi.fn();
    topo.on('beforeRender', cb);
    topo.on('beforeRender', cb);
    topo.off('beforeRender', cb);
    // Should remove only one instance
    expect(topo._pluginHooks.beforeRender.length).toBe(1);
  });

  it('does nothing when callback not found', () => {
    const topo = makeTopo();
    const cb1 = vi.fn();
    const cb2 = vi.fn();
    topo.on('beforeRender', cb1);
    topo.off('beforeRender', cb2);
    expect(topo._pluginHooks.beforeRender.length).toBe(1);
  });

  it('does nothing for invalid event name', () => {
    const topo = makeTopo();
    const cb = vi.fn();
    const result = topo.off('invalidEvent', cb);
    expect(result).toBe(topo);
  });

  it('does nothing when _pluginHooks is null', () => {
    const topo = makeTopo();
    topo._pluginHooks = null;
    const result = topo.off('beforeRender', vi.fn());
    expect(result).toBe(topo);
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.off('beforeRender', vi.fn());
    expect(result).toBe(topo);
  });
});

/* ══════════════════════════════════════════
   setState / getState edge cases (line 1602)
   ══════════════════════════════════════════ */

describe('setState / getState edge cases', () => {
  it('stores and retrieves various types', () => {
    const topo = makeTopo();
    topo.setState('num', 42);
    topo.setState('str', 'hello');
    topo.setState('bool', false);
    topo.setState('obj', { a: 1 });
    topo.setState('arr', [1, 2, 3]);
    topo.setState('nil', null);

    expect(topo.getState('num')).toBe(42);
    expect(topo.getState('str')).toBe('hello');
    expect(topo.getState('bool')).toBe(false);
    expect(topo.getState('obj')).toEqual({ a: 1 });
    expect(topo.getState('arr')).toEqual([1, 2, 3]);
    expect(topo.getState('nil')).toBeNull();
  });

  it('overwrites existing state', () => {
    const topo = makeTopo();
    topo.setState('key', 'old');
    topo.setState('key', 'new');
    expect(topo.getState('key')).toBe('new');
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.setState('x', 1);
    expect(result).toBe(topo);
  });

  it('triggers render when mounted (line 1602-1603)', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    const renderSpy = vi.spyOn(topo, 'render').mockImplementation(() => {});
    topo.setState('firewall.status', 'breached');
    expect(renderSpy).toHaveBeenCalled();
    renderSpy.mockRestore();
    container.remove();
  });

  it('does not trigger render when not mounted', () => {
    const topo = makeTopo();
    const renderSpy = vi.spyOn(topo, 'render').mockImplementation(() => {});
    topo.setState('test', 'value');
    expect(renderSpy).not.toHaveBeenCalled();
    renderSpy.mockRestore();
  });

  it('getState returns undefined for non-existent key', () => {
    const topo = makeTopo();
    expect(topo.getState('nonexistent')).toBeUndefined();
  });
});

/* ══════════════════════════════════════════
   setTheme / getTheme edge cases (lines 1699-1708)
   ══════════════════════════════════════════ */

describe('setTheme / getTheme edge cases', () => {
  it('rejects invalid theme values (line 1699)', () => {
    const topo = makeTopo();
    topo.setTheme('light');
    const result = topo.setTheme('neon');
    expect(result).toBe(topo);
    expect(topo.getTheme()).toBe('light');
  });

  it('rejects empty string theme', () => {
    const topo = makeTopo();
    topo.setTheme('');
    expect(topo.getTheme()).toBe('dark');
  });

  it('sets light theme and updates DOM when mounted (lines 1701-1708)', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    topo.setTheme('light');
    expect(topo.getTheme()).toBe('light');
    const root = container.querySelector('.tds-root');
    if (root) {
      expect(root.classList.contains('tds-light')).toBe(true);
    }
    container.remove();
  });

  it('sets dark theme and removes tds-light class', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    topo.setTheme('light');
    topo.setTheme('dark');
    expect(topo.getTheme()).toBe('dark');
    const root = container.querySelector('.tds-root');
    if (root) {
      expect(root.classList.contains('tds-light')).toBe(false);
    }
    container.remove();
  });

  it('updates bg rect fill when mounted (lines 1706-1708)', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    topo.setTheme('light');
    const bg = document.getElementById('tds-bg-rect');
    if (bg) {
      expect(bg.getAttribute('fill')).toBe('#f0f1f3');
    }
    topo.setTheme('dark');
    if (bg) {
      expect(bg.getAttribute('fill')).toBe('#1d1f27');
    }
    container.remove();
  });

  it('stores theme in localStorage', () => {
    const topo = makeTopo();
    const setItemSpy = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {});
    topo.setTheme('light');
    expect(setItemSpy).toHaveBeenCalledWith('tds-theme', 'light');
    setItemSpy.mockRestore();
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.setTheme('dark');
    expect(result).toBe(topo);
  });

  it('getTheme defaults to dark when _theme is undefined', () => {
    const topo = makeTopo();
    topo._theme = undefined;
    expect(topo.getTheme()).toBe('dark');
  });
});

/* ══════════════════════════════════════════
   setTemporalMode edge cases (line 1272)
   ══════════════════════════════════════════ */

describe('setTemporalMode edge cases', () => {
  it('rejects invalid mode', () => {
    const topo = makeTopo();
    const result = topo.setTemporalMode('invalid');
    expect(result).toBe(topo);
    expect(topo.temporalMode).toBe('design');
  });

  it('accepts design mode', () => {
    const topo = makeTopo();
    topo.setTemporalMode('operational');
    topo.setTemporalMode('design');
    expect(topo.temporalMode).toBe('design');
  });

  it('accepts operational mode', () => {
    const topo = makeTopo();
    topo.setTemporalMode('operational');
    expect(topo.temporalMode).toBe('operational');
  });

  it('accepts incident mode', () => {
    const topo = makeTopo();
    topo.setTemporalMode('incident');
    expect(topo.temporalMode).toBe('incident');
  });

  it('calls _onTemporalModeChange callback when set (line 1272)', () => {
    const cb = vi.fn();
    const topo = makeTopo({ onTemporalModeChange: cb });
    topo.setTemporalMode('incident');
    expect(cb).toHaveBeenCalledWith('incident');
  });

  it('does not call callback when mode is invalid', () => {
    const cb = vi.fn();
    const topo = makeTopo({ onTemporalModeChange: cb });
    topo.setTemporalMode('bogus');
    expect(cb).not.toHaveBeenCalled();
  });

  it('triggers render when mounted (line 1273)', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    const renderSpy = vi.spyOn(topo, 'render').mockImplementation(() => {});
    topo.setTemporalMode('operational');
    expect(renderSpy).toHaveBeenCalled();
    renderSpy.mockRestore();
    container.remove();
  });

  it('does not trigger render when not mounted', () => {
    const topo = makeTopo();
    const renderSpy = vi.spyOn(topo, 'render').mockImplementation(() => {});
    topo.setTemporalMode('incident');
    expect(renderSpy).not.toHaveBeenCalled();
    renderSpy.mockRestore();
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.setTemporalMode('operational');
    expect(result).toBe(topo);
  });
});

/* ══════════════════════════════════════════
   setNodePositions edge cases
   ══════════════════════════════════════════ */

describe('setNodePositions edge cases', () => {
  it('sets _positions on an existing node', () => {
    const topo = makePopulatedTopo();
    topo.setNodePositions('A', { 1: { x: 200, y: 300 }, 3: { x: 500, y: 100 } });
    const node = topo._nodes.get('A');
    expect(node._positions).toEqual({ 1: { x: 200, y: 300 }, 3: { x: 500, y: 100 } });
  });

  it('does nothing for non-existent node', () => {
    const topo = makePopulatedTopo();
    const result = topo.setNodePositions('nonexistent', { 1: { x: 100, y: 100 } });
    expect(result).toBe(topo);
  });

  it('overwrites previous positions', () => {
    const topo = makePopulatedTopo();
    topo.setNodePositions('A', { 1: { x: 100, y: 100 } });
    topo.setNodePositions('A', { 2: { x: 200, y: 200 } });
    const node = topo._nodes.get('A');
    expect(node._positions).toEqual({ 2: { x: 200, y: 200 } });
    expect(node._positions[1]).toBeUndefined();
  });

  it('returns this for chaining', () => {
    const topo = makePopulatedTopo();
    const result = topo.setNodePositions('A', {});
    expect(result).toBe(topo);
  });

  it('handles empty positions object', () => {
    const topo = makePopulatedTopo();
    topo.setNodePositions('A', {});
    expect(topo._nodes.get('A')._positions).toEqual({});
  });
});

/* ══════════════════════════════════════════
   toggleIsometric edge cases
   ══════════════════════════════════════════ */

describe('toggleIsometric', () => {
  it('toggles isometric mode on and off', () => {
    const topo = makeTopo();
    expect(topo.isometricMode).toBe(false);
    const result1 = topo.toggleIsometric();
    expect(result1).toBe(true);
    expect(topo.isometricMode).toBe(true);
    const result2 = topo.toggleIsometric();
    expect(result2).toBe(false);
    expect(topo.isometricMode).toBe(false);
  });

  it('sets explicit value', () => {
    const topo = makeTopo();
    topo.toggleIsometric(true);
    expect(topo.isometricMode).toBe(true);
    topo.toggleIsometric(true);
    expect(topo.isometricMode).toBe(true);
    topo.toggleIsometric(false);
    expect(topo.isometricMode).toBe(false);
  });

  it('toggles CSS classes when mounted', () => {
    const topo = makePopulatedTopo();
    const container = mountTopo(topo);
    topo.toggleIsometric(true);
    const canvas = container.querySelector('.tds-canvas');
    if (canvas) {
      expect(canvas.classList.contains('tds-isometric')).toBe(true);
    }
    topo.toggleIsometric(false);
    if (canvas) {
      expect(canvas.classList.contains('tds-isometric')).toBe(false);
    }
    container.remove();
  });
});

/* ══════════════════════════════════════════
   _interpolateStep — animation frame callback (line 1215)
   ══════════════════════════════════════════ */

describe('_interpolateStep animation callback', () => {
  it('animates node positions through the callback (line 1215)', () => {
    const topo = makePopulatedTopo();
    const nodeA = topo._nodes.get('A');
    nodeA._positions = { 2: { x: 500, y: 400 } };

    // Mock requestAnimationFrame to invoke immediately with a timestamp
    const startTime = performance.now();
    let rafCallback = null;
    const rafSpy = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(cb => {
      rafCallback = cb;
      return 1;
    });

    // Mock document.getElementById to return a minimal element for tds-diagram
    const mockDiagram = document.createElement('div');
    mockDiagram.id = 'tds-diagram';
    document.body.appendChild(mockDiagram);

    topo.step = 1;
    const onComplete = vi.fn();
    topo._interpolateStep(1, 2, onComplete);

    expect(rafSpy).toHaveBeenCalled();
    expect(topo._interpolating).toBe(true);

    // Simulate the final frame (t >= 1)
    if (rafCallback) {
      rafCallback(startTime + topo._interpolationDuration + 100);
    }

    expect(topo._interpolating).toBe(false);
    expect(onComplete).toHaveBeenCalled();
    // Node should be at final position
    expect(nodeA.x).toBe(500);
    expect(nodeA.y).toBe(400);

    rafSpy.mockRestore();
    mockDiagram.remove();
  });

  it('skips animation when reducedMotion is true', () => {
    const topo = makePopulatedTopo();
    topo.reducedMotion = true;
    const nodeA = topo._nodes.get('A');
    nodeA._positions = { 2: { x: 500, y: 400 } };

    const onComplete = vi.fn();
    topo._interpolateStep(1, 2, onComplete);
    expect(onComplete).toHaveBeenCalled();
  });

  it('calls onComplete immediately when no nodes are moving', () => {
    const topo = makePopulatedTopo();
    const onComplete = vi.fn();
    topo._interpolateStep(1, 2, onComplete);
    expect(onComplete).toHaveBeenCalled();
  });

  it('handles intermediate animation frame (t < 1)', () => {
    const topo = makePopulatedTopo();
    const nodeA = topo._nodes.get('A');
    nodeA._positions = { 2: { x: 500, y: 400 } };

    const startTime = performance.now();
    let callbacks = [];
    const rafSpy = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(cb => {
      callbacks.push(cb);
      return callbacks.length;
    });

    const mockDiagram = document.createElement('div');
    mockDiagram.id = 'tds-diagram';
    document.body.appendChild(mockDiagram);

    topo.step = 1;
    topo._interpolateStep(1, 2, () => {});

    // Simulate a mid-animation frame (t = 0.5)
    if (callbacks.length > 0) {
      callbacks[0](startTime + topo._interpolationDuration * 0.5);
    }
    // Should still be interpolating
    expect(topo._interpolating).toBe(true);
    // Should have requested another frame
    expect(callbacks.length).toBeGreaterThanOrEqual(2);

    // Now simulate the final frame
    if (callbacks.length >= 2) {
      callbacks[callbacks.length - 1](startTime + topo._interpolationDuration + 100);
    }
    expect(topo._interpolating).toBe(false);

    rafSpy.mockRestore();
    mockDiagram.remove();
  });
});

/* ══════════════════════════════════════════
   _routeLink — multiple obstructions sort (line 1118)
   ══════════════════════════════════════════ */

describe('_routeLink with multiple obstructions triggering sort', () => {
  it('routes around multiple obstructing nodes (lines 1118-1122)', () => {
    const topo = makeTopo();
    // Set up nodes in a line: A ------ C ------ D ------ B
    // C and D are between A and B, forcing obstructions
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.node('B', { type: 'router', x: 900, y: 250, label: 'B' });
    topo.node('C', { type: 'switch', x: 400, y: 250, label: 'C' });
    topo.node('D', { type: 'host', x: 600, y: 250, label: 'D' });
    topo.link('ab', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'All visible', goal: 'Show all',
      focus: [],
      phases: [{ show: ['A', 'B', 'C', 'D', 'ab'], diff: 'All' }],
    });
    topo._buildIndex();
    topo.step = 1;

    const path = topo._routeLink({ x: 100, y: 250 }, { x: 900, y: 250 }, 'ab');
    // With obstructions, _routeLink should return a non-null detour path
    // The exact path depends on the geometry, but it should be a valid SVG path
    if (path) {
      expect(path).toContain('M');
      // Verify it's a real path, not just the straight line
      expect(path.length).toBeGreaterThan(10);
    }
  });
});

/* ══════════════════════════════════════════
   _snapshotPositions
   ══════════════════════════════════════════ */

describe('_snapshotPositions', () => {
  it('captures current node positions for the current step', () => {
    const topo = makePopulatedTopo();
    topo.step = 1;
    topo._snapshotPositions();
    const snapshot = topo._nodePositionSnapshots.get(1);
    expect(snapshot).toBeDefined();
    expect(snapshot.get('A')).toEqual({ x: 100, y: 100 });
    expect(snapshot.get('B')).toEqual({ x: 400, y: 100 });
  });
});

/* ══════════════════════════════════════════
   _clearRouteCache
   ══════════════════════════════════════════ */

describe('_clearRouteCache', () => {
  it('clears all cached routes', () => {
    const topo = makePopulatedTopo();
    topo._routeCache.set('ab', { key: 'k1', path: 'M0,0' });
    topo._routeCache.set('bc', { key: 'k2', path: 'M1,1' });
    topo._clearRouteCache();
    expect(topo._routeCache.size).toBe(0);
  });
});

/* ══════════════════════════════════════════
   removeNode with graph (normal path) — step cleanup
   ══════════════════════════════════════════ */

describe('removeNode normal path step cleanup', () => {
  it('delegates to graph.removeNode and cleans steps', () => {
    const topo = makePopulatedTopo();
    const graphRemoveSpy = vi.spyOn(topo._graph, 'removeNode');
    topo.removeNode('A');
    expect(graphRemoveSpy).toHaveBeenCalledWith('A');
    // Step phases should be cleaned
    expect(topo._steps[0].phases[0].show).not.toContain('A');
    graphRemoveSpy.mockRestore();
  });

  it('returns this for chaining', () => {
    const topo = makePopulatedTopo();
    const result = topo.removeNode('B');
    expect(result).toBe(topo);
  });
});

describe('removeLink normal path step cleanup', () => {
  it('delegates to graph.removeLink and cleans steps', () => {
    const topo = makePopulatedTopo();
    const graphRemoveSpy = vi.spyOn(topo._graph, 'removeLink');
    topo.removeLink('ab');
    expect(graphRemoveSpy).toHaveBeenCalledWith('ab');
    expect(topo._steps[0].phases[0].show).not.toContain('ab');
    graphRemoveSpy.mockRestore();
  });

  it('returns this for chaining', () => {
    const topo = makePopulatedTopo();
    const result = topo.removeLink('ab');
    expect(result).toBe(topo);
  });
});

/* ══════════════════════════════════════════
   _evaluateCondition — conditional step logic
   ══════════════════════════════════════════ */

describe('_evaluateCondition', () => {
  it('evaluates equality condition', () => {
    const topo = makeTopo();
    topo.setState('status', 'active');
    expect(topo._evaluateCondition('status == "active"')).toBe(true);
    expect(topo._evaluateCondition('status == "inactive"')).toBe(false);
  });

  it('evaluates inequality condition', () => {
    const topo = makeTopo();
    topo.setState('mode', 'dark');
    expect(topo._evaluateCondition('mode != "light"')).toBe(true);
    expect(topo._evaluateCondition('mode != "dark"')).toBe(false);
  });

  it('evaluates truthy check', () => {
    const topo = makeTopo();
    topo.setState('enabled', true);
    expect(topo._evaluateCondition('enabled')).toBe(true);
    topo.setState('disabled', false);
    expect(topo._evaluateCondition('disabled')).toBe(false);
  });

  it('returns false for unset variables', () => {
    const topo = makeTopo();
    expect(topo._evaluateCondition('nonexistent')).toBe(false);
  });
});

/* ══════════════════════════════════════════
   Layer visibility helpers
   ══════════════════════════════════════════ */

describe('layer visibility (_getLayerOpacity)', () => {
  it('returns layer opacity when no step overrides', () => {
    const topo = makeTopo();
    // The default physical layer has opacity 1
    const opacity = topo._getLayerOpacity('physical');
    expect(opacity).toBe(1);
  });

  it('returns 1 for unknown layer', () => {
    const topo = makeTopo();
    const opacity = topo._getLayerOpacity('nonexistent');
    expect(opacity).toBe(1);
  });

  it('returns 0 for a hidden layer', () => {
    const topo = makeTopo();
    topo._layers[0].visible = false;
    const opacity = topo._getLayerOpacity('physical');
    expect(opacity).toBe(0);
  });

  it('uses per-step layerVisibility override', () => {
    const topo = makePopulatedTopo();
    topo._steps[0].layerVisibility = { physical: { opacity: 0.5 } };
    topo.step = 1;
    const opacity = topo._getLayerOpacity('physical');
    expect(opacity).toBe(0.5);
  });
});

describe('setStepLayerVisibility (choreography layer show/hide)', () => {
  it('sets per-step layer opacity that _getLayerOpacity resolves', () => {
    const topo = makePopulatedTopo();
    topo.setStepLayerVisibility('s1', 'physical', 0);
    expect(topo._steps[0].layerVisibility).toEqual({ physical: { opacity: 0 } });
    topo.step = 1;
    expect(topo._getLayerOpacity('physical')).toBe(0);
  });

  it('holds the setting forward across later steps until overridden', () => {
    const topo = makePopulatedTopo();
    topo.setStepLayerVisibility('s1', 'physical', 0.2);
    // s2 has no override, so it inherits s1's setting
    topo.step = 2;
    expect(topo._getLayerOpacity('physical')).toBe(0.2);
    // overriding on s2 takes precedence at step 2
    topo.setStepLayerVisibility('s2', 'physical', 1);
    expect(topo._getLayerOpacity('physical')).toBe(1);
  });

  it('clears an override when opacity is null and prunes empty maps', () => {
    const topo = makePopulatedTopo();
    topo.setStepLayerVisibility('s1', 'physical', 0.5);
    topo.setStepLayerVisibility('s1', 'physical', null);
    expect(topo._steps[0].layerVisibility).toBeUndefined();
  });

  it('is a no-op for an unknown step id and returns this for chaining', () => {
    const topo = makePopulatedTopo();
    const ret = topo.setStepLayerVisibility('nope', 'physical', 0);
    expect(ret).toBe(topo);
    expect(topo._steps[0].layerVisibility).toBeUndefined();
  });

  it('round-trips through toJSON/fromJSON', () => {
    const topo = makePopulatedTopo();
    topo.setStepLayerVisibility('s2', 'physical', 0);
    const json = topo.toJSON();
    const restored = new TopologyDesigner();
    restored.fromJSON(json);
    const s2 = restored._steps.find(s => s.id === 's2');
    expect(s2.layerVisibility).toEqual({ physical: { opacity: 0 } });
  });

  it('keeps a flow path hidden on a layer until a later step shows it', () => {
    const topo = makePopulatedTopo();
    topo.layer('flow_1', { name: 'Flow', type: 'flow', visible: true, opacity: 1, color: '#65aef9', order: 1 });
    topo.flowPath('fp1', { waypoints: ['A', 'B'], color: '#65aef9', layer: 'flow_1' });
    topo.setStepLayerVisibility('s1', 'flow_1', 0); // hidden on step 1
    topo.setStepLayerVisibility('s2', 'flow_1', 1); // revealed on step 2
    topo._buildIndex();
    mountTopo(topo);

    topo.step = 1; // s1 — layer hidden
    expect(topo._renderSVG()).not.toContain('data-tds-flowpath="fp1"');

    topo.step = 2; // s2 — layer shown
    expect(topo._renderSVG()).toContain('data-tds-flowpath="fp1"');
  });
});

/* ══════════════════════════════════════════
   flowPath / policyMarker / layer API basics
   ══════════════════════════════════════════ */

describe('flowPath', () => {
  it('adds and retrieves a flow path', () => {
    const topo = makeTopo();
    topo.flowPath('fp1', { waypoints: [{ x: 100, y: 100 }, { x: 200, y: 200 }], color: '#ff0000' });
    expect(topo._flowPaths.has('fp1')).toBe(true);
    expect(topo._flowPaths.get('fp1').color).toBe('#ff0000');
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.flowPath('fp1', { waypoints: [] });
    expect(result).toBe(topo);
  });
});

describe('policyMarker', () => {
  it('adds and retrieves a policy marker', () => {
    const topo = makeTopo();
    topo.policyMarker('pm1', { nodeId: 'A', type: 'deny', color: '#ff0000' });
    expect(topo._policyMarkers.has('pm1')).toBe(true);
    expect(topo._policyMarkers.get('pm1').type).toBe('deny');
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.policyMarker('pm1', { nodeId: 'A', type: 'allow' });
    expect(result).toBe(topo);
  });
});

describe('layer', () => {
  it('adds a layer', () => {
    const topo = makeTopo();
    topo.layer('flow', { name: 'Flow Layer', type: 'flow', visible: true, opacity: 0.8 });
    const flowLayer = topo._layers.find(l => l.id === 'flow');
    expect(flowLayer).toBeDefined();
    expect(flowLayer.name).toBe('Flow Layer');
  });

  it('returns this for chaining', () => {
    const topo = makeTopo();
    const result = topo.layer('test', { name: 'Test' });
    expect(result).toBe(topo);
  });
});

/* ══════════════════════════════════════════
   _buildIndex with populated topology
   ══════════════════════════════════════════ */

describe('_buildIndex populates stepIndex and act metadata', () => {
  it('assigns 1-based indices to steps', () => {
    const topo = makePopulatedTopo();
    expect(topo._stepIndex['s1']).toBe(1);
    expect(topo._stepIndex['s2']).toBe(2);
  });

  it('sets act start and count', () => {
    const topo = makePopulatedTopo();
    const act = topo._acts[0];
    expect(act.start).toBe(0);
    expect(act.count).toBe(2);
  });
});

/* ══════════════════════════════════════════
   Constructor edge cases
   ══════════════════════════════════════════ */

describe('constructor defaults and options', () => {
  it('uses default values when no config given', () => {
    const topo = new TopologyDesigner();
    expect(topo.title).toBe('Network Topology');
    expect(topo.subtitle).toBe('');
    expect(topo.viewBox).toBe('0 0 1050 700');
    expect(topo.mode).toBe('manual');
    expect(topo.speedMs).toBe(4000);
    expect(topo.temporalMode).toBe('design');
    expect(topo.isometricMode).toBe(false);
    expect(topo.ghostingEnabled).toBe(true);
  });

  it('applies custom config values', () => {
    const topo = new TopologyDesigner({
      title: 'Custom',
      subtitle: 'Sub',
      viewBox: '0 0 500 300',
      mode: 'auto',
      speedMs: 2000,
      temporalMode: 'operational',
      isometricMode: true,
    });
    expect(topo.title).toBe('Custom');
    expect(topo.subtitle).toBe('Sub');
    expect(topo.viewBox).toBe('0 0 500 300');
    expect(topo.mode).toBe('auto');
    expect(topo.speedMs).toBe(2000);
    expect(topo.temporalMode).toBe('operational');
    expect(topo.isometricMode).toBe(true);
  });
});

/* ══════════════════════════════════════════
   _findShowPhase helper
   ══════════════════════════════════════════ */

describe('_findShowPhase', () => {
  it('finds the step and phase containing an element', () => {
    const topo = makePopulatedTopo();
    const result = topo._findShowPhase('A');
    expect(result).toBeDefined();
    expect(result.stepId).toBe('s1');
  });

  it('returns null for non-existent element', () => {
    const topo = makePopulatedTopo();
    const result = topo._findShowPhase('nonexistent');
    expect(result).toBeNull();
  });
});

/* ══════════════════════════════════════════
   Chaining tests — multiple operations
   ══════════════════════════════════════════ */

describe('method chaining', () => {
  it('chains node, link, act, addStep, zone, waypoint operations', () => {
    const topo = makeTopo();
    const result = topo
      .node('A', { type: 'router', x: 100, y: 100 })
      .node('B', { type: 'switch', x: 300, y: 100 })
      .link('ab', { type: 'line', from: 'A', to: 'B' })
      .zone('z1', { label: 'Zone 1', nodes: ['A', 'B'] })
      .addWaypoint('ab', { x: 200, y: 50 })
      .setLinkRouting('ab', 'orthogonal')
      .setNodePositions('A', { 1: { x: 200, y: 200 } })
      .setState('test', true)
      .setTemporalMode('operational');
    expect(result).toBe(topo);
  });
});
