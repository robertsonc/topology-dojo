import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Ghosting Engine', () => {
  let topo;

  function buildMultiActTopo() {
    topo = new TopologyDesigner({ title: 'Ghost Test' });
    topo.reducedMotion = true;

    topo.node('A', { type: 'server', x: 100, y: 100, label: 'A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'B' })
        .node('C', { type: 'switch', x: 200, y: 300, label: 'C' })
        .node('D', { type: 'host', x: 400, y: 300, label: 'D' })
        .link('l1', { type: 'line', from: 'A', to: 'B' })
        .link('l2', { type: 'tunnel', from: 'B', to: 'C' })
        .link('l3', { type: 'line', from: 'C', to: 'D' })
        .act('act1', { label: 'Act One', color: '#01a982' })
        .act('act2', { label: 'Act Two', color: '#65aef9' })
        .act('act3', { label: 'Act Three', color: '#ff5722' })
        .addStep('step1', {
          act: 'act1', name: 'Step One', goal: 'Show A and B',
          focus: ['A', 'B'],
          phases: [{ show: ['A', 'B', 'l1'], diff: 'First elements' }],
        })
        .addStep('step2', {
          act: 'act2', name: 'Step Two', goal: 'Show C',
          focus: ['C'],
          phases: [{ show: ['C', 'l2'], diff: 'Second act' }],
        })
        .addStep('step3', {
          act: 'act3', name: 'Step Three', goal: 'Show D',
          focus: ['D'],
          phases: [{ show: ['D', 'l3'], diff: 'Third act' }],
        });
    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildMultiActTopo();
  });

  describe('_getGhostState()', () => {
    it('returns null for elements in the current act', () => {
      topo.step = 1; // act1 is current
      expect(topo._getGhostState('A')).toBeNull();
      expect(topo._getGhostState('B')).toBeNull();
      expect(topo._getGhostState('l1')).toBeNull();
    });

    it('returns opacity for previous act elements', () => {
      topo.step = 2; // act2 is current, act1 elements should be ghosted
      const ghostOpacity = topo._getGhostState('A');
      expect(ghostOpacity).not.toBeNull();
      expect(ghostOpacity).toBeGreaterThan(0);
      expect(ghostOpacity).toBeLessThan(1);
    });

    it('deeper acts get lower opacity', () => {
      topo.step = 3; // act3 is current
      const act1Ghost = topo._getGhostState('A'); // 2 acts back
      const act2Ghost = topo._getGhostState('C'); // 1 act back
      expect(act1Ghost).not.toBeNull();
      expect(act2Ghost).not.toBeNull();
      // Deeper in the past = lower opacity
      expect(act1Ghost).toBeLessThan(act2Ghost);
    });

    it('returns null when ghosting is disabled', () => {
      topo.ghostingEnabled = false;
      topo.step = 2;
      expect(topo._getGhostState('A')).toBeNull();
    });

    it('returns null at step 0', () => {
      topo.step = 0;
      expect(topo._getGhostState('A')).toBeNull();
      expect(topo._getGhostState('B')).toBeNull();
    });

    it('returns null for elements not yet shown', () => {
      topo.step = 1; // Only act1 elements shown
      expect(topo._getGhostState('C')).toBeNull();
      expect(topo._getGhostState('D')).toBeNull();
    });

    it('returns null for unknown elements', () => {
      topo.step = 2;
      expect(topo._getGhostState('nonexistent')).toBeNull();
    });
  });
});
