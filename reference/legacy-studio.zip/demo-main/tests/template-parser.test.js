import { describe, it, expect, vi, afterEach } from 'vitest';

const TemplateParser = require('../design-system/modules/template-parser.js');

describe('TemplateParser', () => {

  describe('fromText — direction parsing', () => {
    it('defaults to TB direction', () => {
      const result = TemplateParser.fromText('A[Node A]');
      expect(result.direction).toBe('TB');
    });

    it('parses topology direction', () => {
      expect(TemplateParser.fromText('topology LR').direction).toBe('LR');
      expect(TemplateParser.fromText('topology BT').direction).toBe('BT');
      expect(TemplateParser.fromText('topology RL').direction).toBe('RL');
      expect(TemplateParser.fromText('topology TB').direction).toBe('TB');
    });

    it('is case-insensitive for direction keyword', () => {
      expect(TemplateParser.fromText('topology lr').direction).toBe('LR');
    });
  });

  describe('fromText — node parsing', () => {
    it('parses a simple node with bracket label', () => {
      const result = TemplateParser.fromText('A[My Node]');
      expect(result.nodes).toHaveLength(1);
      expect(result.nodes[0]).toEqual({ id: 'A', label: 'My Node', type: 'server' });
    });

    it('parses a node with type annotation (:: syntax)', () => {
      // Note: the regex uses (?:::(\w+)) which matches :: (2 colons), not ::: (3)
      const result = TemplateParser.fromText('FW[Firewall]::firewall');
      expect(result.nodes).toHaveLength(1);
      expect(result.nodes[0].type).toBe('firewall');
      expect(result.nodes[0].label).toBe('Firewall');
    });

    it('documents that ::: (3 colons) does NOT match the type regex', () => {
      // The comment/docs say :::type but the regex only handles ::type
      const result = TemplateParser.fromText('FW[Firewall]:::firewall');
      // This is a known parser bug — the line doesn't match any pattern
      expect(result.nodes).toHaveLength(0);
    });

    it('parses a bare node ID (no label)', () => {
      const result = TemplateParser.fromText('NodeA');
      expect(result.nodes).toHaveLength(1);
      expect(result.nodes[0].id).toBe('NodeA');
      expect(result.nodes[0].label).toBe('NodeA');
    });

    it('parses database node via type annotation', () => {
      // Note: the [(label)] syntax is ambiguous — the first \[...\] regex group matches it
      // as a regular bracket label. Use ::database for explicit database type.
      const result = TemplateParser.fromText('DB[MyDB]::database');
      expect(result.nodes).toHaveLength(1);
      expect(result.nodes[0].type).toBe('database');
      expect(result.nodes[0].label).toBe('MyDB');
    });

    it('ignores comment lines', () => {
      const text = `# This is a comment
// Another comment
A[Node A]`;
      const result = TemplateParser.fromText(text);
      expect(result.nodes).toHaveLength(1);
    });

    it('ignores empty lines', () => {
      const text = `A[Node A]

B[Node B]`;
      const result = TemplateParser.fromText(text);
      expect(result.nodes).toHaveLength(2);
    });
  });

  describe('fromText — link parsing', () => {
    it('parses a simple arrow link -->', () => {
      const result = TemplateParser.fromText('A --> B');
      expect(result.links).toHaveLength(1);
      expect(result.links[0].from).toBe('A');
      expect(result.links[0].to).toBe('B');
      expect(result.links[0].type).toBe('line');
    });

    it('parses a tunnel link ==>', () => {
      const result = TemplateParser.fromText('A ==> B');
      expect(result.links).toHaveLength(1);
      expect(result.links[0].type).toBe('tunnel');
      expect(result.links[0].color).toBe('#65aef9');
    });

    it('parses a dashed link -.->', () => {
      const result = TemplateParser.fromText('A -.-> B');
      expect(result.links).toHaveLength(1);
      expect(result.links[0].type).toBe('line');
      expect(result.links[0].dashed).toBe(true);
    });

    it('parses a flow link ~~>', () => {
      const result = TemplateParser.fromText('A ~~> B');
      expect(result.links).toHaveLength(1);
      expect(result.links[0].type).toBe('flow');
    });

    it('parses a link with label', () => {
      const result = TemplateParser.fromText('A -->|HTTPS| B');
      expect(result.links).toHaveLength(1);
      expect(result.links[0].label).toBe('HTTPS');
    });

    it('auto-registers nodes referenced in links', () => {
      const result = TemplateParser.fromText('X --> Y');
      expect(result.nodes).toHaveLength(2);
      expect(result.nodes.find(n => n.id === 'X')).toBeDefined();
      expect(result.nodes.find(n => n.id === 'Y')).toBeDefined();
    });

    it('does not duplicate nodes defined before links', () => {
      const text = `A[Alpha]::router
B[Beta]::switch
A --> B`;
      const result = TemplateParser.fromText(text);
      expect(result.nodes).toHaveLength(2);
      expect(result.nodes.find(n => n.id === 'A').type).toBe('router');
    });

    it('updates label and type when a node is redefined', () => {
      const text = `A --> B
A[Gateway]::firewall`;
      const result = TemplateParser.fromText(text);
      expect(result.nodes).toHaveLength(2);
      const nodeA = result.nodes.find(n => n.id === 'A');
      expect(nodeA.label).toBe('Gateway');
      expect(nodeA.type).toBe('firewall');
    });
  });

  describe('fromText — complex topologies', () => {
    it('parses a multi-node multi-link topology', () => {
      const text = `topology LR
LB[Load Balancer]::ec
APP1[App Server 1]::server
APP2[App Server 2]::server
DB[Database]::database
LB --> APP1
LB --> APP2
APP1 --> DB
APP2 --> DB`;
      const result = TemplateParser.fromText(text);
      expect(result.direction).toBe('LR');
      expect(result.nodes).toHaveLength(4);
      expect(result.links).toHaveLength(4);
    });

    it('handles links with labels in a full topology', () => {
      const text = `A[Frontend]
B[Backend]
C[DB]
A -->|REST| B
B ==>|SQL| C`;
      const result = TemplateParser.fromText(text);
      expect(result.links[0].label).toBe('REST');
      expect(result.links[1].label).toBe('SQL');
      expect(result.links[1].type).toBe('tunnel');
    });
  });

  describe('TEMPLATES', () => {
    it('has expected built-in templates', () => {
      const templateIds = Object.keys(TemplateParser.TEMPLATES);
      expect(templateIds).toContain('hub-spoke');
      expect(templateIds).toContain('3-tier');
      expect(templateIds).toContain('mesh');
      expect(templateIds).toContain('star');
      expect(templateIds).toContain('spine-leaf');
      expect(templateIds).toContain('sdwan');
      expect(templateIds).toContain('firewall-dmz');
    });

    describe('hub-spoke', () => {
      it('generates correct number of nodes and links', () => {
        const result = TemplateParser.TEMPLATES['hub-spoke'].generate({ branches: 3 });
        expect(result.nodes).toHaveLength(4); // 1 hub + 3 spokes
        expect(result.links).toHaveLength(3);
        expect(result.nodes[0].id).toBe('HUB');
      });

      it('defaults to 4 branches', () => {
        const result = TemplateParser.TEMPLATES['hub-spoke'].generate();
        expect(result.nodes).toHaveLength(5);
        expect(result.links).toHaveLength(4);
      });
    });

    describe('3-tier', () => {
      it('generates LB, app servers, and DB', () => {
        const result = TemplateParser.TEMPLATES['3-tier'].generate({ appServers: 3 });
        expect(result.nodes.find(n => n.id === 'LB')).toBeDefined();
        expect(result.nodes.find(n => n.id === 'DB')).toBeDefined();
        expect(result.links).toHaveLength(6); // 3 LB->APP + 3 APP->DB
      });
    });

    describe('mesh', () => {
      it('generates fully connected mesh', () => {
        const result = TemplateParser.TEMPLATES['mesh'].generate({ count: 4 });
        expect(result.nodes).toHaveLength(4);
        // n*(n-1)/2 = 4*3/2 = 6
        expect(result.links).toHaveLength(6);
      });

      it('generates all tunnel links', () => {
        const result = TemplateParser.TEMPLATES['mesh'].generate({ count: 3 });
        result.links.forEach(l => expect(l.type).toBe('tunnel'));
      });
    });

    describe('star', () => {
      it('generates core switch with endpoints', () => {
        const result = TemplateParser.TEMPLATES['star'].generate({ endpoints: 5 });
        expect(result.nodes).toHaveLength(6); // 1 switch + 5 endpoints
        expect(result.links).toHaveLength(5);
        expect(result.nodes[0].type).toBe('switch');
      });
    });

    describe('spine-leaf', () => {
      it('generates full mesh between spines and leaves', () => {
        const result = TemplateParser.TEMPLATES['spine-leaf'].generate({ spines: 2, leaves: 3 });
        expect(result.nodes).toHaveLength(5); // 2 spines + 3 leaves
        expect(result.links).toHaveLength(6); // 2 * 3
      });
    });

    describe('sdwan', () => {
      it('generates complete SD-WAN topology', () => {
        const result = TemplateParser.TEMPLATES['sdwan'].generate();
        expect(result.nodes.length).toBeGreaterThan(5);
        expect(result.links.length).toBeGreaterThan(5);
        expect(result.nodes.find(n => n.id === 'SSE')).toBeDefined();
      });
    });

    describe('firewall-dmz', () => {
      it('generates firewall + DMZ topology', () => {
        const result = TemplateParser.TEMPLATES['firewall-dmz'].generate();
        expect(result.nodes.find(n => n.id === 'FW')).toBeDefined();
        expect(result.nodes.find(n => n.type === 'firewall')).toBeDefined();
        expect(result.nodes.find(n => n.type === 'database')).toBeDefined();
      });
    });
  });

  describe('applyToDesigner', () => {
    function createMockTopo() {
      return {
        _nodes: new Map(),
        _links: new Map(),
        _anchors: new Map(),
        _acts: [],
        _steps: [],
        node: vi.fn(),
        link: vi.fn(),
        act: vi.fn(),
        addStep: vi.fn(),
      };
    }

    afterEach(() => {
      // Clean up any LayoutEngine we may have placed on globalThis
      if (typeof globalThis.LayoutEngine !== 'undefined') {
        delete globalThis.LayoutEngine;
      }
    });

    it('calls topo.node() for each node and topo.link() for each link', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [
          { id: 'A', label: 'Alpha', type: 'router' },
          { id: 'B', label: 'Beta', type: 'switch' },
        ],
        links: [
          { from: 'A', to: 'B', type: 'line' },
        ],
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.node).toHaveBeenCalledTimes(2);
      expect(topo.node).toHaveBeenCalledWith('A', expect.objectContaining({
        id: 'A', label: 'Alpha', type: 'router', x: 0, y: 0,
      }));
      expect(topo.node).toHaveBeenCalledWith('B', expect.objectContaining({
        id: 'B', label: 'Beta', type: 'switch',
      }));

      expect(topo.link).toHaveBeenCalledTimes(1);
      expect(topo.link).toHaveBeenCalledWith('link-1', expect.objectContaining({
        from: 'A', to: 'B', type: 'line',
      }));
    });

    it('uses explicit link.id when provided', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'X', label: 'X', type: 'server' }],
        links: [{ id: 'my-link', from: 'X', to: 'X', type: 'tunnel' }],
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.link).toHaveBeenCalledWith('my-link', expect.objectContaining({
        from: 'X', to: 'X', type: 'tunnel',
      }));
    });

    it('clears topo state when clearFirst option is true', () => {
      const topo = createMockTopo();
      // Pre-populate to confirm clearing
      topo._nodes.set('old', {});
      topo._links.set('old-link', {});
      topo._anchors.set('old-anchor', {});
      topo._acts.push({ id: 'old-act' });
      topo._steps.push({ id: 'old-step' });

      const parsed = { nodes: [], links: [], direction: 'TB' };
      TemplateParser.applyToDesigner(topo, parsed, { clearFirst: true });

      expect(topo._nodes.size).toBe(0);
      expect(topo._links.size).toBe(0);
      expect(topo._anchors.size).toBe(0);
      expect(topo._acts).toHaveLength(0);
      expect(topo._steps).toHaveLength(0);
    });

    it('does not clear topo state when clearFirst is false (default)', () => {
      const topo = createMockTopo();
      topo._nodes.set('existing', {});
      topo._acts.push({ id: 'existing-act' });

      const parsed = { nodes: [], links: [], direction: 'TB' };
      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo._nodes.size).toBe(1);
      expect(topo._acts).toHaveLength(1);
    });

    it('auto-generates choreography when no acts exist and nodes are present', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [
          { id: 'N1', label: 'Node 1', type: 'server' },
          { id: 'N2', label: 'Node 2', type: 'server' },
        ],
        links: [],
        direction: 'LR',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.act).toHaveBeenCalledWith('auto', { label: 'Topology', color: '#01a982' });
      expect(topo.addStep).toHaveBeenCalledWith('overview', expect.objectContaining({
        act: 'auto',
        name: 'Overview',
        goal: 'Complete topology view.',
        focus: [],
      }));

      // Phases should contain only node phase (no links)
      const stepCall = topo.addStep.mock.calls[0][1];
      expect(stepCall.phases).toHaveLength(1);
      expect(stepCall.phases[0]).toEqual({ show: ['N1', 'N2'], diff: 'All nodes appear' });
    });

    it('auto-generates phase 2 for links when links exist', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [
          { id: 'A', label: 'A', type: 'router' },
          { id: 'B', label: 'B', type: 'switch' },
        ],
        links: [
          { from: 'A', to: 'B', type: 'line' },
          { id: 'custom-id', from: 'B', to: 'A', type: 'tunnel' },
        ],
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      const stepCall = topo.addStep.mock.calls[0][1];
      expect(stepCall.phases).toHaveLength(2);
      expect(stepCall.phases[0]).toEqual({ show: ['A', 'B'], diff: 'All nodes appear' });
      // link IDs: first has no id so 'link-1', second has explicit id 'custom-id'
      expect(stepCall.phases[1]).toEqual({ show: ['link-1', 'custom-id'], diff: 'All connections' });
    });

    it('does NOT auto-generate choreography when acts already exist', () => {
      const topo = createMockTopo();
      topo._acts.push({ id: 'existing-act' });

      const parsed = {
        nodes: [{ id: 'N1', label: 'N1', type: 'server' }],
        links: [],
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.act).not.toHaveBeenCalled();
      expect(topo.addStep).not.toHaveBeenCalled();
    });

    it('does NOT auto-generate choreography when nodes array is empty', () => {
      const topo = createMockTopo();
      const parsed = { nodes: [], links: [], direction: 'TB' };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.act).not.toHaveBeenCalled();
      expect(topo.addStep).not.toHaveBeenCalled();
    });

    it('invokes LayoutEngine when it is globally available', () => {
      const mockPositions = { A: { x: 100, y: 200 } };
      const hierarchicalFn = vi.fn().mockReturnValue(mockPositions);

      globalThis.LayoutEngine = {
        hierarchical: hierarchicalFn,
        apply: vi.fn(),
      };

      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'A', label: 'A', type: 'server' }],
        links: [],
        direction: 'LR',
      };

      TemplateParser.applyToDesigner(topo, parsed, { width: 800, height: 600 });

      expect(hierarchicalFn).toHaveBeenCalledWith(
        topo._nodes, topo._links,
        { width: 800, height: 600, direction: 'LR' },
      );
      expect(globalThis.LayoutEngine.apply).toHaveBeenCalledWith(topo, mockPositions, false);
    });

    it('uses specified layout function from LayoutEngine', () => {
      const mockPositions = {};
      const gridFn = vi.fn().mockReturnValue(mockPositions);

      globalThis.LayoutEngine = {
        hierarchical: vi.fn(),
        grid: gridFn,
        apply: vi.fn(),
      };

      const topo = createMockTopo();
      const parsed = { nodes: [{ id: 'A', label: 'A', type: 'server' }], links: [], direction: 'TB' };

      TemplateParser.applyToDesigner(topo, parsed, { layout: 'grid' });

      expect(gridFn).toHaveBeenCalled();
      expect(globalThis.LayoutEngine.hierarchical).not.toHaveBeenCalled();
    });

    it('falls back to hierarchical layout when specified layout does not exist', () => {
      const mockPositions = {};
      const hierarchicalFn = vi.fn().mockReturnValue(mockPositions);

      globalThis.LayoutEngine = {
        hierarchical: hierarchicalFn,
        apply: vi.fn(),
      };

      const topo = createMockTopo();
      const parsed = { nodes: [{ id: 'A', label: 'A', type: 'server' }], links: [], direction: 'TB' };

      TemplateParser.applyToDesigner(topo, parsed, { layout: 'nonexistent' });

      expect(hierarchicalFn).toHaveBeenCalled();
    });

    it('applies default options when none provided', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'Z', label: 'Z', type: 'host' }],
        links: [],
        direction: 'TB',
      };

      // Should not throw and should use defaults (width=1050, height=700, layout=hierarchical, clearFirst=false)
      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.node).toHaveBeenCalledTimes(1);
      expect(topo.act).toHaveBeenCalled(); // auto-choreography triggers
    });

    it('sets default values for node properties', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'D' }], // no label, no type
        links: [],
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.node).toHaveBeenCalledWith('D', expect.objectContaining({
        type: 'server',
        label: 'D',
        x: 0,
        y: 0,
      }));
    });

    it('sets default values for link properties', () => {
      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'A', label: 'A', type: 'server' }],
        links: [{ from: 'A', to: 'A' }], // no type, no label, no color, no dashed
        direction: 'TB',
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(topo.link).toHaveBeenCalledWith('link-1', expect.objectContaining({
        type: 'line',
        label: '',
        color: '#01a982',
        dashed: false,
      }));
    });

    it('uses parsed.direction default when direction is missing', () => {
      const mockPositions = {};
      const hierarchicalFn = vi.fn().mockReturnValue(mockPositions);

      globalThis.LayoutEngine = {
        hierarchical: hierarchicalFn,
        apply: vi.fn(),
      };

      const topo = createMockTopo();
      const parsed = {
        nodes: [{ id: 'A', label: 'A', type: 'server' }],
        links: [],
        // direction is intentionally omitted
      };

      TemplateParser.applyToDesigner(topo, parsed);

      expect(hierarchicalFn).toHaveBeenCalledWith(
        topo._nodes, topo._links,
        expect.objectContaining({ direction: 'TB' }),
      );
    });
  });
});
