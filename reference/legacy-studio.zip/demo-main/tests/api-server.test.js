/**
 * REST API server tests.
 *
 * Covers the Express routes in api/server.js end-to-end by booting the
 * exported `app` on an ephemeral port and driving it with Node's built-in
 * `fetch`. Exercises every documented endpoint to keep the server.js file
 * above the 75% coverage floor and to guarantee the OpenAPI surface stays
 * honest.
 */
import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';

// The server expects `window`/`document` globals on require. jsdom provides
// them in this test environment, but api/server.js also installs its own
// fallback shim — both paths are covered.
const app = require('../api/server.js');

let server;
let base;

async function req(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(`${base}${path}`, opts);
  let data = null;
  if (r.status !== 204) {
    const text = await r.text();
    data = text ? JSON.parse(text) : null;
  }
  return { status: r.status, body: data };
}

beforeAll(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      base = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

afterAll(async () => {
  await new Promise((resolve) => server.close(() => resolve()));
});

// A full topology payload reused across tests.
function sampleTopology() {
  return {
    title: 'Test Topology',
    subtitle: 'API test',
    viewBox: '0 0 1000 600',
    phaseMs: 500,
  };
}

// Convenience: create a topology and return its ID.
async function createTopology(cfg = sampleTopology()) {
  const r = await req('POST', '/api/topologies', cfg);
  expect(r.status).toBe(201);
  expect(r.body.id).toBeDefined();
  return r.body.id;
}

describe('API — Meta & Health', () => {
  it('GET /api/health returns ok', async () => {
    const r = await req('GET', '/api/health');
    expect(r.status).toBe(200);
    expect(r.body.status).toBe('ok');
    expect(typeof r.body.topologyCount).toBe('number');
  });

  it('GET /api/meta/node-types returns node types', async () => {
    const r = await req('GET', '/api/meta/node-types');
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.nodeTypes)).toBe(true);
    expect(r.body.nodeTypes.length).toBeGreaterThan(0);
    expect(r.body.nodeTypes).toContain('ec');
    expect(r.body.nodeTypes).toContain('switch');
  });

  it('GET /api/meta/link-types returns link types', async () => {
    const r = await req('GET', '/api/meta/link-types');
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.linkTypes)).toBe(true);
    expect(r.body.linkTypes).toContain('line');
    expect(r.body.linkTypes).toContain('tunnel');
  });

  it('GET /openapi.json returns valid spec', async () => {
    const r = await req('GET', '/openapi.json');
    expect(r.status).toBe(200);
    expect(r.body.openapi).toBe('3.0.3');
    expect(r.body.paths).toBeDefined();
  });

  it('GET /openapi.json returns the generated spec', async () => {
    const r = await req('GET', '/openapi.json');
    expect(r.status).toBe(200);
    expect(r.body.openapi).toBe('3.0.3');
    expect(r.body.info.title).toContain('Topology');
    expect(Object.keys(r.body.paths).length).toBeGreaterThan(20);
  });
});

describe('API — Topology lifecycle', () => {
  it('POST /api/topologies creates a topology', async () => {
    const r = await req('POST', '/api/topologies', sampleTopology());
    expect(r.status).toBe(201);
    expect(r.body.title).toBe('Test Topology');
    expect(r.body.nodeCount).toBe(0);
    expect(r.body.linkCount).toBe(0);
  });

  it('GET /api/topologies lists all topologies', async () => {
    await createTopology();
    const r = await req('GET', '/api/topologies');
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body)).toBe(true);
    expect(r.body.length).toBeGreaterThan(0);
  });

  it('GET /api/topologies/:id returns full export', async () => {
    const id = await createTopology();
    const r = await req('GET', `/api/topologies/${id}`);
    expect(r.status).toBe(200);
    expect(r.body.id).toBe(id);
    expect(r.body.title).toBe('Test Topology');
  });

  it('GET /api/topologies/:id → 404 when not found', async () => {
    const r = await req('GET', '/api/topologies/missing-id');
    expect(r.status).toBe(404);
    expect(r.body.error).toContain('not found');
  });

  it('PUT /api/topologies/:id replaces state via fromJSON', async () => {
    const id = await createTopology();
    const payload = {
      title: 'Replaced',
      subtitle: 'new',
      viewBox: '0 0 200 200',
      phaseMs: 300,
      nodes: { N1: { type: 'router', x: 10, y: 10 } },
      links: {},
      anchors: {},
      acts: [],
      steps: [],
      glossary: [],
    };
    const r = await req('PUT', `/api/topologies/${id}`, payload);
    expect(r.status).toBe(200);
    expect(r.body.title).toBe('Replaced');
    expect(r.body.nodeCount).toBe(1);
  });

  it('PUT /api/topologies/:id → 404 when missing', async () => {
    const r = await req('PUT', '/api/topologies/nope', { title: 'x' });
    expect(r.status).toBe(404);
  });

  it('DELETE /api/topologies/:id removes it', async () => {
    const id = await createTopology();
    const r = await req('DELETE', `/api/topologies/${id}`);
    expect(r.status).toBe(204);
    const after = await req('GET', `/api/topologies/${id}`);
    expect(after.status).toBe(404);
  });

  it('DELETE /api/topologies/:id → 404 when missing', async () => {
    const r = await req('DELETE', '/api/topologies/missing');
    expect(r.status).toBe(404);
  });

  it('POST /api/topologies/import creates from full JSON', async () => {
    const r = await req('POST', '/api/topologies/import', {
      title: 'Imported',
      subtitle: 'via import',
      viewBox: '0 0 400 400',
      phaseMs: 600,
      nodes: { R1: { type: 'router', x: 100, y: 100 } },
      links: {},
      anchors: {},
      acts: [{ id: 'a1', label: 'Act 1' }],
      steps: [{ id: 's1', act: 'a1', name: 'S', phases: [{ show: ['R1'] }] }],
      glossary: [],
    });
    expect(r.status).toBe(201);
    expect(r.body.title).toBe('Imported');
    expect(r.body.nodeCount).toBe(1);
    expect(r.body.stepCount).toBe(1);
  });
});

describe('API — Nodes CRUD', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /nodes/:id creates a node', async () => {
    const r = await req('PUT', `/api/topologies/${id}/nodes/R1`, {
      type: 'router', x: 100, y: 200, label: 'Core Router',
    });
    expect(r.status).toBe(200);
    expect(r.body.type).toBe('router');
    expect(r.body.label).toBe('Core Router');
  });

  it('GET /nodes lists nodes', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 10, y: 10 });
    await req('PUT', `/api/topologies/${id}/nodes/S1`, { type: 'switch', x: 30, y: 10 });
    const r = await req('GET', `/api/topologies/${id}/nodes`);
    expect(r.status).toBe(200);
    expect(Object.keys(r.body).length).toBe(2);
    expect(r.body.R1.type).toBe('router');
  });

  it('GET /nodes/:id returns a single node', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 10, y: 10 });
    const r = await req('GET', `/api/topologies/${id}/nodes/R1`);
    expect(r.status).toBe(200);
    expect(r.body.type).toBe('router');
  });

  it('GET /nodes/:id → 404 when missing', async () => {
    const r = await req('GET', `/api/topologies/${id}/nodes/unknown`);
    expect(r.status).toBe(404);
  });

  it('DELETE /nodes/:id removes the node', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 10, y: 10 });
    const r = await req('DELETE', `/api/topologies/${id}/nodes/R1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe(true);
    const after = await req('GET', `/api/topologies/${id}/nodes/R1`);
    expect(after.status).toBe(404);
  });

  it('DELETE /nodes/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/nodes/ghost`);
    expect(r.status).toBe(404);
  });

  it('GET /nodes/:id/neighbors returns connected nodes', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    await req('PUT', `/api/topologies/${id}/nodes/B`, { type: 'router', x: 50, y: 0 });
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    const r = await req('GET', `/api/topologies/${id}/nodes/A/neighbors`);
    expect(r.status).toBe(200);
    expect(r.body.nodeId).toBe('A');
    expect(r.body.neighbors).toContain('B');
    expect(r.body.degree).toBe(1);
  });

  it('GET /nodes/:id/blast-radius returns reachability result', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    await req('PUT', `/api/topologies/${id}/nodes/B`, { type: 'host', x: 50, y: 0 });
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    const r = await req('GET', `/api/topologies/${id}/nodes/A/blast-radius`);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.isolated)).toBe(true);
    expect(Array.isArray(r.body.affected)).toBe(true);
  });

  it('PUT /nodes/:id/positions stores keyframes', async () => {
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 10, y: 10 });
    const r = await req('PUT', `/api/topologies/${id}/nodes/R1/positions`, {
      '1': { x: 100, y: 200 },
      '2': { x: 300, y: 400 },
    });
    expect(r.status).toBe(200);
    expect(r.body.nodeId).toBe('R1');
    expect(r.body.keyframes['1'].x).toBe(100);
  });

  it('PUT /nodes/:id/positions → 404 when node missing', async () => {
    const r = await req('PUT', `/api/topologies/${id}/nodes/missing/positions`, {
      '1': { x: 0, y: 0 },
    });
    expect(r.status).toBe(404);
  });
});

describe('API — Links CRUD', () => {
  let id;
  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    await req('PUT', `/api/topologies/${id}/nodes/B`, { type: 'switch', x: 100, y: 0 });
  });

  it('PUT /links/:id creates a link', async () => {
    const r = await req('PUT', `/api/topologies/${id}/links/L1`, {
      type: 'tunnel', from: 'A', to: 'B', color: '#01a982',
    });
    expect(r.status).toBe(200);
    expect(r.body.type).toBe('tunnel');
  });

  it('GET /links lists all links', async () => {
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    const r = await req('GET', `/api/topologies/${id}/links`);
    expect(r.status).toBe(200);
    expect(r.body.L1).toBeDefined();
  });

  it('GET /links/:id returns one link', async () => {
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    const r = await req('GET', `/api/topologies/${id}/links/L1`);
    expect(r.status).toBe(200);
    expect(r.body.type).toBe('line');
  });

  it('GET /links/:id → 404 when missing', async () => {
    const r = await req('GET', `/api/topologies/${id}/links/ghost`);
    expect(r.status).toBe(404);
  });

  it('DELETE /links/:id removes it', async () => {
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    const r = await req('DELETE', `/api/topologies/${id}/links/L1`);
    expect(r.status).toBe(204);
  });

  it('DELETE /links/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/links/missing`);
    expect(r.status).toBe(404);
  });
});

describe('API — Anchors CRUD', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /anchors/:id creates an anchor', async () => {
    const r = await req('PUT', `/api/topologies/${id}/anchors/P1`, { x: 50, y: 75 });
    expect(r.status).toBe(200);
    expect(r.body.x).toBe(50);
    expect(r.body.y).toBe(75);
  });

  it('GET /anchors lists anchors', async () => {
    await req('PUT', `/api/topologies/${id}/anchors/P1`, { x: 1, y: 2 });
    await req('PUT', `/api/topologies/${id}/anchors/P2`, { x: 3, y: 4 });
    const r = await req('GET', `/api/topologies/${id}/anchors`);
    expect(r.status).toBe(200);
    expect(Object.keys(r.body)).toEqual(expect.arrayContaining(['P1', 'P2']));
  });

  it('GET /anchors/:id returns one anchor', async () => {
    await req('PUT', `/api/topologies/${id}/anchors/P1`, { x: 10, y: 20 });
    const r = await req('GET', `/api/topologies/${id}/anchors/P1`);
    expect(r.status).toBe(200);
    expect(r.body.x).toBe(10);
  });

  it('GET /anchors/:id → 404 when missing', async () => {
    const r = await req('GET', `/api/topologies/${id}/anchors/ghost`);
    expect(r.status).toBe(404);
  });

  it('DELETE /anchors/:id removes the anchor', async () => {
    await req('PUT', `/api/topologies/${id}/anchors/P1`, { x: 1, y: 2 });
    const r = await req('DELETE', `/api/topologies/${id}/anchors/P1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe(true);
  });

  it('DELETE /anchors/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/anchors/ghost`);
    expect(r.status).toBe(404);
  });
});

describe('API — Acts & Steps', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /acts/:id creates an act', async () => {
    const r = await req('PUT', `/api/topologies/${id}/acts/a1`, {
      label: 'Act One', color: '#01a982', intro: ['Welcome'],
    });
    expect([200, 201]).toContain(r.status);
    expect(r.body.label).toBe('Act One');
  });

  it('PUT /acts/:id updates existing act', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Original' });
    const r = await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Updated' });
    expect(r.status).toBe(200);
    expect(r.body.label).toBe('Updated');
  });

  it('GET /acts lists all acts', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/acts/a2`, { label: 'Act 2' });
    const r = await req('GET', `/api/topologies/${id}/acts`);
    expect(r.status).toBe(200);
    expect(r.body.length).toBe(2);
  });

  it('DELETE /acts/:id removes act', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    const r = await req('DELETE', `/api/topologies/${id}/acts/a1`);
    expect(r.status).toBe(204);
  });

  it('DELETE /acts/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/acts/missing`);
    expect(r.status).toBe(404);
  });

  it('PUT /steps/:id creates a step', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    const r = await req('PUT', `/api/topologies/${id}/steps/s1`, {
      act: 'a1', name: 'Intro', goal: 'Show it', focus: [],
      phases: [{ show: [], diff: 'empty' }],
    });
    expect([200, 201]).toContain(r.status);
    expect(r.body.name).toBe('Intro');
  });

  it('PUT /steps/:id updates existing step', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/s1`, { act: 'a1', name: 'First' });
    const r = await req('PUT', `/api/topologies/${id}/steps/s1`, { act: 'a1', name: 'Updated' });
    expect(r.status).toBe(200);
    expect(r.body.name).toBe('Updated');
  });

  it('GET /steps lists steps', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/s1`, { act: 'a1', name: 'First' });
    const r = await req('GET', `/api/topologies/${id}/steps`);
    expect(r.status).toBe(200);
    expect(r.body.length).toBe(1);
    expect(r.body[0].id).toBe('s1');
    expect(r.body[0].index).toBe(0);
  });

  it('DELETE /steps/:id removes the step', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/s1`, { act: 'a1', name: 'First' });
    const r = await req('DELETE', `/api/topologies/${id}/steps/s1`);
    expect(r.status).toBe(204);
  });

  it('DELETE /steps/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/steps/missing`);
    expect(r.status).toBe(404);
  });
});

describe('API — Glossary', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /glossary replaces terms', async () => {
    const terms = [
      { t: 'SD-WAN', d: 'Software-Defined WAN' },
      { t: 'ZTNA', d: 'Zero Trust Network Access' },
    ];
    const r = await req('PUT', `/api/topologies/${id}/glossary`, terms);
    expect(r.status).toBe(200);
    expect(r.body.length).toBe(2);
  });

  it('GET /glossary returns terms', async () => {
    await req('PUT', `/api/topologies/${id}/glossary`, [{ t: 'X', d: 'def' }]);
    const r = await req('GET', `/api/topologies/${id}/glossary`);
    expect(r.status).toBe(200);
    expect(r.body[0].t).toBe('X');
  });
});

describe('API — Graph analysis', () => {
  let id;
  beforeEach(async () => {
    id = await createTopology();
    // Build a small graph: A─B─C and an isolated D
    for (const n of ['A', 'B', 'C', 'D']) {
      await req('PUT', `/api/topologies/${id}/nodes/${n}`, { type: 'router', x: 0, y: 0 });
    }
    await req('PUT', `/api/topologies/${id}/links/AB`, { type: 'line', from: 'A', to: 'B' });
    await req('PUT', `/api/topologies/${id}/links/BC`, { type: 'line', from: 'B', to: 'C' });
  });

  it('GET /analysis returns findings', async () => {
    const r = await req('GET', `/api/topologies/${id}/analysis`);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body)).toBe(true);
  });

  it('GET /paths?from&to returns shortest path', async () => {
    const r = await req('GET', `/api/topologies/${id}/paths?from=A&to=C`);
    expect(r.status).toBe(200);
    expect(r.body.path).toEqual(['A', 'B', 'C']);
    expect(r.body.length).toBe(2);
  });

  it('GET /paths → 400 when missing params', async () => {
    const r = await req('GET', `/api/topologies/${id}/paths`);
    expect(r.status).toBe(400);
  });

  it('GET /components returns connected components', async () => {
    const r = await req('GET', `/api/topologies/${id}/components`);
    expect(r.status).toBe(200);
    expect(r.body.count).toBeGreaterThanOrEqual(2); // {A,B,C} + {D}
  });

  it('GET /bridges returns bridge links', async () => {
    const r = await req('GET', `/api/topologies/${id}/bridges`);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.bridges)).toBe(true);
    // Both AB and BC are bridges in the A-B-C chain
    expect(r.body.bridges).toEqual(expect.arrayContaining(['AB', 'BC']));
  });

  it('GET /articulation-points returns cut vertices', async () => {
    const r = await req('GET', `/api/topologies/${id}/articulation-points`);
    expect(r.status).toBe(200);
    // B is the cut vertex in A-B-C
    expect(r.body.articulationPoints).toContain('B');
  });

  it('GET /bfs returns traversal order', async () => {
    const r = await req('GET', `/api/topologies/${id}/bfs?start=A`);
    expect(r.status).toBe(200);
    expect(r.body.start).toBe('A');
    expect(r.body.order[0]).toBe('A');
  });

  it('GET /bfs → 400 when missing start', async () => {
    const r = await req('GET', `/api/topologies/${id}/bfs`);
    expect(r.status).toBe(400);
  });

  it('POST /subgraph extracts subset', async () => {
    const r = await req('POST', `/api/topologies/${id}/subgraph`, { nodeIds: ['A', 'B'] });
    expect(r.status).toBe(200);
    expect(Object.keys(r.body.nodes)).toEqual(expect.arrayContaining(['A', 'B']));
    expect(r.body.links.AB).toBeDefined();
    expect(r.body.links.BC).toBeUndefined();
  });

  it('POST /subgraph → 400 without nodeIds', async () => {
    const r = await req('POST', `/api/topologies/${id}/subgraph`, {});
    expect(r.status).toBe(400);
  });
});

describe('API — Playback state', () => {
  let id;
  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/s1`, {
      act: 'a1', name: 'S1', phases: [{ show: [] }],
    });
    await req('PUT', `/api/topologies/${id}/steps/s2`, {
      act: 'a1', name: 'S2', phases: [{ show: [] }],
    });
  });

  it('GET /playback returns current state', async () => {
    const r = await req('GET', `/api/topologies/${id}/playback`);
    expect(r.status).toBe(200);
    expect(r.body.step).toBe(0);
    expect(r.body.totalSteps).toBe(2);
    expect(r.body.mode).toBe('manual');
  });

  it('PUT /playback updates step/mode/speed', async () => {
    const r = await req('PUT', `/api/topologies/${id}/playback`, {
      step: 1,
      mode: 'auto',
      speedMs: 3000,
    });
    expect(r.status).toBe(200);
    expect(r.body.step).toBe(1);
    expect(r.body.mode).toBe('auto');
    expect(r.body.speedMs).toBe(3000);
  });

  it('PUT /playback clamps step to [0, totalSteps]', async () => {
    const r = await req('PUT', `/api/topologies/${id}/playback`, { step: 99 });
    expect(r.body.step).toBe(2);
    const r2 = await req('PUT', `/api/topologies/${id}/playback`, { step: -5 });
    expect(r2.body.step).toBe(0);
  });
});

describe('API — Export', () => {
  it('GET /export returns full JSON', async () => {
    const id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 0, y: 0 });
    const r = await req('GET', `/api/topologies/${id}/export`);
    expect(r.status).toBe(200);
    expect(r.body.title).toBe('Test Topology');
    expect(r.body.nodes.R1).toBeDefined();
  });
});

describe('API — Layers', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /layers/:id creates a layer', async () => {
    const r = await req('PUT', `/api/topologies/${id}/layers/physical`, {
      name: 'Physical', type: 'physical', visible: true, opacity: 1, order: 0,
    });
    expect(r.status).toBe(200);
    expect(r.body.name).toBe('Physical');
  });

  it('GET /layers lists layers', async () => {
    await req('PUT', `/api/topologies/${id}/layers/flow1`, { name: 'Flow', type: 'flow' });
    const r = await req('GET', `/api/topologies/${id}/layers`);
    expect(r.status).toBe(200);
    expect(r.body.some(l => l.id === 'flow1')).toBe(true);
  });

  it('DELETE /layers/:id removes a layer', async () => {
    await req('PUT', `/api/topologies/${id}/layers/flow1`, { name: 'Flow', type: 'flow' });
    const r = await req('DELETE', `/api/topologies/${id}/layers/flow1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe('flow1');
  });

  it('DELETE /layers/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/layers/ghost`);
    expect(r.status).toBe(404);
  });
});

describe('API — Flow paths', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /flow-paths/:id creates a flow path', async () => {
    const r = await req('PUT', `/api/topologies/${id}/flow-paths/fp1`, {
      waypoints: ['A', 'B'], color: '#01a982', animation: 'particles', speed: 2,
    });
    expect(r.status).toBe(200);
    expect(r.body.animation).toBe('particles');
  });

  it('GET /flow-paths lists flow paths', async () => {
    await req('PUT', `/api/topologies/${id}/flow-paths/fp1`, {
      waypoints: ['A', 'B'], color: '#f00',
    });
    const r = await req('GET', `/api/topologies/${id}/flow-paths`);
    expect(r.status).toBe(200);
    expect(r.body.fp1).toBeDefined();
  });

  it('DELETE /flow-paths/:id removes it', async () => {
    await req('PUT', `/api/topologies/${id}/flow-paths/fp1`, {
      waypoints: ['A', 'B'], color: '#f00',
    });
    const r = await req('DELETE', `/api/topologies/${id}/flow-paths/fp1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe('fp1');
  });

  it('DELETE /flow-paths/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/flow-paths/ghost`);
    expect(r.status).toBe(404);
  });
});

describe('API — Policy markers', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('PUT /policy-markers/:id creates a marker', async () => {
    const r = await req('PUT', `/api/topologies/${id}/policy-markers/pm1`, {
      nodeId: 'FW', type: 'inspect', color: '#deb146',
    });
    expect(r.status).toBe(200);
    expect(r.body.type).toBe('inspect');
  });

  it('GET /policy-markers lists markers', async () => {
    await req('PUT', `/api/topologies/${id}/policy-markers/pm1`, {
      nodeId: 'FW', type: 'deny',
    });
    const r = await req('GET', `/api/topologies/${id}/policy-markers`);
    expect(r.status).toBe(200);
    expect(r.body.pm1).toBeDefined();
  });

  it('DELETE /policy-markers/:id removes it', async () => {
    await req('PUT', `/api/topologies/${id}/policy-markers/pm1`, {
      nodeId: 'FW', type: 'allow',
    });
    const r = await req('DELETE', `/api/topologies/${id}/policy-markers/pm1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe('pm1');
  });

  it('DELETE /policy-markers/:id → 404 when missing', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/policy-markers/ghost`);
    expect(r.status).toBe(404);
  });
});

// ─── 404 coverage for topology-scoped routes with non-existent topology ───
describe('API — Topology-scoped 404s (non-existent topology)', () => {
  const fake = '00000000-0000-0000-0000-000000000000';

  it('GET /nodes → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/nodes`)).status).toBe(404);
  });

  it('PUT /nodes/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/nodes/n1`, { type: 'host', x: 0, y: 0 })).status).toBe(404);
  });

  it('GET /nodes/:id/neighbors → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/nodes/n1/neighbors`)).status).toBe(404);
  });

  it('GET /nodes/:id/blast-radius → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/nodes/n1/blast-radius`)).status).toBe(404);
  });

  it('GET /links → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/links`)).status).toBe(404);
  });

  it('PUT /links/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/links/l1`, { type: 'line', from: 'a', to: 'b' })).status).toBe(404);
  });

  it('GET /anchors → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/anchors`)).status).toBe(404);
  });

  it('PUT /anchors/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/anchors/a1`, { x: 0, y: 0 })).status).toBe(404);
  });

  it('GET /acts → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/acts`)).status).toBe(404);
  });

  it('PUT /acts/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/acts/a1`, { label: 'Test' })).status).toBe(404);
  });

  it('GET /steps → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/steps`)).status).toBe(404);
  });

  it('PUT /steps/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/steps/s1`, { act: 'a1' })).status).toBe(404);
  });

  it('GET /glossary → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/glossary`)).status).toBe(404);
  });

  it('PUT /glossary → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/glossary`, [])).status).toBe(404);
  });

  it('GET /analysis → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/analysis`)).status).toBe(404);
  });

  it('GET /paths → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/paths?from=a&to=b`)).status).toBe(404);
  });

  it('GET /components → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/components`)).status).toBe(404);
  });

  it('GET /bridges → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/bridges`)).status).toBe(404);
  });

  it('GET /articulation-points → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/articulation-points`)).status).toBe(404);
  });

  it('GET /bfs → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/bfs?start=a`)).status).toBe(404);
  });

  it('POST /subgraph → 404', async () => {
    expect((await req('POST', `/api/topologies/${fake}/subgraph`, { nodeIds: ['a'] })).status).toBe(404);
  });

  it('GET /playback → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/playback`)).status).toBe(404);
  });

  it('PUT /playback → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/playback`, { step: 0 })).status).toBe(404);
  });

  it('GET /export → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/export`)).status).toBe(404);
  });

  it('GET /layers → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/layers`)).status).toBe(404);
  });

  it('PUT /layers/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/layers/l1`, { name: 'test' })).status).toBe(404);
  });

  it('GET /flow-paths → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/flow-paths`)).status).toBe(404);
  });

  it('PUT /flow-paths/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/flow-paths/fp1`, { path: 'test' })).status).toBe(404);
  });

  it('GET /policy-markers → 404', async () => {
    expect((await req('GET', `/api/topologies/${fake}/policy-markers`)).status).toBe(404);
  });

  it('PUT /policy-markers/:id → 404', async () => {
    expect((await req('PUT', `/api/topologies/${fake}/policy-markers/pm1`, { action: 'allow' })).status).toBe(404);
  });
});
