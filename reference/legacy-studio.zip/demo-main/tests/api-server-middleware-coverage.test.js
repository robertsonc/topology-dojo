// @vitest-environment node
/**
 * Middleware branch-coverage tests for api/server.js.
 *
 * Covers the three currently-uncovered middleware branches:
 *   1. CORS rejection when CORS_ORIGINS is non-empty and origin is unlisted
 *   2. Rate-limit 429 response when request count exceeds RATE_LIMIT_MAX
 *   3. API key 401 response when API_KEY is set and wrong/missing key supplied
 *
 * Environment variables are set BEFORE requiring the server module so the
 * middleware captures the desired configuration at load time.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';

// ── Configure env vars before the server module loads ──
process.env.CORS_ORIGINS = 'https://allowed.example.com,https://also-allowed.example.com';
process.env.API_RATE_LIMIT_WINDOW_MS = '60000';
process.env.API_RATE_LIMIT_MAX = '20';
process.env.API_KEY = 'test-secret-key-42';

const app = require('../api/server.js');

let server;
let base;

/**
 * Raw fetch helper that returns the full Response so callers can inspect
 * headers and status directly.
 */
async function rawFetch(method, path, opts = {}) {
  const fetchOpts = { method, headers: { ...opts.headers } };
  if (opts.body !== undefined) {
    fetchOpts.body = opts.body;
    if (!fetchOpts.headers['Content-Type']) {
      fetchOpts.headers['Content-Type'] = 'application/json';
    }
  }
  return fetch(`${base}${path}`, fetchOpts);
}

beforeAll(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      base = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

afterAll(async () => {
  delete process.env.CORS_ORIGINS;
  delete process.env.API_RATE_LIMIT_MAX;
  delete process.env.API_RATE_LIMIT_WINDOW_MS;
  delete process.env.API_KEY;
  await new Promise((resolve) => server.close(() => resolve()));
});

// ═══════════════════════════════════════════════════════════════
//  CORS — rejection of unlisted origins
// ═══════════════════════════════════════════════════════════════
describe('CORS — origin rejection', () => {
  it('allows requests from a listed origin', async () => {
    const res = await rawFetch('GET', '/api/health', {
      headers: { Origin: 'https://allowed.example.com' },
    });
    expect(res.status).toBe(200);
    expect(res.headers.get('access-control-allow-origin')).toBe('https://allowed.example.com');
  });

  it('rejects requests from an unlisted origin (no ACAO header)', async () => {
    const res = await rawFetch('GET', '/api/health', {
      headers: { Origin: 'https://evil.example.com' },
    });
    // The cors middleware with callback(null, false) does not set the
    // Access-Control-Allow-Origin header, effectively denying CORS access.
    // The request itself still succeeds at the HTTP level.
    expect(res.status).toBe(200);
    expect(res.headers.get('access-control-allow-origin')).toBeNull();
  });

  it('allows requests with no Origin header (server-to-server)', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.status).toBe(200);
  });

  it('rejects preflight from unlisted origin', async () => {
    const res = await rawFetch('OPTIONS', '/api/health', {
      headers: {
        Origin: 'https://evil.example.com',
        'Access-Control-Request-Method': 'POST',
      },
    });
    expect(res.headers.get('access-control-allow-origin')).toBeNull();
  });

  it('allows preflight from a listed origin', async () => {
    const res = await rawFetch('OPTIONS', '/api/health', {
      headers: {
        Origin: 'https://also-allowed.example.com',
        'Access-Control-Request-Method': 'POST',
      },
    });
    expect(res.headers.get('access-control-allow-origin')).toBe('https://also-allowed.example.com');
  });
});

// ═══════════════════════════════════════════════════════════════
//  API Key auth — 401 Unauthorized
// ═══════════════════════════════════════════════════════════════
describe('API Key auth — 401 Unauthorized', () => {
  it('rejects POST with no API key provided', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      body: JSON.stringify({ title: 'No Key' }),
    });
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.error).toBe('Unauthorized');
    expect(body.requestId).toBeTruthy();
  });

  it('rejects POST with wrong API key via x-api-key header', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      headers: { 'x-api-key': 'wrong-key' },
      body: JSON.stringify({ title: 'Wrong Key' }),
    });
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.error).toBe('Unauthorized');
  });

  it('rejects POST with wrong Bearer token', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      headers: { Authorization: 'Bearer wrong-token' },
      body: JSON.stringify({ title: 'Wrong Bearer' }),
    });
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.error).toBe('Unauthorized');
  });

  it('allows POST with correct API key via x-api-key header', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      headers: { 'x-api-key': 'test-secret-key-42' },
      body: JSON.stringify({ title: 'Correct Key', viewBox: '0 0 1000 600' }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.id).toBeTruthy();
  });

  it('allows POST with correct Bearer token', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      headers: { Authorization: 'Bearer test-secret-key-42' },
      body: JSON.stringify({ title: 'Correct Bearer', viewBox: '0 0 1000 600' }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.id).toBeTruthy();
  });

  it('allows GET without any API key (read-only methods skip auth)', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.status).toBe(200);
  });

  it('allows HEAD without any API key', async () => {
    const res = await rawFetch('HEAD', '/api/health');
    expect(res.status).toBe(200);
  });
});

// ═══════════════════════════════════════════════════════════════
//  Rate limiting — 429 response
//  This suite runs last because it exhausts the per-IP quota.
// ═══════════════════════════════════════════════════════════════
describe('Rate limiting — 429 Too Many Requests', () => {
  it('returns 429 after exceeding RATE_LIMIT_MAX requests', async () => {
    // RATE_LIMIT_MAX is 20. Previous tests already consumed some quota.
    // Send enough requests to guarantee we exceed the limit.
    let got429 = false;
    for (let i = 0; i < 25; i++) {
      const res = await rawFetch('GET', '/api/health');
      if (res.status === 429) {
        const body = await res.json();
        expect(body.error).toBe('Too many requests');
        expect(body.requestId).toBeTruthy();
        got429 = true;
        break;
      }
    }
    expect(got429).toBe(true);
  });

  it('returns X-RateLimit-Remaining of 0 when limit is exceeded', async () => {
    // After the previous test, we are well over the limit.
    const res = await rawFetch('GET', '/api/health');
    expect(res.status).toBe(429);
    expect(res.headers.get('X-RateLimit-Remaining')).toBe('0');
  });

  it('includes rate-limit headers even on 429 responses', async () => {
    const res = await rawFetch('GET', '/api/health');
    expect(res.status).toBe(429);
    expect(res.headers.get('X-RateLimit-Limit')).toBe('20');
    expect(res.headers.get('X-RateLimit-Remaining')).toBe('0');
    expect(res.headers.get('X-RateLimit-Reset')).toBeTruthy();
  });
});
