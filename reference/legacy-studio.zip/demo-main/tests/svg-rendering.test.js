import { describe, it, expect } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('SVG Rendering', () => {

  describe('Static Node Renderers', () => {
    const renderers = [
      ['renderEC', TopologyDesigner.renderEC],
      ['renderSwitch', TopologyDesigner.renderSwitch],
      ['renderSwitchEnterprise', TopologyDesigner.renderSwitchEnterprise],
      ['renderCloud', TopologyDesigner.renderCloud],
      ['renderHost', TopologyDesigner.renderHost],
      ['renderConnector', TopologyDesigner.renderConnector],
      ['renderApps', TopologyDesigner.renderApps],
      ['renderSaaS', TopologyDesigner.renderSaaS],
      ['renderServer', TopologyDesigner.renderServer],
      ['renderRouter', TopologyDesigner.renderRouter],
      ['renderFirewall', TopologyDesigner.renderFirewall],
      ['renderDatabase', TopologyDesigner.renderDatabase],
      ['renderAP', TopologyDesigner.renderAP],
      ['renderText', TopologyDesigner.renderText],
    ];

    renderers.forEach(([name, fn]) => {
      it(`${name} returns non-empty SVG string`, () => {
        const svg = fn(100, 200, {});
        expect(typeof svg).toBe('string');
        expect(svg.length).toBeGreaterThan(0);
      });

      it(`${name} includes x position coordinate`, () => {
        const svg = fn(150, 250, {});
        expect(svg).toContain('150');
        // Note: y coordinate may be offset (e.g. renderText adds +5)
      });
    });

    describe('renderEC variants', () => {
      it('renders generic variant', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'generic' });
        expect(svg).toContain('#01a982');
      });

      it('renders virtual variant with VM badge', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'virtual' });
        expect(svg).toContain('VM');
      });

      it('renders physical variant with rack ears', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'physical' });
        expect(svg).toContain('HW');
      });

      it('renders AWS variant with badge', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'aws' });
        expect(svg).toContain('AWS');
        expect(svg).toContain('#ec8c25');
      });

      it('renders Azure variant', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'azure' });
        expect(svg).toContain('AZ');
      });

      it('renders GCP variant', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'gcp' });
        expect(svg).toContain('GCP');
      });

      it('renders Oracle variant', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { variant: 'oracle' });
        expect(svg).toContain('OCI');
      });

      it('accepts custom color override', () => {
        const svg = TopologyDesigner.renderEC(100, 200, { color: '#ff0000' });
        expect(svg).toContain('#ff0000');
      });
    });

    describe('renderCloud', () => {
      it('renders with label', () => {
        const svg = TopologyDesigner.renderCloud(100, 200, { label: 'Internet' });
        expect(svg).toContain('Internet');
      });

      it('renders sublabels', () => {
        const svg = TopologyDesigner.renderCloud(100, 200, { label: 'SSE', sub1: 'SWG · ZTNA' });
        expect(svg).toContain('SWG · ZTNA');
      });

      it('controls inner clouds', () => {
        const none = TopologyDesigner.renderCloud(100, 200, { innerClouds: 'none' });
        const both = TopologyDesigner.renderCloud(100, 200, { innerClouds: 'both' });
        // 'both' should have more SVG content (inner ellipses)
        expect(both.length).toBeGreaterThan(none.length);
      });
    });

    describe('renderHost', () => {
      it('renders basic host', () => {
        const svg = TopologyDesigner.renderHost(100, 200, {});
        expect(svg).toContain('rect');
      });

      it('renders managed host with shield badge', () => {
        const svg = TopologyDesigner.renderHost(100, 200, { managed: true });
        expect(svg).toContain('#05cc93');
      });

      it('renders host with agent indicator', () => {
        const svg = TopologyDesigner.renderHost(100, 200, { agent: true });
        // Agent indicator has multiple circles (spoke pattern)
        expect(svg.split('<circle').length).toBeGreaterThan(3);
      });
    });

    describe('renderIdCard', () => {
      it('renders in id mode', () => {
        const svg = TopologyDesigner.renderIdCard(100, 200, { mode: 'id' });
        expect(svg).toContain('IDENTIFIED');
      });

      it('renders in auth mode', () => {
        const svg = TopologyDesigner.renderIdCard(100, 200, { mode: 'auth' });
        expect(svg).toContain('AUTHENTICATED');
      });

      it('includes user, host, and role', () => {
        const svg = TopologyDesigner.renderIdCard(100, 200, {
          user: 'Alice', host: 'laptop1', role: 'ADMIN',
        });
        expect(svg).toContain('Alice');
        expect(svg).toContain('laptop1');
        expect(svg).toContain('ADMIN');
      });
    });

    describe('renderSwitchEnterprise', () => {
      it('renders with custom port counts', () => {
        const svg = TopologyDesigner.renderSwitchEnterprise(100, 200, {
          copperPorts: 4, fiberPorts: 1,
        });
        expect(svg).toContain('rect');
      });
    });
  });

  describe('Shape Renderers', () => {
    const shapes = [
      ['renderShapeArrow', TopologyDesigner.renderShapeArrow],
      ['renderShapeSquare', TopologyDesigner.renderShapeSquare],
      ['renderShapeRectangle', TopologyDesigner.renderShapeRectangle],
      ['renderShapeTriangle', TopologyDesigner.renderShapeTriangle],
      ['renderShapeCircle', TopologyDesigner.renderShapeCircle],
      ['renderShapeEllipse', TopologyDesigner.renderShapeEllipse],
      ['renderShapeDiamond', TopologyDesigner.renderShapeDiamond],
      ['renderShapePentagon', TopologyDesigner.renderShapePentagon],
      ['renderShapeHexagon', TopologyDesigner.renderShapeHexagon],
      ['renderShapeStar', TopologyDesigner.renderShapeStar],
      ['renderShapeCross', TopologyDesigner.renderShapeCross],
    ];

    shapes.forEach(([name, fn]) => {
      it(`${name} returns valid SVG`, () => {
        const svg = fn(200, 300, { color: '#ff0000' });
        expect(typeof svg).toBe('string');
        expect(svg.length).toBeGreaterThan(0);
        expect(svg).toContain('#ff0000');
      });
    });

    it('renderShapeArrow supports direction variants', () => {
      const right = TopologyDesigner.renderShapeArrow(100, 100, { variant: 'right' });
      const left = TopologyDesigner.renderShapeArrow(100, 100, { variant: 'left' });
      expect(right).not.toBe(left);
    });
  });

  describe('NODE_TYPES registry', () => {
    it('has all expected node type keys', () => {
      const types = Object.keys(TopologyDesigner.NODE_TYPES);
      expect(types).toContain('ec');
      expect(types).toContain('switch');
      expect(types).toContain('cloud');
      expect(types).toContain('host');
      expect(types).toContain('server');
      expect(types).toContain('router');
      expect(types).toContain('firewall');
      expect(types).toContain('database');
      expect(types).toContain('shape:arrow');
      expect(types).toContain('shape:hexagon');
    });

    it('all registered renderers are functions', () => {
      Object.values(TopologyDesigner.NODE_TYPES).forEach(fn => {
        expect(typeof fn).toBe('function');
      });
    });

    it('registerNodeType adds custom type', () => {
      const customRenderer = (x, y) => `<circle cx="${x}" cy="${y}" r="10"/>`;
      TopologyDesigner.registerNodeType('custom-test', customRenderer);
      expect(TopologyDesigner.NODE_TYPES['custom-test']).toBe(customRenderer);
      // Clean up
      delete TopologyDesigner.NODE_TYPES['custom-test'];
    });
  });

  describe('_glowForColorStatic', () => {
    it('maps known colors to correct glow filters', () => {
      expect(TopologyDesigner._glowForColorStatic('#01a982')).toBe('tds-glow-green');
      expect(TopologyDesigner._glowForColorStatic('#65aef9')).toBe('tds-glow-blue');
      expect(TopologyDesigner._glowForColorStatic('#7764fc')).toBe('tds-glow-purple');
      expect(TopologyDesigner._glowForColorStatic('#deb146')).toBe('tds-glow-gold');
      expect(TopologyDesigner._glowForColorStatic('#fc6161')).toBe('tds-glow-red');
    });

    it('returns default glow for unknown colors', () => {
      expect(TopologyDesigner._glowForColorStatic('#123456')).toBe('tds-glow');
    });
  });

  describe('Instance render methods', () => {
    let topo;

    function buildTopo() {
      topo = new TopologyDesigner({ title: 'Test' });
      topo.reducedMotion = true;
      topo.node('A', { type: 'server', x: 100, y: 100, label: 'A' })
          .node('B', { type: 'router', x: 300, y: 300, label: 'B' })
          .link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' })
          .act('a1', { label: 'Act', color: '#01a982' })
          .addStep('s1', {
            act: 'a1', name: 'S1', goal: 'Goal',
            focus: [],
            phases: [{ show: ['A', 'B', 'l1'], diff: 'All' }],
          });
      topo._buildIndex();
      return topo;
    }

    it('_renderNodeSVG renders by type', () => {
      buildTopo();
      const svg = topo._renderNodeSVG({ type: 'server', x: 100, y: 200 });
      expect(svg).toContain('rect');
    });

    it('_renderNodeSVG returns empty for unknown type without render function', () => {
      buildTopo();
      const svg = topo._renderNodeSVG({ type: 'nonexistent', x: 0, y: 0 });
      expect(svg).toBe('');
    });

    it('_renderNodeSVG calls custom render function', () => {
      buildTopo();
      const svg = topo._renderNodeSVG({
        type: 'custom',
        x: 50, y: 60,
        render: (x, y) => `<custom x="${x}" y="${y}"/>`,
      });
      expect(svg).toBe('<custom x="50" y="60"/>');
    });

    it('_svgDefs returns SVG definitions', () => {
      buildTopo();
      const defs = topo._svgDefs();
      expect(defs).toContain('<defs>');
      expect(defs).toContain('</defs>');
      expect(defs).toContain('tds-glow');
      expect(defs).toContain('tds-bloom');
    });

    it('_svgAmbient returns ambient background SVG', () => {
      buildTopo();
      const ambient = topo._svgAmbient(1050, 700);
      expect(ambient).toContain('tds-ambientGreen');
      expect(ambient).toContain('tds-grid');
    });

    it('_renderSVG produces complete SVG content', () => {
      buildTopo();
      topo.step = 1;
      const svg = topo._renderSVG();
      expect(svg).toContain('<defs>');
      expect(svg).toContain('data-tds-node="A"');
      expect(svg).toContain('data-tds-node="B"');
    });

    it('_renderLine returns empty when phase not shown', () => {
      buildTopo();
      topo.step = 0;
      const svg = topo._renderLine('s1', 0, 0, 0, 100, 100, '#01a982', 1);
      expect(svg).toBe('');
    });

    it('_renderLine returns SVG line when phase is shown', () => {
      buildTopo();
      topo.step = 1;
      const svg = topo._renderLine('s1', 0, 0, 0, 100, 100, '#01a982', 1);
      expect(svg).toContain('line');
      expect(svg).toContain('#01a982');
    });

    it('_renderLine supports dashed style', () => {
      buildTopo();
      topo.step = 1;
      const svg = topo._renderLine('s1', 0, 0, 0, 100, 100, '#01a982', 1, true);
      expect(svg).toContain('stroke-dasharray');
    });

    it('_renderTunnel returns tunnel SVG when shown', () => {
      buildTopo();
      topo.step = 1;
      const svg = topo._renderTunnel('s1', 0, 'M0,0 L200,200', '#65aef9', 'IPsec', 100, 100, 1);
      expect(svg).toContain('#65aef9');
      expect(svg).toContain('IPsec');
    });

    it('_renderBlocked shows X mark and BLOCKED text', () => {
      buildTopo();
      topo.step = 1;
      const svg = topo._renderBlocked('s1', 0, 0, 0, 200, 200, 'Policy denied');
      expect(svg).toContain('BLOCKED');
      expect(svg).toContain('Policy denied');
      expect(svg).toContain('#fc6161');
    });
  });
});
