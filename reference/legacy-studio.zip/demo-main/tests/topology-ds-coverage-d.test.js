import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

function buildBasicTopo() {
  const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 250, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 600, y: 250, label: 'Node B' });
  topo.link('link1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show elements',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'All visible' }],
  });
  topo._buildIndex();
  topo.step = 1;
  return topo;
}

// ─── getNodeTypeCatalog with custom plugin ───
describe('getNodeTypeCatalog', () => {
  it('returns network and shape categories', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    expect(catalog.length).toBeGreaterThanOrEqual(2);
    expect(catalog[0].category).toBe('Network');
    expect(catalog[1].category).toBe('Shapes');
    expect(catalog[0].types.length).toBeGreaterThan(0);
    expect(catalog[1].types.length).toBeGreaterThan(0);
  });

  it('includes custom registered types in a third category', () => {
    TopologyDesigner.registerNodeType('myCustom', {
      render: (x, y, color) => `<circle cx="${x}" cy="${y}" r="10" fill="${color}"/>`,
      description: 'My custom node',
    });
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    const customCat = catalog.find(c => c.category === 'Custom');
    expect(customCat).toBeDefined();
    expect(customCat.types.some(t => t.name === 'myCustom')).toBe(true);
    // Clean up
    delete TopologyDesigner.NODE_TYPES['myCustom'];
    delete TopologyDesigner._nodePluginMeta['myCustom'];
  });
});

// ─── renderNodePreview ───
describe('renderNodePreview', () => {
  it('returns SVG markup for a valid type', () => {
    const svg = TopologyDesigner.renderNodePreview('router', 48);
    expect(svg).toContain('<svg');
    expect(svg).toContain('width="48"');
    expect(svg).toContain('height="48"');
  });

  it('returns empty string for unknown type', () => {
    expect(TopologyDesigner.renderNodePreview('nonexistent')).toBe('');
  });
});

// ─── getRegisteredLinkTypes ───
describe('getRegisteredLinkTypes', () => {
  it('returns built-in link types', () => {
    const types = TopologyDesigner.getRegisteredLinkTypes();
    expect(types).toContain('line');
    expect(types).toContain('tunnel');
    expect(types).toContain('wireguard');
    expect(types).toContain('flow');
    expect(types).toContain('packet');
    expect(types).toContain('blocked');
    expect(types).toContain('wifi');
    expect(types).toContain('poe');
    expect(types).toContain('optical');
  });

  it('includes custom link plugins', () => {
    TopologyDesigner.registerLinkType('myLink', {
      render: () => '<line/>',
    });
    const types = TopologyDesigner.getRegisteredLinkTypes();
    expect(types).toContain('myLink');
    delete TopologyDesigner._linkPlugins['myLink'];
  });
});

// ─── _isActBound ───
describe('_isActBound', () => {
  it('returns true at act boundaries', () => {
    const topo = new TopologyDesigner({ title: 'Act Bound Test' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.node('B', { type: 'switch', x: 300, y: 100 });
    topo.act('a1', { label: 'Act 1' });
    topo.act('a2', { label: 'Act 2' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'] }] });
    topo.addStep('s2', { act: 'a2', name: 'S2', phases: [{ show: ['B'] }] });
    topo._buildIndex();
    // Step 2 starts act 2, which has start=1 (0-indexed), so _isActBound(2) should be true
    expect(topo._isActBound(2)).toBe(true);
    expect(topo._isActBound(1)).toBe(false);
  });
});

// ─── _animDot ───
describe('_animDot', () => {
  it('returns animateMotion SVG when not reduced motion', () => {
    const topo = new TopologyDesigner({ title: 'Anim Test' });
    topo.reducedMotion = false;
    topo._isMobile = false;
    const dot = topo._animDot('M0,0 L100,100', '#01a982', 1, 3);
    expect(dot).toContain('animateMotion');
    expect(dot).toContain('dur="3s"');
    expect(dot).toContain('#01a982');
  });

  it('returns empty when reduced motion', () => {
    const topo = new TopologyDesigner({ title: 'Anim Test' });
    topo.reducedMotion = true;
    expect(topo._animDot('M0,0 L100,100', '#fff')).toBe('');
  });

  it('returns empty on mobile', () => {
    const topo = new TopologyDesigner({ title: 'Anim Test' });
    topo.reducedMotion = false;
    topo._isMobile = true;
    expect(topo._animDot('M0,0 L100,100', '#fff')).toBe('');
  });
});

// ─── _svgDefsMobile ───
describe('_svgDefsMobile', () => {
  it('returns simplified defs with reduced blur radii', () => {
    const topo = new TopologyDesigner({ title: 'Mobile Defs Test' });
    const defs = topo._svgDefsMobile();
    expect(defs).toContain('<defs>');
    expect(defs).toContain('tds-glow');
    expect(defs).toContain('tds-bloom');
    expect(defs).toContain('tds-ghost');
    expect(defs).toContain('</defs>');
  });
});

// ─── getBlastRadius (instance method) ───
describe('getBlastRadius (instance)', () => {
  it('returns reachable nodes within hop limit', () => {
    const topo = buildBasicTopo();
    topo.node('C', { type: 'host', x: 800, y: 250, label: 'Node C' });
    topo.link('link2', { type: 'line', from: 'B', to: 'C', color: '#65aef9' });
    topo._buildIndex();
    const radius1 = topo.getBlastRadius('A', 1);
    expect(radius1.has('A')).toBe(true);
    expect(radius1.has('B')).toBe(true);
    expect(radius1.has('C')).toBe(false);
    const radius2 = topo.getBlastRadius('A', 2);
    expect(radius2.has('C')).toBe(true);
  });

  it('returns only self when graph is null', () => {
    const topo = new TopologyDesigner({ title: 'No Graph' });
    topo._graph = null;
    const result = topo.getBlastRadius('X');
    expect(result.has('X')).toBe(true);
    expect(result.size).toBe(1);
  });
});

// ─── importFromText ───
describe('importFromText', () => {
  it('imports diagram-as-code text', () => {
    const topo = new TopologyDesigner({ title: 'Import Test' });
    const TP = require('../design-system/modules/template-parser.js');
    globalThis.TemplateParser = TP;

    topo.importFromText('A --> B');
    expect(topo._nodes.has('A')).toBe(true);
    expect(topo._nodes.has('B')).toBe(true);

    delete globalThis.TemplateParser;
  });

  it('returns this when TemplateParser not loaded', () => {
    const saved = globalThis.TemplateParser;
    delete globalThis.TemplateParser;
    const topo = new TopologyDesigner({ title: 'No Parser' });
    const result = topo.importFromText('A --> B');
    expect(result).toBe(topo);
    if (saved) globalThis.TemplateParser = saved;
  });
});

// ─── loadTemplate ───
describe('loadTemplate', () => {
  it('loads a built-in template', () => {
    const topo = new TopologyDesigner({ title: 'Template Test' });
    const TP = require('../design-system/modules/template-parser.js');
    globalThis.TemplateParser = TP;

    topo.loadTemplate('hub-spoke');
    expect(topo._nodes.size).toBeGreaterThan(0);

    delete globalThis.TemplateParser;
  });

  it('warns and returns this for unknown template', () => {
    const topo = new TopologyDesigner({ title: 'Template Test' });
    const TP = require('../design-system/modules/template-parser.js');
    globalThis.TemplateParser = TP;

    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.loadTemplate('nonexistent-template');
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();

    delete globalThis.TemplateParser;
  });
});

// ─── applyTheme ───
describe('applyTheme', () => {
  it('warns when ThemeEngine is not loaded', () => {
    const saved = globalThis.ThemeEngine;
    delete globalThis.ThemeEngine;
    const topo = new TopologyDesigner({ title: 'Theme Test' });
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.applyTheme('midnight');
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
    if (saved) globalThis.ThemeEngine = saved;
  });

  it('warns for unknown theme preset name', () => {
    const TE = require('../design-system/modules/theme-engine.js');
    globalThis.ThemeEngine = TE;
    const topo = new TopologyDesigner({ title: 'Theme Test' });
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    topo.applyTheme('totally-unknown');
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
    delete globalThis.ThemeEngine;
  });

  it('applies a valid theme preset', () => {
    const TE = require('../design-system/modules/theme-engine.js');
    globalThis.ThemeEngine = TE;
    const topo = new TopologyDesigner({ title: 'Theme Test' });
    const result = topo.applyTheme('midnight');
    expect(result).toBe(topo);
    delete globalThis.ThemeEngine;
  });

  it('applies a custom theme object', () => {
    const TE = require('../design-system/modules/theme-engine.js');
    globalThis.ThemeEngine = TE;
    const topo = new TopologyDesigner({ title: 'Theme Test' });
    const custom = { bg: '#000', surface: '#111', text: '#fff', accent: '#f00' };
    const result = topo.applyTheme(custom);
    expect(result).toBe(topo);
    delete window.ThemeEngine;
  });
});

// ─── _interpolateStep (choreography smoothing) ───
describe('_interpolateStep', () => {
  it('calls onComplete immediately if no nodes move', () => {
    const topo = buildBasicTopo();
    const cb = vi.fn();
    topo._interpolateStep(0, 1, cb);
    expect(cb).toHaveBeenCalled();
  });

  it('calls onComplete immediately if reducedMotion', () => {
    const topo = buildBasicTopo();
    topo.reducedMotion = true;
    const cb = vi.fn();
    topo._interpolateStep(1, 2, cb);
    expect(cb).toHaveBeenCalled();
  });

  it('calls onComplete immediately if already interpolating', () => {
    const topo = buildBasicTopo();
    topo._interpolating = true;
    const cb = vi.fn();
    topo._interpolateStep(0, 1, cb);
    expect(cb).toHaveBeenCalled();
  });
});

// ─── Zone depth-first ordering in _renderSVG ───
describe('Zone ordering in render', () => {
  it('renders parent zones before child zones', () => {
    const topo = new TopologyDesigner({ title: 'Zone Order Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100, label: 'A' });
    topo.node('B', { type: 'switch', x: 300, y: 100, label: 'B' });
    topo.zone('parent', { label: 'Parent', nodes: ['A', 'B'], color: '#01a982' });
    topo.zone('child', { label: 'Child', nodes: ['A'], color: '#65aef9', parentZone: 'parent' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A', 'B'] }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    const parentIdx = svg.indexOf('Parent');
    const childIdx = svg.indexOf('Child');
    expect(parentIdx).toBeLessThan(childIdx);
  });
});

// ─── Flow path rendering ───
describe('Flow path rendering', () => {
  it('renders flow paths with waypoints through SVG', () => {
    const topo = new TopologyDesigner({ title: 'Flow Path Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.node('B', { type: 'switch', x: 400, y: 250, label: 'B' });
    topo.node('C', { type: 'host', x: 700, y: 250, label: 'C' });
    topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.link('l2', { type: 'line', from: 'B', to: 'C', color: '#65aef9' });
    topo.flowPath('fp1', { waypoints: ['A', 'B', 'C'], color: '#ff0', width: 3 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1',
      phases: [{ show: ['A', 'B', 'C', 'l1', 'l2'] }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('ff0');
  });
});

// ─── Policy marker rendering ───
describe('Policy marker rendering', () => {
  it('includes policy markers in rendered SVG', () => {
    const topo = new TopologyDesigner({ title: 'Policy Test', viewBox: '0 0 800 500' });
    topo.node('fw', { type: 'firewall', x: 400, y: 250, label: 'Firewall' });
    topo.policyMarker('pm1', { nodeId: 'fw', type: 'inspect', color: '#ffd700', label: 'Inspect' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1',
      phases: [{ show: ['fw'] }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Inspect');
  });
});

// ─── exportStandaloneHTML ───
describe('exportStandaloneHTML', () => {
  it('generates HTML and triggers download', async () => {
    const topo = buildBasicTopo();
    const mockUrl = 'blob:mock';
    global.URL.createObjectURL = vi.fn(() => mockUrl);
    global.URL.revokeObjectURL = vi.fn();

    const clickSpy = vi.fn();
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return { set href(v) {}, get href() { return mockUrl; }, set download(v) {}, click: clickSpy };
      }
      return document.createElement(tag);
    });

    global.fetch = vi.fn((url) =>
      Promise.resolve({ text: () => Promise.resolve('/* css or js */') })
    );

    await topo.exportStandaloneHTML();
    expect(global.fetch).toHaveBeenCalledTimes(2);
    expect(global.URL.createObjectURL).toHaveBeenCalled();

    vi.restoreAllMocks();
    delete global.fetch;
  });
});

// ─── copyEmbedCode ───
describe('copyEmbedCode', () => {
  it('copies embed code to clipboard', async () => {
    const topo = buildBasicTopo();
    let written = '';
    navigator.clipboard = { writeText: vi.fn((t) => { written = t; return Promise.resolve(); }) };

    topo.copyEmbedCode();
    await new Promise(r => setTimeout(r, 10));

    expect(navigator.clipboard.writeText).toHaveBeenCalled();
    const arg = navigator.clipboard.writeText.mock.calls[0][0];
    expect(arg).toContain('iframe');
    expect(arg).toContain('standalone.html');
  });
});

// ─── showAnalyticsDashboard ───
describe('showAnalyticsDashboard', () => {
  it('creates analytics dashboard DOM element', () => {
    const container = document.createElement('div');
    container.id = 'analytics-test-container';
    document.body.appendChild(container);

    const topo = new TopologyDesigner({ title: 'Analytics Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'] }] });
    topo._buildIndex();
    topo.mount('analytics-test-container');

    topo.showAnalyticsDashboard();

    const dashboard = document.querySelector('.tds-analytics-backdrop');
    expect(dashboard).not.toBeNull();

    // Clean up dashboard and container
    if (dashboard) dashboard.remove();
    container.remove();
  });
});

// ─── getAnalytics ───
describe('getAnalytics', () => {
  it('returns analytics data structure', () => {
    const topo = new TopologyDesigner({ title: 'Analytics Data Test' });
    const analytics = topo.getAnalytics();
    expect(analytics).toBeDefined();
    expect(typeof analytics.sessionDuration).toBe('number');
    expect(typeof analytics.completionRate).toBe('number');
    expect(analytics.stepBreakdown).toBeDefined();
    expect(Array.isArray(analytics.interactionLog)).toBe(true);
  });
});

// ─── enableMobileQuickEdit / disableMobileQuickEdit ───
describe('Mobile quick-edit', () => {
  it('enables and disables mobile quick-edit mode', () => {
    const container = document.createElement('div');
    container.id = 'topo-mq';
    document.body.appendChild(container);

    const topo = new TopologyDesigner({ title: 'MQ Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'] }] });
    topo._buildIndex();
    topo.mount('topo-mq');

    topo.enableMobileQuickEdit();
    expect(topo._mobileQuickEditEnabled).toBe(true);

    topo.disableMobileQuickEdit();
    expect(topo._mobileQuickEditEnabled).toBe(false);

    container.remove();
  });
});

// ─── _showExportMenu ───
describe('_showExportMenu', () => {
  it('creates export menu DOM element', () => {
    const topo = buildBasicTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);
    topo._showExportMenu(btn);
    const menu = document.getElementById('tds-export-menu');
    expect(menu).not.toBeNull();
    // Clean up
    if (menu) menu.remove();
    btn.remove();
  });
});

// ─── Smart link routing with obstructions ───
describe('Smart link routing (_routeLink)', () => {
  it('computes a detour path when nodes obstruct the line', () => {
    const topo = new TopologyDesigner({ title: 'Smart Route Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.node('B', { type: 'switch', x: 700, y: 250, label: 'B' });
    topo.node('OBS', { type: 'host', x: 400, y: 250, label: 'Obstruction' });
    topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1',
      phases: [{ show: ['A', 'B', 'OBS', 'l1'] }],
    });
    topo._buildIndex();
    topo.step = 1;
    const fromPos = { x: 100, y: 250 };
    const toPos = { x: 700, y: 250 };
    const path = topo._routeLink(fromPos, toPos, 'l1');
    // path may be null if obstruction not detected due to AABB size
    // but the function should run without error
    expect(path === null || typeof path === 'string').toBe(true);
  });

  it('returns null when no obstructions exist', () => {
    const topo = new TopologyDesigner({ title: 'No Obs', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100, label: 'A' });
    topo.node('B', { type: 'switch', x: 700, y: 100, label: 'B' });
    topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A', 'B', 'l1'] }] });
    topo._buildIndex();
    topo.step = 1;
    const path = topo._routeLink({ x: 100, y: 100 }, { x: 700, y: 100 }, 'l1');
    expect(path).toBeNull();
  });
});

// ─── Presentation auto-advance ───
describe('Presentation auto-advance', () => {
  it('_startPresentAutoAdvance sets timers', () => {
    const topo = buildBasicTopo();
    topo._presenting = true;
    topo._startPresentAutoAdvance(5000);
    expect(topo._presentTimer).toBeDefined();
    // Clean up
    clearTimeout(topo._presentTimer);
    clearInterval(topo._presentProgressInterval);
  });
});

// ─── _togglePresentFullscreen ───
describe('_togglePresentFullscreen', () => {
  it('calls requestFullscreen when not in fullscreen', () => {
    const topo = buildBasicTopo();
    const mockEl = { requestFullscreen: vi.fn(() => Promise.resolve()) };
    Object.defineProperty(document, 'fullscreenElement', { value: null, configurable: true });
    vi.spyOn(document, 'querySelector').mockReturnValue(mockEl);

    topo._togglePresentFullscreen();
    expect(mockEl.requestFullscreen).toHaveBeenCalled();

    vi.restoreAllMocks();
  });
});
