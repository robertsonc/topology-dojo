/**
 * Tests for the actual Cloudflare Pages Function handlers exported by
 * functions/api/ai-assist.js — onRequestOptions, onRequestGet, onRequestPost.
 *
 * Unlike ai-assist.test.js which tests reconstructed logic, this file
 * imports and exercises the real exports.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

// Import the actual module under test
const {
  onRequestOptions,
  onRequestGet,
  onRequestPost,
} = require('../functions/api/ai-assist.js');

/* ── helpers ── */

function makeRequest(body) {
  return {
    json: () => Promise.resolve(body),
  };
}

function makeBadRequest() {
  return {
    json: () => Promise.reject(new SyntaxError('Unexpected token')),
  };
}

async function parseResponse(response) {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

/* ── onRequestOptions ── */

describe('onRequestOptions', () => {
  it('returns 204 with CORS headers', async () => {
    const res = await onRequestOptions();
    expect(res.status).toBe(204);
    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('*');
    expect(res.headers.get('Access-Control-Allow-Methods')).toContain('POST');
  });
});

/* ── onRequestGet ── */

describe('onRequestGet', () => {
  it('returns health check with AI binding present', async () => {
    const ctx = { env: { AI: {}, CF_AI_MODEL: '@cf/meta/test-model' } };
    const res = await onRequestGet(ctx);
    expect(res.status).toBe(200);
    const body = await parseResponse(res);
    expect(body.status).toBe('ok');
    expect(body.service).toBe('ai-assist');
    expect(body.model).toBe('@cf/meta/test-model');
    expect(body.aiBinding).toBe(true);
  });

  it('returns default model when CF_AI_MODEL not set', async () => {
    const ctx = { env: {} };
    const res = await onRequestGet(ctx);
    const body = await parseResponse(res);
    expect(body.model).toBe('@cf/openai/gpt-oss-120b');
    expect(body.aiBinding).toBe(false);
  });

  it('includes CORS and Content-Type headers', async () => {
    const ctx = { env: {} };
    const res = await onRequestGet(ctx);
    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('*');
    expect(res.headers.get('Content-Type')).toBe('application/json');
  });
});

/* ── onRequestPost ── */

describe('onRequestPost', () => {
  const validTopology = {
    nodes: [{ id: 'fw1', type: 'firewall', label: 'FW', x: 200, y: 300 }],
    links: [{ id: 'l1', from: 'fw1', to: 'host1', type: 'line', label: '' }],
  };

  it('returns fallback when AI binding not configured', async () => {
    const ctx = { request: makeRequest({ prompt: 'test' }), env: {} };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.error).toBe('AI binding not configured');
    expect(body.fallback).toBe(true);
  });

  it('returns 400 for invalid JSON body', async () => {
    const ctx = { request: makeBadRequest(), env: { AI: { run: vi.fn() } } };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(400);
    const body = await parseResponse(res);
    expect(body.error).toBe('Invalid JSON body');
    expect(body.fallback).toBe(true);
  });

  it('returns 400 for empty prompt', async () => {
    const ctx = {
      request: makeRequest({ prompt: '   ' }),
      env: { AI: { run: vi.fn() } },
    };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(400);
    const body = await parseResponse(res);
    expect(body.error).toBe('prompt is required');
  });

  it('returns 400 for missing prompt field', async () => {
    const ctx = {
      request: makeRequest({}),
      env: { AI: { run: vi.fn() } },
    };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(400);
    const body = await parseResponse(res);
    expect(body.error).toBe('prompt is required');
  });

  it('returns topology when AI produces valid JSON', async () => {
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(validTopology) }) };
    const ctx = {
      request: makeRequest({ prompt: 'A firewall protecting a host' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(200);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
    expect(body.links).toHaveLength(1);
    expect(body.fallback).toBeUndefined();
  });

  it('handles OpenAI-style response format', async () => {
    const mockAI = {
      run: vi.fn().mockResolvedValue({
        choices: [{ message: { content: JSON.stringify(validTopology) } }],
      }),
    };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
  });

  it('returns fallback for invalid AI output', async () => {
    const mockAI = { run: vi.fn().mockResolvedValue({ response: 'Not valid JSON at all' }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });

  it('returns fallback when AI throws', async () => {
    const mockAI = { run: vi.fn().mockRejectedValue(new Error('rate limited')) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toBe('rate limited');
  });

  it('includes debug info when debug flag is set', async () => {
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(validTopology) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test', debug: true }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body._debug).toBeDefined();
    expect(body._debug.model).toBeDefined();
    expect(body._debug.rawOutput).toBeDefined();
  });

  it('does not include debug info when debug flag is not set', async () => {
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(validTopology) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body._debug).toBeUndefined();
  });

  it('passes correct model and parameters to AI.run', async () => {
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(validTopology) }) };
    const ctx = {
      request: makeRequest({ prompt: 'build a network' }),
      env: { AI: mockAI, CF_AI_MODEL: '@cf/test/model' },
    };
    await onRequestPost(ctx);
    expect(mockAI.run).toHaveBeenCalledWith(
      '@cf/test/model',
      expect.objectContaining({
        max_tokens: 2048,
        temperature: 0.3,
        messages: expect.arrayContaining([
          expect.objectContaining({ role: 'user', content: 'build a network' }),
        ]),
      })
    );
  });

  it('includes CORS headers on all responses', async () => {
    const ctx = { request: makeRequest({ prompt: 'test' }), env: {} };
    const res = await onRequestPost(ctx);
    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('*');
  });
});

/* ── Additional coverage tests for internal extractJSON / validateTopology paths ── */

describe('onRequestPost — extractJSON edge cases (via handler)', () => {
  const validTopology = {
    nodes: [{ id: 'fw1', type: 'firewall', label: 'FW', x: 200, y: 300 }],
    links: [{ id: 'l1', from: 'fw1', to: 'host1', type: 'line', label: '' }],
  };

  it('extracts JSON wrapped in ```json markdown fences (line 48)', async () => {
    const fenced = '```json\n' + JSON.stringify(validTopology) + '\n```';
    const mockAI = { run: vi.fn().mockResolvedValue({ response: fenced }) };
    const ctx = {
      request: makeRequest({ prompt: 'build a network' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(200);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
    expect(body.links).toHaveLength(1);
    expect(body.fallback).toBeUndefined();
  });

  it('extracts JSON wrapped in bare ``` markdown fences (line 48)', async () => {
    const fenced = '```\n' + JSON.stringify(validTopology) + '\n```';
    const mockAI = { run: vi.fn().mockResolvedValue({ response: fenced }) };
    const ctx = {
      request: makeRequest({ prompt: 'build a network' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
    expect(body.fallback).toBeUndefined();
  });

  it('returns fallback when braces are present but inner JSON is invalid (line 60)', async () => {
    // Text that fails initial parse, contains {...} but inner content is not valid JSON
    const malformed = 'Here is your topology: { nodes: [invalid], links: broken } enjoy!';
    const mockAI = { run: vi.fn().mockResolvedValue({ response: malformed }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });

  it('returns fallback when no braces are found in non-JSON text (line 56 branch)', async () => {
    // Text that fails initial parse and has no {...} block at all
    const noBraces = 'Sorry, I am unable to generate a topology for that request.';
    const mockAI = { run: vi.fn().mockResolvedValue({ response: noBraces }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });
});

describe('onRequestPost — validateTopology edge cases (via handler)', () => {
  it('rejects topology where nodes is not an array (line 72)', async () => {
    const badShape = { nodes: 'not-an-array', links: [] };
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(badShape) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });

  it('rejects topology where links is not an array (line 72)', async () => {
    const badShape = { nodes: [], links: 'not-an-array' };
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(badShape) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });

  it('rejects topology where a node is missing required fields', async () => {
    const badNodes = {
      nodes: [{ id: 'n1', type: 'host', x: 100, y: 200 }, { id: 'n2' }],
      links: [],
    };
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(badNodes) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
  });

  it('rejects topology where a link is missing from/to', async () => {
    const badLinks = {
      nodes: [{ id: 'n1', type: 'host', x: 100, y: 200 }],
      links: [{ id: 'l1', from: 'n1' }],
    };
    const mockAI = { run: vi.fn().mockResolvedValue({ response: JSON.stringify(badLinks) }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
  });
});

describe('onRequestPost — error and response edge cases', () => {
  it('handles AI.run returning null/undefined response (line 156 branch)', async () => {
    // aiResponse is null, so Object.keys(aiResponse || {}) uses the fallback {}
    const mockAI = { run: vi.fn().mockResolvedValue(null) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    // rawText will be '' and extractJSON('') returns null → fallback
    expect(body.fallback).toBe(true);
    expect(body.error).toContain('not valid topology JSON');
  });

  it('handles AI.run throwing an error without a message (line 181)', async () => {
    // Throw a non-standard error object without a message property
    const mockAI = { run: vi.fn().mockRejectedValue({ code: 'UNKNOWN' }) };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    expect(res.status).toBe(200);
    const body = await parseResponse(res);
    expect(body.fallback).toBe(true);
    expect(body.error).toBe('AI call failed');
  });

  it('handles result.response format from AI', async () => {
    const validTopology = {
      nodes: [{ id: 'fw1', type: 'firewall', label: 'FW', x: 200, y: 300 }],
      links: [{ id: 'l1', from: 'fw1', to: 'host1', type: 'line', label: '' }],
    };
    const mockAI = {
      run: vi.fn().mockResolvedValue({ result: { response: JSON.stringify(validTopology) } }),
    };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
    expect(body.links).toHaveLength(1);
  });

  it('handles result.choices format from AI (line 154)', async () => {
    const validTopology = {
      nodes: [{ id: 'fw1', type: 'firewall', label: 'FW', x: 200, y: 300 }],
      links: [{ id: 'l1', from: 'fw1', to: 'host1', type: 'line', label: '' }],
    };
    const mockAI = {
      run: vi.fn().mockResolvedValue({
        result: { choices: [{ message: { content: JSON.stringify(validTopology) } }] },
      }),
    };
    const ctx = {
      request: makeRequest({ prompt: 'test' }),
      env: { AI: mockAI },
    };
    const res = await onRequestPost(ctx);
    const body = await parseResponse(res);
    expect(body.nodes).toHaveLength(1);
    expect(body.links).toHaveLength(1);
  });
});
