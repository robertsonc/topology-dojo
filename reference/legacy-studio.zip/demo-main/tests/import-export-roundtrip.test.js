/**
 * tests/import-export-roundtrip.test.js
 *
 * Verifies the export → import → modify → export → import loop works for
 * both the code export (topo.node/link/act/addStep calls) and the standalone
 * HTML export (fromJSON with embedded JSON data).
 *
 * Because parseImportedCode lives in editor.html (browser-side), we inline its
 * logic here so we can unit-test it in Node / jsdom.
 */

import { describe, it, expect, beforeEach } from 'vitest';

// ─── Minimal DOM stubs required by deserializeState ────────────────────────
if (typeof window !== 'undefined') {
  window.matchMedia = window.matchMedia || function () {
    return { matches: false, addListener: () => {}, removeListener: () => {} };
  };
}

// ─── Inline the editor state model ─────────────────────────────────────────
// We replicate just the parts of editor.html that parseImportedCode touches.

function makeState() {
  return {
    nodes: new Map(),
    links: new Map(),
    anchors: new Map(),
    acts: [],
    steps: [],
    title: '',
    subtitle: '',
    viewBox: '0 0 1200 675',
    glossary: [],
    layers: [],
    flowPaths: new Map(),
    policyMarkers: new Map(),
    zones: new Map(),
    _nextNodeNum: 10,
    _nextLinkNum: 10,
    _nextAnchorNum: 10,
    _nextActNum: 1,
    _nextStepNum: 10,
    _nextLayerNum: 1,
  };
}

// ─── Replicate serializeState / deserializeState ────────────────────────────
function serializeState(state) {
  const plain = {
    nodes: [...state.nodes.entries()],
    links: [...state.links.entries()],
    anchors: [...state.anchors.entries()],
    acts: state.acts,
    steps: state.steps,
    title: state.title,
    subtitle: state.subtitle,
    viewBox: state.viewBox,
    glossary: state.glossary,
    layers: state.layers,
    flowPaths: [...state.flowPaths.entries()],
    policyMarkers: [...state.policyMarkers.entries()],
    zones: state.zones ? [...state.zones.entries()] : [],
    _nextNodeNum: state._nextNodeNum,
    _nextLinkNum: state._nextLinkNum,
    _nextAnchorNum: state._nextAnchorNum,
    _nextActNum: state._nextActNum,
    _nextStepNum: state._nextStepNum,
    _nextLayerNum: state._nextLayerNum,
  };
  return JSON.stringify(plain);
}

function deserializeState(json, state) {
  const d = JSON.parse(json);
  state.nodes = new Map(d.nodes.map(([k, v]) => [k, v]));
  state.links = new Map(d.links.map(([k, v]) => [k, v]));
  state.anchors = new Map(d.anchors.map(([k, v]) => [k, v]));
  state.acts = d.acts;
  state.steps = d.steps;
  state.title = d.title || '';
  state.subtitle = d.subtitle || '';
  state.viewBox = d.viewBox || '0 0 1200 675';
  state.glossary = d.glossary || [];
  state.layers = (d.layers && d.layers.length > 0) ? d.layers : [
    { id: 'physical', name: 'Physical', type: 'physical', visible: true, opacity: 1, locked: false, color: '#01a982', order: 0 }
  ];
  if (d._nextNodeNum) state._nextNodeNum = d._nextNodeNum;
  if (d._nextLinkNum) state._nextLinkNum = d._nextLinkNum;
  if (d._nextAnchorNum) state._nextAnchorNum = d._nextAnchorNum;
  if (d._nextActNum) state._nextActNum = d._nextActNum;
  if (d._nextStepNum) state._nextStepNum = d._nextStepNum;
  if (d._nextLayerNum) state._nextLayerNum = d._nextLayerNum;
  state.flowPaths = new Map(d.flowPaths ? d.flowPaths.map(([k, v]) => [k, v]) : []);
  state.policyMarkers = new Map(d.policyMarkers ? d.policyMarkers.map(([k, v]) => [k, v]) : []);
  if (d.zones) state.zones = new Map(d.zones);
}

function clearAll(state) {
  state.nodes.clear();
  state.links.clear();
  state.anchors.clear();
  state.acts = [];
  state.steps = [];
  state.title = '';
  state.subtitle = '';
  state.viewBox = '0 0 1200 675';
  state.glossary = [];
  state.layers = [];
  state.flowPaths.clear();
  state.policyMarkers.clear();
  if (state.zones) state.zones.clear();
}

// ─── Replicate parseImportedCode (with the fix applied) ────────────────────
function _parseId(s) {
  return s.trim().replace(/^['"]|['"]$/g, '');
}

function parseImportedCode(code, state) {
  // Extract script content from full HTML
  let script = code;
  const scriptMatch = code.match(/<script>[\s\S]*?<\/script>/g);
  if (scriptMatch) {
    const lastScript = scriptMatch[scriptMatch.length - 1];
    script = lastScript.replace(/<\/?script>/g, '');
  }

  // ── FIX: Detect standalone HTML export format ──
  const standaloneMatch = script.match(/var\s+data\s*=\s*(\{[\s\S]*?\});\s*var\s+topo\s*=/);
  if (standaloneMatch) {
    try {
      // eslint-disable-next-line no-new-func
      const topoData = new Function('return ' + standaloneMatch[1])();
      const stateData = {
        nodes:    Object.entries(topoData.nodes    || {}),
        links:    Object.entries(topoData.links    || {}),
        anchors:  Object.entries(topoData.anchors  || {}),
        acts:     topoData.acts    || [],
        steps:    topoData.steps   || [],
        title:    topoData.title   || '',
        subtitle: topoData.subtitle || '',
        viewBox:  topoData.viewBox || '0 0 1200 675',
        glossary: topoData.glossary || [],
        layers:   topoData.layers  || [],
        flowPaths:     topoData.flowPaths     || [],
        policyMarkers: topoData.policyMarkers || [],
        zones:         topoData.zones         || [],
        _nextNodeNum:  topoData._nextNodeNum,
        _nextLinkNum:  topoData._nextLinkNum,
        _nextAnchorNum: topoData._nextAnchorNum,
        _nextActNum:   topoData._nextActNum,
        _nextStepNum:  topoData._nextStepNum,
        _nextLayerNum: topoData._nextLayerNum,
      };
      deserializeState(JSON.stringify(stateData), state);
      return;
    } catch (e) {
      // fall through to legacy parser
    }
  }

  clearAll(state);

  // Parse TopologyDesigner constructor
  const ctorMatch = script.match(/new TopologyDesigner\(\{([\s\S]*?)\}\)/);
  if (ctorMatch) {
    try {
      // eslint-disable-next-line no-new-func
      const ctorObj = new Function('return ({' + ctorMatch[1] + '})')();
      if (ctorObj.title) state.title = ctorObj.title;
      if (ctorObj.subtitle) state.subtitle = ctorObj.subtitle;
      if (ctorObj.viewBox) state.viewBox = ctorObj.viewBox;
    } catch (e) {}
  }

  // Parse topo.node() calls
  const nodeRegex = /topo\.node\(([^,]+),\s*(\{[\s\S]*?\})\s*\);/g;
  let m;
  let nodeCount = 0;
  while ((m = nodeRegex.exec(script)) !== null) {
    try {
      const id = _parseId(m[1]);
      // eslint-disable-next-line no-new-func
      const cfg = new Function('return ' + m[2])();
      cfg.id = id;
      state.nodes.set(id, cfg);
      nodeCount++;
    } catch (e) {}
  }

  // Parse topo.anchor() calls
  const anchorRegex = /topo\.anchor\(([^,]+),\s*(\{[\s\S]*?\})\s*\);/g;
  let anchorCount = 0;
  while ((m = anchorRegex.exec(script)) !== null) {
    try {
      const id = _parseId(m[1]);
      // eslint-disable-next-line no-new-func
      const cfg = new Function('return ' + m[2])();
      state.anchors.set(id, cfg);
      anchorCount++;
    } catch (e) {}
  }

  // Parse topo.link() calls
  const linkRegex = /topo\.link\(([^,]+),\s*(\{[\s\S]*?\})\s*\);/g;
  let linkCount = 0;
  while ((m = linkRegex.exec(script)) !== null) {
    try {
      const id = _parseId(m[1]);
      // eslint-disable-next-line no-new-func
      const cfg = new Function('return ' + m[2])();
      cfg.id = id;
      state.links.set(id, cfg);
      linkCount++;
    } catch (e) {}
  }

  // Parse topo.act() calls
  const actRegex = /topo\.act\(([^,]+),\s*(\{[\s\S]*?\})\s*\);/g;
  while ((m = actRegex.exec(script)) !== null) {
    try {
      const id = _parseId(m[1]);
      // eslint-disable-next-line no-new-func
      const cfg = new Function('return ' + m[2])();
      cfg.id = id;
      state.acts.push(cfg);
    } catch (e) {}
  }

  // Parse topo.addStep() calls
  const stepRegex = /topo\.addStep\(([^,]+),\s*(\{[\s\S]*?\})\s*\);/g;
  while ((m = stepRegex.exec(script)) !== null) {
    try {
      const id = _parseId(m[1]);
      // eslint-disable-next-line no-new-func
      const cfg = new Function('return ' + m[2])();
      cfg.id = id;
      if (!cfg.focus) cfg.focus = [];
      if (!cfg.phases) cfg.phases = [{ show: [], diff: '' }];
      state.steps.push(cfg);
    } catch (e) {}
  }

  // Parse topo.glossary() calls
  const glossMatch = script.match(/topo\.glossary\(([\s\S]*?)\);/);
  if (glossMatch) {
    try {
      // eslint-disable-next-line no-new-func
      state.glossary = new Function('return ' + glossMatch[1])();
    } catch (e) {}
  }

  state._nextNodeNum = nodeCount + 10;
  state._nextLinkNum = linkCount + 10;
  state._nextAnchorNum = anchorCount + 10;
  state._nextActNum = state.acts.length + 1;
  state._nextStepNum = state.steps.length + 10;
}

// ─── exportCode helper (replicates what the editor's Export Code does) ──────
function exportCode(state) {
  let code = '';
  code += `const topo = new TopologyDesigner({\n`;
  code += `  title: '${state.title}',\n`;
  code += `  subtitle: '${state.subtitle}',\n`;
  code += `  viewBox: '${state.viewBox}',\n`;
  code += `});\n\n`;
  state.nodes.forEach((cfg, id) => {
    const { id: _id, ...rest } = cfg;
    code += `topo.node('${id}', ${JSON.stringify(rest)});\n`;
  });
  state.anchors.forEach((cfg, id) => {
    code += `topo.anchor('${id}', ${JSON.stringify(cfg)});\n`;
  });
  state.links.forEach((cfg, id) => {
    const { id: _id, ...rest } = cfg;
    code += `topo.link('${id}', ${JSON.stringify(rest)});\n`;
  });
  state.acts.forEach(a => {
    const { id, ...rest } = a;
    code += `topo.act('${id}', ${JSON.stringify(rest)});\n`;
  });
  state.steps.forEach(s => {
    const { id, ...rest } = s;
    code += `topo.addStep('${id}', ${JSON.stringify(rest)});\n`;
  });
  if (state.glossary && state.glossary.length > 0) {
    code += `topo.glossary(${JSON.stringify(state.glossary)});\n`;
  }
  return code;
}

// ─── exportStandaloneHTML helper (replicates topology-ds.js logic) ───────────
function exportStandaloneData(state) {
  // toJSON() format: nodes as object, zones as array of entries
  const topoData = {
    title: state.title,
    subtitle: state.subtitle,
    viewBox: state.viewBox,
    nodes:    Object.fromEntries(state.nodes),
    anchors:  Object.fromEntries(state.anchors),
    links:    Object.fromEntries(state.links),
    acts:     state.acts.map(a => ({ id: a.id, label: a.label, color: a.color, intro: a.intro })),
    steps:    state.steps.map(s => ({ ...s })),
    glossary: state.glossary,
    layers:   state.layers,
    flowPaths:     [...state.flowPaths.entries()],
    policyMarkers: [...state.policyMarkers.entries()],
    zones:         state.zones ? [...state.zones.entries()] : [],
  };
  // Mimic the standalone script block the exporter produces
  return `<script>
(function(){
  var data = ${JSON.stringify(topoData)};
  var topo = new TopologyDesigner(data);
  topo.fromJSON(data);
  topo.mount('#topology-container');
})();
</script>`;
}

// ─── Test helpers ────────────────────────────────────────────────────────────
function buildKnownTopology() {
  const state = makeState();
  state.title = 'Round-Trip Test';
  state.subtitle = 'QA topology';
  state.viewBox = '0 0 1200 675';

  state.nodes.set('srv1', { type: 'server',   x: 100, y: 100, label: 'Web Server' });
  state.nodes.set('fw1',  { type: 'firewall',  x: 300, y: 100, label: 'Firewall' });
  state.nodes.set('db1',  { type: 'database',  x: 500, y: 100, label: 'Database' });

  state.anchors.set('mid', { x: 300, y: 300 });

  state.links.set('l1', { type: 'line',   from: 'srv1', to: 'fw1',  label: 'HTTP' });
  state.links.set('l2', { type: 'tunnel', from: 'fw1',  to: 'db1',  label: 'SQL' });

  state.acts.push({ id: 'a1', label: 'Data Flow', color: '#01a982', intro: ['Intro'] });
  state.steps.push({
    id: 's1', act: 'a1', name: 'Request',
    focus: ['srv1', 'fw1'],
    phases: [{ show: ['srv1'], diff: 'Web server up' }, { show: ['fw1', 'l1'], diff: 'Firewall' }],
  });
  state.steps.push({
    id: 's2', act: 'a1', name: 'DB Query',
    focus: ['db1'],
    phases: [{ show: ['db1', 'l2'], diff: 'DB query' }],
  });

  state.glossary = [{ term: 'SQL', definition: 'Structured Query Language' }];

  return state;
}

// ─── Tests ───────────────────────────────────────────────────────────────────
describe('Import/Export Round-Trip', () => {
  // ── 1. exportCode → parseImportedCode ─────────────────────────────────────
  describe('exportCode format (topo.node / topo.link / ... calls)', () => {
    it('round-trips all nodes, links, acts, steps', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);

      const imported = makeState();
      parseImportedCode(code, imported);

      expect(imported.nodes.size).toBe(3);
      expect(imported.links.size).toBe(2);
      expect(imported.anchors.size).toBe(1);
      expect(imported.acts.length).toBe(1);
      expect(imported.steps.length).toBe(2);
    });

    it('preserves node labels', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);
      const imported = makeState();
      parseImportedCode(code, imported);
      expect(imported.nodes.get('srv1').label).toBe('Web Server');
    });

    it('preserves link properties', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);
      const imported = makeState();
      parseImportedCode(code, imported);
      expect(imported.links.get('l2').type).toBe('tunnel');
      expect(imported.links.get('l2').label).toBe('SQL');
    });

    it('preserves step phases', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);
      const imported = makeState();
      parseImportedCode(code, imported);
      const s1 = imported.steps.find(s => s.id === 's1');
      expect(s1).toBeDefined();
      expect(s1.phases.length).toBe(2);
    });

    it('preserves title and subtitle', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);
      const imported = makeState();
      parseImportedCode(code, imported);
      expect(imported.title).toBe('Round-Trip Test');
      expect(imported.subtitle).toBe('QA topology');
    });

    it('preserves glossary', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);
      const imported = makeState();
      parseImportedCode(code, imported);
      expect(imported.glossary).toHaveLength(1);
      expect(imported.glossary[0].term).toBe('SQL');
    });
  });

  // ── 2. exportStandaloneHTML → parseImportedCode (the bug fix) ─────────────
  describe('exportStandaloneHTML format (fromJSON with embedded JSON data)', () => {
    it('round-trips all nodes, links, acts, steps', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);

      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.nodes.size).toBe(3);
      expect(imported.links.size).toBe(2);
      expect(imported.anchors.size).toBe(1);
      expect(imported.acts.length).toBe(1);
      expect(imported.steps.length).toBe(2);
    });

    it('preserves title and subtitle', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.title).toBe('Round-Trip Test');
      expect(imported.subtitle).toBe('QA topology');
    });

    it('preserves node labels', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.nodes.get('fw1').label).toBe('Firewall');
    });

    it('preserves link types', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.links.get('l2').type).toBe('tunnel');
    });

    it('preserves step act references', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.steps[0].act).toBe('a1');
    });

    it('preserves anchor positions', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      const mid = imported.anchors.get('mid');
      expect(mid).toBeDefined();
      expect(mid.x).toBe(300);
      expect(mid.y).toBe(300);
    });

    it('preserves glossary entries', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.glossary).toHaveLength(1);
      expect(imported.glossary[0].definition).toBe('Structured Query Language');
    });

    it('preserves viewBox', () => {
      const original = buildKnownTopology();
      const html = exportStandaloneData(original);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.viewBox).toBe('0 0 1200 675');
    });
  });

  // ── 3. Modify after import, then re-export and re-import ──────────────────
  describe('modify → re-export → re-import loop', () => {
    it('exportCode: survives two round-trips with added node', () => {
      const original = buildKnownTopology();
      const code1 = exportCode(original);

      // First import
      const state1 = makeState();
      parseImportedCode(code1, state1);
      expect(state1.nodes.size).toBe(3);

      // Modify: add a node
      state1.nodes.set('lb1', { type: 'load-balancer', x: 50, y: 100, label: 'LB' });

      // Re-export and re-import
      const code2 = exportCode(state1);
      const state2 = makeState();
      parseImportedCode(code2, state2);

      expect(state2.nodes.size).toBe(4);
      expect(state2.nodes.get('lb1').label).toBe('LB');
      // Original nodes still present
      expect(state2.nodes.has('srv1')).toBe(true);
      expect(state2.nodes.has('db1')).toBe(true);
    });

    it('standalone: survives two round-trips with added node', () => {
      const original = buildKnownTopology();
      const html1 = exportStandaloneData(original);

      const state1 = makeState();
      parseImportedCode(html1, state1);
      expect(state1.nodes.size).toBe(3);

      state1.nodes.set('lb1', { type: 'load-balancer', x: 50, y: 100, label: 'LB' });

      const html2 = exportStandaloneData(state1);
      const state2 = makeState();
      parseImportedCode(html2, state2);

      expect(state2.nodes.size).toBe(4);
      expect(state2.nodes.get('lb1').label).toBe('LB');
    });

    it('cross-format: exportCode output can be re-imported from standalone format', () => {
      const original = buildKnownTopology();
      const code = exportCode(original);

      const state1 = makeState();
      parseImportedCode(code, state1);

      // Now export as standalone and re-import
      const html = exportStandaloneData(state1);
      const state2 = makeState();
      parseImportedCode(html, state2);

      expect(state2.nodes.size).toBe(3);
      expect(state2.links.size).toBe(2);
      expect(state2.steps.length).toBe(2);
    });
  });

  // ── 4. Edge cases ──────────────────────────────────────────────────────────
  describe('edge cases', () => {
    it('empty topology: exportCode → import yields 0 nodes, 0 links', () => {
      const empty = makeState();
      const code = exportCode(empty);
      const imported = makeState();
      parseImportedCode(code, imported);
      expect(imported.nodes.size).toBe(0);
      expect(imported.links.size).toBe(0);
    });

    it('empty topology: standalone → import yields 0 nodes, 0 links', () => {
      const empty = makeState();
      const html = exportStandaloneData(empty);
      const imported = makeState();
      parseImportedCode(html, imported);
      expect(imported.nodes.size).toBe(0);
      expect(imported.links.size).toBe(0);
    });

    it('topology with zones survives standalone round-trip', () => {
      const state = buildKnownTopology();
      state.zones.set('z1', { label: 'DMZ', nodes: ['fw1'], color: '#ff6600', padding: 40 });

      const html = exportStandaloneData(state);
      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.nodes.size).toBe(3);
      expect(imported.zones.size).toBe(1);
      const z = imported.zones.get('z1');
      expect(z).toBeDefined();
      expect(z.label).toBe('DMZ');
    });

    it('topology with layers survives standalone round-trip', () => {
      const state = buildKnownTopology();
      state.layers = [
        { id: 'physical', name: 'Physical', visible: true, opacity: 1, locked: false },
        { id: 'logical', name: 'Logical', visible: true, opacity: 0.8, locked: false },
      ];

      const html = exportStandaloneData(state);
      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.layers.length).toBe(2);
      expect(imported.layers[1].name).toBe('Logical');
    });

    it('topology with flowPaths survives standalone round-trip', () => {
      const state = buildKnownTopology();
      state.flowPaths.set('fp1', { waypoints: [{ x: 100, y: 100 }, { x: 200, y: 200 }], color: '#01a982' });

      const html = exportStandaloneData(state);
      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.flowPaths.size).toBe(1);
      expect(imported.flowPaths.get('fp1').color).toBe('#01a982');
    });

    it('topology with policyMarkers survives standalone round-trip', () => {
      const state = buildKnownTopology();
      state.policyMarkers.set('pm1', { x: 200, y: 200, label: 'Policy A', color: '#ff0000' });

      const html = exportStandaloneData(state);
      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.policyMarkers.size).toBe(1);
      expect(imported.policyMarkers.get('pm1').label).toBe('Policy A');
    });

    it('does not corrupt state when given invalid/empty string', () => {
      const state = makeState();
      // Should not throw
      expect(() => parseImportedCode('', state)).not.toThrow();
      expect(() => parseImportedCode('not html or code', state)).not.toThrow();
    });

    it('handles standalone format with special characters in title', () => {
      const state = buildKnownTopology();
      state.title = 'My Topology "v2" & More';

      const html = exportStandaloneData(state);
      const imported = makeState();
      parseImportedCode(html, imported);

      expect(imported.title).toBe('My Topology "v2" & More');
    });
  });
});
