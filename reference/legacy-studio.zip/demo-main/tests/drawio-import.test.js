/**
 * draw.io XML Import Tests (#142)
 * Comprehensive tests for importDrawio() — parsing .drawio / mxGraph XML format.
 */

import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

// ─────────────────────────────────────────────
// Fixtures
// ─────────────────────────────────────────────

const BASIC_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Router A" style="shape=mxgraph.network.router;" vertex="1" parent="1">
      <mxGeometry x="100" y="200" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="3" value="Server B" style="shape=mxgraph.network.server;" vertex="1" parent="1">
      <mxGeometry x="400" y="200" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="4" value="Link 1" edge="1" source="2" target="3" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const MULTI_NODE_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="10" value="Firewall" style="shape=mxgraph.network.firewall;" vertex="1" parent="1">
      <mxGeometry x="50" y="50" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="11" value="Switch" style="shape=mxgraph.network.switch;" vertex="1" parent="1">
      <mxGeometry x="200" y="50" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="12" value="Cloud" style="shape=mxgraph.network.cloud;" vertex="1" parent="1">
      <mxGeometry x="350" y="50" width="80" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="13" value="DB" style="shape=mxgraph.network.database;" vertex="1" parent="1">
      <mxGeometry x="500" y="50" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="14" value="Laptop" style="shape=mxgraph.network.laptop;" vertex="1" parent="1">
      <mxGeometry x="650" y="50" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="20" edge="1" source="10" target="11" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="21" edge="1" source="11" target="12" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="22" edge="1" source="11" target="13" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="23" edge="1" source="14" target="11" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const CISCO_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Cisco Router" style="shape=mxgraph.cisco.routers.router;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="3" value="Cisco Switch" style="shape=mxgraph.cisco.switches.layer_3_switch;" vertex="1" parent="1">
      <mxGeometry x="300" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="4" edge="1" source="2" target="3" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const STYLED_LINKS_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="A" style="shape=mxgraph.network.router;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="3" value="B" style="shape=mxgraph.network.router;" vertex="1" parent="1">
      <mxGeometry x="300" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="4" value="C" style="shape=mxgraph.network.server;" vertex="1" parent="1">
      <mxGeometry x="500" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="10" value="dashed link" edge="1" source="2" target="3" style="dashed=1;" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
    <mxCell id="11" value="arrow link" edge="1" source="3" target="4" style="endArrow=block;" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const HTML_LABEL_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="&lt;b&gt;Bold&lt;/b&gt; &lt;i&gt;Label&lt;/i&gt;" style="shape=mxgraph.network.server;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const COLOR_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Red Node" style="shape=mxgraph.network.router;fillColor=#FF0000;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="3" value="Blue Node" style="shape=mxgraph.network.server;fillColor=#0000FF;" vertex="1" parent="1">
      <mxGeometry x="300" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="4" edge="1" source="2" target="3" style="strokeColor=#00FF00;" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const NODES_ONLY_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Standalone" style="shape=mxgraph.network.server;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

const EDGE_DANGLING_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Node" style="shape=mxgraph.network.router;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="99" edge="1" source="2" target="999" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

// ─────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────

function makeTopo() {
  const t = new TopologyDesigner({ title: 'Drawio Import', viewBox: '0 0 1050 700' });
  t._buildIndex();
  return t;
}

describe('draw.io Import — basic parsing', () => {
  it('creates correct number of nodes from basic XML', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    expect(t._nodes.size).toBe(2);
  });

  it('creates correct number of links from basic XML', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    expect(t._links.size).toBe(1);
  });

  it('node IDs are prefixed with drio-', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    for (const id of t._nodes.keys()) {
      expect(id).toMatch(/^drio-/);
    }
  });

  it('link IDs are prefixed with drio-link-', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    for (const id of t._links.keys()) {
      expect(id).toMatch(/^drio-link-/);
    }
  });

  it('preserves node labels from XML value attribute', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const labels = [...t._nodes.values()].map(n => n.label);
    expect(labels).toContain('Router A');
    expect(labels).toContain('Server B');
  });

  it('computes node position from geometry center', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    // Router A: x=100, w=60 → center 130; y=200, h=60 → center 230
    const routerNode = [...t._nodes.values()].find(n => n.label === 'Router A');
    expect(routerNode).toBeDefined();
    expect(routerNode.x).toBe(130);
    expect(routerNode.y).toBe(230);
  });

  it('link references valid from/to node IDs', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const link = [...t._links.values()][0];
    expect(t._nodes.has(link.from)).toBe(true);
    expect(t._nodes.has(link.to)).toBe(true);
  });
});

describe('draw.io Import — shape type mapping', () => {
  it('maps mxgraph.network.router → router', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const router = [...t._nodes.values()].find(n => n.label === 'Router A');
    expect(router.type).toBe('router');
  });

  it('maps mxgraph.network.server → server', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const server = [...t._nodes.values()].find(n => n.label === 'Server B');
    expect(server.type).toBe('server');
  });

  it('maps mxgraph.network.firewall → firewall', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    const fw = [...t._nodes.values()].find(n => n.label === 'Firewall');
    expect(fw.type).toBe('firewall');
  });

  it('maps mxgraph.network.switch → switch', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    const sw = [...t._nodes.values()].find(n => n.label === 'Switch');
    expect(sw.type).toBe('switch');
  });

  it('maps mxgraph.network.cloud → cloud', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    const cloud = [...t._nodes.values()].find(n => n.label === 'Cloud');
    expect(cloud.type).toBe('cloud');
  });

  it('maps mxgraph.network.database → database', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    const db = [...t._nodes.values()].find(n => n.label === 'DB');
    expect(db.type).toBe('database');
  });

  it('maps mxgraph.network.laptop → host', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    const laptop = [...t._nodes.values()].find(n => n.label === 'Laptop');
    expect(laptop.type).toBe('host');
  });

  it('maps Cisco shapes correctly', () => {
    const t = makeTopo();
    t.importDrawio(CISCO_XML);
    const types = [...t._nodes.values()].map(n => n.type);
    expect(types).toContain('router');
    expect(types).toContain('switch');
  });
});

describe('draw.io Import — link styles', () => {
  it('maps dashed=1 style to tunnel link type', () => {
    const t = makeTopo();
    t.importDrawio(STYLED_LINKS_XML);
    const dashedLink = [...t._links.values()].find(l => l.label === 'dashed link');
    expect(dashedLink).toBeDefined();
    expect(dashedLink.type).toBe('tunnel');
  });

  it('maps endArrow=block style to flow link type', () => {
    const t = makeTopo();
    t.importDrawio(STYLED_LINKS_XML);
    const arrowLink = [...t._links.values()].find(l => l.label === 'arrow link');
    expect(arrowLink).toBeDefined();
    expect(arrowLink.type).toBe('flow');
  });

  it('preserves link strokeColor', () => {
    const t = makeTopo();
    t.importDrawio(COLOR_XML);
    const link = [...t._links.values()][0];
    expect(link.color).toBe('#00FF00');
  });
});

describe('draw.io Import — colors', () => {
  it('preserves fillColor on nodes', () => {
    const t = makeTopo();
    t.importDrawio(COLOR_XML);
    const red = [...t._nodes.values()].find(n => n.label === 'Red Node');
    expect(red.color).toBe('#FF0000');
  });

  it('nodes with no fillColor get default color', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const router = [...t._nodes.values()].find(n => n.label === 'Router A');
    expect(router.color).toBe('#01a982');
  });
});

describe('draw.io Import — HTML label stripping', () => {
  it('strips HTML tags from node labels', () => {
    const t = makeTopo();
    t.importDrawio(HTML_LABEL_XML);
    const node = [...t._nodes.values()][0];
    expect(node.label).toBe('Bold Label');
    expect(node.label).not.toContain('<');
  });
});

describe('draw.io Import — options', () => {
  it('applies offsetX and offsetY to node positions', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML, { offsetX: 100, offsetY: 50 });
    // Router A: (100+100)+30=230, (200+50)+30=280
    const router = [...t._nodes.values()].find(n => n.label === 'Router A');
    expect(router.x).toBe(230);
    expect(router.y).toBe(280);
  });

  it('custom typeMap overrides default shape mapping', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML, { typeMap: { 'mxgraph.network.router': 'gateway' } });
    const router = [...t._nodes.values()].find(n => n.label === 'Router A');
    expect(router.type).toBe('gateway');
  });

  it('defaultNodeType is used for unknown shapes', () => {
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel><root>
  <mxCell id="0"/><mxCell id="1" parent="0"/>
  <mxCell id="2" value="Unknown" style="shape=something_custom;" vertex="1" parent="1">
    <mxGeometry x="0" y="0" width="60" height="60" as="geometry"/>
  </mxCell>
</root></mxGraphModel>`;
    const t = makeTopo();
    t.importDrawio(xml, { defaultNodeType: 'appliance' });
    const node = [...t._nodes.values()][0];
    expect(node.type).toBe('appliance');
  });

  it('defaultLinkType applies to unstyled links', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML, { defaultLinkType: 'cable' });
    const link = [...t._links.values()][0];
    expect(link.type).toBe('cable');
  });

  it('autoAct=false suppresses act/step creation', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML, { autoAct: false });
    // Should still have nodes but no drawio-import act
    expect(t._nodes.size).toBe(2);
    const hasAct = t._acts && t._acts.has && t._acts.has('drawio-import');
    // If acts are tracked, it should NOT have the auto-created one
    if (t._acts && t._acts.has) {
      expect(hasAct).toBe(false);
    }
  });
});

describe('draw.io Import — multi-node topology', () => {
  it('imports 5 nodes and 4 links from multi-node XML', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    expect(t._nodes.size).toBe(5);
    expect(t._links.size).toBe(4);
  });

  it('all imported nodes have x and y coordinates', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    for (const node of t._nodes.values()) {
      expect(typeof node.x).toBe('number');
      expect(typeof node.y).toBe('number');
      expect(Number.isFinite(node.x)).toBe(true);
      expect(Number.isFinite(node.y)).toBe(true);
    }
  });

  it('all links reference existing nodes', () => {
    const t = makeTopo();
    t.importDrawio(MULTI_NODE_XML);
    for (const link of t._links.values()) {
      expect(t._nodes.has(link.from)).toBe(true);
      expect(t._nodes.has(link.to)).toBe(true);
    }
  });
});

describe('draw.io Import — edge cases', () => {
  it('returns this (chainable) on valid XML', () => {
    const t = makeTopo();
    expect(t.importDrawio(BASIC_XML)).toBe(t);
  });

  it('returns this on malformed XML', () => {
    const t = makeTopo();
    expect(t.importDrawio('<broken<<xml>')).toBe(t);
  });

  it('returns this on empty string', () => {
    const t = makeTopo();
    expect(t.importDrawio('')).toBe(t);
  });

  it('nodes-only XML creates no links', () => {
    const t = makeTopo();
    t.importDrawio(NODES_ONLY_XML);
    expect(t._nodes.size).toBe(1);
    expect(t._links.size).toBe(0);
  });

  it('dangling edges (target not found) are skipped', () => {
    const t = makeTopo();
    t.importDrawio(EDGE_DANGLING_XML);
    expect(t._nodes.size).toBe(1);
    expect(t._links.size).toBe(0);
  });

  it('skips root cells id=0 and id=1', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    expect(t._nodes.has('drio-0')).toBe(false);
    expect(t._nodes.has('drio-1')).toBe(false);
  });

  it('multiple imports accumulate nodes', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    expect(t._nodes.size).toBe(2);
    // Use XML with a different cell ID so it doesn't overwrite
    const secondXml = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel><root>
  <mxCell id="0"/><mxCell id="1" parent="0"/>
  <mxCell id="50" value="Extra" style="shape=mxgraph.network.server;" vertex="1" parent="1">
    <mxGeometry x="0" y="0" width="60" height="60" as="geometry"/>
  </mxCell>
</root></mxGraphModel>`;
    t.importDrawio(secondXml);
    expect(t._nodes.size).toBe(3);
  });

  it('stores _drawioId metadata on imported nodes', () => {
    const t = makeTopo();
    t.importDrawio(BASIC_XML);
    const node = t._nodes.get('drio-2');
    expect(node._drawioId).toBe('2');
  });
});
