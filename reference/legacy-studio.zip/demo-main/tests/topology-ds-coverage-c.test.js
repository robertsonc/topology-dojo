import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* Helper: create topo with two nodes, a link, an act, and a step showing them all */
function makeTopo(linkType, linkExtras = {}) {
  const topo = new TopologyDesigner();
  topo.node('A', { type: 'router', x: 100, y: 200 });
  topo.node('B', { type: 'switch', x: 400, y: 200 });
  topo.link('l1', { type: linkType, from: 'A', to: 'B', color: '#01a982', ...linkExtras });
  topo.act('a1', { label: 'A1' });
  topo.addStep('s1', {
    act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }],
  });
  topo._buildIndex();
  topo.step = 1;
  return topo;
}

// ── _renderLinkSVG switch branches ──
describe('_renderLinkSVG via full pipeline', () => {
  it('renders tunnel link type', () => {
    const topo = makeTopo('tunnel', { label: 'IPsec' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
    expect(svg).toContain('stroke-dasharray');
  });

  it('renders wireguard link type', () => {
    const topo = makeTopo('wireguard', { label: 'WG' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('renders flow link type', () => {
    const topo = makeTopo('flow', { path: 'M100,200 L400,200', labelPos: { x: 250, y: 180 } });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
    expect(svg).toContain('animateMotion');
  });

  it('renders packet link type', () => {
    const topo = makeTopo('packet', { label: 'TCP', sublabel: 'SYN' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('renders blocked link type', () => {
    const topo = makeTopo('blocked', { reason: 'Denied' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
    expect(svg).toContain('Denied');
  });

  it('renders wifi link type', () => {
    const topo = makeTopo('wifi', { label: 'WiFi6' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('renders poe link type', () => {
    const topo = makeTopo('poe', { label: 'PoE+' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('renders optical link type', () => {
    const topo = makeTopo('optical', { label: 'Fiber' });
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('falls back to line for unknown type', () => {
    const topo = makeTopo('unknownType');
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('renders endpoint labels (fromLabel/toLabel)', () => {
    const topo = makeTopo('line', { fromLabel: 'eth0', toLabel: 'ge1' });
    const svg = topo._renderSVG();
    expect(svg).toContain('eth0');
    expect(svg).toContain('ge1');
  });

  it('renders routed line through obstruction', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('C', { type: 'server', x: 250, y: 200 }); // obstruction in the middle
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'line', from: 'A', to: 'B' });
    topo._routingEnabled = true;
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A', 'B', 'C', 'l1'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('data-tds-link="l1"');
  });
});

// ── _buildRenderContext ──
describe('_buildRenderContext', () => {
  it('returns a render context object with expected keys', () => {
    const topo = makeTopo('line');
    const step = topo._steps[0];
    const ctx = topo._buildRenderContext(step);
    expect(ctx).toHaveProperty('step');
    expect(ctx).toHaveProperty('stepId', 's1');
    expect(ctx).toHaveProperty('vis');
    expect(ctx).toHaveProperty('ph');
    expect(ctx).toHaveProperty('pw');
    expect(ctx).toHaveProperty('dim');
    expect(ctx).toHaveProperty('dimAll');
    expect(ctx).toHaveProperty('pos');
    expect(ctx).toHaveProperty('pathThrough');
    expect(ctx).toHaveProperty('pathBetween');
    expect(ctx).toHaveProperty('renderLine');
    expect(ctx).toHaveProperty('renderTunnel');
    expect(ctx).toHaveProperty('renderWG');
    expect(ctx).toHaveProperty('renderFlow');
    expect(ctx).toHaveProperty('renderBlocked');
    expect(ctx).toHaveProperty('renderPoE');
    expect(ctx).toHaveProperty('renderOptical');
    expect(ctx).toHaveProperty('renderCallout');
    expect(ctx).toHaveProperty('renderNode');
    expect(ctx).toHaveProperty('reducedMotion');
  });

  it('context functions are callable', () => {
    const topo = makeTopo('line');
    const step = topo._steps[0];
    const ctx = topo._buildRenderContext(step);
    // Test vis
    expect(typeof ctx.vis('A')).toBe('boolean');
    // Test dim
    expect(typeof ctx.dim('A')).toBe('number');
    // Test pos
    const pos = ctx.pos('A');
    expect(pos).toHaveProperty('x');
    expect(pos).toHaveProperty('y');
    // Test pathThrough
    const path = ctx.pathThrough('A', 'B');
    expect(path).toContain('M');
    // Test renderNode
    const svg = ctx.renderNode('router', 100, 200, {});
    expect(svg).toContain('circle');
    // Test renderNode unknown type
    expect(ctx.renderNode('nonexistent', 0, 0, {})).toBe('');
    // Test ph
    const ph = ctx.ph('s1', 0);
    expect(ph).toHaveProperty('show');
    // Test pw
    const pw = ctx.pw('s1', 0, 1, '<rect/>');
    expect(typeof pw).toBe('string');
    // Test dimAll
    expect(typeof ctx.dimAll('A', 'B')).toBe('number');
    // Test pathBetween
    const pb = ctx.pathBetween('A', 'B', {});
    expect(pb).toContain('M');
    // Test renderLine
    const rl = ctx.renderLine('s1', 0, 100, 200, 400, 200, '#01a982', 1, false);
    expect(typeof rl).toBe('string');
    // Test renderTunnel
    const rt = ctx.renderTunnel('s1', 0, 100, 200, 400, 200, '#01a982', 'T', 1, true);
    expect(typeof rt).toBe('string');
    // Test renderWG
    const rw = ctx.renderWG('s1', 0, 100, 200, 400, 200, 'WG', 1, true);
    expect(typeof rw).toBe('string');
    // Test renderFlow
    const rf = ctx.renderFlow('s1', 0, 'M100,200 L400,200', '#01a982', null, null, null, 1, true);
    expect(typeof rf).toBe('string');
    // Test renderBlocked
    const rb = ctx.renderBlocked('s1', 0, 100, 200, 400, 200, 'blocked');
    expect(typeof rb).toBe('string');
    // Test renderPoE
    const rp = ctx.renderPoE('s1', 0, 100, 200, 400, 200, '#01a982', 'PoE', 1);
    expect(typeof rp).toBe('string');
    // Test renderOptical
    const ro = ctx.renderOptical('s1', 0, 100, 200, 400, 200, '#01a982', 'Opt', 1);
    expect(typeof ro).toBe('string');
    // Test renderCallout
    const rc = ctx.renderCallout('s1', 0, 50, 50, 100, 40, [{ text: 'X' }], '#fff', 1);
    expect(typeof rc).toBe('string');
  });
});

// ── Declarative phase actions (flow, label, badge, callout, blocked, rerender) ──
describe('Declarative phase rendering', () => {
  it('renders declarative flow phases', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A', 'B'], diff: '',
        flow: { through: ['A', 'B'], color: '#65aef9', label: 'Traffic', dots: true },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('animateMotion');
  });

  it('renders declarative label phases', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        label: { at: 'A', text: 'MyLabel', color: '#01a982', offsetY: 30 },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('MyLabel');
  });

  it('renders declarative badge phases', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        badge: { at: 'A', text: 'NEW', color: '#fc6161' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('NEW');
  });

  it('renders declarative callout phases', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        callout: { x: 50, y: 50, w: 100, h: 40, lines: [{ text: 'Info', color: '#fff' }] },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Info');
  });

  it('renders declarative blocked phases', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A', 'B'], diff: '',
        blocked: { from: 'A', to: 'B', reason: 'Firewall' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Firewall');
  });

  it('renders declarative rerender phase', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        rerender: { node: 'A', type: 'host', cfg: { managed: true }, label: 'Managed', sublabel: 'Sub' },
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Managed');
    expect(svg).toContain('Sub');
  });
});

// ── SVG event handlers: mousedown/mousemove/mouseup for anchor dragging ──
describe('SVG anchor dragging', () => {
  let topo, container;

  beforeEach(() => {
    container = document.createElement('div');
    container.id = 'topo-drag-test';
    document.body.appendChild(container);
    topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.anchor('mid', { x: 250, y: 200 });
    topo.link('l1', { type: 'line', from: 'A', to: 'mid' });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A', 'mid', 'l1'], diff: '' }],
    });
    topo.mount('topo-drag-test');
  });

  afterEach(() => {
    document.body.removeChild(container);
  });

  it('handles mousedown on anchor element', () => {
    const svg = document.getElementById('tds-diagram');
    if (!svg) return;

    // Create a mock anchor element
    const anchor = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    anchor.setAttribute('data-tds-anchor', 'mid');
    svg.appendChild(anchor);

    // Mock getScreenCTM and createSVGPoint
    svg.createSVGPoint = () => ({
      x: 0, y: 0,
      matrixTransform: () => ({ x: 250, y: 200 }),
    });
    svg.getScreenCTM = () => ({ inverse: () => ({}) });

    const event = new MouseEvent('mousedown', {
      bubbles: true, clientX: 250, clientY: 200,
    });
    anchor.dispatchEvent(event);
    expect(topo._draggingAnchor).toBe('mid');
  });
});

// ── Node rendering edge cases for zone labels, zone indicator, sideLabel ──
describe('Node rendering with zone and side labels', () => {
  it('renders zoneLabel on a node', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'ec', x: 100, y: 200, label: 'EC',
      zoneLabel: { text: 'DMZ', color: '#fc6161' } });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('DMZ');
  });

  it('renders zoneIndicator on a node', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'ec', x: 100, y: 200, label: 'EC', zoneIndicator: 'right' });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('WAN');
    expect(svg).toContain('LAN');
  });

  it('renders sideLabel on a node', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200, label: 'R1',
      sideLabel: { x: 60, y: 200, label: 'Side', sublabel: 'Info', color: '#01a982' } });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Side');
    expect(svg).toContain('Info');
  });
});

// ── _renderSingleElement (lines 371-408) ──
describe('_renderSingleElement', () => {
  it('renders a node element', () => {
    const topo = makeTopo('line');
    const svg = topo._renderSingleElement('A');
    expect(svg).toContain('data-tds-node="A"');
  });

  it('renders a link element', () => {
    const topo = makeTopo('line');
    const svg = topo._renderSingleElement('l1');
    expect(svg).toContain('data-tds-link="l1"');
  });

  it('returns empty string for non-existent element', () => {
    const topo = makeTopo('line');
    expect(topo._renderSingleElement('nonexistent')).toBe('');
  });

  it('renders overlayCloud with spans via _renderSingleElement', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.node('oc', { type: 'overlayCloud', x: 250, y: 200, spans: ['A', 'B'], label: 'Overlay' });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A', 'B', 'oc'], diff: '' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSingleElement('oc');
    expect(svg).toContain('data-tds-node="oc"');
  });

  it('renders node with showNodeIds enabled', () => {
    const topo = makeTopo('line');
    topo.showNodeIds = true;
    const svg = topo._renderSingleElement('A');
    expect(svg).toContain('[A]');
  });
});

// ── fromJSON mounted path (line 3933-3937) - module export fallback ──
describe('module export', () => {
  it('exports TopologyDesigner via module.exports', () => {
    expect(typeof TopologyDesigner).toBe('function');
    expect(TopologyDesigner.name).toBe('TopologyDesigner');
  });
});

// ── onRender step hook triggers _buildRenderContext in render loop ──
describe('step onRender hook', () => {
  it('calls onRender with render context', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.act('a1', { label: 'A1' });
    let capturedCtx = null;
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{ show: ['A', 'B'], diff: '' }],
      onRender: (ctx) => { capturedCtx = ctx; return '<circle r="99" data-hook="true"/>'; },
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(capturedCtx).not.toBeNull();
    expect(capturedCtx).toHaveProperty('stepId', 's1');
    expect(capturedCtx).toHaveProperty('renderLine');
    expect(svg).toContain('data-hook="true"');
  });
});

// ── _renderSVG with step 0 shows no phases ──
describe('_renderSVG edge cases', () => {
  it('at step 0, still includes defs and ambient', () => {
    const topo = makeTopo('line');
    topo.step = 0;
    const svg = topo._renderSVG();
    expect(svg).toContain('tds-grid');
    expect(svg).not.toContain('data-tds-node="A"');
  });

  it('renders with no phases on a step', () => {
    const topo = new TopologyDesigner();
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '' });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('tds-grid');
  });
});

// ── _advance at act boundary in presenter mode ──
describe('_advance presenter act boundary', () => {
  it('stops at act boundary in presenter mode', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'], diff: '' }] });
    topo.act('a2', { label: 'A2' });
    topo.addStep('s2', { act: 'a2', name: 'S2', phases: [{ show: ['A'], diff: '' }] });
    topo._buildIndex();

    topo.mode = 'presenter';
    topo.playing = true;
    topo.step = 1; // Last step of act 1

    vi.spyOn(topo, '_updateUI').mockImplementation(() => {});
    vi.spyOn(topo, 'render').mockImplementation(() => {});

    topo._advance();

    // Should stop at act boundary
    expect(topo.playing).toBe(false);
  });
});

// ── _advance when step >= _steps.length ──
describe('_advance at end', () => {
  it('stops when step is at the end', () => {
    const topo = new TopologyDesigner();
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', phases: [] });
    topo._buildIndex();

    topo.mode = 'auto';
    topo.playing = true;
    topo.step = 1;

    vi.spyOn(topo, '_updateUI').mockImplementation(() => {});
    vi.spyOn(topo, 'render').mockImplementation(() => {});

    topo._advance();

    expect(topo.playing).toBe(false);
  });
});
