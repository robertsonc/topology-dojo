/**
 * Additional coverage tests for LayoutEngine — cluster() and removeOverlaps()
 * methods that were previously untested.
 */
import { describe, it, expect } from 'vitest';

const LayoutEngine = require('../design-system/modules/layout-engine.js');

describe('LayoutEngine.cluster', () => {
  it('returns empty map for empty input', () => {
    const result = LayoutEngine.cluster([], []);
    expect(result.size).toBe(0);
  });

  it('positions a single node at center of its grid cell', () => {
    const nodes = [{ id: 'A', x: 0, y: 0 }];
    const result = LayoutEngine.cluster(nodes, []);
    expect(result.size).toBe(1);
    expect(result.has('A')).toBe(true);
    const pos = result.get('A');
    expect(typeof pos.x).toBe('number');
    expect(typeof pos.y).toBe('number');
  });

  it('groups connected nodes in the same cluster', () => {
    const nodes = [
      { id: 'A', x: 0, y: 0 },
      { id: 'B', x: 0, y: 0 },
      { id: 'C', x: 0, y: 0 },
    ];
    const links = [
      { from: 'A', to: 'B' },
      { from: 'B', to: 'C' },
    ];
    const result = LayoutEngine.cluster(nodes, links);
    expect(result.size).toBe(3);
    // All three are connected — they should be in one cluster, positioned
    // in a circular arrangement (not at the exact same point)
    const posA = result.get('A');
    const posB = result.get('B');
    expect(posA.x !== posB.x || posA.y !== posB.y).toBe(true);
  });

  it('creates separate clusters for disconnected components', () => {
    const nodes = [
      { id: 'A', x: 0, y: 0 },
      { id: 'B', x: 0, y: 0 },
      { id: 'C', x: 0, y: 0 },
      { id: 'D', x: 0, y: 0 },
    ];
    const links = [
      { from: 'A', to: 'B' },
      { from: 'C', to: 'D' },
    ];
    const result = LayoutEngine.cluster(nodes, links);
    expect(result.size).toBe(4);
    // Cluster 1 (A,B) and Cluster 2 (C,D) should be in different regions
    const posA = result.get('A');
    const posC = result.get('C');
    const dist = Math.sqrt((posA.x - posC.x) ** 2 + (posA.y - posC.y) ** 2);
    expect(dist).toBeGreaterThan(10); // separated on grid
  });

  it('accepts Map input for nodes', () => {
    const nodeMap = new Map([
      ['A', { id: 'A', x: 0, y: 0 }],
      ['B', { id: 'B', x: 0, y: 0 }],
    ]);
    const linkMap = new Map([
      ['l1', { from: 'A', to: 'B' }],
    ]);
    const result = LayoutEngine.cluster(nodeMap, linkMap);
    expect(result.size).toBe(2);
  });

  it('respects custom width/height options', () => {
    const nodes = [{ id: 'A', x: 0, y: 0 }];
    const result = LayoutEngine.cluster(nodes, [], { width: 500, height: 400, padding: 40 });
    const pos = result.get('A');
    expect(pos.x).toBeGreaterThanOrEqual(40);
    expect(pos.x).toBeLessThanOrEqual(500);
    expect(pos.y).toBeGreaterThanOrEqual(40);
    expect(pos.y).toBeLessThanOrEqual(400);
  });
});

describe('LayoutEngine.removeOverlaps', () => {
  it('returns same positions when no overlaps', () => {
    const positions = new Map([
      ['A', { x: 100, y: 100 }],
      ['B', { x: 300, y: 300 }],
    ]);
    const result = LayoutEngine.removeOverlaps(positions);
    // Should not move nodes that are already far apart
    expect(result.get('A').x).toBe(100);
    expect(result.get('A').y).toBe(100);
    expect(result.get('B').x).toBe(300);
    expect(result.get('B').y).toBe(300);
  });

  it('separates overlapping nodes', () => {
    const positions = new Map([
      ['A', { x: 100, y: 100 }],
      ['B', { x: 110, y: 100 }], // 10px apart, below 80px threshold
    ]);
    const result = LayoutEngine.removeOverlaps(positions);
    const distAfter = Math.sqrt(
      (result.get('A').x - result.get('B').x) ** 2 +
      (result.get('A').y - result.get('B').y) ** 2
    );
    expect(distAfter).toBeGreaterThanOrEqual(80); // default minDistance
  });

  it('handles nodes at exact same position', () => {
    const positions = new Map([
      ['A', { x: 200, y: 200 }],
      ['B', { x: 200, y: 200 }],
    ]);
    const result = LayoutEngine.removeOverlaps(positions);
    // At minimum the algorithm runs without error; the distance
    // uses || 0.1 to avoid division by zero so nodes get pushed apart
    const posA = result.get('A');
    const posB = result.get('B');
    expect(typeof posA.x).toBe('number');
    expect(typeof posB.x).toBe('number');
  });

  it('constrains to bounds with padding', () => {
    const positions = new Map([
      ['A', { x: 10, y: 10 }],
      ['B', { x: 15, y: 10 }],
    ]);
    const result = LayoutEngine.removeOverlaps(positions, { padding: 40, width: 500, height: 400 });
    // Nodes should not go below padding
    expect(result.get('A').x).toBeGreaterThanOrEqual(40);
    expect(result.get('A').y).toBeGreaterThanOrEqual(40);
  });

  it('handles single node (no pairs to check)', () => {
    const positions = new Map([['A', { x: 100, y: 100 }]]);
    const result = LayoutEngine.removeOverlaps(positions);
    expect(result.get('A')).toEqual({ x: 100, y: 100 });
  });

  it('respects custom minDistance', () => {
    const positions = new Map([
      ['A', { x: 100, y: 100 }],
      ['B', { x: 140, y: 100 }], // 40px apart
    ]);
    // With minDistance 30, they should NOT be pushed apart
    const result = LayoutEngine.removeOverlaps(positions, { minDistance: 30 });
    expect(result.get('A').x).toBe(100);
    expect(result.get('B').x).toBe(140);
  });
});
