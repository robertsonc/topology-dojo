import { describe, it, expect } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Site model on nodes', () => {
  it('stores site property on a node', () => {
    const topo = new TopologyDesigner({ title: 'Site Test' });
    topo.node('slc-router1', { type: 'router', x: 100, y: 100, label: 'SLC Router', site: 'slc' });
    const node = topo._nodes.get('slc-router1');
    expect(node.site).toBe('slc');
  });

  it('preserves site property through toJSON/fromJSON', () => {
    const topo = new TopologyDesigner({ title: 'Site Test' });
    topo.node('slc-sw1', { type: 'switch', x: 100, y: 100, label: 'SLC Switch', site: 'slc' });
    topo.node('nyc-sw1', { type: 'switch', x: 300, y: 100, label: 'NYC Switch', site: 'nyc' });
    topo.node('plain', { type: 'host', x: 500, y: 100, label: 'No Site' });

    const json = topo.toJSON();
    expect(json.nodes['slc-sw1'].site).toBe('slc');
    expect(json.nodes['nyc-sw1'].site).toBe('nyc');
    expect(json.nodes['plain'].site).toBeUndefined();

    const topo2 = new TopologyDesigner({ title: 'Restore' });
    topo2.fromJSON(json);
    expect(topo2._nodes.get('slc-sw1').site).toBe('slc');
    expect(topo2._nodes.get('nyc-sw1').site).toBe('nyc');
    expect(topo2._nodes.get('plain').site).toBeUndefined();
  });

  it('allows site to be undefined/absent', () => {
    const topo = new TopologyDesigner({ title: 'Site Test' });
    topo.node('A', { type: 'router', x: 100, y: 100, label: 'Router' });
    const node = topo._nodes.get('A');
    expect(node.site).toBeUndefined();
  });
});

describe('Zone step-awareness during choreography', () => {
  function buildTopoWithSitesAndZones() {
    const topo = new TopologyDesigner({ title: 'Zone Choreo Test', viewBox: '0 0 1000 600' });

    // SLC site nodes
    topo.node('slc-router', { type: 'router', x: 100, y: 100, label: 'SLC Router', site: 'slc' });
    topo.node('slc-switch', { type: 'switch', x: 200, y: 200, label: 'SLC Switch', site: 'slc' });
    topo.node('slc-host', { type: 'host', x: 300, y: 300, label: 'SLC Host', site: 'slc' });

    // NYC site nodes
    topo.node('nyc-router', { type: 'router', x: 500, y: 100, label: 'NYC Router', site: 'nyc' });
    topo.node('nyc-switch', { type: 'switch', x: 600, y: 200, label: 'NYC Switch', site: 'nyc' });

    // Links
    topo.link('l1', { type: 'line', from: 'slc-router', to: 'slc-switch' });
    topo.link('l2', { type: 'line', from: 'slc-switch', to: 'slc-host' });
    topo.link('l3', { type: 'line', from: 'nyc-router', to: 'nyc-switch' });
    topo.link('l4', { type: 'line', from: 'slc-router', to: 'nyc-router' }); // inter-site

    // Zones
    topo.zone('z-slc', { label: 'Salt Lake City', nodes: ['slc-router', 'slc-switch', 'slc-host'], color: '#01a982' });
    topo.zone('z-nyc', { label: 'New York City', nodes: ['nyc-router', 'nyc-switch'], color: '#65aef9' });

    return topo;
  }

  it('zone becomes visible when all member nodes are shown in choreography', () => {
    const topo = buildTopoWithSitesAndZones();

    // Create choreography: step 1 shows only slc-router and slc-switch (not slc-host)
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Partial SLC', goal: 'Show partial SLC',
      focus: [],
      phases: [{ show: ['slc-router', 'slc-switch'], diff: 'Partial SLC' }],
    });
    // step 2 shows slc-host (completing the zone)
    topo.addStep('s2', {
      act: 'a1', name: 'Complete SLC', goal: 'Complete SLC site',
      focus: [],
      phases: [{ show: ['slc-host'], diff: 'SLC Host' }],
    });
    topo._buildIndex();

    // At step 1: z-slc should be visible (it has at least one visible node)
    topo.step = 1;
    let svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z-slc"');
    // z-nyc should NOT be visible (no NYC nodes shown yet)
    expect(svg).not.toContain('data-zone-id="z-nyc"');

    // At step 2: both zones' rendering depends on node visibility
    topo.step = 2;
    svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z-slc"');
    // z-nyc still not visible
    expect(svg).not.toContain('data-zone-id="z-nyc"');
  });

  it('zones render correctly at step 0 when no steps defined', () => {
    const topo = new TopologyDesigner({ title: 'No Steps', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100, label: 'A', site: 'hq' });
    topo.node('B', { type: 'switch', x: 200, y: 100, label: 'B', site: 'hq' });
    topo.zone('z1', { label: 'HQ Zone', nodes: ['A', 'B'] });
    topo._buildIndex();
    topo.step = 0;
    const svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z1"');
    expect(svg).toContain('HQ Zone');
  });
});

describe('Zone visibility tracks node reveal order', () => {
  it('zone appears at the step where its first member node is shown', () => {
    const topo = new TopologyDesigner({ title: 'Zone Order Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.node('B', { type: 'switch', x: 300, y: 100 });
    topo.node('C', { type: 'host', x: 500, y: 100 });
    topo.zone('z1', { label: 'Zone 1', nodes: ['A', 'B'] });
    topo.zone('z2', { label: 'Zone 2', nodes: ['C'] });

    topo.act('a1', { label: 'Test' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', focus: [], phases: [{ show: ['A'], diff: 'A' }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: '', focus: [], phases: [{ show: ['B'], diff: 'B' }] });
    topo.addStep('s3', { act: 'a1', name: 'S3', goal: '', focus: [], phases: [{ show: ['C'], diff: 'C' }] });
    topo._buildIndex();

    // Step 0: nothing visible
    topo.step = 0;
    let svg = topo._renderSVG();
    expect(svg).not.toContain('data-zone-id="z1"');
    expect(svg).not.toContain('data-zone-id="z2"');

    // Step 1: A visible → z1 appears (has at least one visible member)
    topo.step = 1;
    svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z1"');
    expect(svg).not.toContain('data-zone-id="z2"');

    // Step 3: C visible → z2 appears
    topo.step = 3;
    svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z1"');
    expect(svg).toContain('data-zone-id="z2"');
  });
});
