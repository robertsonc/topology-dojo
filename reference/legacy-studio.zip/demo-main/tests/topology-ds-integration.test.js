import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// Mock window.matchMedia for jsdom
window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

// Mock scrollIntoView (not available in jsdom)
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: build a full topology and mount it into a container div
 */
function buildAndMount() {
  const container = document.createElement('div');
  container.id = 'test-container';
  document.body.appendChild(container);

  const topo = new TopologyDesigner({
    title: 'Test Topo',
    subtitle: 'Integration Test',
    viewBox: '0 0 800 500',
    phaseMs: 100,
    mode: 'manual',
  });

  topo.node('R1', { type: 'router', x: 200, y: 250, label: 'Router 1' });
  topo.node('SW1', { type: 'switch', x: 500, y: 250, label: 'Switch 1' });
  topo.node('FW1', { type: 'firewall', x: 350, y: 100, label: 'Firewall' });
  topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982' });
  topo.link('r1-fw1', { type: 'tunnel', from: 'R1', to: 'FW1', color: '#65aef9', label: 'IPsec' });

  topo.act('a1', { label: 'Act 1 · Network', color: '#01a982', intro: ['Setting up the network.'] });
  topo.act('a2', { label: 'Act 2 · Security', color: '#fc6161', intro: ['Adding security.'] });

  topo.addStep('deploy', {
    act: 'a1', name: 'Deploy Devices', goal: 'Place devices.',
    focus: ['R1', 'SW1'],
    phases: [
      { show: ['R1'], diff: 'Router deployed' },
      { show: ['SW1', 'r1-sw1'], diff: 'Switch connected' },
    ],
  });
  topo.addStep('secure', {
    act: 'a2', name: 'Add Firewall', goal: 'Secure the path.',
    focus: ['FW1'],
    phases: [
      { show: ['FW1', 'r1-fw1'], diff: 'Firewall added' },
    ],
  });

  topo.glossary([
    { t: 'IPsec', d: 'Internet Protocol Security' },
    { t: 'ZTNA', d: 'Zero Trust Network Access' },
  ]);

  topo.mount('test-container');
  return { topo, container };
}

describe('Mount & Scaffold', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('sets _mounted to true', () => {
    expect(topo._mounted).toBe(true);
  });

  it('creates topbar with title', () => {
    const topbar = container.querySelector('.tds-topbar');
    expect(topbar).not.toBeNull();
    expect(topbar.textContent).toContain('Test Topo');
  });

  it('creates sidebar', () => {
    const sidebar = container.querySelector('#tds-sidebar');
    expect(sidebar).not.toBeNull();
  });

  it('creates SVG diagram', () => {
    const svg = container.querySelector('#tds-diagram');
    expect(svg).not.toBeNull();
    expect(svg.tagName.toLowerCase()).toBe('svg');
  });

  it('creates narrator panel', () => {
    const narrator = container.querySelector('#tds-narrator');
    expect(narrator).not.toBeNull();
  });

  it('creates control buttons', () => {
    expect(container.querySelector('#tds-resetBtn')).not.toBeNull();
    expect(container.querySelector('#tds-prevBtn')).not.toBeNull();
    expect(container.querySelector('#tds-playBtn')).not.toBeNull();
    expect(container.querySelector('#tds-nextBtn')).not.toBeNull();
  });

  it('creates toolbar with mode selector', () => {
    const modeSel = container.querySelector('#tds-modeSel');
    expect(modeSel).not.toBeNull();
    expect(modeSel.value).toBe('manual');
  });

  it('creates temporal mode selector', () => {
    const sel = container.querySelector('#tds-temporalSel');
    expect(sel).not.toBeNull();
  });

  it('creates glossary button when glossary exists', () => {
    const btn = container.querySelector('#tds-glossBtn');
    expect(btn).not.toBeNull();
  });

  it('creates glossary modal', () => {
    const modal = container.querySelector('#tds-modalBg');
    expect(modal).not.toBeNull();
  });

  it('creates progress pips', () => {
    const pips = container.querySelector('#tds-progress');
    expect(pips).not.toBeNull();
    expect(pips.children.length).toBeGreaterThan(0);
  });

  it('handles mount to non-existent container', () => {
    const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const t = new TopologyDesigner();
    t.mount('nonexistent');
    expect(t._mounted).toBe(false);
    errSpy.mockRestore();
  });

  it('applies CSS timings', () => {
    const root = document.documentElement;
    expect(root.style.getPropertyValue('--tds-phase-ms')).toBe('100ms');
  });
});

describe('Sidebar', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('shows act headers', () => {
    const sidebar = container.querySelector('#tds-sidebar');
    expect(sidebar.textContent).toContain('Act 1');
    expect(sidebar.textContent).toContain('Act 2');
  });

  it('shows step entries', () => {
    const sidebar = container.querySelector('#tds-sidebar');
    expect(sidebar.textContent).toContain('Deploy Devices');
    expect(sidebar.textContent).toContain('Add Firewall');
  });
});

describe('Narrator', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('shows step info after navigating', () => {
    topo.next();
    const narrator = container.querySelector('#tds-narrator');
    expect(narrator.textContent).toContain('Deploy Devices');
  });
});

describe('Playback Control Buttons', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('next button advances step', () => {
    const before = topo.step;
    container.querySelector('#tds-nextBtn').click();
    expect(topo.step).toBe(before + 1);
  });

  it('prev button goes back', () => {
    topo.goTo(2);
    container.querySelector('#tds-prevBtn').click();
    expect(topo.step).toBe(1);
  });

  it('reset button goes to step 0', () => {
    topo.goTo(2);
    container.querySelector('#tds-resetBtn').click();
    expect(topo.step).toBe(0);
  });

  it('play button starts playback', () => {
    container.querySelector('#tds-playBtn').click();
    expect(topo.playing).toBe(true);
    topo.pause(); // cleanup
  });
});

describe('Keyboard Shortcuts', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  function pressKey(key) {
    document.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true }));
  }

  it('ArrowRight advances step', () => {
    const before = topo.step;
    pressKey('ArrowRight');
    expect(topo.step).toBe(before + 1);
  });

  it('ArrowLeft goes back', () => {
    topo.goTo(2);
    pressKey('ArrowLeft');
    expect(topo.step).toBe(1);
  });

  it('Home resets to step 0', () => {
    topo.goTo(2);
    pressKey('Home');
    expect(topo.step).toBe(0);
  });

  it('End jumps to last step', () => {
    pressKey('End');
    expect(topo.step).toBe(topo._steps.length);
  });

  it('Space toggles play/pause', () => {
    pressKey(' ');
    expect(topo.playing).toBe(true);
    pressKey(' ');
    expect(topo.playing).toBe(false);
  });

  it('I toggles node IDs', () => {
    const before = topo.showNodeIds;
    pressKey('I');
    expect(topo.showNodeIds).toBe(!before);
  });
});

describe('toggleNodeIds', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('toggles showNodeIds', () => {
    expect(topo.showNodeIds).toBe(false);
    topo.toggleNodeIds();
    expect(topo.showNodeIds).toBe(true);
    topo.toggleNodeIds();
    expect(topo.showNodeIds).toBe(false);
  });

  it('accepts explicit value', () => {
    topo.toggleNodeIds(true);
    expect(topo.showNodeIds).toBe(true);
    topo.toggleNodeIds(false);
    expect(topo.showNodeIds).toBe(false);
  });
});

describe('setMode', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('changes interactive mode', () => {
    topo.setMode('link');
    expect(topo.interactiveMode).toBe('link');
  });

  it('calls onModeChange callback', () => {
    const cb = vi.fn();
    topo._onModeChange = cb;
    topo.setMode('link');
    expect(cb).toHaveBeenCalledWith('link');
  });
});

describe('URL State', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('updates URL on step change', () => {
    const spy = vi.spyOn(window.history, 'replaceState').mockImplementation(() => {});
    topo.next();
    // _updateURL is called within render()
    expect(spy).toHaveBeenCalled();
    spy.mockRestore();
  });
});

describe('Temporal Digital Twin (DOM integration)', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('temporal selector changes mode', () => {
    const sel = container.querySelector('#tds-temporalSel');
    sel.value = 'operational';
    sel.dispatchEvent(new Event('change'));
    expect(topo.temporalMode).toBe('operational');
  });
});

describe('Isometric Tilt (DOM integration)', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('tilt button toggles isometric', () => {
    const btn = container.querySelector('#tds-isoBtn');
    btn.click();
    expect(topo.isometricMode).toBe(true);
    btn.click();
    expect(topo.isometricMode).toBe(false);
  });
});

describe('Security Mode (DOM integration)', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('security button toggles security mode', () => {
    const btn = container.querySelector('#tds-secBtn');
    btn.click();
    expect(topo._securityMode).toBe(true);
    btn.click();
    expect(topo._securityMode).toBe(false);
  });
});

describe('Glossary Modal', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('opens glossary on button click', () => {
    const btn = container.querySelector('#tds-glossBtn');
    btn.click();
    const modal = container.querySelector('#tds-modalBg');
    expect(modal.style.display).not.toBe('none');
  });

  it('displays glossary terms', () => {
    const btn = container.querySelector('#tds-glossBtn');
    btn.click();
    const body = container.querySelector('#tds-glossaryBody');
    expect(body.textContent).toContain('IPsec');
    expect(body.textContent).toContain('ZTNA');
  });
});

describe('Theme integration', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('applyTheme does not throw for valid preset', () => {
    expect(() => topo.applyTheme('default-dark')).not.toThrow();
  });

  it('applyTheme handles string preset name', () => {
    expect(() => topo.applyTheme('midnight')).not.toThrow();
  });
});

describe('Layout integration', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('autoLayout repositions nodes', () => {
    const origX = topo._nodes.get('R1').x;
    topo.autoLayout('circular');
    // Position may or may not change depending on algorithm, but it shouldn't throw
    expect(topo._nodes.get('R1').x).toBeDefined();
  });

  it('autoLayout with force-directed', () => {
    expect(() => topo.autoLayout('force-directed')).not.toThrow();
  });

  it('autoLayout with hierarchical', () => {
    expect(() => topo.autoLayout('hierarchical')).not.toThrow();
  });

  it('autoLayout with grid', () => {
    expect(() => topo.autoLayout('grid')).not.toThrow();
  });
});

describe('Template integration', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('importFromText creates nodes', () => {
    topo.importFromText('A[Router]::router --> B[Switch]::switch', { clearFirst: true });
    expect(topo._nodes.size).toBeGreaterThan(0);
  });

  it('loadTemplate creates nodes', () => {
    topo.loadTemplate('hub-spoke', { clearFirst: true });
    expect(topo._nodes.size).toBeGreaterThan(0);
  });
});

describe('Serialization (mount integration)', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('toJSON includes all topology data', () => {
    const json = topo.toJSON();
    expect(json.title).toBe('Test Topo');
    expect(json.nodes).toBeDefined();
    expect(json.links).toBeDefined();
    expect(json.acts).toBeDefined();
    expect(json.steps).toBeDefined();
  });

  it('fromJSON restores topology', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json);
    expect(topo2._nodes.size).toBe(json.nodes ? Object.keys(json.nodes).length : topo._nodes.size);
  });
});

describe('Render pipeline hooks', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('fires beforeRender hook', () => {
    const cb = vi.fn();
    topo.on('beforeRender', cb);
    topo.render();
    expect(cb).toHaveBeenCalled();
  });

  it('fires afterRender hook', () => {
    const cb = vi.fn();
    topo.on('afterRender', cb);
    topo.render();
    expect(cb).toHaveBeenCalled();
  });

  it('fires onStepChange hook on step change', () => {
    const cb = vi.fn();
    topo.on('onStepChange', cb);
    topo.next();
    expect(cb).toHaveBeenCalledWith(expect.objectContaining({ prevStep: expect.any(Number), step: expect.any(Number) }));
  });
});

describe('showDuring', () => {
  it('stores visibility ranges', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: '', phases: [{ show: [], diff: '' }] });
    topo.showDuring(['elem1'], { from: 's1', until: 's2' });
    expect(topo._persistentElements).toBeDefined();
    expect(topo._persistentElements.length).toBeGreaterThan(0);
  });
});

describe('removeAnchor', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.anchor('anc1', { x: 300, y: 200 });
    topo.link('l1', { type: 'line', from: 'A', to: 'anc1' });
  });

  it('removes anchor and dependent links', () => {
    topo.removeAnchor('anc1');
    expect(topo._anchors.has('anc1')).toBe(false);
    expect(topo._links.has('l1')).toBe(false);
  });
});

describe('SVG diffing / incremental render', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('_computeDirtyElements returns elements that changed', () => {
    topo.goTo(1);
    const dirty = topo._computeDirtyElements(0, 1);
    expect(dirty).toBeDefined();
    // Should contain newly shown elements
    expect(dirty.size).toBeGreaterThan(0);
  });

  it('incremental render is attempted for single-step changes', () => {
    topo.goTo(1);
    // Step forward by 1 to trigger incremental path
    topo.next();
    // Should not throw and should render correctly
    const svg = document.querySelector('#tds-diagram');
    expect(svg.innerHTML.length).toBeGreaterThan(0);
  });
});

describe('Ambient atmosphere', () => {
  it('renders ambient effects in SVG', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('tds-ambientGreen');
  });
});

describe('Reduced motion', () => {
  it('suppresses animations when reduced motion active', () => {
    const origMatch = window.matchMedia;
    window.matchMedia = () => ({ matches: true, addListener: () => {}, removeListener: () => {} });
    const topo = new TopologyDesigner();
    expect(topo.reducedMotion).toBe(true);
    window.matchMedia = origMatch;
  });
});

describe('Play behavior', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('play() in manual mode switches to auto', () => {
    topo.mode = 'manual';
    topo.playing = false;
    topo.play();
    expect(topo.mode).toBe('auto');
    expect(topo.playing).toBe(true);
  });

  it('pause() stops playback', () => {
    topo.play();
    topo.pause();
    expect(topo.playing).toBe(false);
  });
});

describe('Choreography smoothing', () => {
  let topo;

  beforeEach(() => {
    const result = buildAndMount();
    topo = result.topo;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('setNodePositions stores keyframes', () => {
    topo.setNodePositions('R1', { 2: { x: 400, y: 400 } });
    const node = topo._nodes.get('R1');
    expect(node._positions).toBeDefined();
    expect(node._positions[2]).toEqual({ x: 400, y: 400 });
  });

  it('applies position keyframes during render when step changes', () => {
    // Use step index 1 (first step) which maps to step number 1
    topo.setNodePositions('R1', { 1: { x: 400, y: 400 } });
    // Force step to 0, then advance to 1 to trigger position application
    topo.step = 0;
    topo._lastRenderedStep = -1;
    topo.step = 1;
    topo.render();
    const node = topo._nodes.get('R1');
    expect(node.x).toBe(400);
    expect(node.y).toBe(400);
  });
});
