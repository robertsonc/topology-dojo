import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: create a basic topo with notes on steps.
 */
function buildTopo() {
  const topo = new TopologyDesigner({ title: 'Presentation Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 250, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 600, y: 250, label: 'Node B' });
  topo.link('link1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step One', goal: 'Intro',
    notes: 'Talk about the architecture overview',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'All visible' }],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step Two', goal: 'Details',
    notes: 'Explain the link between A and B',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'Same' }],
  });
  topo.addStep('s3', {
    act: 'a1', name: 'Step Three', goal: 'Wrap up',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'Same' }],
  });
  return topo;
}

// ── Notes serialization ──
describe('Step notes serialization', () => {
  it('addStep stores notes on the step config', () => {
    const topo = buildTopo();
    expect(topo._steps[0].notes).toBe('Talk about the architecture overview');
    expect(topo._steps[1].notes).toBe('Explain the link between A and B');
    expect(topo._steps[2].notes).toBeUndefined();
  });

  it('toJSON includes notes when present', () => {
    const topo = buildTopo();
    topo._buildIndex();
    const json = topo.toJSON();
    expect(json.steps[0].notes).toBe('Talk about the architecture overview');
    expect(json.steps[1].notes).toBe('Explain the link between A and B');
    expect(json.steps[2].notes).toBeUndefined();
  });

  it('fromJSON round-trips notes correctly', () => {
    const topo = buildTopo();
    topo._buildIndex();
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'RT', viewBox: '0 0 800 500' });
    topo2.fromJSON(json);
    expect(topo2._steps[0].notes).toBe('Talk about the architecture overview');
    expect(topo2._steps[1].notes).toBe('Explain the link between A and B');
    expect(topo2._steps[2].notes).toBeUndefined();
  });
});

// ── present() / exitPresentation() ──
describe('Presentation mode', () => {
  let topo;

  beforeEach(() => {
    document.body.innerHTML = '<div id="tds-present-host"></div>';
    topo = buildTopo();
    topo.mount('tds-present-host');
  });

  it('present() sets _presenting flag and adds .tds-presenting class', () => {
    topo.present();
    expect(topo._presenting).toBe(true);
    const root = document.querySelector('.tds-root');
    expect(root.classList.contains('tds-presenting')).toBe(true);
  });

  it('present() creates step counter overlay', () => {
    topo.present();
    const counter = document.getElementById('tds-presentCounter');
    expect(counter).not.toBeNull();
    expect(counter.className).toBe('tds-present-counter');
  });

  it('present() shows correct step counter text', () => {
    topo.step = 0;
    topo.present();
    const counter = document.getElementById('tds-presentCounter');
    expect(counter.textContent).toContain('0 / 3');
  });

  it('step counter updates after stepping', () => {
    topo.present();
    topo.step = 2;
    topo.render();
    const counter = document.getElementById('tds-presentCounter');
    expect(counter.textContent).toContain('2 / 3');
  });

  it('present({ showNotes: true }) creates notes panel', () => {
    topo.present({ showNotes: true });
    const notes = document.getElementById('tds-presenterNotes');
    expect(notes).not.toBeNull();
    expect(notes.className).toBe('tds-presenter-notes');
  });

  it('presenter notes show step notes content', () => {
    topo.step = 1;
    topo.present({ showNotes: true });
    // Force UI update
    topo._updatePresentUI();
    const notes = document.getElementById('tds-presenterNotes');
    expect(notes.textContent).toContain('Talk about the architecture overview');
  });

  it('presenter notes show "No notes" for steps without notes', () => {
    topo.step = 3;
    topo.present({ showNotes: true });
    topo._updatePresentUI();
    const notes = document.getElementById('tds-presenterNotes');
    expect(notes.textContent).toContain('No notes for this step');
  });

  it('present({ autoAdvance: 500 }) creates progress bar', () => {
    topo.present({ autoAdvance: 500 });
    const bar = document.querySelector('.tds-present-progress');
    expect(bar).not.toBeNull();
    clearTimeout(topo._presentTimer);
    clearInterval(topo._presentProgressInterval);
  });

  it('exitPresentation() restores UI', () => {
    topo.present({ showNotes: true });
    expect(topo._presenting).toBe(true);

    topo.exitPresentation();
    expect(topo._presenting).toBe(false);

    const root = document.querySelector('.tds-root');
    expect(root.classList.contains('tds-presenting')).toBe(false);

    // Overlays removed
    expect(document.getElementById('tds-presentCounter')).toBeNull();
    expect(document.getElementById('tds-presenterNotes')).toBeNull();
  });

  it('exitPresentation() is idempotent', () => {
    topo.present();
    topo.exitPresentation();
    topo.exitPresentation(); // should not throw
    expect(topo._presenting).toBe(false);
  });

  it('present() is idempotent when already presenting', () => {
    topo.present();
    topo.present(); // should not create duplicate overlays
    const counters = document.querySelectorAll('.tds-present-counter');
    expect(counters.length).toBe(1);
  });

  it('present() returns this for chaining', () => {
    const result = topo.present();
    expect(result).toBe(topo);
    topo.exitPresentation();
  });

  it('exitPresentation() returns this for chaining', () => {
    topo.present();
    const result = topo.exitPresentation();
    expect(result).toBe(topo);
  });
});

// ── Present button in toolbar ──
describe('Present button', () => {
  it('toolbar contains Present button', () => {
    document.body.innerHTML = '<div id="tds-present-btn-host"></div>';
    const topo = buildTopo();
    topo.mount('tds-present-btn-host');
    const btn = document.getElementById('tds-presentBtn');
    expect(btn).not.toBeNull();
    expect(btn.textContent).toContain('Present');
  });
});

// ── Constructor initializes presentation state ──
describe('Constructor defaults', () => {
  it('_presenting is false by default', () => {
    const topo = new TopologyDesigner({ title: 'T', viewBox: '0 0 100 100' });
    expect(topo._presenting).toBe(false);
    expect(topo._presentOpts).toBeNull();
  });
});
