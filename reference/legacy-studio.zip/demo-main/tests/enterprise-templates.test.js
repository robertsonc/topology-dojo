import { describe, it, expect } from 'vitest';

const TemplateParser = require('../design-system/modules/template-parser.js');

describe('Enterprise Templates (#180)', () => {

  const ENTERPRISE_IDS = ['sd-wan', 'ztna', 'campus', 'data-center', 'cloud-migration', 'simple'];

  it('all enterprise templates are registered', () => {
    const keys = Object.keys(TemplateParser.TEMPLATES);
    ENTERPRISE_IDS.forEach(id => {
      expect(keys).toContain(id);
    });
  });

  ENTERPRISE_IDS.forEach(templateId => {
    describe(templateId, () => {
      let result;

      // Generate once per template
      const template = TemplateParser.TEMPLATES[templateId];

      it('has name, description, icon, and generate function', () => {
        expect(template.name).toBeTruthy();
        expect(template.description).toBeTruthy();
        expect(template.icon).toBeTruthy();
        expect(typeof template.generate).toBe('function');
      });

      it('generate() returns valid nodes', () => {
        result = template.generate();
        expect(Array.isArray(result.nodes)).toBe(true);
        expect(result.nodes.length).toBeGreaterThan(0);
        result.nodes.forEach(n => {
          expect(n.id).toBeTruthy();
          expect(n.label).toBeTruthy();
          expect(n.type).toBeTruthy();
        });
      });

      it('generate() returns valid links', () => {
        result = template.generate();
        expect(Array.isArray(result.links)).toBe(true);
        expect(result.links.length).toBeGreaterThan(0);
        const nodeIds = new Set(result.nodes.map(n => n.id));
        result.links.forEach(l => {
          expect(l.from).toBeTruthy();
          expect(l.to).toBeTruthy();
          expect(nodeIds.has(l.from)).toBe(true);
          expect(nodeIds.has(l.to)).toBe(true);
        });
      });

      it('generate() returns valid acts and steps', () => {
        result = template.generate();
        expect(Array.isArray(result.acts)).toBe(true);
        expect(result.acts.length).toBeGreaterThan(0);
        result.acts.forEach(a => {
          expect(a.id).toBeTruthy();
          expect(a.label).toBeTruthy();
        });

        expect(Array.isArray(result.steps)).toBe(true);
        expect(result.steps.length).toBeGreaterThan(0);
        const actIds = new Set(result.acts.map(a => a.id));
        result.steps.forEach(s => {
          expect(s.id).toBeTruthy();
          expect(s.name).toBeTruthy();
          expect(s.goal).toBeTruthy();
          expect(actIds.has(s.act)).toBe(true);
          expect(Array.isArray(s.focus)).toBe(true);
          expect(Array.isArray(s.phases)).toBe(true);
          expect(s.phases.length).toBeGreaterThan(0);
          s.phases.forEach(p => {
            expect(Array.isArray(p.show)).toBe(true);
            expect(p.diff).toBeTruthy();
          });
        });
      });

      it('has a direction', () => {
        result = template.generate();
        expect(['TB', 'LR', 'BT', 'RL']).toContain(result.direction);
      });

      it('node IDs are unique', () => {
        result = template.generate();
        const ids = result.nodes.map(n => n.id);
        expect(new Set(ids).size).toBe(ids.length);
      });

      it('link IDs are unique when provided', () => {
        result = template.generate();
        const ids = result.links.filter(l => l.id).map(l => l.id);
        expect(new Set(ids).size).toBe(ids.length);
      });
    });
  });

  // Specific template validations

  describe('sd-wan specifics', () => {
    const result = TemplateParser.TEMPLATES['sd-wan'].generate();

    it('has 6 nodes (orchestrator + 2 DCs + 3 branches)', () => {
      expect(result.nodes).toHaveLength(6);
    });

    it('has 4 steps', () => {
      expect(result.steps).toHaveLength(4);
    });

    it('has zones for DCs and branches', () => {
      expect(result.zones).toHaveLength(2);
      expect(result.zones.find(z => z.id === 'zone-dc')).toBeDefined();
      expect(result.zones.find(z => z.id === 'zone-branch')).toBeDefined();
    });

    it('uses tunnel links for WAN connections', () => {
      const tunnels = result.links.filter(l => l.type === 'tunnel');
      expect(tunnels.length).toBeGreaterThanOrEqual(3);
    });
  });

  describe('ztna specifics', () => {
    const result = TemplateParser.TEMPLATES['ztna'].generate();

    it('has 7 nodes (IDP + PE + 2 apps + 3 users)', () => {
      expect(result.nodes).toHaveLength(7);
    });

    it('has 3 steps', () => {
      expect(result.steps).toHaveLength(3);
    });

    it('has identity provider and policy engine', () => {
      expect(result.nodes.find(n => n.id === 'IDP')).toBeDefined();
      expect(result.nodes.find(n => n.id === 'PE')).toBeDefined();
    });
  });

  describe('campus specifics', () => {
    const result = TemplateParser.TEMPLATES['campus'].generate();

    it('has 15 nodes (1 core + 2 dist + 4 access + 4 APs + 4 hosts)', () => {
      expect(result.nodes).toHaveLength(15);
    });

    it('has 3 steps', () => {
      expect(result.steps).toHaveLength(3);
    });

    it('has 3 zones (core, distribution, access)', () => {
      expect(result.zones).toHaveLength(3);
    });
  });

  describe('data-center specifics', () => {
    const result = TemplateParser.TEMPLATES['data-center'].generate();

    it('has 15 nodes (2 spine + 4 leaf + 8 servers + 1 storage)', () => {
      expect(result.nodes).toHaveLength(15);
    });

    it('has 3 steps', () => {
      expect(result.steps).toHaveLength(3);
    });

    it('has spine-leaf full mesh links (8 links)', () => {
      const fabricLinks = result.links.filter(l =>
        l.from.startsWith('SP') && l.to.startsWith('LF') ||
        l.from.startsWith('LF') && l.to.startsWith('SP')
      );
      expect(fabricLinks).toHaveLength(8);
    });

    it('has storage node', () => {
      expect(result.nodes.find(n => n.id === 'STOR')).toBeDefined();
    });
  });

  describe('cloud-migration specifics', () => {
    const result = TemplateParser.TEMPLATES['cloud-migration'].generate();

    it('has 9 nodes (5 on-prem + 4 cloud)', () => {
      expect(result.nodes).toHaveLength(9);
    });

    it('has 4 steps', () => {
      expect(result.steps).toHaveLength(4);
    });

    it('has VPN tunnel link between on-prem and cloud', () => {
      const vpn = result.links.find(l => l.type === 'tunnel');
      expect(vpn).toBeDefined();
      expect(vpn.label).toBe('VPN Tunnel');
    });

    it('has 2 zones (on-prem and cloud)', () => {
      expect(result.zones).toHaveLength(2);
    });
  });

  describe('simple specifics', () => {
    const result = TemplateParser.TEMPLATES['simple'].generate();

    it('has 5 nodes (1 router + 1 switch + 3 hosts)', () => {
      expect(result.nodes).toHaveLength(5);
    });

    it('has 2 steps', () => {
      expect(result.steps).toHaveLength(2);
    });

    it('has no zones (simple topology)', () => {
      expect(result.zones).toBeUndefined();
    });

    it('has 4 links', () => {
      expect(result.links).toHaveLength(4);
    });
  });
});
