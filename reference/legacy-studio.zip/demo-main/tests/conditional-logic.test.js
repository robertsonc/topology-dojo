import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Conditional Step Logic', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Conditional Test' });
    topo.reducedMotion = true;
    topo.node('A', { type: 'server', x: 100, y: 100, label: 'Server A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'Router B' })
        .node('FW', { type: 'firewall', x: 500, y: 100, label: 'Firewall' })
        .link('tunnel-01', { type: 'tunnel', from: 'A', to: 'B', color: '#01a982' })
        .link('tunnel-02', { type: 'tunnel', from: 'B', to: 'FW', color: '#65aef9' })
        .act('act1', { label: 'Act One', color: '#01a982' })
        .addStep('step1', {
          act: 'act1', name: 'Step One', goal: 'Show all',
          focus: [],
          phases: [{ show: ['A', 'B', 'FW', 'tunnel-01', 'tunnel-02'], diff: 'All appear' }],
        });
    topo._buildIndex();
  });

  describe('setState() / getState()', () => {
    it('stores and retrieves values', () => {
      const result = topo.setState('firewall.status', 'active');
      expect(result).toBe(topo); // returns this for chaining
      expect(topo.getState('firewall.status')).toBe('active');
    });

    it('returns undefined for unset variables', () => {
      expect(topo.getState('nonexistent')).toBeUndefined();
    });

    it('overwrites existing values', () => {
      topo.setState('mode', 'safe');
      topo.setState('mode', 'breach');
      expect(topo.getState('mode')).toBe('breach');
    });

    it('stores various value types', () => {
      topo.setState('count', 42);
      topo.setState('flag', true);
      topo.setState('name', 'test');
      expect(topo.getState('count')).toBe(42);
      expect(topo.getState('flag')).toBe(true);
      expect(topo.getState('name')).toBe('test');
    });
  });

  describe('_evaluateCondition()', () => {
    it('equality: x == "val"', () => {
      topo.setState('status', 'breached');
      expect(topo._evaluateCondition('status == "breached"')).toBe(true);
      expect(topo._evaluateCondition('status == "healthy"')).toBe(false);
    });

    it('inequality: x != "val"', () => {
      topo.setState('status', 'breached');
      expect(topo._evaluateCondition('status != "healthy"')).toBe(true);
      expect(topo._evaluateCondition('status != "breached"')).toBe(false);
    });

    it('greater than: x > 5', () => {
      topo.setState('latency', 10);
      expect(topo._evaluateCondition('latency > 5')).toBe(true);
      expect(topo._evaluateCondition('latency > 10')).toBe(false);
    });

    it('less than: x < 10', () => {
      topo.setState('latency', 3);
      expect(topo._evaluateCondition('latency < 10')).toBe(true);
      expect(topo._evaluateCondition('latency < 3')).toBe(false);
    });

    it('truthy check', () => {
      topo.setState('enabled', true);
      expect(topo._evaluateCondition('enabled')).toBe(true);

      topo.setState('disabled', false);
      expect(topo._evaluateCondition('disabled')).toBe(false);

      topo.setState('value', 'something');
      expect(topo._evaluateCondition('value')).toBe(true);

      expect(topo._evaluateCondition('unset')).toBe(false);
    });

    it('null/empty condition returns true', () => {
      expect(topo._evaluateCondition(null)).toBe(true);
      expect(topo._evaluateCondition(undefined)).toBe(true);
      expect(topo._evaluateCondition('')).toBe(true);
    });
  });

  describe('_evaluatePhaseConditions()', () => {
    it('changes link type when condition is met', () => {
      topo.setState('firewall.status', 'breached');
      const phase = {
        condition: 'firewall.status == "breached"',
        actions: [
          { changeLink: 'tunnel-01', toType: 'blocked', reason: 'Quarantine' },
        ],
      };
      topo._evaluatePhaseConditions(phase);
      expect(topo._links.get('tunnel-01').type).toBe('blocked');
      expect(topo._links.get('tunnel-01').reason).toBe('Quarantine');
    });

    it('changes node config when condition is met', () => {
      topo.setState('firewall.status', 'breached');
      const phase = {
        condition: 'firewall.status == "breached"',
        actions: [
          { changeNode: 'FW', cfg: { color: '#fc6161', label: 'BREACHED' } },
        ],
      };
      topo._evaluatePhaseConditions(phase);
      expect(topo._nodes.get('FW').color).toBe('#fc6161');
      expect(topo._nodes.get('FW').label).toBe('BREACHED');
    });

    it('skips actions when condition is not met', () => {
      topo.setState('firewall.status', 'healthy');
      const originalType = topo._links.get('tunnel-01').type;
      const phase = {
        condition: 'firewall.status == "breached"',
        actions: [
          { changeLink: 'tunnel-01', toType: 'blocked' },
        ],
      };
      topo._evaluatePhaseConditions(phase);
      expect(topo._links.get('tunnel-01').type).toBe(originalType);
    });

    it('sets state variables via actions', () => {
      topo.setState('firewall.status', 'breached');
      const phase = {
        condition: 'firewall.status == "breached"',
        actions: [
          { setState: { 'quarantine.active': true, 'alert.level': 'critical' } },
        ],
      };
      topo._evaluatePhaseConditions(phase);
      expect(topo.getState('quarantine.active')).toBe(true);
      expect(topo.getState('alert.level')).toBe('critical');
    });

    it('does nothing when phase has no condition', () => {
      const phase = { show: ['A'], diff: 'normal phase' };
      // Should not throw
      topo._evaluatePhaseConditions(phase);
      expect(topo._links.get('tunnel-01').type).toBe('tunnel');
    });

    it('handles multiple actions in a single phase', () => {
      topo.setState('firewall.status', 'breached');
      const phase = {
        condition: 'firewall.status == "breached"',
        actions: [
          { changeLink: 'tunnel-01', toType: 'blocked' },
          { changeLink: 'tunnel-02', color: '#fc6161' },
          { changeNode: 'FW', cfg: { color: '#fc6161' } },
          { setState: { 'incident.logged': true } },
        ],
      };
      topo._evaluatePhaseConditions(phase);
      expect(topo._links.get('tunnel-01').type).toBe('blocked');
      expect(topo._links.get('tunnel-02').color).toBe('#fc6161');
      expect(topo._nodes.get('FW').color).toBe('#fc6161');
      expect(topo.getState('incident.logged')).toBe(true);
    });
  });
});
