/**
 * Branch-coverage tests for api/server.js.
 *
 * Targets specific uncovered branches identified in the coverage report,
 * particularly: _graph-null fallback paths, node-not-found on neighbors,
 * error-handler non-413 paths, playback partial-update branches, step
 * deletion without a parent act, and meta endpoint catch branches.
 *
 * Uses a prototype-patching technique on TopologyDesigner to obtain
 * references to in-memory topology instances (the `store` Map is not
 * exported), allowing tests to set `_graph = null` and exercise the
 * fallback code paths.
 */
import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';

const app = require('../api/server.js');
const TopologyDesigner = require('../design-system/topology-ds.js');

let server;
let base;

async function req(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(`${base}${path}`, opts);
  let data = null;
  if (r.status !== 204) {
    const text = await r.text();
    data = text ? JSON.parse(text) : null;
  }
  return { status: r.status, body: data, headers: r.headers };
}

async function rawFetch(method, path, opts = {}) {
  const fetchOpts = { method, headers: { ...opts.headers } };
  if (opts.body !== undefined) {
    fetchOpts.body = opts.body;
    if (!fetchOpts.headers['Content-Type']) {
      fetchOpts.headers['Content-Type'] = 'application/json';
    }
  }
  return fetch(`${base}${path}`, fetchOpts);
}

function sampleTopology() {
  return {
    title: 'Branch Test',
    subtitle: 'branch coverage',
    viewBox: '0 0 1000 600',
    phaseMs: 500,
  };
}

async function createTopology(cfg = sampleTopology()) {
  const r = await req('POST', '/api/topologies', cfg);
  expect(r.status).toBe(201);
  expect(r.body.id).toBeDefined();
  return r.body.id;
}

/**
 * Capture the live TopologyDesigner instance from the in-memory store by
 * temporarily patching toJSON. The GET /api/topologies/:id route calls
 * td.toJSON(), so patching the prototype lets us grab the instance.
 */
async function captureTopology(topoId) {
  let captured = null;
  const orig = TopologyDesigner.prototype.toJSON;
  TopologyDesigner.prototype.toJSON = function () {
    captured = this;
    return orig.call(this);
  };
  try {
    await req('GET', `/api/topologies/${topoId}`);
  } finally {
    TopologyDesigner.prototype.toJSON = orig;
  }
  return captured;
}

/**
 * Null out _graph on a topology instance to exercise the fallback
 * code paths, and install the plain Map shims.
 */
function nullifyGraph(td) {
  td.__nodes = new Map(td._graph.rawNodes);
  td.__links = new Map(td._graph.rawLinks);
  td.__anchors = new Map(td._graph.rawAnchors);
  td._graph = null;
}

/**
 * Restore _graph on a topology instance from shim data.
 */
function restoreGraph(td) {
  const TopologyGraph = require('../design-system/core/graph.js');
  td._graph = new TopologyGraph();
  for (const [id, cfg] of td.__nodes) td._graph.addNode(id, cfg);
  for (const [id, cfg] of td.__links) td._graph.addLink(id, cfg);
  for (const [id, pos] of td.__anchors) td._graph.addAnchor(id, pos);
}

beforeAll(async () => {
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      base = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

afterAll(async () => {
  await new Promise((resolve) => server.close(() => resolve()));
});

// =====================================================================
//  _graph = null fallback branches
// =====================================================================

describe('Node delete -- _graph null fallback (lines 482-488)', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/N1`, { type: 'router', x: 10, y: 10 });
    await req('PUT', `/api/topologies/${id}/nodes/N2`, { type: 'host', x: 50, y: 50 });
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('deletes a node when _graph is null', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/nodes/N1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe(true);
  });

  it('returns 404 when node not found and _graph is null', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/nodes/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Node not found');
  });
});

describe('Neighbors -- node not found (line 518)', () => {
  let id;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
  });

  it('returns 404 when requesting neighbors of a non-existent node', async () => {
    const r = await req('GET', `/api/topologies/${id}/nodes/nonexistent/neighbors`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Node not found');
  });
});

describe('Neighbors -- _graph null (line 517)', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('returns 501 when _graph is null', async () => {
    const r = await req('GET', `/api/topologies/${id}/nodes/A/neighbors`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });
});

describe('Blast radius -- _graph null (line 549)', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('returns 501 when _graph is null', async () => {
    const r = await req('GET', `/api/topologies/${id}/nodes/A/blast-radius`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });
});

describe('Link delete -- _graph null fallback (lines 704-709)', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/A`, { type: 'router', x: 0, y: 0 });
    await req('PUT', `/api/topologies/${id}/nodes/B`, { type: 'host', x: 50, y: 0 });
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'A', to: 'B' });
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('deletes a link when _graph is null', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/links/L1`);
    expect(r.status).toBe(204);
  });

  it('returns 404 when link not found and _graph is null', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/links/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Link not found');
  });
});

describe('Anchor delete -- _graph null fallback (lines 829-832)', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    await req('PUT', `/api/topologies/${id}/anchors/P1`, { x: 10, y: 20 });
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('deletes an anchor when _graph is null', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/anchors/P1`);
    expect(r.status).toBe(200);
    expect(r.body.deleted).toBe(true);
    expect(r.body.removedLinks).toEqual([]);
  });
});

// =====================================================================
//  Analysis routes -- _graph null -> 501
// =====================================================================

describe('Graph analysis -- _graph null -> 501', () => {
  let id, td;

  beforeEach(async () => {
    id = await createTopology();
    td = await captureTopology(id);
    nullifyGraph(td);
  });

  afterEach(() => {
    if (td && !td._graph) restoreGraph(td);
  });

  it('GET /analysis returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/analysis`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('GET /paths returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/paths?from=A&to=B`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('GET /components returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/components`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('GET /bridges returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/bridges`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('GET /articulation-points returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/articulation-points`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('GET /bfs returns 501', async () => {
    const r = await req('GET', `/api/topologies/${id}/bfs?start=A`);
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });

  it('POST /subgraph returns 501', async () => {
    const r = await req('POST', `/api/topologies/${id}/subgraph`, { nodeIds: ['A'] });
    expect(r.status).toBe(501);
    expect(r.body.error).toBe('Graph module not loaded');
  });
});

// =====================================================================
//  Playback PUT -- partial update branches
// =====================================================================

describe('Playback PUT -- partial updates', () => {
  let id;

  beforeEach(async () => {
    id = await createTopology();
  });

  it('updates only mode (no step, no speedMs)', async () => {
    const r = await req('PUT', `/api/topologies/${id}/playback`, { mode: 'presenter' });
    expect(r.status).toBe(200);
    expect(r.body.mode).toBe('presenter');
    expect(r.body.step).toBe(0);
  });

  it('updates only speedMs (no step, no mode)', async () => {
    const r = await req('PUT', `/api/topologies/${id}/playback`, { speedMs: 5000 });
    expect(r.status).toBe(200);
    expect(r.body.speedMs).toBe(5000);
    expect(r.body.step).toBe(0);
    expect(r.body.mode).toBe('manual');
  });

  it('updates with empty body (no fields)', async () => {
    const r = await req('PUT', `/api/topologies/${id}/playback`, {});
    expect(r.status).toBe(200);
    expect(r.body.step).toBe(0);
    expect(r.body.mode).toBe('manual');
  });
});

// =====================================================================
//  Step deletion -- orphan step without parent act
// =====================================================================

describe('Step deletion -- act edge cases', () => {
  let id;

  beforeEach(async () => {
    id = await createTopology();
  });

  it('deletes a step whose act does not exist (orphan step)', async () => {
    await req('PUT', `/api/topologies/${id}/steps/orphan`, {
      act: 'nonexistent-act',
      name: 'Orphan Step',
    });
    const r = await req('DELETE', `/api/topologies/${id}/steps/orphan`);
    expect(r.status).toBe(204);
  });

  it('deletes a step when act exists but step not in act.steps array', async () => {
    await req('PUT', `/api/topologies/${id}/acts/a1`, { label: 'Act 1' });
    await req('PUT', `/api/topologies/${id}/steps/s1`, { act: 'a1', name: 'Step 1' });

    const td = await captureTopology(id);
    const act = td._acts.find(a => a.id === 'a1');
    if (act && act.steps) {
      act.steps = [];
    }

    const r = await req('DELETE', `/api/topologies/${id}/steps/s1`);
    expect(r.status).toBe(204);
  });
});

// =====================================================================
//  Error handler -- non-413 paths
// =====================================================================

describe('Error handler -- malformed JSON (400 path)', () => {
  it('returns 400 for syntactically invalid JSON body', async () => {
    const res = await rawFetch('POST', '/api/topologies', {
      body: '{invalid json!!!',
    });
    expect(res.status).toBe(400);
    const data = await res.json();
    expect(data.error).toBe('Invalid request');
    expect(data.requestId).toBeTruthy();
  });

  it('returns 400 for truncated JSON', async () => {
    const res = await rawFetch('PUT', '/api/topologies/fake-id/nodes/n1', {
      body: '{"type": "router", "x":',
    });
    expect(res.status).toBe(400);
    const data = await res.json();
    expect(data.error).toBe('Invalid request');
  });
});

// =====================================================================
//  Logging -- 500-level status code branch
// =====================================================================

describe('Logging -- 500-level status code branch', () => {
  it('triggers 500-level logging when route handler throws', async () => {
    const id = await createTopology();
    await captureTopology(id);

    const orig = TopologyDesigner.prototype.toJSON;
    TopologyDesigner.prototype.toJSON = function () {
      throw new Error('Simulated internal error');
    };
    try {
      const r = await req('GET', `/api/topologies/${id}`);
      expect(r.status).toBe(500);
      expect(r.body.error).toBe('Internal server error');
    } finally {
      TopologyDesigner.prototype.toJSON = orig;
    }
  });
});

// =====================================================================
//  Meta endpoints -- fallback catch branches
// =====================================================================

describe('Meta endpoints -- fallback catch branches', () => {
  it('node-types falls back when getRegisteredNodeTypes throws', async () => {
    const orig = TopologyDesigner.getRegisteredNodeTypes;
    TopologyDesigner.getRegisteredNodeTypes = () => { throw new Error('no registry'); };
    try {
      const r = await req('GET', '/api/meta/node-types');
      expect(r.status).toBe(200);
      expect(r.body.nodeTypes).toContain('ec');
      expect(r.body.nodeTypes).toContain('switch');
    } finally {
      TopologyDesigner.getRegisteredNodeTypes = orig;
    }
  });

  it('link-types falls back when getRegisteredLinkTypes throws', async () => {
    const orig = TopologyDesigner.getRegisteredLinkTypes;
    TopologyDesigner.getRegisteredLinkTypes = () => { throw new Error('no registry'); };
    try {
      const r = await req('GET', '/api/meta/link-types');
      expect(r.status).toBe(200);
      expect(r.body.linkTypes).toContain('line');
      expect(r.body.linkTypes).toContain('tunnel');
    } finally {
      TopologyDesigner.getRegisteredLinkTypes = orig;
    }
  });
});

// =====================================================================
//  Resource 404 paths
// =====================================================================

describe('Resource 404 paths', () => {
  let id;
  beforeEach(async () => { id = await createTopology(); });

  it('GET /links/:id returns 404 for non-existent link', async () => {
    const r = await req('GET', `/api/topologies/${id}/links/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Link not found');
    expect(r.body.id).toBe('ghost');
  });

  it('GET /anchors/:id returns 404 for non-existent anchor', async () => {
    const r = await req('GET', `/api/topologies/${id}/anchors/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Anchor not found');
    expect(r.body.id).toBe('ghost');
  });

  it('DELETE /acts/:id returns 404 for non-existent act', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/acts/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Act not found');
  });

  it('DELETE /steps/:id returns 404 for non-existent step', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/steps/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Step not found');
  });

  it('DELETE /nodes/:id returns 404 for non-existent node', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/nodes/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Node not found');
  });

  it('DELETE /links/:id returns 404 for non-existent link', async () => {
    const r = await req('DELETE', `/api/topologies/${id}/links/ghost`);
    expect(r.status).toBe(404);
    expect(r.body.error).toBe('Link not found');
  });

  it('PUT /nodes/:id/positions returns 404 for non-existent node', async () => {
    const r = await req('PUT', `/api/topologies/${id}/nodes/ghost/positions`, {
      '1': { x: 100, y: 200 },
    });
    expect(r.status).toBe(404);
  });
});

// =====================================================================
//  Import and export
// =====================================================================

describe('Import and export', () => {
  it('creates a topology from a full JSON export', async () => {
    const id = await createTopology();
    await req('PUT', `/api/topologies/${id}/nodes/R1`, { type: 'router', x: 10, y: 10 });
    await req('PUT', `/api/topologies/${id}/nodes/R2`, { type: 'host', x: 50, y: 50 });
    await req('PUT', `/api/topologies/${id}/links/L1`, { type: 'line', from: 'R1', to: 'R2' });

    const exported = await req('GET', `/api/topologies/${id}/export`);
    expect(exported.status).toBe(200);

    const imported = await req('POST', '/api/topologies/import', exported.body);
    expect(imported.status).toBe(201);
    expect(imported.body.nodeCount).toBe(2);
    expect(imported.body.linkCount).toBe(1);
  });
});
