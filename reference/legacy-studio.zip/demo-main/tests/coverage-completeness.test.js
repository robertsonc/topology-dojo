/**
 * Coverage-completeness invariants.
 *
 * Locks in two kinds of cross-cutting guarantees that the rest of the suite
 * does not assert directly:
 *
 * 1. Every public API listed in CLAUDE.md "Key APIs" actually exists on the
 *    TopologyDesigner class (instance + static surface). If a method is
 *    accidentally removed or renamed, these tests fail loudly so the entry in
 *    CLAUDE.md / USER-MANUAL.md gets updated alongside the rename.
 *
 * 2. The `/api/meta/*` endpoints' fallback catch blocks return their hardcoded
 *    type lists when TopologyDesigner.getRegisteredNodeTypes /
 *    getRegisteredLinkTypes throws. Without these tests the catch branches
 *    are unreachable from api-server.test.js (which only exercises the happy
 *    path) and the routes silently rot.
 */
import { describe, it, expect, vi, afterEach } from 'vitest';

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ══════════════════════════════════════════
   Public API surface invariants
   ══════════════════════════════════════════ */

describe('Public API surface — instance methods', () => {
  // The list mirrors CLAUDE.md "Key APIs". Adding a method here is a
  // deliberate signal that the surface should be documented and tested.
  const INSTANCE_METHODS = [
    'removeNode', 'removeLink', 'on', 'off',
    'toJSON', 'fromJSON',
    'importFromText', 'importDrawio',
    'loadTemplate', 'autoLayout',
    'validateTopology', 'validatePath',
    'getBlastRadius', 'setBlastRadiusNode',
    'setTemporalMode', 'setState', 'getState',
    'pathThrough', 'pathBetween',
    'setNodePositions',
    'zone', 'removeZone', 'getChildZones',
    'addWaypoint', 'removeWaypoint', 'clearWaypoints',
    'setLinkRouting',
    'layer', 'setLayers',
    'flowPath', 'setFlowPaths',
    'policyMarker', 'setPolicyMarkers',
    'exportPNG', 'exportSVG', 'exportPDF', 'exportStandaloneHTML',
    'present', 'exitPresentation',
    'enterLayoutEditMode', 'exitLayoutEditMode', 'toggleLayoutEditMode',
    'getPositionSnippet',
    'setTheme', 'getTheme', 'applyTheme',
    'toggleIsometric', 'toggleSecurityMode',
    'enableMobileQuickEdit', 'disableMobileQuickEdit',
    'copyEmbedCode',
    'getAnalytics', 'showAnalyticsDashboard',
    'showAIAssist',
  ];

  for (const name of INSTANCE_METHODS) {
    it(`TopologyDesigner.prototype.${name} is a function`, () => {
      expect(typeof TopologyDesigner.prototype[name]).toBe('function');
    });
  }
});

describe('Public API surface — static methods', () => {
  const STATIC_METHODS = [
    'registerNodeType',
    'registerLinkType',
    'getRegisteredNodeTypes',
    'getRegisteredLinkTypes',
    'getNodeTypeCatalog',
    'renderNodePreview',
  ];

  for (const name of STATIC_METHODS) {
    it(`TopologyDesigner.${name} is a function`, () => {
      expect(typeof TopologyDesigner[name]).toBe('function');
    });
  }

  it('getNodeTypeCatalog returns categorized node descriptors', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    expect(Array.isArray(catalog)).toBe(true);
    expect(catalog.length).toBeGreaterThan(0);
    for (const group of catalog) {
      expect(typeof group.category).toBe('string');
      expect(Array.isArray(group.types)).toBe(true);
      for (const t of group.types) {
        expect(typeof t.name).toBe('string');
        expect(typeof t.description).toBe('string');
      }
    }
  });

  it('renderNodePreview returns SVG markup for a known type', () => {
    const svg = TopologyDesigner.renderNodePreview('router', 64);
    expect(typeof svg).toBe('string');
    expect(svg).toMatch(/<svg[\s>]/);
  });
});

/* ══════════════════════════════════════════
   registerNodeType / registerLinkType — error branch
   ══════════════════════════════════════════ */

describe('registerNodeType / registerLinkType — invalid plugin', () => {
  let errSpy;
  afterEach(() => {
    if (errSpy) errSpy.mockRestore();
  });

  it('registerNodeType logs an error when plugin is neither function nor {render}', () => {
    errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    TopologyDesigner.registerNodeType('badNodePlugin', { not: 'valid' });
    expect(errSpy).toHaveBeenCalled();
    const msg = String(errSpy.mock.calls[0][0]);
    expect(msg).toContain('registerNodeType');
    // Sanity: plugin was not registered
    expect(TopologyDesigner.getRegisteredNodeTypes()).not.toContain('badNodePlugin');
  });

  it('registerLinkType logs an error when plugin is neither function nor {render}', () => {
    errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    TopologyDesigner.registerLinkType('badLinkPlugin', 42);
    expect(errSpy).toHaveBeenCalled();
    const msg = String(errSpy.mock.calls[0][0]);
    expect(msg).toContain('registerLinkType');
    expect(TopologyDesigner.getRegisteredLinkTypes()).not.toContain('badLinkPlugin');
  });

  it('registerNodeType supports the {render, validate, defaults} plugin shape and runs validate', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    TopologyDesigner.registerNodeType('validatedPlugin', {
      defaults: { color: '#fff' },
      validate: cfg => (cfg.color ? true : 'color is required'),
      render: (x, y, cfg) => `<rect x="${x}" y="${y}" fill="${cfg.color}"/>`,
    });
    // Trigger the rendered-by-engine path indirectly: registerNodeType returns
    // the class, and the plugin must be in the registered list.
    expect(TopologyDesigner.getRegisteredNodeTypes()).toContain('validatedPlugin');
    // Defaults should mean validate passes silently
    const renderFn = TopologyDesigner.NODE_TYPES.validatedPlugin;
    const svg = renderFn(10, 20, {});
    expect(svg).toContain('rect');
    expect(warnSpy).not.toHaveBeenCalled();
    warnSpy.mockRestore();
  });
});

/* ══════════════════════════════════════════
   /api/meta/* fallback catch branches
   ══════════════════════════════════════════ */

describe('/api/meta/* fallback when TopologyDesigner type registry throws', () => {
  // We mutate the static methods to throw, then re-import a fresh app instance
  // bound to those mutations and exercise the route. Vitest's module cache
  // makes the second require return the already-bound app, so we instead use
  // supertest-style direct invocation against the existing app: the route
  // closure references the live class, so swapping the static method is
  // enough.
  const app = require('../api/server.js');

  let server;
  let base;

  beforeAll(async () => {
    await new Promise(resolve => {
      server = app.listen(0, '127.0.0.1', () => {
        base = `http://127.0.0.1:${server.address().port}`;
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise(resolve => server.close(() => resolve()));
  });

  it('node-types returns hardcoded fallback when getRegisteredNodeTypes throws', async () => {
    const orig = TopologyDesigner.getRegisteredNodeTypes;
    TopologyDesigner.getRegisteredNodeTypes = () => {
      throw new Error('boom');
    };
    try {
      const r = await fetch(`${base}/api/meta/node-types`);
      expect(r.status).toBe(200);
      const body = await r.json();
      expect(Array.isArray(body.nodeTypes)).toBe(true);
      // Hardcoded fallback should still include the canonical built-ins.
      expect(body.nodeTypes).toEqual(expect.arrayContaining(['ec', 'switch', 'cloud', 'router']));
    } finally {
      TopologyDesigner.getRegisteredNodeTypes = orig;
    }
  });

  it('link-types returns hardcoded fallback when getRegisteredLinkTypes throws', async () => {
    const orig = TopologyDesigner.getRegisteredLinkTypes;
    TopologyDesigner.getRegisteredLinkTypes = () => {
      throw new Error('boom');
    };
    try {
      const r = await fetch(`${base}/api/meta/link-types`);
      expect(r.status).toBe(200);
      const body = await r.json();
      expect(Array.isArray(body.linkTypes)).toBe(true);
      expect(body.linkTypes).toEqual(
        expect.arrayContaining(['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'])
      );
    } finally {
      TopologyDesigner.getRegisteredLinkTypes = orig;
    }
  });
});

/* ══════════════════════════════════════════
   Health endpoint shape
   ══════════════════════════════════════════ */

describe('/api/health', () => {
  const app = require('../api/server.js');
  let server;
  let base;

  beforeAll(async () => {
    await new Promise(resolve => {
      server = app.listen(0, '127.0.0.1', () => {
        base = `http://127.0.0.1:${server.address().port}`;
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise(resolve => server.close(() => resolve()));
  });

  it('returns { status, topologyCount } matching the HealthStatus schema', async () => {
    const r = await fetch(`${base}/api/health`);
    expect(r.status).toBe(200);
    const body = await r.json();
    expect(body).toHaveProperty('status');
    expect(body.status).toBe('ok');
    expect(typeof body.topologyCount).toBe('number');
  });
});
