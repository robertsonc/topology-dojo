import { describe, it, expect, beforeEach } from 'vitest';

const TopologyGraph = require('../design-system/core/graph.js');

describe('TopologyGraph', () => {
  let g;

  beforeEach(() => {
    g = new TopologyGraph();
  });

  /* ══════════════════════════════════════════
     NODE OPERATIONS
     ══════════════════════════════════════════ */

  describe('nodes', () => {
    it('adds and retrieves a node', () => {
      g.addNode('A', { type: 'server', x: 100, y: 200 });
      expect(g.getNode('A')).toEqual({ id: 'A', type: 'server', x: 100, y: 200 });
    });

    it('sets id on the config automatically', () => {
      g.addNode('FOO', { type: 'host', x: 0, y: 0 });
      expect(g.getNode('FOO').id).toBe('FOO');
    });

    it('overwrites existing node with same id', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('A', { type: 'router', x: 50, y: 50 });
      expect(g.nodeCount).toBe(1);
      expect(g.getNode('A').type).toBe('router');
    });

    it('returns this for chaining', () => {
      expect(g.addNode('A', { type: 'server', x: 0, y: 0 })).toBe(g);
    });

    it('reports correct count', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 0, y: 0 });
      expect(g.nodeCount).toBe(2);
    });

    it('hasNode returns true for existing, false for missing', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      expect(g.hasNode('A')).toBe(true);
      expect(g.hasNode('Z')).toBe(false);
    });

    it('iterates nodes via entries()', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      const ids = [...g.nodes()].map(([id]) => id);
      expect(ids).toEqual(['A', 'B']);
    });

    it('removeNode deletes node and connected links', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.removeNode('A');
      expect(g.hasNode('A')).toBe(false);
      expect(g.hasLink('ab')).toBe(false);
      expect(g.hasNode('B')).toBe(true);
    });

    it('removeNode returns false for non-existent node', () => {
      expect(g.removeNode('Z')).toBe(false);
    });

    it('removeNode clears adjacency for the removed node', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      g.removeNode('B');

      // Removed node has no adjacency
      expect(g.getLinksForNode('B')).toEqual(new Set());
      // Links referencing B are also gone
      expect(g.hasLink('ab')).toBe(false);
      expect(g.hasLink('bc')).toBe(false);
    });

    it('removeNode causes neighbors to no longer list it', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      g.removeNode('B');

      // A and C should no longer see B as a neighbor
      expect(g.getNeighbors('A')).toEqual(new Set());
      expect(g.getNeighbors('C')).toEqual(new Set());
    });

    it('removeNode on non-existent id is a no-op (no crash)', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addLink('aa', { type: 'line', from: 'A', to: 'A' });
      expect(() => g.removeNode('nonexistent')).not.toThrow();
      expect(g.nodeCount).toBe(1);
      expect(g.linkCount).toBe(1);
    });
  });

  /* ══════════════════════════════════════════
     LINK OPERATIONS
     ══════════════════════════════════════════ */

  describe('links', () => {
    it('adds and retrieves a link', () => {
      g.addLink('l1', { type: 'tunnel', from: 'A', to: 'B', color: '#01a982' });
      expect(g.getLink('l1').type).toBe('tunnel');
      expect(g.getLink('l1').from).toBe('A');
    });

    it('sets id on config', () => {
      g.addLink('myLink', { type: 'line', from: 'X', to: 'Y' });
      expect(g.getLink('myLink').id).toBe('myLink');
    });

    it('returns this for chaining', () => {
      expect(g.addLink('l1', { type: 'line', from: 'A', to: 'B' })).toBe(g);
    });

    it('reports correct count', () => {
      g.addLink('l1', { type: 'line', from: 'A', to: 'B' });
      g.addLink('l2', { type: 'tunnel', from: 'B', to: 'C' });
      expect(g.linkCount).toBe(2);
    });

    it('removeLink deletes and returns true', () => {
      g.addLink('l1', { type: 'line', from: 'A', to: 'B' });
      expect(g.removeLink('l1')).toBe(true);
      expect(g.hasLink('l1')).toBe(false);
    });

    it('removeLink returns false for non-existent', () => {
      expect(g.removeLink('nope')).toBe(false);
    });

    it('removeLink updates adjacency for both endpoints', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });

      // Confirm adjacency exists before removal
      expect(g.getLinksForNode('A')).toEqual(new Set(['ab']));
      expect(g.getLinksForNode('B')).toEqual(new Set(['ab']));

      g.removeLink('ab');

      // Both endpoints should now have empty adjacency
      expect(g.getLinksForNode('A')).toEqual(new Set());
      expect(g.getLinksForNode('B')).toEqual(new Set());
      // Nodes themselves still exist
      expect(g.hasNode('A')).toBe(true);
      expect(g.hasNode('B')).toBe(true);
    });
  });

  /* ══════════════════════════════════════════
     ANCHOR OPERATIONS
     ══════════════════════════════════════════ */

  describe('anchors', () => {
    it('adds and retrieves an anchor', () => {
      g.addAnchor('pt1', { x: 500, y: 300 });
      expect(g.getAnchor('pt1')).toEqual({ x: 500, y: 300 });
    });

    it('returns this for chaining', () => {
      expect(g.addAnchor('pt1', { x: 0, y: 0 })).toBe(g);
    });

    it('removeAnchor deletes anchor and dependent links', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addAnchor('mid', { x: 50, y: 50 });
      g.addLink('l1', { type: 'line', from: 'A', to: 'mid' });
      g.addLink('l2', { type: 'line', from: 'mid', to: 'A' });
      g.addLink('l3', { type: 'line', from: 'A', to: 'A' }); // unrelated

      const removed = g.removeAnchor('mid');
      expect(removed).toEqual(['l1', 'l2']);
      expect(g.hasAnchor('mid')).toBe(false);
      expect(g.hasLink('l1')).toBe(false);
      expect(g.hasLink('l2')).toBe(false);
      expect(g.hasLink('l3')).toBe(true); // unrelated link survives
    });

    it('removeAnchor returns empty array for non-existent', () => {
      expect(g.removeAnchor('nope')).toEqual([]);
    });
  });

  /* ══════════════════════════════════════════
     POSITION RESOLUTION
     ══════════════════════════════════════════ */

  describe('resolvePosition', () => {
    it('resolves node position', () => {
      g.addNode('A', { type: 'server', x: 100, y: 200 });
      expect(g.resolvePosition('A')).toEqual({ x: 100, y: 200 });
    });

    it('resolves anchor position', () => {
      g.addAnchor('pt1', { x: 50, y: 75 });
      expect(g.resolvePosition('pt1')).toEqual({ x: 50, y: 75 });
    });

    it('prefers node over anchor if same id', () => {
      g.addNode('X', { type: 'server', x: 100, y: 100 });
      g.addAnchor('X', { x: 999, y: 999 });
      expect(g.resolvePosition('X')).toEqual({ x: 100, y: 100 });
    });

    it('returns null for unknown id', () => {
      expect(g.resolvePosition('nope')).toBeNull();
    });
  });

  describe('elementType', () => {
    it('identifies nodes, links, anchors', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addLink('l1', { type: 'line', from: 'A', to: 'B' });
      g.addAnchor('pt1', { x: 0, y: 0 });
      expect(g.elementType('A')).toBe('node');
      expect(g.elementType('l1')).toBe('link');
      expect(g.elementType('pt1')).toBe('anchor');
      expect(g.elementType('nope')).toBeNull();
    });
  });

  /* ══════════════════════════════════════════
     ADJACENCY QUERIES
     ══════════════════════════════════════════ */

  describe('adjacency', () => {
    beforeEach(() => {
      //   A --- B --- C
      //         |
      //         D
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addNode('D', { type: 'database', x: 100, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'tunnel', from: 'B', to: 'C' });
      g.addLink('bd', { type: 'line', from: 'B', to: 'D' });
    });

    it('getLinksForNode returns correct link set', () => {
      expect(g.getLinksForNode('A')).toEqual(new Set(['ab']));
      expect(g.getLinksForNode('B')).toEqual(new Set(['ab', 'bc', 'bd']));
      expect(g.getLinksForNode('C')).toEqual(new Set(['bc']));
    });

    it('getLinksForNode returns empty set for unknown node', () => {
      expect(g.getLinksForNode('Z')).toEqual(new Set());
    });

    it('getNeighbors returns adjacent nodes', () => {
      expect(g.getNeighbors('B')).toEqual(new Set(['A', 'C', 'D']));
      expect(g.getNeighbors('A')).toEqual(new Set(['B']));
    });

    it('degree returns correct count', () => {
      expect(g.degree('A')).toBe(1);
      expect(g.degree('B')).toBe(3);
      expect(g.degree('C')).toBe(1);
    });

    it('getLinksBetween returns links connecting two nodes', () => {
      expect(g.getLinksBetween('A', 'B')).toEqual(['ab']);
      expect(g.getLinksBetween('B', 'A')).toEqual(['ab']); // bidirectional
      expect(g.getLinksBetween('A', 'C')).toEqual([]);
    });

    it('getLinksBetween finds multiple parallel links', () => {
      g.addLink('ab2', { type: 'tunnel', from: 'A', to: 'B' });
      expect(g.getLinksBetween('A', 'B').sort()).toEqual(['ab', 'ab2']);
    });

    it('adjacency rebuilds lazily after structural change', () => {
      expect(g.degree('B')).toBe(3);
      g.addLink('ad', { type: 'line', from: 'A', to: 'D' });
      expect(g.degree('A')).toBe(2); // Was 1, now 2
    });

    it('getLinksForAnchor tracks anchor references', () => {
      g.addAnchor('mid', { x: 50, y: 50 });
      g.addLink('amid', { type: 'line', from: 'A', to: 'mid' });
      expect(g.getLinksForAnchor('mid')).toEqual(new Set(['amid']));
    });

    it('getLinksForAnchor tracks anchor as from-endpoint', () => {
      g.addAnchor('start', { x: 0, y: 0 });
      g.addNode('Z', { type: 'host', x: 100, y: 100 });
      g.addLink('start-z', { type: 'line', from: 'start', to: 'Z' });
      expect(g.getLinksForAnchor('start')).toEqual(new Set(['start-z']));
    });
  });

  /* ══════════════════════════════════════════
     GRAPH ALGORITHMS
     ══════════════════════════════════════════ */

  describe('bfs', () => {
    it('traverses in breadth-first order', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      const order = g.bfs('A');
      expect(order).toEqual(['A', 'B', 'C']);
    });

    it('returns empty for non-existent start', () => {
      expect(g.bfs('nope')).toEqual([]);
    });

    it('handles disconnected nodes', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'server', x: 100, y: 0 });
      // No links
      expect(g.bfs('A')).toEqual(['A']);
    });
  });

  describe('shortestPath', () => {
    beforeEach(() => {
      //   A -- B -- C
      //        |    |
      //        D -- E
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addNode('D', { type: 'switch', x: 100, y: 100 });
      g.addNode('E', { type: 'firewall', x: 200, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      g.addLink('bd', { type: 'line', from: 'B', to: 'D' });
      g.addLink('de', { type: 'line', from: 'D', to: 'E' });
      g.addLink('ce', { type: 'line', from: 'C', to: 'E' });
    });

    it('finds shortest path', () => {
      const path = g.shortestPath('A', 'E');
      // A->B->C->E or A->B->D->E, both length 4
      expect(path.length).toBe(4);
      expect(path[0]).toBe('A');
      expect(path[path.length - 1]).toBe('E');
    });

    it('returns [id] for same-node path', () => {
      expect(g.shortestPath('A', 'A')).toEqual(['A']);
    });

    it('returns empty for no path', () => {
      g.addNode('Z', { type: 'server', x: 500, y: 500 }); // disconnected
      expect(g.shortestPath('A', 'Z')).toEqual([]);
    });

    it('returns empty for non-existent nodes', () => {
      expect(g.shortestPath('X', 'Y')).toEqual([]);
    });
  });

  describe('connectedComponents', () => {
    it('finds single component', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      const comps = g.connectedComponents();
      expect(comps).toHaveLength(1);
      expect(comps[0]).toEqual(new Set(['A', 'B']));
    });

    it('finds multiple components', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addNode('D', { type: 'switch', x: 300, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('cd', { type: 'line', from: 'C', to: 'D' });
      const comps = g.connectedComponents();
      expect(comps).toHaveLength(2);
    });

    it('handles isolated nodes', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'server', x: 100, y: 0 });
      const comps = g.connectedComponents();
      expect(comps).toHaveLength(2);
    });
  });

  describe('articulationPoints', () => {
    it('finds articulation points in linear graph', () => {
      // A -- B -- C
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      expect(g.articulationPoints()).toEqual(['B']);
    });

    it('finds no articulation points in fully connected triangle', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 50, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      g.addLink('ca', { type: 'line', from: 'C', to: 'A' });
      expect(g.articulationPoints()).toEqual([]);
    });

    it('handles star topology', () => {
      // Hub-and-spoke: center is articulation point
      g.addNode('HUB', { type: 'router', x: 100, y: 100 });
      g.addNode('S1', { type: 'host', x: 0, y: 0 });
      g.addNode('S2', { type: 'host', x: 200, y: 0 });
      g.addNode('S3', { type: 'host', x: 100, y: 200 });
      g.addLink('h1', { type: 'line', from: 'HUB', to: 'S1' });
      g.addLink('h2', { type: 'line', from: 'HUB', to: 'S2' });
      g.addLink('h3', { type: 'line', from: 'HUB', to: 'S3' });
      expect(g.articulationPoints()).toEqual(['HUB']);
    });
  });

  describe('bridges', () => {
    it('finds bridge links', () => {
      // A -- B -- C (both links are bridges)
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      expect(g.bridges().sort()).toEqual(['ab', 'bc']);
    });

    it('finds no bridges in a triangle', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 50, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      g.addLink('ca', { type: 'line', from: 'C', to: 'A' });
      expect(g.bridges()).toEqual([]);
    });

    it('ignores parallel links (redundant)', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addLink('ab1', { type: 'line', from: 'A', to: 'B' });
      g.addLink('ab2', { type: 'tunnel', from: 'A', to: 'B' });
      expect(g.bridges()).toEqual([]);
    });
  });

  describe('blastRadius', () => {
    it('identifies isolated nodes after failure', () => {
      // A -- B -- C -- D
      //           |
      //           E
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'switch', x: 200, y: 0 });
      g.addNode('D', { type: 'host', x: 300, y: 0 });
      g.addNode('E', { type: 'database', x: 200, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      g.addLink('cd', { type: 'line', from: 'C', to: 'D' });
      g.addLink('ce', { type: 'line', from: 'C', to: 'E' });

      // If B fails: A is isolated, C/D/E still connected
      const { isolated, affected } = g.blastRadius('B');
      expect(isolated).toEqual(new Set(['A']));
      expect(affected).toEqual(new Set(['C'])); // direct neighbor, not isolated
    });

    it('returns empty for non-existent node', () => {
      const { isolated, affected } = g.blastRadius('nope');
      expect(isolated.size).toBe(0);
      expect(affected.size).toBe(0);
    });
  });

  /* ══════════════════════════════════════════
     SUBGRAPH
     ══════════════════════════════════════════ */

  describe('subgraph', () => {
    it('extracts a subset of nodes and their connecting links', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      const sub = g.subgraph(['A', 'B']);
      expect(sub.nodes.size).toBe(2);
      expect(sub.links.size).toBe(1);
      expect(sub.links.has('ab')).toBe(true);
      expect(sub.links.has('bc')).toBe(false); // C not in subset
    });

    it('includes anchors referenced by included links', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addAnchor('mid', { x: 50, y: 50 });
      g.addLink('amid', { type: 'line', from: 'A', to: 'mid' });

      const sub = g.subgraph(['A']);
      expect(sub.links.size).toBe(1);
      expect(sub.anchors.has('mid')).toBe(true);
    });
  });

  /* ══════════════════════════════════════════
     ANALYSIS
     ══════════════════════════════════════════ */

  describe('analyze', () => {
    it('reports single points of failure', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      const findings = g.analyze();
      const spofs = findings.filter(f => f.type === 'single-point-of-failure');
      expect(spofs).toHaveLength(1);
      expect(spofs[0].elements).toEqual(['B']);
    });

    it('reports bridge links', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });

      const findings = g.analyze();
      const bridges = findings.filter(f => f.type === 'bridge-link');
      expect(bridges).toHaveLength(1);
    });

    it('reports isolated nodes', () => {
      g.addNode('LONELY', { type: 'server', x: 0, y: 0 });
      const findings = g.analyze();
      const isolated = findings.filter(f => f.type === 'isolated-node');
      expect(isolated).toHaveLength(1);
    });

    it('reports disconnected components', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'server', x: 100, y: 0 });
      g.addNode('C', { type: 'server', x: 200, y: 0 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      // C is disconnected

      const findings = g.analyze();
      const disc = findings.filter(f => f.type === 'disconnected-graph');
      expect(disc).toHaveLength(1);
      expect(disc[0].message).toContain('2 disconnected components');
    });

    it('returns empty for healthy, connected topology', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addNode('C', { type: 'host', x: 50, y: 100 });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
      g.addLink('ca', { type: 'line', from: 'C', to: 'A' });
      expect(g.analyze()).toEqual([]);
    });
  });

  /* ══════════════════════════════════════════
     SERIALIZATION
     ══════════════════════════════════════════ */

  describe('serialization', () => {
    it('round-trips via toJSON/fromJSON', () => {
      g.addNode('A', { type: 'server', x: 100, y: 200, label: 'Server' });
      g.addNode('B', { type: 'router', x: 300, y: 200, label: 'Router' });
      g.addAnchor('mid', { x: 200, y: 200 });
      g.addLink('ab', { type: 'tunnel', from: 'A', to: 'B', label: 'IPsec' });

      const json = g.toJSON();
      const g2 = new TopologyGraph();
      g2.fromJSON(json);

      expect(g2.nodeCount).toBe(2);
      expect(g2.linkCount).toBe(1);
      expect(g2.anchorCount).toBe(1);
      expect(g2.getNode('A').label).toBe('Server');
      expect(g2.getLink('ab').label).toBe('IPsec');
      expect(g2.getAnchor('mid')).toEqual({ x: 200, y: 200 });
    });

    it('clear empties everything', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addLink('l1', { type: 'line', from: 'A', to: 'B' });
      g.addAnchor('pt1', { x: 0, y: 0 });
      g.clear();
      expect(g.nodeCount).toBe(0);
      expect(g.linkCount).toBe(0);
      expect(g.anchorCount).toBe(0);
    });
  });

  /* ══════════════════════════════════════════
     BACKWARD COMPAT
     ══════════════════════════════════════════ */

  describe('backward compatibility', () => {
    it('exposes raw Maps via rawNodes/rawLinks/rawAnchors', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addLink('l1', { type: 'line', from: 'A', to: 'B' });
      g.addAnchor('pt1', { x: 0, y: 0 });

      expect(g.rawNodes).toBeInstanceOf(Map);
      expect(g.rawNodes.get('A').type).toBe('server');
      expect(g.rawLinks.get('l1').from).toBe('A');
      expect(g.rawAnchors.get('pt1').x).toBe(0);
    });

    it('raw Maps reflect mutations through graph API', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      expect(g.rawNodes.size).toBe(1);
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      expect(g.rawNodes.size).toBe(2);
    });
  });

  /* ══════════════════════════════════════════
     SUBGRAPH — ANCHOR EDGE CASES
     ══════════════════════════════════════════ */

  describe('subgraph anchor edge cases', () => {
    it('excludes links where both endpoints are anchors (no node involved)', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addAnchor('anc1', { x: 50, y: 50 });
      g.addAnchor('anc2', { x: 150, y: 150 });
      // Link between two anchors — no node endpoint
      g.addLink('anchor-only', { type: 'line', from: 'anc1', to: 'anc2' });
      // Link from node to anchor — has a node endpoint
      g.addLink('node-to-anc', { type: 'line', from: 'A', to: 'anc1' });

      const sub = g.subgraph(['A']);
      // anchor-only link should be excluded (neither endpoint is a node in subset)
      expect(sub.links.has('anchor-only')).toBe(false);
      // node-to-anc should be included
      expect(sub.links.has('node-to-anc')).toBe(true);
      expect(sub.anchors.has('anc1')).toBe(true);
      // anc2 is not referenced by any included link
      expect(sub.anchors.has('anc2')).toBe(false);
    });

    it('includes anchor on the from-side of a link when to-side is a node', () => {
      g.addNode('B', { type: 'router', x: 100, y: 0 });
      g.addAnchor('start', { x: 0, y: 0 });
      // Link goes FROM anchor TO node
      g.addLink('anc-to-node', { type: 'line', from: 'start', to: 'B' });

      const sub = g.subgraph(['B']);
      expect(sub.links.has('anc-to-node')).toBe(true);
      expect(sub.anchors.has('start')).toBe(true);
      expect(sub.anchors.get('start')).toEqual({ x: 0, y: 0 });
    });

    it('includes anchor on the to-side when from-side is a node', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addAnchor('end', { x: 200, y: 200 });
      g.addLink('node-to-anc', { type: 'line', from: 'A', to: 'end' });

      const sub = g.subgraph(['A']);
      expect(sub.links.has('node-to-anc')).toBe(true);
      expect(sub.anchors.has('end')).toBe(true);
      expect(sub.anchors.get('end')).toEqual({ x: 200, y: 200 });
    });

    it('returns empty subgraph for empty id list', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0 });
      g.addLink('l1', { type: 'line', from: 'A', to: 'A' });
      const sub = g.subgraph([]);
      expect(sub.nodes.size).toBe(0);
      expect(sub.links.size).toBe(0);
      expect(sub.anchors.size).toBe(0);
    });
  });

  /* ══════════════════════════════════════════
     ANALYZE — LABEL FALLBACK
     ══════════════════════════════════════════ */

  describe('analyze label fallback', () => {
    it('uses node label in SPOF message when label exists', () => {
      g.addNode('A', { type: 'server', x: 0, y: 0, label: 'Alpha' });
      g.addNode('B', { type: 'router', x: 100, y: 0, label: 'Hub' });
      g.addNode('C', { type: 'host', x: 200, y: 0, label: 'Charlie' });
      g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
      g.addLink('bc', { type: 'line', from: 'B', to: 'C' });

      const findings = g.analyze();
      const spof = findings.find(f => f.type === 'single-point-of-failure');
      expect(spof.message).toContain('"Hub"');
    });

    it('uses node id in isolated-node message when no label', () => {
      g.addNode('SOLO', { type: 'server', x: 0, y: 0 });
      const findings = g.analyze();
      const iso = findings.find(f => f.type === 'isolated-node');
      expect(iso.message).toContain('"SOLO"');
    });
  });

  /* ══════════════════════════════════════════
     MODULE EXPORT
     ══════════════════════════════════════════ */

  describe('module export', () => {
    it('exports TopologyGraph as a constructor via module.exports', () => {
      // Verifies the module.exports branch (lines 786-787)
      const Imported = require('../design-system/core/graph.js');
      expect(typeof Imported).toBe('function');
      const instance = new Imported();
      expect(instance).toBeInstanceOf(Imported);
      expect(typeof instance.addNode).toBe('function');
    });

    it('constructor has expected prototype methods', () => {
      // Ensures the exported class is fully formed
      const Imported = require('../design-system/core/graph.js');
      const proto = Imported.prototype;
      expect(typeof proto.addNode).toBe('function');
      expect(typeof proto.addLink).toBe('function');
      expect(typeof proto.addAnchor).toBe('function');
      expect(typeof proto.analyze).toBe('function');
      expect(typeof proto.subgraph).toBe('function');
    });
  });
});
