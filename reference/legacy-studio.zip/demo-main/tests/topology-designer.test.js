import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock window.matchMedia for jsdom (not implemented by default)
window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('TopologyDesigner', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Test', subtitle: 'Sub' });
  });

  describe('constructor', () => {
    it('sets defaults', () => {
      const t = new TopologyDesigner();
      expect(t.title).toBe('Network Topology');
      expect(t.subtitle).toBe('');
      expect(t.viewBox).toBe('0 0 1050 700');
      expect(t.step).toBe(0);
      expect(t.playing).toBe(false);
      expect(t.mode).toBe('manual');
    });

    it('accepts custom configuration', () => {
      expect(topo.title).toBe('Test');
      expect(topo.subtitle).toBe('Sub');
    });

    it('initializes empty registries', () => {
      expect(topo._nodes.size).toBe(0);
      expect(topo._links.size).toBe(0);
      expect(topo._anchors.size).toBe(0);
      expect(topo._acts).toHaveLength(0);
      expect(topo._steps).toHaveLength(0);
    });
  });

  describe('node registration', () => {
    it('registers a node', () => {
      topo.node('A', { type: 'server', x: 100, y: 200, label: 'Server A' });
      expect(topo._nodes.size).toBe(1);
      expect(topo._nodes.get('A').type).toBe('server');
      expect(topo._nodes.get('A').x).toBe(100);
    });

    it('returns this for chaining', () => {
      const result = topo.node('A', { type: 'server', x: 0, y: 0 });
      expect(result).toBe(topo);
    });

    it('overwrites existing node with same id', () => {
      topo.node('A', { type: 'server', x: 0, y: 0 });
      topo.node('A', { type: 'router', x: 50, y: 50 });
      expect(topo._nodes.size).toBe(1);
      expect(topo._nodes.get('A').type).toBe('router');
    });

    it('sets the id property on the config', () => {
      topo.node('FOO', { type: 'host', x: 0, y: 0 });
      expect(topo._nodes.get('FOO').id).toBe('FOO');
    });
  });

  describe('anchor registration', () => {
    it('registers an anchor point', () => {
      topo.anchor('pt1', { x: 500, y: 300 });
      expect(topo._anchors.size).toBe(1);
      expect(topo._anchors.get('pt1')).toEqual({ x: 500, y: 300 });
    });

    it('returns this for chaining', () => {
      expect(topo.anchor('pt1', { x: 0, y: 0 })).toBe(topo);
    });
  });

  describe('link registration', () => {
    it('registers a link', () => {
      topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
      expect(topo._links.size).toBe(1);
      expect(topo._links.get('l1').from).toBe('A');
      expect(topo._links.get('l1').to).toBe('B');
    });

    it('returns this for chaining', () => {
      expect(topo.link('l1', { type: 'line', from: 'A', to: 'B' })).toBe(topo);
    });

    it('sets the id property on the config', () => {
      topo.link('myLink', { type: 'tunnel', from: 'X', to: 'Y' });
      expect(topo._links.get('myLink').id).toBe('myLink');
    });
  });

  describe('act registration', () => {
    it('registers an act', () => {
      topo.act('a1', { label: 'Act 1', color: '#01a982' });
      expect(topo._acts).toHaveLength(1);
      expect(topo._acts[0].label).toBe('Act 1');
      expect(topo._acts[0].id).toBe('a1');
      expect(topo._acts[0].steps).toEqual([]);
    });

    it('returns this for chaining', () => {
      expect(topo.act('a1', { label: 'Act 1' })).toBe(topo);
    });
  });

  describe('step registration', () => {
    it('registers a step and attaches to act', () => {
      topo.act('a1', { label: 'Act 1', color: '#01a982' });
      topo.addStep('s1', {
        act: 'a1', name: 'Step 1', goal: 'Goal 1',
        focus: ['A'], phases: [{ show: ['A'], diff: 'A appears' }],
      });
      expect(topo._steps).toHaveLength(1);
      expect(topo._acts[0].steps).toHaveLength(1);
      expect(topo._acts[0].steps[0].id).toBe('s1');
    });

    it('returns this for chaining', () => {
      topo.act('a1', { label: 'Act 1' });
      expect(topo.addStep('s1', { act: 'a1', name: 'S1' })).toBe(topo);
    });

    it('handles step without matching act gracefully', () => {
      topo.addStep('orphan', { act: 'nonexistent', name: 'Orphan' });
      expect(topo._steps).toHaveLength(1);
    });
  });

  describe('glossary', () => {
    it('sets glossary terms', () => {
      topo.glossary([{ t: 'SSE', d: 'Security Service Edge' }]);
      expect(topo._glossary).toHaveLength(1);
      expect(topo._glossary[0].t).toBe('SSE');
    });

    it('returns this for chaining', () => {
      expect(topo.glossary([])).toBe(topo);
    });
  });

  describe('_buildIndex', () => {
    it('creates step index mapping', () => {
      topo.act('a1', { label: 'Act 1', color: '#01a982' });
      topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'] }] });
      topo.addStep('s2', { act: 'a1', name: 'S2', phases: [{ show: ['B'] }] });
      topo._buildIndex();
      expect(topo._stepIndex['s1']).toBe(1);
      expect(topo._stepIndex['s2']).toBe(2);
    });

    it('computes act start and count', () => {
      topo.act('a1', { label: 'A1', color: '#fff' });
      topo.addStep('s1', { act: 'a1', name: 'S1', phases: [] });
      topo.addStep('s2', { act: 'a1', name: 'S2', phases: [] });
      topo._buildIndex();
      expect(topo._acts[0].start).toBe(0);
      expect(topo._acts[0].count).toBe(2);
    });
  });

  describe('fluent API chaining', () => {
    it('supports full method chaining', () => {
      const result = topo
        .node('A', { type: 'server', x: 100, y: 100, label: 'A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'B' })
        .anchor('mid', { x: 200, y: 100 })
        .link('l1', { type: 'line', from: 'A', to: 'B' })
        .act('a1', { label: 'Act 1', color: '#01a982' })
        .addStep('s1', { act: 'a1', name: 'Step 1', phases: [{ show: ['A', 'B', 'l1'] }] })
        .glossary([{ t: 'Test', d: 'A test term' }]);

      expect(result).toBe(topo);
      expect(topo._nodes.size).toBe(2);
      expect(topo._links.size).toBe(1);
      expect(topo._anchors.size).toBe(1);
      expect(topo._acts).toHaveLength(1);
      expect(topo._steps).toHaveLength(1);
    });
  });

  describe('toggleIsometric()', () => {
    it('toggles and returns boolean', () => {
      expect(topo.isometricMode).toBe(false);
      const on = topo.toggleIsometric();
      expect(on).toBe(true);
      expect(topo.isometricMode).toBe(true);
      const off = topo.toggleIsometric();
      expect(off).toBe(false);
      expect(topo.isometricMode).toBe(false);
    });

    it('accepts explicit boolean', () => {
      topo.toggleIsometric(true);
      expect(topo.isometricMode).toBe(true);
      topo.toggleIsometric(true);
      expect(topo.isometricMode).toBe(true);
      topo.toggleIsometric(false);
      expect(topo.isometricMode).toBe(false);
    });
  });

  describe('toggleSecurityMode()', () => {
    it('toggles and returns boolean', () => {
      expect(topo._securityMode).toBe(false);
      const on = topo.toggleSecurityMode();
      expect(on).toBe(true);
      expect(topo._securityMode).toBe(true);
      const off = topo.toggleSecurityMode();
      expect(off).toBe(false);
      expect(topo._securityMode).toBe(false);
    });

    it('accepts explicit boolean', () => {
      topo.toggleSecurityMode(true);
      expect(topo._securityMode).toBe(true);
      topo.toggleSecurityMode(false);
      expect(topo._securityMode).toBe(false);
    });
  });

  describe('constructor new defaults', () => {
    it('includes temporalMode default', () => {
      const t = new TopologyDesigner();
      expect(t.temporalMode).toBe('design');
    });

    it('includes ghostingEnabled default', () => {
      const t = new TopologyDesigner();
      expect(t.ghostingEnabled).toBe(true);
    });

    it('ghosting can be disabled via config', () => {
      const t = new TopologyDesigner({ ghosting: false });
      expect(t.ghostingEnabled).toBe(false);
    });

    it('includes isometricMode default', () => {
      const t = new TopologyDesigner();
      expect(t.isometricMode).toBe(false);
    });

    it('includes securityMode default', () => {
      const t = new TopologyDesigner();
      expect(t._securityMode).toBe(false);
    });

    it('includes empty state variables map', () => {
      const t = new TopologyDesigner();
      expect(t._stateVariables).toBeInstanceOf(Map);
      expect(t._stateVariables.size).toBe(0);
    });

    it('includes empty incident data map', () => {
      const t = new TopologyDesigner();
      expect(t._incidentData).toBeInstanceOf(Map);
      expect(t._incidentData.size).toBe(0);
    });

    it('includes blastRadiusHops default', () => {
      const t = new TopologyDesigner();
      expect(t._blastRadiusHops).toBe(2);
    });

    it('accepts custom blastRadiusHops', () => {
      const t = new TopologyDesigner({ blastRadiusHops: 5 });
      expect(t._blastRadiusHops).toBe(5);
    });
  });

  describe('critical UX + ops behaviors', () => {
    it('play() switches manual mode to auto and starts playback', () => {
      topo.act('a1', { label: 'Act 1', color: '#01a982' });
      topo.addStep('s1', { act: 'a1', name: 'S1', phases: [{ show: ['A'] }] });
      topo._buildIndex();

      const updateUISpy = vi.spyOn(topo, '_updateUI').mockImplementation(() => {});
      const advanceSpy = vi.spyOn(topo, '_advance').mockImplementation(() => {});
      topo.reducedMotion = false;
      topo.mode = 'manual';

      topo.play();

      expect(topo.mode).toBe('auto');
      expect(topo.playing).toBe(true);
      expect(updateUISpy).toHaveBeenCalled();
      expect(advanceSpy).toHaveBeenCalled();
    });

    it('play() is a no-op when reduced motion is enabled', () => {
      const updateUISpy = vi.spyOn(topo, '_updateUI').mockImplementation(() => {});
      const advanceSpy = vi.spyOn(topo, '_advance').mockImplementation(() => {});
      topo.reducedMotion = true;
      topo.mode = 'manual';

      topo.play();

      expect(topo.mode).toBe('manual');
      expect(topo.playing).toBe(false);
      expect(updateUISpy).not.toHaveBeenCalled();
      expect(advanceSpy).not.toHaveBeenCalled();
    });

    it('setMode() only accepts supported editing modes', () => {
      topo.setMode('link');
      expect(topo.interactiveMode).toBe('link');

      topo.setMode('unsupported-mode');
      expect(topo.interactiveMode).toBe('link');
    });

    it('removeAnchor() removes dependent links and phase references', () => {
      topo
        .anchor('mid', { x: 200, y: 100 })
        .node('A', { type: 'server', x: 0, y: 0 })
        .node('B', { type: 'router', x: 100, y: 0 })
        .link('l1', { type: 'line', from: 'A', to: 'mid' })
        .link('l2', { type: 'line', from: 'mid', to: 'B' })
        .act('a1', { label: 'Act 1' })
        .addStep('s1', {
          act: 'a1',
          name: 'S1',
          phases: [{ show: ['A', 'mid', 'l1', 'l2'] }],
        });

      const removed = topo.removeAnchor('mid');

      expect(removed).toBe(true);
      expect(topo._anchors.has('mid')).toBe(false);
      expect(topo._links.has('l1')).toBe(false);
      expect(topo._links.has('l2')).toBe(false);
      expect(topo._steps[0].phases[0].show).not.toContain('mid');
    });
  });
});
