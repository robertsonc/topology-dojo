/**
 * Unit tests for the /api/ai-assist Pages Function logic.
 *
 * We import the pure helper functions by extracting them from the module
 * (the Pages Function exports onRequestPost etc., but we test the logic
 * by reconstructing minimal equivalents here).
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// ─── Inline the helpers we want to test ────────────────────────────────────
// (Mirrors the implementations in functions/api/ai-assist.js)

function extractJSON(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const stripped = raw.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim();
  try {
    return JSON.parse(stripped);
  } catch (_) {
    const match = stripped.match(/\{[\s\S]*\}/);
    if (match) {
      try { return JSON.parse(match[0]); } catch (_2) { return null; }
    }
    return null;
  }
}

function validateTopology(obj) {
  if (!obj || typeof obj !== 'object') return false;
  if (!Array.isArray(obj.nodes) || !Array.isArray(obj.links)) return false;
  for (const n of obj.nodes) {
    if (!n.id || !n.type || typeof n.x !== 'number' || typeof n.y !== 'number') return false;
  }
  for (const l of obj.links) {
    if (!l.id || !l.from || !l.to) return false;
  }
  return true;
}

/**
 * Minimal handler factory — mirrors onRequestPost logic for unit testing.
 */
function makeHandler(env) {
  return async function handlePost(bodyObj) {
    if (!env.AI) {
      return { status: 200, body: { error: 'AI binding not configured', fallback: true } };
    }

    const prompt = bodyObj?.prompt?.trim();
    if (!prompt) {
      return { status: 400, body: { error: 'prompt is required', fallback: true } };
    }

    try {
      const aiResponse = await env.AI.run('@cf/moonshotai/kimi-k2.6', {
        messages: [
          { role: 'system', content: 'system' },
          { role: 'user', content: prompt },
        ],
        max_tokens: 2048,
        temperature: 0.3,
      });

      const rawText = aiResponse?.response ?? aiResponse?.result?.response ?? '';
      const parsed = extractJSON(rawText);

      if (!parsed || !validateTopology(parsed)) {
        return { status: 200, body: { error: 'AI returned invalid topology', fallback: true } };
      }

      return { status: 200, body: { nodes: parsed.nodes, links: parsed.links } };
    } catch (err) {
      return { status: 200, body: { error: err.message || 'AI call failed', fallback: true } };
    }
  };
}

// ─── Tests ──────────────────────────────────────────────────────────────────

describe('extractJSON', () => {
  it('parses a plain JSON string', () => {
    const input = '{"nodes":[],"links":[]}';
    expect(extractJSON(input)).toEqual({ nodes: [], links: [] });
  });

  it('strips markdown code fences', () => {
    const input = '```json\n{"nodes":[],"links":[]}\n```';
    expect(extractJSON(input)).toEqual({ nodes: [], links: [] });
  });

  it('extracts JSON from surrounding prose', () => {
    const input = 'Here is your topology: {"nodes":[],"links":[]} hope that helps!';
    const result = extractJSON(input);
    expect(result).toEqual({ nodes: [], links: [] });
  });

  it('returns null for non-JSON strings', () => {
    expect(extractJSON('sorry I cannot help with that')).toBeNull();
  });

  it('returns null for empty input', () => {
    expect(extractJSON('')).toBeNull();
    expect(extractJSON(null)).toBeNull();
  });
});

describe('validateTopology', () => {
  const validNode = { id: 'n1', type: 'host', label: 'Server', x: 100, y: 200 };
  const validLink = { id: 'l1', from: 'n1', to: 'n2', type: 'line', label: '' };

  it('accepts a valid topology', () => {
    expect(validateTopology({ nodes: [validNode], links: [validLink] })).toBe(true);
  });

  it('accepts empty nodes and links arrays', () => {
    expect(validateTopology({ nodes: [], links: [] })).toBe(true);
  });

  it('rejects null', () => {
    expect(validateTopology(null)).toBe(false);
  });

  it('rejects missing nodes array', () => {
    expect(validateTopology({ links: [] })).toBe(false);
  });

  it('rejects missing links array', () => {
    expect(validateTopology({ nodes: [] })).toBe(false);
  });

  it('rejects nodes with missing id', () => {
    expect(validateTopology({ nodes: [{ type: 'host', x: 0, y: 0 }], links: [] })).toBe(false);
  });

  it('rejects nodes with non-numeric coordinates', () => {
    expect(validateTopology({ nodes: [{ id: 'n1', type: 'host', x: '100', y: '200' }], links: [] })).toBe(false);
  });

  it('rejects links missing from/to', () => {
    expect(validateTopology({ nodes: [], links: [{ id: 'l1', from: 'n1' }] })).toBe(false);
  });
});

describe('handler — AI binding missing', () => {
  it('returns fallback:true when env.AI is not set', async () => {
    const handle = makeHandler({});
    const result = await handle({ prompt: 'a simple network' });
    expect(result.body.fallback).toBe(true);
    expect(result.body.error).toBe('AI binding not configured');
  });
});

describe('handler — AI binding present', () => {
  let mockAI;
  let handle;

  const goodTopology = {
    nodes: [{ id: 'fw1', type: 'firewall', label: 'Firewall', x: 200, y: 350 }],
    links: [{ id: 'l1', from: 'fw1', to: 'host1', type: 'line', label: '' }],
  };

  beforeEach(() => {
    mockAI = { run: vi.fn() };
    handle = makeHandler({ AI: mockAI });
  });

  it('returns topology when AI returns valid JSON', async () => {
    mockAI.run.mockResolvedValue({ response: JSON.stringify(goodTopology) });
    const result = await handle({ prompt: 'A firewall protecting a host' });
    expect(result.body.fallback).toBeUndefined();
    expect(result.body.nodes).toHaveLength(1);
    expect(result.body.links).toHaveLength(1);
  });

  it('returns fallback:true when AI returns malformed output', async () => {
    mockAI.run.mockResolvedValue({ response: 'I cannot generate that topology.' });
    const result = await handle({ prompt: 'test' });
    expect(result.body.fallback).toBe(true);
    expect(result.body.error).toBe('AI returned invalid topology');
  });

  it('returns fallback:true when AI returns invalid topology shape', async () => {
    mockAI.run.mockResolvedValue({ response: '{"foo":"bar"}' });
    const result = await handle({ prompt: 'test' });
    expect(result.body.fallback).toBe(true);
  });

  it('returns fallback:true when AI call throws', async () => {
    mockAI.run.mockRejectedValue(new Error('rate limited'));
    const result = await handle({ prompt: 'test' });
    expect(result.body.fallback).toBe(true);
    expect(result.body.error).toBe('rate limited');
  });

  it('handles AI response wrapped in markdown fences', async () => {
    mockAI.run.mockResolvedValue({
      response: '```json\n' + JSON.stringify(goodTopology) + '\n```',
    });
    const result = await handle({ prompt: 'test' });
    expect(result.body.nodes).toHaveLength(1);
  });

  it('returns 400 for empty prompt', async () => {
    const result = await handle({ prompt: '' });
    expect(result.status).toBe(400);
    expect(result.body.fallback).toBe(true);
  });
});
