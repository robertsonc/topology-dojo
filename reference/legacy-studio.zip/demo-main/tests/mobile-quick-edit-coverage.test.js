import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ── Helpers ── */

let _containerId = 0;

function buildTopo() {
  const topo = new TopologyDesigner({ title: 'MQE Test', viewBox: '0 0 1050 700' });
  topo.node('r1', { type: 'router', x: 100, y: 100, label: 'Router 1' });
  topo.node('sw1', { type: 'switch', x: 300, y: 200, label: 'Switch 1' });
  topo.node('fw1', { type: 'firewall', x: 500, y: 100, label: 'Firewall 1' });
  topo.link('l1', { type: 'line', from: 'r1', to: 'sw1' });
  topo.link('l2', { type: 'line', from: 'sw1', to: 'fw1' });

  const id = `tds-mqe-test-${++_containerId}`;
  const container = document.createElement('div');
  container.id = id;
  document.body.appendChild(container);
  topo.mount(id);
  return { topo, container, containerId: id };
}

/* ══════════════════════════════════════════
   Mobile Quick-Edit Mode (#147)
   ══════════════════════════════════════════ */

describe('Mobile Quick-Edit Mode (#147)', () => {
  let topo, container, containerId;

  beforeEach(() => {
    const ctx = buildTopo();
    topo = ctx.topo;
    container = ctx.container;
    containerId = ctx.containerId;
  });

  afterEach(() => {
    // Clean up DOM
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
  });

  /* ── enableMobileQuickEdit ── */

  describe('enableMobileQuickEdit()', () => {
    it('creates FAB element in the container', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      expect(fab).not.toBeNull();
      expect(fab.innerHTML).toContain('✎');
      expect(fab.title).toBe('Quick Edit');
    });

    it('creates quick-edit panel in the container', () => {
      topo.enableMobileQuickEdit();
      const panel = container.querySelector('.tds-mobile-qe-panel');
      expect(panel).not.toBeNull();
    });

    it('panel contains header with close button', () => {
      topo.enableMobileQuickEdit();
      const panel = container.querySelector('.tds-mobile-qe-panel');
      const header = panel.querySelector('.tds-mobile-qe-header');
      expect(header).not.toBeNull();
      expect(header.textContent).toContain('Quick Edit');
      const closeBtn = panel.querySelector('.tds-mobile-qe-close');
      expect(closeBtn).not.toBeNull();
      expect(closeBtn.textContent).toBe('✕');
    });

    it('panel contains all 8 node type buttons', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');
      expect(typeBtns.length).toBe(8);
      const labels = Array.from(typeBtns).map(b => b.textContent);
      expect(labels).toEqual(['ec', 'switch', 'router', 'firewall', 'cloud', 'host', 'server', 'database']);
    });

    it('panel contains action buttons', () => {
      topo.enableMobileQuickEdit();
      const actions = container.querySelectorAll('[data-action]');
      const actionNames = Array.from(actions).map(b => b.dataset.action);
      expect(actionNames).toContain('copy-positions');
      expect(actionNames).toContain('auto-layout');
      expect(actionNames).toContain('export-json');
      expect(actionNames).toContain('undo-move');
      expect(actionNames).toContain('delete-node');
    });

    it('sets _mobileQuickEditEnabled to true', () => {
      expect(topo._mobileQuickEditEnabled).toBeFalsy();
      topo.enableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(true);
    });

    it('returns this for chaining', () => {
      const result = topo.enableMobileQuickEdit();
      expect(result).toBe(topo);
    });

    it('is idempotent — calling twice does not duplicate DOM elements', () => {
      topo.enableMobileQuickEdit();
      topo.enableMobileQuickEdit();
      const fabs = container.querySelectorAll('.tds-mobile-fab');
      const panels = container.querySelectorAll('.tds-mobile-qe-panel');
      expect(fabs.length).toBe(1);
      expect(panels.length).toBe(1);
    });

    it('idempotent call still returns this', () => {
      topo.enableMobileQuickEdit();
      const result = topo.enableMobileQuickEdit();
      expect(result).toBe(topo);
    });
  });

  /* ── disableMobileQuickEdit ── */

  describe('disableMobileQuickEdit()', () => {
    it('removes FAB from the container', () => {
      topo.enableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-fab')).not.toBeNull();
      topo.disableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-fab')).toBeNull();
    });

    it('removes panel from the container', () => {
      topo.enableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-qe-panel')).not.toBeNull();
      topo.disableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-qe-panel')).toBeNull();
    });

    it('sets _mobileQuickEditEnabled to false', () => {
      topo.enableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(true);
      topo.disableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(false);
    });

    it('returns this for chaining', () => {
      topo.enableMobileQuickEdit();
      const result = topo.disableMobileQuickEdit();
      expect(result).toBe(topo);
    });

    it('is safe to call without prior enable', () => {
      const result = topo.disableMobileQuickEdit();
      expect(result).toBe(topo);
      expect(topo._mobileQuickEditEnabled).toBe(false);
    });
  });

  /* ── _mobileQuickEditEnabled flag lifecycle ── */

  describe('_mobileQuickEditEnabled flag', () => {
    it('starts falsy before enable', () => {
      const fresh = new TopologyDesigner({ title: 'Flag Test' });
      expect(fresh._mobileQuickEditEnabled).toBeFalsy();
    });

    it('tracks enable/disable/enable cycle', () => {
      topo.enableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(true);
      topo.disableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(false);
      topo.enableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(true);
    });

    it('re-enable after disable recreates DOM', () => {
      topo.enableMobileQuickEdit();
      topo.disableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-fab')).toBeNull();
      topo.enableMobileQuickEdit();
      expect(container.querySelector('.tds-mobile-fab')).not.toBeNull();
      expect(container.querySelector('.tds-mobile-qe-panel')).not.toBeNull();
    });
  });

  /* ── FAB toggle ── */

  describe('FAB toggle behavior', () => {
    it('clicking FAB opens the panel', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      const panel = container.querySelector('.tds-mobile-qe-panel');

      fab.click();

      expect(panel.classList.contains('open')).toBe(true);
      expect(fab.classList.contains('active')).toBe(true);
    });

    it('clicking FAB again closes the panel', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      const panel = container.querySelector('.tds-mobile-qe-panel');

      fab.click(); // open
      fab.click(); // close

      expect(panel.classList.contains('open')).toBe(false);
      expect(fab.classList.contains('active')).toBe(false);
    });

    it('toggle cycles open/close/open', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      const panel = container.querySelector('.tds-mobile-qe-panel');

      fab.click(); // open
      expect(panel.classList.contains('open')).toBe(true);

      fab.click(); // close
      expect(panel.classList.contains('open')).toBe(false);

      fab.click(); // open again
      expect(panel.classList.contains('open')).toBe(true);
    });
  });

  /* ── Close button ── */

  describe('Close button', () => {
    it('closes the panel when clicked', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      const panel = container.querySelector('.tds-mobile-qe-panel');
      const closeBtn = panel.querySelector('.tds-mobile-qe-close');

      fab.click(); // open panel first
      expect(panel.classList.contains('open')).toBe(true);

      closeBtn.click();

      expect(panel.classList.contains('open')).toBe(false);
      expect(fab.classList.contains('active')).toBe(false);
    });

    it('close button works even if FAB is clicked after close', () => {
      topo.enableMobileQuickEdit();
      const fab = container.querySelector('.tds-mobile-fab');
      const panel = container.querySelector('.tds-mobile-qe-panel');
      const closeBtn = panel.querySelector('.tds-mobile-qe-close');

      fab.click();   // open
      closeBtn.click(); // close via button
      fab.click();   // reopen via FAB

      expect(panel.classList.contains('open')).toBe(true);
    });
  });

  /* ── Node type buttons ── */

  describe('Node type buttons', () => {
    it('clicking a node type button adds a node', () => {
      topo.enableMobileQuickEdit();
      const initialCount = topo._nodes.size;
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');

      // Click the 'router' button (index 2)
      const routerBtn = Array.from(typeBtns).find(b => b.textContent === 'router');
      routerBtn.click();

      expect(topo._nodes.size).toBe(initialCount + 1);
    });

    it('added node has correct type', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');

      const firewallBtn = Array.from(typeBtns).find(b => b.textContent === 'firewall');
      firewallBtn.click();

      // Find the newly added node (should have qe- prefix)
      const newNodeId = Array.from(topo._nodes.keys()).find(k => k.startsWith('qe-firewall-'));
      expect(newNodeId).toBeDefined();
      const cfg = topo._nodes.get(newNodeId);
      expect(cfg.type).toBe('firewall');
    });

    it('added node has uppercase label', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');

      const cloudBtn = Array.from(typeBtns).find(b => b.textContent === 'cloud');
      cloudBtn.click();

      const newNodeId = Array.from(topo._nodes.keys()).find(k => k.startsWith('qe-cloud-'));
      expect(newNodeId).toBeDefined();
      const cfg = topo._nodes.get(newNodeId);
      expect(cfg.label).toBe('CLOUD');
    });

    it('added node is placed at center of viewbox', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');

      const hostBtn = Array.from(typeBtns).find(b => b.textContent === 'host');
      hostBtn.click();

      const newNodeId = Array.from(topo._nodes.keys()).find(k => k.startsWith('qe-host-'));
      expect(newNodeId).toBeDefined();
      const cfg = topo._nodes.get(newNodeId);
      // viewBox is '0 0 1050 700', center = 525, 350
      expect(cfg.x).toBe(525);
      expect(cfg.y).toBe(350);
    });

    it('added node id follows qe-{type}-{timestamp} pattern', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');

      const ecBtn = Array.from(typeBtns).find(b => b.textContent === 'ec');
      ecBtn.click();

      const newNodeId = Array.from(topo._nodes.keys()).find(k => k.startsWith('qe-ec-'));
      expect(newNodeId).toBeDefined();
      expect(newNodeId).toMatch(/^qe-ec-\d+$/);
    });

    it('each node type button creates a node of the correct type', () => {
      topo.enableMobileQuickEdit();
      const typeBtns = container.querySelectorAll('.tds-mobile-qe-type-btn');
      const types = ['ec', 'switch', 'router', 'firewall', 'cloud', 'host', 'server', 'database'];

      types.forEach((type, i) => {
        typeBtns[i].click();
        const newNodeId = Array.from(topo._nodes.keys()).find(k => k.startsWith(`qe-${type}-`));
        expect(newNodeId).toBeDefined();
        expect(topo._nodes.get(newNodeId).type).toBe(type);
      });

      // All 8 nodes added on top of the 3 originals
      expect(topo._nodes.size).toBe(3 + types.length);
    });
  });

  /* ── Action buttons ── */

  describe('Action buttons', () => {
    it('copy-positions calls copyPositions()', () => {
      topo.enableMobileQuickEdit();
      topo.copyPositions = vi.fn();

      const copyBtn = container.querySelector('[data-action="copy-positions"]');
      copyBtn.click();

      expect(topo.copyPositions).toHaveBeenCalledTimes(1);
    });

    it('export-json creates a download link', () => {
      topo.enableMobileQuickEdit();

      // Mock URL.createObjectURL and URL.revokeObjectURL
      const mockUrl = 'blob:mock-url';
      const origCreate = URL.createObjectURL;
      const origRevoke = URL.revokeObjectURL;
      URL.createObjectURL = vi.fn(() => mockUrl);
      URL.revokeObjectURL = vi.fn();

      // Mock anchor click
      const clickSpy = vi.fn();
      const origCreateElement = document.createElement.bind(document);
      vi.spyOn(document, 'createElement').mockImplementation((tag) => {
        const el = origCreateElement(tag);
        if (tag === 'a') {
          el.click = clickSpy;
        }
        return el;
      });

      const exportBtn = container.querySelector('[data-action="export-json"]');
      exportBtn.click();

      expect(URL.createObjectURL).toHaveBeenCalled();
      expect(clickSpy).toHaveBeenCalled();

      // Cleanup
      URL.createObjectURL = origCreate;
      URL.revokeObjectURL = origRevoke;
      vi.restoreAllMocks();
    });

    it('delete-node removes selected node', () => {
      topo.enableMobileQuickEdit();
      expect(topo._nodes.has('r1')).toBe(true);

      // Simulate selecting a node
      topo._selectedElement = 'r1';

      const deleteBtn = container.querySelector('[data-action="delete-node"]');
      deleteBtn.click();

      expect(topo._nodes.has('r1')).toBe(false);
      expect(topo._selectedElement).toBeNull();
    });

    it('delete-node hides the properties section after removal', () => {
      topo.enableMobileQuickEdit();
      const propsSection = container.querySelector('.tds-mobile-qe-props');

      // Show the props section and select a node
      propsSection.style.display = 'block';
      topo._selectedElement = 'sw1';

      const deleteBtn = container.querySelector('[data-action="delete-node"]');
      deleteBtn.click();

      expect(propsSection.style.display).toBe('none');
    });

    it('delete-node is a no-op when no node is selected', () => {
      topo.enableMobileQuickEdit();
      topo._selectedElement = null;
      const initialCount = topo._nodes.size;

      const deleteBtn = container.querySelector('[data-action="delete-node"]');
      deleteBtn.click();

      expect(topo._nodes.size).toBe(initialCount);
    });

    it('undo-move calls _lastMoveUndo when set', () => {
      topo.enableMobileQuickEdit();
      const undoFn = vi.fn();
      topo._lastMoveUndo = undoFn;

      const undoBtn = container.querySelector('[data-action="undo-move"]');
      undoBtn.click();

      expect(undoFn).toHaveBeenCalledTimes(1);
    });

    it('undo-move is a no-op when _lastMoveUndo is not set', () => {
      topo.enableMobileQuickEdit();
      topo._lastMoveUndo = null;

      const undoBtn = container.querySelector('[data-action="undo-move"]');
      // Should not throw
      expect(() => undoBtn.click()).not.toThrow();
    });
  });

  /* ── No container (unmounted) ── */

  describe('enableMobileQuickEdit() without mounted container', () => {
    it('returns this without throwing when container does not exist', () => {
      const unmounted = new TopologyDesigner({ title: 'Unmounted' });
      // Not mounted — _containerId won't match any DOM element
      unmounted._containerId = 'nonexistent-container-id';
      const result = unmounted.enableMobileQuickEdit();
      expect(result).toBe(unmounted);
      expect(unmounted._mobileQuickEditEnabled).toBe(true);
    });

    it('does not create any DOM elements when container is absent', () => {
      const unmounted = new TopologyDesigner({ title: 'Unmounted' });
      unmounted._containerId = 'nonexistent-container-id';
      unmounted.enableMobileQuickEdit();
      // No FAB should exist anywhere — it never got appended
      expect(document.querySelector('#nonexistent-container-id')).toBeNull();
    });
  });

  /* ── disableMobileQuickEdit without container ── */

  describe('disableMobileQuickEdit() without mounted container', () => {
    it('returns this without throwing when container does not exist', () => {
      const unmounted = new TopologyDesigner({ title: 'Unmounted' });
      unmounted._containerId = 'nonexistent-disable-id';
      const result = unmounted.disableMobileQuickEdit();
      expect(result).toBe(unmounted);
    });
  });

  /* ── Chaining ── */

  describe('Chaining', () => {
    it('enableMobileQuickEdit and disableMobileQuickEdit can be chained', () => {
      const result = topo.enableMobileQuickEdit().disableMobileQuickEdit();
      expect(result).toBe(topo);
      expect(topo._mobileQuickEditEnabled).toBe(false);
      expect(container.querySelector('.tds-mobile-fab')).toBeNull();
    });

    it('can chain enable after disable', () => {
      const result = topo.enableMobileQuickEdit().disableMobileQuickEdit().enableMobileQuickEdit();
      expect(result).toBe(topo);
      expect(topo._mobileQuickEditEnabled).toBe(true);
      expect(container.querySelector('.tds-mobile-fab')).not.toBeNull();
    });
  });
});
