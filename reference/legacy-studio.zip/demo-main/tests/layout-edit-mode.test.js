import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock window.matchMedia for jsdom
window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Layout Edit Mode (#148)', () => {
  let td;

  beforeEach(() => {
    td = new TopologyDesigner({ title: 'Layout Test' });
    td.node('fw1', { type: 'firewall', x: 100, y: 200, label: 'FW-1' });
    td.node('sw1', { type: 'switch', x: 300, y: 400, label: 'SW-1' });
    td.node('srv1', { type: 'server', x: 500, y: 150, label: 'SRV-1' });
  });

  describe('_layoutEditMode flag', () => {
    it('initializes as false', () => {
      expect(td._layoutEditMode).toBe(false);
    });

    it('_savedPositions initializes as null', () => {
      expect(td._savedPositions).toBeNull();
    });
  });

  describe('enterLayoutEditMode()', () => {
    it('sets _layoutEditMode to true', () => {
      td.enterLayoutEditMode();
      expect(td._layoutEditMode).toBe(true);
    });

    it('snapshots current node positions into _savedPositions', () => {
      td.enterLayoutEditMode();
      expect(td._savedPositions).toBeInstanceOf(Map);
      expect(td._savedPositions.size).toBe(3);
      expect(td._savedPositions.get('fw1')).toEqual({ x: 100, y: 200 });
      expect(td._savedPositions.get('sw1')).toEqual({ x: 300, y: 400 });
      expect(td._savedPositions.get('srv1')).toEqual({ x: 500, y: 150 });
    });

    it('is idempotent — calling twice does not re-snapshot', () => {
      td.enterLayoutEditMode();
      // Mutate a node position after entering
      td._nodes.get('fw1').x = 999;
      td.enterLayoutEditMode(); // second call should no-op
      // Saved positions should still reflect original
      expect(td._savedPositions.get('fw1')).toEqual({ x: 100, y: 200 });
    });
  });

  describe('exitLayoutEditMode()', () => {
    it('sets _layoutEditMode to false', () => {
      td.enterLayoutEditMode();
      td.exitLayoutEditMode();
      expect(td._layoutEditMode).toBe(false);
    });

    it('restores original node positions (non-destructive)', () => {
      td.enterLayoutEditMode();
      // Simulate dragging nodes to new positions
      td._nodes.get('fw1').x = 999;
      td._nodes.get('fw1').y = 888;
      td._nodes.get('sw1').x = 777;
      td._nodes.get('sw1').y = 666;
      td.exitLayoutEditMode();
      // Positions should be restored
      expect(td._nodes.get('fw1').x).toBe(100);
      expect(td._nodes.get('fw1').y).toBe(200);
      expect(td._nodes.get('sw1').x).toBe(300);
      expect(td._nodes.get('sw1').y).toBe(400);
      expect(td._nodes.get('srv1').x).toBe(500);
      expect(td._nodes.get('srv1').y).toBe(150);
    });

    it('clears _savedPositions after exit', () => {
      td.enterLayoutEditMode();
      td.exitLayoutEditMode();
      expect(td._savedPositions).toBeNull();
    });

    it('is a no-op when not in layout edit mode', () => {
      td._nodes.get('fw1').x = 999;
      td.exitLayoutEditMode(); // should not throw or alter positions
      expect(td._nodes.get('fw1').x).toBe(999);
    });
  });

  describe('toggleLayoutEditMode()', () => {
    it('enters layout edit mode when off', () => {
      const result = td.toggleLayoutEditMode();
      expect(result).toBe(true);
      expect(td._layoutEditMode).toBe(true);
    });

    it('exits layout edit mode when on', () => {
      td.enterLayoutEditMode();
      const result = td.toggleLayoutEditMode();
      expect(result).toBe(false);
      expect(td._layoutEditMode).toBe(false);
    });

    it('round-trips: toggle on, mutate, toggle off restores positions', () => {
      td.toggleLayoutEditMode(); // enter
      td._nodes.get('fw1').x = 42;
      td._nodes.get('fw1').y = 84;
      td.toggleLayoutEditMode(); // exit — should restore
      expect(td._nodes.get('fw1').x).toBe(100);
      expect(td._nodes.get('fw1').y).toBe(200);
    });
  });

  describe('getPositionSnippet()', () => {
    it('returns a string with all node positions', () => {
      const snippet = td.getPositionSnippet();
      expect(snippet).toContain("td.node('fw1'");
      expect(snippet).toContain('x: 100');
      expect(snippet).toContain('y: 200');
      expect(snippet).toContain("td.node('sw1'");
      expect(snippet).toContain('x: 300');
      expect(snippet).toContain('y: 400');
      expect(snippet).toContain("td.node('srv1'");
    });

    it('reflects mutated positions when in layout edit mode', () => {
      td.enterLayoutEditMode();
      td._nodes.get('fw1').x = 42;
      td._nodes.get('fw1').y = 84;
      const snippet = td.getPositionSnippet();
      expect(snippet).toContain('x: 42');
      expect(snippet).toContain('y: 84');
    });

    it('returns empty string when no nodes exist', () => {
      const empty = new TopologyDesigner();
      expect(empty.getPositionSnippet()).toBe('');
    });
  });

  describe('copyPositions()', () => {
    it('returns positions map for all nodes', async () => {
      const positions = await td.copyPositions();
      expect(positions).toEqual({
        fw1: { x: 100, y: 200 },
        sw1: { x: 300, y: 400 },
        srv1: { x: 500, y: 150 },
      });
    });

    it('reflects current (possibly dragged) positions', async () => {
      td.enterLayoutEditMode();
      td._nodes.get('fw1').x = 42;
      const positions = await td.copyPositions();
      expect(positions.fw1.x).toBe(42);
    });
  });

  describe('_showCoordTooltip / _hideCoordTooltip', () => {
    it('creates tooltip element on first call and shows it', () => {
      td._showCoordTooltip(100, 200, 'fw1', 500, 300);
      expect(td._coordTooltip).toBeTruthy();
      expect(td._coordTooltip.style.display).toBe('block');
      expect(td._coordTooltip.innerHTML).toContain('fw1');
      expect(td._coordTooltip.innerHTML).toContain('x:100');
      expect(td._coordTooltip.innerHTML).toContain('y:200');
    });

    it('hides tooltip', () => {
      td._showCoordTooltip(100, 200, 'fw1', 500, 300);
      td._hideCoordTooltip();
      expect(td._coordTooltip.style.display).toBe('none');
    });

    it('_hideCoordTooltip is safe to call without prior show', () => {
      expect(() => td._hideCoordTooltip()).not.toThrow();
    });
  });

  describe('drag state variables', () => {
    it('initializes _draggingNode as null', () => {
      expect(td._draggingNode).toBeNull();
    });

    it('initializes _dragNodeOffset', () => {
      expect(td._dragNodeOffset).toEqual({ x: 0, y: 0 });
    });

    it('_onNodeReposition callback can be set via config', () => {
      const cb = vi.fn();
      const td2 = new TopologyDesigner({ onNodeReposition: cb });
      expect(td2._onNodeReposition).toBe(cb);
    });
  });

  describe('layout edit mode interaction with other features', () => {
    it('entering and exiting preserves node count', () => {
      const before = td._nodes.size;
      td.enterLayoutEditMode();
      expect(td._nodes.size).toBe(before);
      td.exitLayoutEditMode();
      expect(td._nodes.size).toBe(before);
    });

    it('nodes added during edit mode are not saved for restore', () => {
      td.enterLayoutEditMode();
      td.node('new1', { type: 'server', x: 600, y: 600, label: 'New' });
      // _savedPositions was captured before new1 was added
      expect(td._savedPositions.has('new1')).toBe(false);
      td.exitLayoutEditMode();
      // new1 still exists but its position is whatever it was set to
      expect(td._nodes.has('new1')).toBe(true);
    });
  });
});
