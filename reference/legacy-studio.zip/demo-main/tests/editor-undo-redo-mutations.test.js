import { describe, it, expect, beforeEach } from 'vitest';

let state;

function cloneState() {
  return JSON.parse(JSON.stringify({
    nodes: [...state.nodes.entries()],
    links: [...state.links.entries()],
    zones: [...state.zones.entries()],
    selectedId: state.selectedId,
    selectedType: state.selectedType,
  }));
}

function restoreState(snapshot) {
  state.nodes = new Map(snapshot.nodes);
  state.links = new Map(snapshot.links);
  state.zones = new Map(snapshot.zones);
  state.selectedId = snapshot.selectedId;
  state.selectedType = snapshot.selectedType;
}

function pushUndo(desc = 'Edit') {
  const snap = cloneState();
  snap._desc = desc;
  state._undoStack.push(snap);
  state._redoStack = [];
}

function undo() {
  if (!state._undoStack.length) return;
  const current = cloneState();
  current._desc = 'Redo';
  state._redoStack.push(current);
  restoreState(state._undoStack.pop());
}

function redo() {
  if (!state._redoStack.length) return;
  const current = cloneState();
  current._desc = 'Undo';
  state._undoStack.push(current);
  restoreState(state._redoStack.pop());
}

function serializeState() {
  return JSON.stringify({
    nodes: [...state.nodes.entries()],
    links: [...state.links.entries()],
    zones: [...state.zones.entries()],
    selectedId: state.selectedId,
    selectedType: state.selectedType,
  });
}

function deserializeState(json) {
  const parsed = JSON.parse(json);
  state.nodes = new Map(parsed.nodes);
  state.links = new Map(parsed.links);
  state.zones = new Map(parsed.zones);
  state.selectedId = parsed.selectedId;
  state.selectedType = parsed.selectedType;
}

function mutateNodeColor(id, color) {
  pushUndo('Change node color');
  state.nodes.get(id).color = color;
}

function mutateLinkStyle(id, lineStyle) {
  pushUndo('Change link style');
  state.links.get(id).lineStyle = lineStyle;
}

function mutateZoneColor(id, color) {
  pushUndo('Change zone color');
  state.zones.get(id).color = color;
}

function mutateZoneLabel(id, label) {
  pushUndo('Edit zone label');
  state.zones.get(id).label = label;
}

function assignNodesToZone(zoneId, nodeIds) {
  pushUndo('Assign nodes to zone');
  const zone = state.zones.get(zoneId);
  zone.nodes = [...new Set([...(zone.nodes || []), ...nodeIds])];
}

function makeFixture() {
  return {
    nodes: new Map([
      ['N1', { id: 'N1', type: 'router', x: 100, y: 100, label: 'Router', color: '#01a982', layer: 'physical' }],
      ['N2', { id: 'N2', type: 'switch', x: 300, y: 100, label: 'Switch', color: '#65aef9', layer: 'physical' }],
    ]),
    links: new Map([
      ['L1', { id: 'L1', type: 'line', from: 'N1', to: 'N2', color: '#01a982', lineStyle: 'straight', layer: 'physical' }],
    ]),
    zones: new Map([
      ['zone_1', { id: 'zone_1', label: 'ZONE 1', description: '', color: '#7d8a92', borderStyle: 'dashed', padding: 40, nodes: ['N1'] }],
    ]),
    selectedId: 'zone_1',
    selectedType: 'zone',
    _undoStack: [],
    _redoStack: [],
  };
}

function expectRoundTrip({ readBefore, mutate, readAfterChange, expectChanged, expectUndone, expectRedone, expectPersisted }) {
  const before = readBefore();
  const undoBefore = state._undoStack.length;

  mutate();

  const changed = readAfterChange();
  expect(state._undoStack.length).toBe(undoBefore + 1);
  expectChanged(before, changed);

  undo();
  const undone = readAfterChange();
  expectUndone(before, undone);

  redo();
  const redone = readAfterChange();
  expectRedone(changed, redone);

  const snapshot = serializeState();
  deserializeState(snapshot);
  const persisted = readAfterChange();
  expectPersisted(redone, persisted);
}

beforeEach(() => {
  state = makeFixture();
});

describe('editor mutation family — undo/redo/persistence', () => {
  it('node color changes are undoable and persist', () => {
    expectRoundTrip({
      readBefore: () => state.nodes.get('N1').color,
      mutate: () => mutateNodeColor('N1', '#ff8300'),
      readAfterChange: () => state.nodes.get('N1').color,
      expectChanged: (before, changed) => {
        expect(changed).toBe('#ff8300');
        expect(changed).not.toBe(before);
      },
      expectUndone: (before, undone) => expect(undone).toBe(before),
      expectRedone: (changed, redone) => expect(redone).toBe(changed),
      expectPersisted: (redone, persisted) => expect(persisted).toBe(redone),
    });
  });

  it('link style changes are undoable and persist', () => {
    expectRoundTrip({
      readBefore: () => state.links.get('L1').lineStyle,
      mutate: () => mutateLinkStyle('L1', 'orthogonal'),
      readAfterChange: () => state.links.get('L1').lineStyle,
      expectChanged: (before, changed) => {
        expect(changed).toBe('orthogonal');
        expect(changed).not.toBe(before);
      },
      expectUndone: (before, undone) => expect(undone).toBe(before),
      expectRedone: (changed, redone) => expect(redone).toBe(changed),
      expectPersisted: (redone, persisted) => expect(persisted).toBe(redone),
    });
  });

  it('zone color changes are undoable and persist', () => {
    expectRoundTrip({
      readBefore: () => state.zones.get('zone_1').color,
      mutate: () => mutateZoneColor('zone_1', '#fc6161'),
      readAfterChange: () => state.zones.get('zone_1').color,
      expectChanged: (before, changed) => {
        expect(changed).toBe('#fc6161');
        expect(changed).not.toBe(before);
      },
      expectUndone: (before, undone) => expect(undone).toBe(before),
      expectRedone: (changed, redone) => expect(redone).toBe(changed),
      expectPersisted: (redone, persisted) => expect(persisted).toBe(redone),
    });
  });

  it('zone label changes are undoable and persist', () => {
    expectRoundTrip({
      readBefore: () => state.zones.get('zone_1').label,
      mutate: () => mutateZoneLabel('zone_1', 'Branch Boundary'),
      readAfterChange: () => state.zones.get('zone_1').label,
      expectChanged: (before, changed) => {
        expect(changed).toBe('Branch Boundary');
        expect(changed).not.toBe(before);
      },
      expectUndone: (before, undone) => expect(undone).toBe(before),
      expectRedone: (changed, redone) => expect(redone).toBe(changed),
      expectPersisted: (redone, persisted) => expect(persisted).toBe(redone),
    });
  });

  it('adding nodes to a zone is undoable and persists', () => {
    expectRoundTrip({
      readBefore: () => [...state.zones.get('zone_1').nodes],
      mutate: () => assignNodesToZone('zone_1', ['N2']),
      readAfterChange: () => [...state.zones.get('zone_1').nodes],
      expectChanged: (before, changed) => {
        expect(changed).toContain('N2');
        expect(changed.length).toBe(before.length + 1);
      },
      expectUndone: (before, undone) => expect(undone).toEqual(before),
      expectRedone: (changed, redone) => expect(redone).toEqual(changed),
      expectPersisted: (redone, persisted) => expect(persisted).toEqual(redone),
    });
  });
});
