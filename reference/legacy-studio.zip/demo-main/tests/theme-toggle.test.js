import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Theme Toggle API (#183)', () => {
  let topo;

  beforeEach(() => {
    localStorage.clear();
    document.body.innerHTML = '<div id="app"></div>';
    topo = new TopologyDesigner({ title: 'Theme Test' });
    topo.reducedMotion = true;
    topo.node('A', { type: 'server', x: 100, y: 100, label: 'A' })
        .addStep('s1', {
          act: 'default', name: 'Step 1', goal: 'Show A',
          phases: [{ show: ['A'], diff: 'Node A' }],
        })
        .mount('app');
  });

  it('setTheme("light") adds tds-light class', () => {
    topo.setTheme('light');
    const root = document.querySelector('.tds-root');
    expect(root.classList.contains('tds-light')).toBe(true);
  });

  it('setTheme("dark") removes tds-light class', () => {
    topo.setTheme('light');
    topo.setTheme('dark');
    const root = document.querySelector('.tds-root');
    expect(root.classList.contains('tds-light')).toBe(false);
  });

  it('getTheme() returns correct value', () => {
    expect(topo.getTheme()).toBe('dark');
    topo.setTheme('light');
    expect(topo.getTheme()).toBe('light');
    topo.setTheme('dark');
    expect(topo.getTheme()).toBe('dark');
  });

  it('persists theme to localStorage', () => {
    topo.setTheme('light');
    expect(localStorage.getItem('tds-theme')).toBe('light');
    topo.setTheme('dark');
    expect(localStorage.getItem('tds-theme')).toBe('dark');
  });

  it('rejects invalid theme values', () => {
    topo.setTheme('light');
    topo.setTheme('neon'); // invalid
    expect(topo.getTheme()).toBe('light'); // unchanged
  });

  it('updates toggle button icon', () => {
    const btn = document.getElementById('tds-themeBtn');
    expect(btn).toBeTruthy();
    topo.setTheme('light');
    expect(btn.textContent).toBe('🌙');
    topo.setTheme('dark');
    expect(btn.textContent).toBe('☀️');
  });
});
