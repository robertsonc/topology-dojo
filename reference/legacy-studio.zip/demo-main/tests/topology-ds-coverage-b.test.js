import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

// Load module globals so autoLayout / loadTemplate / applyTheme work
const LayoutEngine = require('../design-system/modules/layout-engine.js');
const TemplateParser = require('../design-system/modules/template-parser.js');
const ThemeEngine = require('../design-system/modules/theme-engine.js');
globalThis.LayoutEngine = LayoutEngine;
globalThis.TemplateParser = TemplateParser;
globalThis.ThemeEngine = ThemeEngine;

/**
 * Helper: create a topo with acts/steps and mount it.
 */
function buildAndMount(opts = {}) {
  const container = document.createElement('div');
  container.id = 'test-cov-b';
  document.body.appendChild(container);

  const topo = new TopologyDesigner({
    title: 'Coverage B',
    subtitle: 'Tests',
    viewBox: '0 0 800 500',
    phaseMs: 600,
    mode: opts.mode || 'manual',
  });

  topo.node('A', { type: 'router', x: 100, y: 100, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 400, y: 100, label: 'Node B' });
  topo.node('C', { type: 'host', x: 250, y: 300, label: 'Node C' });
  topo.anchor('anc1', { x: 250, y: 100, label: 'Waypoint' });
  topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982', label: 'Link1' });
  topo.link('l2', { type: 'tunnel', from: 'A', to: 'anc1', color: '#65aef9' });
  topo.link('l3', { type: 'line', from: 'B', to: 'C', color: '#7764fc' });

  topo.act('a1', { label: 'Act One', color: '#01a982', intro: ['Intro 1'] });
  topo.act('a2', { label: 'Act Two', color: '#65aef9', intro: ['Intro 2'] });

  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show A',
    focus: ['A'],
    phases: [{ show: ['A', 'l1'], diff: 'Added A' }],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Show B',
    focus: ['B'],
    phases: [{ show: ['B', 'l2', 'anc1'], diff: 'Added B' }],
  });
  topo.addStep('s3', {
    act: 'a2', name: 'Step 3', goal: 'Show C',
    focus: ['C'],
    phases: [{ show: ['C', 'l3'], diff: 'Added C' }],
  });

  if (opts.noMount) return { topo, container };
  topo.mount('test-cov-b');
  return { topo, container };
}

describe('_advance method', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('when playing is false, calls _updateUI and returns early', () => {
    topo.playing = false;
    const spy = vi.spyOn(topo, '_updateUI');
    topo._advance();
    expect(spy).toHaveBeenCalled();
    expect(topo.playing).toBe(false);
  });

  it('when step >= _steps.length, sets playing = false', () => {
    topo.step = topo._steps.length;
    topo.playing = true;
    topo._advance();
    expect(topo.playing).toBe(false);
  });

  it('when mode is auto, sets a timer via setTimeout', () => {
    vi.useFakeTimers();
    topo.mode = 'auto';
    topo.step = 0;
    topo.playing = true;
    topo._advance();
    expect(topo.step).toBe(1);
    expect(topo._timer).not.toBeNull();
    vi.useRealTimers();
  });

  it('when mode is manual, stops playing after one advance', () => {
    topo.mode = 'manual';
    topo.step = 0;
    topo.playing = true;
    topo._advance();
    expect(topo.step).toBe(1);
    expect(topo.playing).toBe(false);
  });
});

describe('_advance presenter mode at act boundary', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount({ mode: 'presenter' }));
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('stops playing at an act boundary', () => {
    // s3 is act a2 which starts at index 2. Step is 1-based for the boundary check.
    // _isActBound checks if nextStep (step+1) matches an act start.
    // Act a2 start is at index 2 (the third step s3). _isActBound(n) checks a.start === n-1.
    // So _isActBound(3) => a2.start === 2 => true.
    // We need step=1 so that nextStep=2. Actually let's check what _isActBound does:
    // _isActBound(n) { return this._acts.some(a => a.start === n - 1 && n - 1 !== 0); }
    // We need nextStep where nextStep-1 is an act start and != 0.
    // a2.start = 2, so nextStep = 3 means _isActBound(3) => 3-1=2 === a2.start=2, true.
    // So set step = 2 so nextStep = 3.
    topo.mode = 'presenter';
    topo.step = 2;
    topo.playing = true;
    topo._advance();
    // It should advance to step 3 then stop playing
    expect(topo.step).toBe(3);
    expect(topo.playing).toBe(false);
  });
});

describe('_buildSidebar with acts', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('creates act headers and step rows', () => {
    topo._buildSidebar();
    const sidebar = container.querySelector('#tds-sidebar');
    const actHeaders = sidebar.querySelectorAll('.tds-act-hdr');
    expect(actHeaders.length).toBe(2);

    const stepRows = sidebar.querySelectorAll('.tds-step-row');
    expect(stepRows.length).toBe(3);
  });

  it('step rows contain inline thumbnail previews (#141)', () => {
    topo._buildSidebar();
    const sidebar = container.querySelector('#tds-sidebar');
    const thumbs = sidebar.querySelectorAll('.tds-step-thumb');
    expect(thumbs.length).toBe(3); // 3 steps
    // Each thumbnail should contain an SVG
    thumbs.forEach(thumb => {
      expect(thumb.querySelector('svg') || thumb.innerHTML).toBeTruthy();
      expect(thumb.innerHTML).toContain('<svg');
    });
  });

  it('inline thumbnails use ~80x50 dimensions (#141)', () => {
    topo._buildSidebar();
    const sidebar = container.querySelector('#tds-sidebar');
    const thumb = sidebar.querySelector('.tds-step-thumb svg');
    expect(thumb).toBeTruthy();
    expect(thumb.getAttribute('width')).toBe('80');
    expect(thumb.getAttribute('height')).toBe('50');
  });

  it('thumbnails refresh when sidebar is rebuilt (#141)', () => {
    topo._buildSidebar();
    const sidebar = container.querySelector('#tds-sidebar');
    const before = sidebar.querySelector('.tds-step-thumb').innerHTML;
    // Rebuild sidebar
    topo._buildSidebar();
    const after = sidebar.querySelector('.tds-step-thumb').innerHTML;
    // Should still have SVG content after rebuild
    expect(after).toContain('<svg');
  });

  it('clicking act header toggles collapse state', () => {
    topo._collapsedActs.set('a1', false);
    topo._buildSidebar();
    const sidebar = container.querySelector('#tds-sidebar');
    const header = sidebar.querySelector('.tds-act-hdr');
    header.click();
    expect(topo._collapsedActs.get('a1')).toBe(true);
    // After rebuild, the act div should have 'collapsed' class
    const actDiv = sidebar.querySelector('[data-act-id="a1"]');
    expect(actDiv.classList.contains('collapsed')).toBe(true);
  });
});

describe('_buildPips', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('creates pip elements matching step count', () => {
    topo._buildPips();
    const pips = container.querySelectorAll('.tds-pip');
    expect(pips.length).toBe(3);
  });

  it('clicking a pip navigates to that step', () => {
    topo._buildPips();
    const pips = container.querySelectorAll('.tds-pip');
    pips[1].click();
    expect(topo.step).toBe(2);
  });
});

describe('_bindEvents SVG interactions', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
    // Render to get SVG elements in the DOM
    topo.step = 1;
    topo.render();
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('dblclick on a node shows properties panel', () => {
    const svg = container.querySelector('#tds-diagram');
    const nodeEl = svg.querySelector('[data-tds-node="A"]');
    if (!nodeEl) return; // Guard in case SVG renders differently
    const dblclickEvt = new MouseEvent('dblclick', { bubbles: true });
    nodeEl.dispatchEvent(dblclickEvt);
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
  });

  it('dblclick on a link sets mode to link and shows properties', () => {
    const svg = container.querySelector('#tds-diagram');
    const linkEl = svg.querySelector('[data-tds-link="l1"]');
    if (!linkEl) return;
    const dblclickEvt = new MouseEvent('dblclick', { bubbles: true });
    linkEl.dispatchEvent(dblclickEvt);
    expect(topo.interactiveMode).toBe('link');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
  });

  it('click on anchor shows properties', () => {
    const svg = container.querySelector('#tds-diagram');
    const anchorEl = svg.querySelector('[data-tds-anchor="anc1"]');
    if (!anchorEl) return;
    const clickEvt = new MouseEvent('click', { bubbles: true });
    anchorEl.dispatchEvent(clickEvt);
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
  });

  it('security mode click on node sets blast radius', () => {
    topo._securityMode = true;
    const svg = container.querySelector('#tds-diagram');
    const nodeEl = svg.querySelector('[data-tds-node="A"]');
    if (!nodeEl) return;
    const clickEvt = new MouseEvent('click', { bubbles: true });
    nodeEl.dispatchEvent(clickEvt);
    expect(topo._blastRadiusNode).toBe('A');
    // Click again to clear — re-query because render() rebuilds SVG
    const nodeEl2 = container.querySelector('#tds-diagram [data-tds-node="A"]');
    nodeEl2.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    expect(topo._blastRadiusNode).toBe(null);
  });
});

describe('_showPropertiesPanel', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('creates panel for node type', () => {
    topo._showPropertiesPanel('A', 'node');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
    expect(panel.style.display).not.toBe('none');
  });

  it('creates panel for anchor type', () => {
    topo._showPropertiesPanel('anc1', 'anchor');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
  });

  it('creates panel for link type', () => {
    topo._showPropertiesPanel('l1', 'link');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
  });
});

describe('removeAnchor with graph shim fallback', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Shim Test' });
    // Force graph to null to use the shim path
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    // Populate shim maps directly
    topo.__nodes.set('N1', { type: 'router', x: 100, y: 100, label: 'N1' });
    topo.__anchors.set('wp1', { x: 200, y: 200, label: 'WP1' });
    topo.__links.set('lk1', { from: 'N1', to: 'wp1', type: 'line' });
    topo.__links.set('lk2', { from: 'wp1', to: 'N1', type: 'line' });
    topo.__links.set('lk3', { from: 'N1', to: 'N1', type: 'line' });

    topo._steps = [];
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('removes anchor and dependent links from shim maps', () => {
    // Need to mount minimally or stub render/hidePropertiesPanel
    const renderSpy = vi.spyOn(topo, 'render').mockImplementation(() => {});
    const hideSpy = vi.spyOn(topo, '_hidePropertiesPanel').mockImplementation(() => {});

    const result = topo.removeAnchor('wp1');
    expect(result).toBe(true);
    expect(topo.__anchors.has('wp1')).toBe(false);
    expect(topo.__links.has('lk1')).toBe(false);
    expect(topo.__links.has('lk2')).toBe(false);
    // lk3 doesn't reference wp1, so it should remain
    expect(topo.__links.has('lk3')).toBe(true);

    renderSpy.mockRestore();
    hideSpy.mockRestore();
  });

  it('returns false for non-existent anchor', () => {
    const result = topo.removeAnchor('nonexistent');
    expect(result).toBe(false);
  });
});

describe('autoLayout (applyLayout)', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('applies circular layout and returns this', () => {
    // Pass animate=false to avoid lingering requestAnimationFrame callbacks
    const result = topo.autoLayout('circular', {}, false);
    expect(result).toBe(topo);
  });

  it('warns and returns this for unknown algorithm', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.autoLayout('unknownAlgo');
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('unknown layout algorithm'));
    warnSpy.mockRestore();
  });
});

describe('loadTemplate (applyTemplate)', () => {
  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('loads 3-tier template on unmounted topo and returns this', () => {
    const topo = new TopologyDesigner({ title: 'Template Test' });
    const result = topo.loadTemplate('3-tier');
    expect(result).toBe(topo);
    expect(topo._nodes.size).toBeGreaterThan(0);
  });

  it('warns and returns this for unknown template', () => {
    const topo = new TopologyDesigner({ title: 'Template Test' });
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.loadTemplate('totally-fake-template');
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('unknown template'));
    warnSpy.mockRestore();
  });
});

describe('applyTheme', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('applies midnight theme by string and returns this', () => {
    const result = topo.applyTheme('midnight');
    expect(result).toBe(topo);
  });

  it('applies theme by object and returns this', () => {
    const result = topo.applyTheme({ primary: '#ff0000' });
    expect(result).toBe(topo);
  });

  it('warns for unknown theme string', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = topo.applyTheme('nonexistent-theme');
    expect(result).toBe(topo);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('unknown theme'));
    warnSpy.mockRestore();
  });
});

describe('fromJSON full reconstruction', () => {
  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('serializes and deserializes unmounted topo', () => {
    const original = new TopologyDesigner({ title: 'Original' });
    original.node('X', { type: 'cloud', x: 50, y: 50, label: 'Cloud' });
    original.node('Y', { type: 'host', x: 300, y: 200, label: 'Host' });
    original.anchor('a1', { x: 150, y: 100 });
    original.link('xy', { type: 'line', from: 'X', to: 'Y' });
    original.act('act1', { label: 'Act', color: '#fff' });
    original.addStep('step1', { act: 'act1', name: 'S1', goal: 'G1', focus: [], phases: [{ show: ['X'], diff: 'x' }] });
    original.glossary([{ t: 'Term', d: 'Def' }]);

    const json = original.toJSON();

    const restored = new TopologyDesigner();
    const result = restored.fromJSON(json);
    expect(result).toBe(restored);
    expect(restored.title).toBe('Original');
    expect(restored._nodes.has('X')).toBe(true);
    expect(restored._nodes.has('Y')).toBe(true);
    expect(restored._links.has('xy')).toBe(true);
    expect(restored._acts.length).toBe(1);
    expect(restored._steps.length).toBe(1);
  });

  it('fromJSON on a mounted instance re-scaffolds', () => {
    const container = document.createElement('div');
    container.id = 'fromjson-mounted';
    document.body.appendChild(container);

    const topo = new TopologyDesigner({ title: 'Mounted' });
    topo.node('M1', { type: 'router', x: 100, y: 100, label: 'M1' });
    topo.act('ma1', { label: 'Act', color: '#01a982' });
    topo.addStep('ms1', { act: 'ma1', name: 'S', goal: 'G', focus: [], phases: [{ show: ['M1'], diff: 'd' }] });
    topo.mount('fromjson-mounted');

    // Now fromJSON with new data
    const data = {
      title: 'Reconstructed',
      nodes: { R1: { type: 'switch', x: 200, y: 200, label: 'R1' } },
      links: {},
      anchors: {},
      acts: [{ id: 'ra1', label: 'Rebuilt Act', color: '#65aef9' }],
      steps: [{ id: 'rs1', act: 'ra1', name: 'Rebuilt', goal: 'RG', focus: [], phases: [{ show: ['R1'], diff: 'rd' }] }],
    };
    topo.fromJSON(data);

    expect(topo.title).toBe('Reconstructed');
    expect(topo._nodes.has('R1')).toBe(true);
    // Check that the container was re-scaffolded (it should have the sidebar etc.)
    const sidebar = container.querySelector('#tds-sidebar');
    expect(sidebar).not.toBeNull();

    topo.pause();
  });
});

describe('_interpolatePositionInline', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('calls requestAnimationFrame', () => {
    const rafSpy = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(cb => {
      cb();
      return 0;
    });
    topo._interpolatePositionInline('A', 0, 0, 100, 100);
    expect(rafSpy).toHaveBeenCalled();
    rafSpy.mockRestore();
  });
});

describe('render with position keyframes', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('updates node position from _positions map on step change', () => {
    const nodeCfg = topo._nodes.get('A');
    // _positions keyed by this.step value (0 = overview, 1 = first step, etc.)
    nodeCfg._positions = {};
    nodeCfg._positions[1] = { x: 200, y: 200 };
    nodeCfg._positions[2] = { x: 400, y: 400 };

    // First render at step 0 to establish _lastRenderedStep
    topo.step = 0;
    topo.render();

    // Render at step 1 — prevStep is 0 which is >= 0, but coords same as initial (100,100) vs (200,200)
    // Since prevStep=0 >= 0 and !reducedMotion, it will interpolate
    const rafSpy = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(cb => {
      cb();
      return 0;
    });
    topo.step = 1;
    topo.render();
    expect(nodeCfg.x).toBe(200);
    expect(nodeCfg.y).toBe(200);

    // Now step 2 - should trigger interpolation path
    topo.step = 2;
    topo.render();
    expect(nodeCfg.x).toBe(400);
    expect(nodeCfg.y).toBe(400);
    rafSpy.mockRestore();
  });

  it('uses direct assignment when reducedMotion is true', () => {
    topo.reducedMotion = true;
    const nodeCfg = topo._nodes.get('A');
    nodeCfg._positions = {};
    nodeCfg._positions[1] = { x: 200, y: 200 };
    nodeCfg._positions[2] = { x: 400, y: 400 };

    topo.step = 0;
    topo.render();
    topo.step = 1;
    topo.render();
    expect(nodeCfg.x).toBe(200);
    expect(nodeCfg.y).toBe(200);
    topo.step = 2;
    topo.render();
    expect(nodeCfg.x).toBe(400);
    expect(nodeCfg.y).toBe(400);
  });
});

describe('Mode selector change event', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });
  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('changes mode when select element fires change event', () => {
    const modeSelect = container.querySelector('#tds-modeSel');
    expect(modeSelect).not.toBeNull();
    modeSelect.value = 'auto';
    modeSelect.dispatchEvent(new Event('change'));
    expect(topo.mode).toBe('auto');
  });

  it('overrides to manual when reducedMotion is true', () => {
    topo.reducedMotion = true;
    const modeSelect = container.querySelector('#tds-modeSel');
    modeSelect.value = 'auto';
    modeSelect.dispatchEvent(new Event('change'));
    expect(topo.mode).toBe('manual');
  });
});
