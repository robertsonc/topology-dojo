import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Intelligence Layer', () => {
  let topo;

  function buildSecurityTopo() {
    topo = new TopologyDesigner({ title: 'Security Test' });
    topo.reducedMotion = true;
    // cloud -> router -> firewall -> database
    topo.node('cloud', { type: 'cloud', x: 100, y: 50, label: 'Internet' })
        .node('router', { type: 'router', x: 300, y: 150, label: 'Edge Router' })
        .node('fw', { type: 'firewall', x: 500, y: 150, label: 'Firewall' })
        .node('db', { type: 'database', x: 700, y: 300, label: 'Database' })
        .node('host', { type: 'host', x: 100, y: 300, label: 'Workstation' })
        .link('l1', { type: 'line', from: 'cloud', to: 'router' })
        .link('l2', { type: 'tunnel', from: 'router', to: 'fw' })
        .link('l3', { type: 'line', from: 'fw', to: 'db' })
        .link('l4', { type: 'line', from: 'host', to: 'router' })
        .act('act1', { label: 'Act One', color: '#01a982' })
        .addStep('step1', {
          act: 'act1', name: 'Step One', goal: 'Show all',
          focus: [],
          phases: [{ show: ['cloud', 'router', 'fw', 'db', 'host', 'l1', 'l2', 'l3', 'l4'], diff: 'All' }],
        });
    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildSecurityTopo();
  });

  describe('validatePath()', () => {
    it('detects missing firewall between cloud and database via direct link', () => {
      // Add a direct cloud-to-database link with no firewall in path
      topo.node('cloud2', { type: 'cloud', x: 100, y: 50, label: 'Cloud 2' })
          .node('db2', { type: 'database', x: 700, y: 300, label: 'DB 2' })
          .link('direct', { type: 'line', from: 'cloud2', to: 'db2' });
      topo._buildIndex();
      const result = topo.validatePath('cloud2', 'db2');
      expect(result.valid).toBe(false);
      expect(result.violations.length).toBeGreaterThan(0);
    });

    it('passes when firewall exists in path', () => {
      const result = topo.validatePath('cloud', 'db');
      expect(result.valid).toBe(true);
      expect(result.violations).toHaveLength(0);
    });

    it('returns empty violations for unrelated paths (no security concern)', () => {
      // host -> router: both non-sensitive/non-public, so no direct violation
      const result = topo.validatePath('host', 'router', { requireTypes: [] });
      expect(result.valid).toBe(true);
      expect(result.violations).toHaveLength(0);
    });

    it('handles no-path-exists case', () => {
      topo.node('isolated', { type: 'server', x: 900, y: 900, label: 'Isolated' });
      topo._buildIndex();
      const result = topo.validatePath('cloud', 'isolated');
      expect(result.valid).toBe(false);
      expect(result.violations).toContain('No path exists');
    });
  });

  describe('validateTopology()', () => {
    it('validates all links and caches results', () => {
      // Add a direct link bypassing firewall
      topo.node('cloud2', { type: 'cloud', x: 50, y: 50, label: 'Cloud2' })
          .node('db2', { type: 'database', x: 800, y: 400, label: 'DB2' })
          .link('bad', { type: 'line', from: 'cloud2', to: 'db2' });
      topo._buildIndex();
      const results = topo.validateTopology();
      expect(Array.isArray(results)).toBe(true);
      // The bad link should have violations
      const badResult = results.find(r => r.linkId === 'bad');
      expect(badResult).toBeDefined();
      expect(badResult.violations.length).toBeGreaterThan(0);
      // Results are cached
      expect(topo._pathViolations).toBe(results);
    });

    it('returns empty array for healthy topology', () => {
      const results = topo.validateTopology();
      // The base topology has firewall in the path from cloud to db
      // host->router doesn't cross public/private boundary in a violating way
      expect(Array.isArray(results)).toBe(true);
    });
  });

  describe('toggleSecurityMode()', () => {
    it('toggles and returns state', () => {
      expect(topo._securityMode).toBe(false);
      const on = topo.toggleSecurityMode();
      expect(on).toBe(true);
      expect(topo._securityMode).toBe(true);
      const off = topo.toggleSecurityMode();
      expect(off).toBe(false);
      expect(topo._securityMode).toBe(false);
    });

    it('accepts explicit boolean', () => {
      topo.toggleSecurityMode(true);
      expect(topo._securityMode).toBe(true);
      topo.toggleSecurityMode(true);
      expect(topo._securityMode).toBe(true);
      topo.toggleSecurityMode(false);
      expect(topo._securityMode).toBe(false);
    });

    it('runs validateTopology when enabling', () => {
      topo.node('cloud2', { type: 'cloud', x: 50, y: 50, label: 'Cloud2' })
          .node('db2', { type: 'database', x: 800, y: 400, label: 'DB2' })
          .link('bad', { type: 'line', from: 'cloud2', to: 'db2' });
      topo._buildIndex();
      topo.toggleSecurityMode(true);
      expect(topo._pathViolations.length).toBeGreaterThan(0);
    });

    it('clears violations and blast radius node when disabling', () => {
      topo.toggleSecurityMode(true);
      topo._blastRadiusNode = 'router';
      topo.toggleSecurityMode(false);
      expect(topo._pathViolations).toHaveLength(0);
      expect(topo._blastRadiusNode).toBeNull();
    });
  });

  describe('getBlastRadius()', () => {
    it('returns correct set for BFS within N hops', () => {
      const reachable = topo.getBlastRadius('router', 1);
      expect(reachable).toBeInstanceOf(Set);
      expect(reachable.has('router')).toBe(true);
      expect(reachable.has('cloud')).toBe(true);
      expect(reachable.has('fw')).toBe(true);
      expect(reachable.has('host')).toBe(true);
    });

    it('with 1 hop returns direct neighbors', () => {
      const reachable = topo.getBlastRadius('fw', 1);
      expect(reachable.has('fw')).toBe(true);
      expect(reachable.has('router')).toBe(true);
      expect(reachable.has('db')).toBe(true);
      expect(reachable.has('cloud')).toBe(false);
    });

    it('with 2 hops returns 2-hop neighborhood', () => {
      const reachable = topo.getBlastRadius('fw', 2);
      expect(reachable.has('fw')).toBe(true);
      expect(reachable.has('router')).toBe(true);
      expect(reachable.has('db')).toBe(true);
      expect(reachable.has('cloud')).toBe(true);
      expect(reachable.has('host')).toBe(true);
    });

    it('with 3 hops reaches entire topology', () => {
      const reachable = topo.getBlastRadius('db', 3);
      expect(reachable.has('db')).toBe(true);
      expect(reachable.has('fw')).toBe(true);
      expect(reachable.has('router')).toBe(true);
      expect(reachable.has('cloud')).toBe(true);
      expect(reachable.has('host')).toBe(true);
    });

    it('always includes the origin node', () => {
      const reachable = topo.getBlastRadius('db', 0);
      expect(reachable.has('db')).toBe(true);
      expect(reachable.size).toBe(1);
    });
  });

  describe('setBlastRadiusNode()', () => {
    it('sets blast radius node and returns this', () => {
      const result = topo.setBlastRadiusNode('router');
      expect(result).toBe(topo);
      expect(topo._blastRadiusNode).toBe('router');
    });

    it('clears blast radius node with null', () => {
      topo.setBlastRadiusNode('router');
      topo.setBlastRadiusNode(null);
      expect(topo._blastRadiusNode).toBeNull();
    });
  });

  describe('_renderViolationOverlay()', () => {
    it('returns empty when not in security mode', () => {
      topo._securityMode = false;
      expect(topo._renderViolationOverlay('l1')).toBe('');
    });

    it('returns empty when no violations exist', () => {
      topo._securityMode = true;
      topo._pathViolations = [];
      expect(topo._renderViolationOverlay('l1')).toBe('');
    });

    it('returns empty for links without violations', () => {
      topo._securityMode = true;
      topo._pathViolations = [{ linkId: 'other', from: 'cloud', to: 'db', violations: ['test'] }];
      expect(topo._renderViolationOverlay('l1')).toBe('');
    });

    it('returns SVG overlay for violated link', () => {
      topo._securityMode = true;
      topo._pathViolations = [{ linkId: 'l1', from: 'cloud', to: 'router', violations: ['Missing firewall'] }];
      const svg = topo._renderViolationOverlay('l1');
      expect(svg).toContain('<circle');
      expect(svg).toContain('#fc6161');
      expect(svg).toContain('!');
      expect(svg).toContain('Missing firewall');
    });
  });

  describe('_evaluateCondition()', () => {
    it('== operator', () => {
      topo.setState('mode', 'active');
      expect(topo._evaluateCondition('mode == "active"')).toBe(true);
      expect(topo._evaluateCondition('mode == "inactive"')).toBe(false);
    });

    it('!= operator', () => {
      topo.setState('mode', 'active');
      expect(topo._evaluateCondition('mode != "inactive"')).toBe(true);
      expect(topo._evaluateCondition('mode != "active"')).toBe(false);
    });

    it('> operator', () => {
      topo.setState('count', 10);
      expect(topo._evaluateCondition('count > 5')).toBe(true);
      expect(topo._evaluateCondition('count > 10')).toBe(false);
      expect(topo._evaluateCondition('count > 15')).toBe(false);
    });

    it('< operator', () => {
      topo.setState('count', 3);
      expect(topo._evaluateCondition('count < 10')).toBe(true);
      expect(topo._evaluateCondition('count < 3')).toBe(false);
      expect(topo._evaluateCondition('count < 1')).toBe(false);
    });

    it('truthy check', () => {
      topo.setState('enabled', true);
      expect(topo._evaluateCondition('enabled')).toBe(true);
      topo.setState('disabled', false);
      expect(topo._evaluateCondition('disabled')).toBe(false);
      expect(topo._evaluateCondition('nonexistent')).toBe(false);
    });
  });
});
