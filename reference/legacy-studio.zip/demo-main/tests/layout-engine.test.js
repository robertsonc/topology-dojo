import { describe, it, expect } from 'vitest';

const LayoutEngine = require('../design-system/modules/layout-engine.js');

describe('LayoutEngine', () => {

  describe('_toNodeArray', () => {
    it('converts a Map to an array', () => {
      const map = new Map([
        ['A', { id: 'A', x: 10, y: 20 }],
        ['B', { id: 'B', x: 30, y: 40 }],
      ]);
      const arr = LayoutEngine._toNodeArray(map);
      expect(arr).toHaveLength(2);
      expect(arr[0].id).toBe('A');
    });

    it('passes arrays through unchanged', () => {
      const arr = [{ id: 'A' }, { id: 'B' }];
      expect(LayoutEngine._toNodeArray(arr)).toBe(arr);
    });

    it('returns empty array for invalid input', () => {
      expect(LayoutEngine._toNodeArray(null)).toEqual([]);
      expect(LayoutEngine._toNodeArray(undefined)).toEqual([]);
      expect(LayoutEngine._toNodeArray(42)).toEqual([]);
    });
  });

  describe('_toLinkArray', () => {
    it('converts a Map to an array', () => {
      const map = new Map([
        ['l1', { from: 'A', to: 'B' }],
      ]);
      const arr = LayoutEngine._toLinkArray(map);
      expect(arr).toHaveLength(1);
      expect(arr[0].from).toBe('A');
    });

    it('returns empty array for invalid input', () => {
      expect(LayoutEngine._toLinkArray(null)).toEqual([]);
    });
  });

  describe('circular', () => {
    it('returns empty map for no nodes', () => {
      const result = LayoutEngine.circular([]);
      expect(result.size).toBe(0);
    });

    it('places single node at top of circle', () => {
      const result = LayoutEngine.circular([{ id: 'A' }]);
      expect(result.size).toBe(1);
      const pos = result.get('A');
      expect(pos.x).toBe(525); // center
      expect(pos.y).toBeLessThan(350); // top half
    });

    it('places all nodes equidistant from center', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }, { id: 'D' }];
      const result = LayoutEngine.circular(nodes, { width: 1000, height: 1000 });
      const cx = 500, cy = 500;
      const distances = [...result.values()].map(p =>
        Math.sqrt((p.x - cx) ** 2 + (p.y - cy) ** 2)
      );
      // All distances should be approximately equal
      const avgDist = distances.reduce((a, b) => a + b, 0) / distances.length;
      distances.forEach(d => {
        expect(Math.abs(d - avgDist)).toBeLessThan(2); // rounding tolerance
      });
    });

    it('respects width/height options', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }];
      const result = LayoutEngine.circular(nodes, { width: 500, height: 300, padding: 50 });
      result.forEach(pos => {
        expect(pos.x).toBeGreaterThanOrEqual(0);
        expect(pos.x).toBeLessThanOrEqual(500);
        expect(pos.y).toBeGreaterThanOrEqual(0);
        expect(pos.y).toBeLessThanOrEqual(300);
      });
    });

    it('accepts Map input', () => {
      const map = new Map([['A', { id: 'A' }], ['B', { id: 'B' }]]);
      const result = LayoutEngine.circular(map);
      expect(result.size).toBe(2);
    });
  });

  describe('grid', () => {
    it('returns empty map for no nodes', () => {
      expect(LayoutEngine.grid([]).size).toBe(0);
    });

    it('places nodes in grid positions', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }, { id: 'D' }];
      const result = LayoutEngine.grid(nodes, { columns: 2 });
      expect(result.size).toBe(4);
      // With 2 columns, A and B share a row, C and D share a row
      const a = result.get('A'), b = result.get('B');
      const c = result.get('C'), d = result.get('D');
      expect(a.y).toBe(c.y - (c.y - a.y)); // A and C in diff rows
      expect(a.x).toBe(c.x); // A and C in same column
      expect(b.x).toBe(d.x); // B and D in same column
    });

    it('auto-calculates columns when columns=0', () => {
      const nodes = Array.from({ length: 9 }, (_, i) => ({ id: `N${i}` }));
      const result = LayoutEngine.grid(nodes);
      expect(result.size).toBe(9);
      // sqrt(9) = 3, so should be 3 columns
    });

    it('keeps all positions within bounds', () => {
      const nodes = Array.from({ length: 12 }, (_, i) => ({ id: `N${i}` }));
      const result = LayoutEngine.grid(nodes, { width: 800, height: 600, padding: 80 });
      result.forEach(pos => {
        expect(pos.x).toBeGreaterThanOrEqual(0);
        expect(pos.x).toBeLessThanOrEqual(800);
        expect(pos.y).toBeGreaterThanOrEqual(0);
        expect(pos.y).toBeLessThanOrEqual(600);
      });
    });
  });

  describe('hierarchical', () => {
    it('returns empty map for no nodes', () => {
      expect(LayoutEngine.hierarchical([], []).size).toBe(0);
    });

    it('assigns layers based on graph structure', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }];
      const links = [{ from: 'A', to: 'B' }, { from: 'B', to: 'C' }];
      const result = LayoutEngine.hierarchical(nodes, links, { direction: 'TB' });

      const a = result.get('A'), b = result.get('B'), c = result.get('C');
      // In TB direction, A should be above B, B above C
      expect(a.y).toBeLessThan(b.y);
      expect(b.y).toBeLessThan(c.y);
    });

    it('handles LR direction', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }];
      const links = [{ from: 'A', to: 'B' }];
      const result = LayoutEngine.hierarchical(nodes, links, { direction: 'LR' });
      expect(result.get('A').x).toBeLessThan(result.get('B').x);
    });

    it('handles BT direction (reversed vertical)', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }];
      const links = [{ from: 'A', to: 'B' }];
      const result = LayoutEngine.hierarchical(nodes, links, { direction: 'BT' });
      expect(result.get('A').y).toBeGreaterThan(result.get('B').y);
    });

    it('handles RL direction (reversed horizontal)', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }];
      const links = [{ from: 'A', to: 'B' }];
      const result = LayoutEngine.hierarchical(nodes, links, { direction: 'RL' });
      expect(result.get('A').x).toBeGreaterThan(result.get('B').x);
    });

    it('handles nodes with no connections', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }];
      const links = [{ from: 'A', to: 'B' }];
      const result = LayoutEngine.hierarchical(nodes, links);
      expect(result.size).toBe(3);
      expect(result.has('C')).toBe(true);
    });

    it('handles tree-like topology (fan-out)', () => {
      const nodes = [{ id: 'ROOT' }, { id: 'L1' }, { id: 'L2' }, { id: 'L3' }];
      const links = [
        { from: 'ROOT', to: 'L1' },
        { from: 'ROOT', to: 'L2' },
        { from: 'ROOT', to: 'L3' },
      ];
      const result = LayoutEngine.hierarchical(nodes, links, { direction: 'TB' });
      // ROOT should be higher than all children
      const rootY = result.get('ROOT').y;
      ['L1', 'L2', 'L3'].forEach(id => {
        expect(result.get(id).y).toBeGreaterThan(rootY);
      });
    });

    it('accepts Map inputs', () => {
      const nodes = new Map([['A', { id: 'A' }], ['B', { id: 'B' }]]);
      const links = new Map([['l1', { from: 'A', to: 'B' }]]);
      const result = LayoutEngine.hierarchical(nodes, links);
      expect(result.size).toBe(2);
    });
  });

  describe('forceDirected', () => {
    it('returns empty map for no nodes', () => {
      expect(LayoutEngine.forceDirected([], []).size).toBe(0);
    });

    it('positions all nodes within bounds', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }];
      const links = [{ from: 'A', to: 'B' }, { from: 'B', to: 'C' }];
      const result = LayoutEngine.forceDirected(nodes, links, {
        width: 1000, height: 800, padding: 60, iterations: 50,
      });
      result.forEach(pos => {
        expect(pos.x).toBeGreaterThanOrEqual(60);
        expect(pos.x).toBeLessThanOrEqual(940);
        expect(pos.y).toBeGreaterThanOrEqual(60);
        expect(pos.y).toBeLessThanOrEqual(740);
      });
    });

    it('keeps connected nodes closer than unconnected nodes', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }, { id: 'C' }];
      const links = [{ from: 'A', to: 'B' }]; // A-B connected, C isolated
      const result = LayoutEngine.forceDirected(nodes, links, { iterations: 100 });

      const a = result.get('A'), b = result.get('B'), c = result.get('C');
      const distAB = Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
      const distAC = Math.sqrt((a.x - c.x) ** 2 + (a.y - c.y) ** 2);
      const distBC = Math.sqrt((b.x - c.x) ** 2 + (b.y - c.y) ** 2);
      const avgUnconnected = (distAC + distBC) / 2;
      // Connected pair should generally be closer (force-directed is non-deterministic
      // but with enough iterations the spring force should pull A-B closer)
      // We just verify all nodes get positioned
      expect(result.size).toBe(3);
    });

    it('separates nodes that are not connected', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }];
      const links = []; // no connections — repulsion only
      const result = LayoutEngine.forceDirected(nodes, links, { iterations: 100 });
      const a = result.get('A'), b = result.get('B');
      const dist = Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
      expect(dist).toBeGreaterThan(50); // repulsion should push them apart
    });

    it('returns integer positions', () => {
      const nodes = [{ id: 'A' }, { id: 'B' }];
      const result = LayoutEngine.forceDirected(nodes, [], { iterations: 10 });
      result.forEach(pos => {
        expect(Number.isInteger(pos.x)).toBe(true);
        expect(Number.isInteger(pos.y)).toBe(true);
      });
    });
  });

  describe('magneticNorth', () => {
    it('returns positions for all nodes', () => {
      const nodes = [
        { id: 'cloud1', type: 'cloud' },
        { id: 'fw1', type: 'firewall' },
        { id: 'host1', type: 'host' },
      ];
      const links = [
        { from: 'cloud1', to: 'fw1' },
        { from: 'fw1', to: 'host1' },
      ];
      const result = LayoutEngine.magneticNorth(nodes, links);
      expect(result.size).toBe(3);
      expect(result.has('cloud1')).toBe(true);
      expect(result.has('fw1')).toBe(true);
      expect(result.has('host1')).toBe(true);
    });

    it('positions are within canvas bounds', () => {
      const nodes = [
        { id: 'cloud1', type: 'cloud' },
        { id: 'router1', type: 'router' },
        { id: 'fw1', type: 'firewall' },
        { id: 'host1', type: 'host' },
        { id: 'db1', type: 'database' },
      ];
      const links = [
        { from: 'cloud1', to: 'router1' },
        { from: 'router1', to: 'fw1' },
        { from: 'fw1', to: 'host1' },
        { from: 'fw1', to: 'db1' },
      ];
      const result = LayoutEngine.magneticNorth(nodes, links, {
        width: 1050, height: 700, padding: 70,
      });
      result.forEach(pos => {
        expect(pos.x).toBeGreaterThanOrEqual(70);
        expect(pos.x).toBeLessThanOrEqual(980);
        expect(pos.y).toBeGreaterThanOrEqual(70);
        expect(pos.y).toBeLessThanOrEqual(630);
      });
    });

    it('cloud-type nodes are positioned in upper portion', () => {
      const nodes = [
        { id: 'c1', type: 'cloud' },
        { id: 'c2', type: 'saas' },
        { id: 'r1', type: 'router' },
        { id: 'h1', type: 'host' },
      ];
      const links = [
        { from: 'c1', to: 'r1' },
        { from: 'c2', to: 'r1' },
        { from: 'r1', to: 'h1' },
      ];
      const height = 700;
      const result = LayoutEngine.magneticNorth(nodes, links, { height });
      expect(result.get('c1').y).toBeLessThan(height * 0.4);
      expect(result.get('c2').y).toBeLessThan(height * 0.4);
    });

    it('host-type nodes are positioned in lower portion', () => {
      const nodes = [
        { id: 'c1', type: 'cloud' },
        { id: 'r1', type: 'router' },
        { id: 'h1', type: 'host' },
        { id: 'h2', type: 'database' },
      ];
      const links = [
        { from: 'c1', to: 'r1' },
        { from: 'r1', to: 'h1' },
        { from: 'r1', to: 'h2' },
      ];
      const height = 700;
      const result = LayoutEngine.magneticNorth(nodes, links, { height });
      expect(result.get('h1').y).toBeGreaterThan(height * 0.6);
      expect(result.get('h2').y).toBeGreaterThan(height * 0.6);
    });

    it('core infrastructure (router/firewall) positioned in middle zone', () => {
      const nodes = [
        { id: 'c1', type: 'cloud' },
        { id: 'r1', type: 'router' },
        { id: 'fw1', type: 'firewall' },
        { id: 'h1', type: 'host' },
      ];
      const links = [
        { from: 'c1', to: 'r1' },
        { from: 'r1', to: 'fw1' },
        { from: 'fw1', to: 'h1' },
      ];
      const height = 700;
      const result = LayoutEngine.magneticNorth(nodes, links, { height });
      const r1y = result.get('r1').y;
      const fw1y = result.get('fw1').y;
      expect(r1y).toBeGreaterThan(height * 0.25);
      expect(r1y).toBeLessThan(height * 0.7);
      expect(fw1y).toBeGreaterThan(height * 0.25);
      expect(fw1y).toBeLessThan(height * 0.7);
    });

    it('works with empty nodes (returns empty map)', () => {
      const result = LayoutEngine.magneticNorth([], []);
      expect(result.size).toBe(0);
    });

    it('respects custom options (width, height, padding)', () => {
      const nodes = [
        { id: 'c1', type: 'cloud' },
        { id: 'h1', type: 'host' },
      ];
      const links = [{ from: 'c1', to: 'h1' }];
      const result = LayoutEngine.magneticNorth(nodes, links, {
        width: 500, height: 300, padding: 50,
      });
      result.forEach(pos => {
        expect(pos.x).toBeGreaterThanOrEqual(50);
        expect(pos.x).toBeLessThanOrEqual(450);
        expect(pos.y).toBeGreaterThanOrEqual(50);
        expect(pos.y).toBeLessThanOrEqual(250);
      });
    });

    it('returns integer positions', () => {
      const nodes = [
        { id: 'c1', type: 'cloud' },
        { id: 'r1', type: 'router' },
        { id: 'h1', type: 'host' },
      ];
      const links = [
        { from: 'c1', to: 'r1' },
        { from: 'r1', to: 'h1' },
      ];
      const result = LayoutEngine.magneticNorth(nodes, links);
      result.forEach(pos => {
        expect(Number.isInteger(pos.x)).toBe(true);
        expect(Number.isInteger(pos.y)).toBe(true);
      });
    });

    it('accepts Map input', () => {
      const nodes = new Map([
        ['c1', { id: 'c1', type: 'cloud' }],
        ['h1', { id: 'h1', type: 'host' }],
      ]);
      const links = new Map([
        ['l1', { from: 'c1', to: 'h1' }],
      ]);
      const result = LayoutEngine.magneticNorth(nodes, links);
      expect(result.size).toBe(2);
    });
  });

  describe('network', () => {
    it('returns empty map for no nodes', () => {
      expect(LayoutEngine.network([], []).size).toBe(0);
    });

    it('positions all nodes', () => {
      const nodes = [
        { id: 'INET', type: 'cloud' },
        { id: 'EC1', type: 'ec' },
        { id: 'SW1', type: 'switch' },
        { id: 'H1', type: 'host' },
      ];
      const links = [
        { from: 'INET', to: 'EC1' },
        { from: 'EC1', to: 'SW1' },
        { from: 'SW1', to: 'H1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(4);
      result.forEach(pos => {
        expect(typeof pos.x).toBe('number');
        expect(typeof pos.y).toBe('number');
      });
    });

    it('places cloud nodes above WAN nodes', () => {
      const nodes = [
        { id: 'INET', type: 'cloud' },
        { id: 'SAAS', type: 'saas' },
        { id: 'EC1', type: 'ec' },
        { id: 'R1', type: 'router' },
      ];
      const links = [
        { from: 'INET', to: 'EC1' },
        { from: 'SAAS', to: 'R1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      const cloudY = result.get('INET').y;
      const wanY = result.get('EC1').y;
      expect(cloudY).toBeLessThan(wanY);
    });

    it('places LAN nodes below WAN nodes', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'SW1', type: 'switch' },
        { id: 'H1', type: 'host' },
        { id: 'DB1', type: 'database' },
      ];
      const links = [
        { from: 'EC1', to: 'SW1' },
        { from: 'EC1', to: 'H1' },
        { from: 'EC1', to: 'DB1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      const wanY = result.get('EC1').y;
      expect(result.get('SW1').y).toBeGreaterThan(wanY);
      expect(result.get('H1').y).toBeGreaterThan(wanY);
      expect(result.get('DB1').y).toBeGreaterThan(wanY);
    });

    it('groups LAN children under their WAN parent', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'EC2', type: 'ec' },
        { id: 'H1', type: 'host' },
        { id: 'H2', type: 'host' },
      ];
      const links = [
        { from: 'EC1', to: 'H1' },
        { from: 'EC2', to: 'H2' },
      ];
      const result = LayoutEngine.network(nodes, links);
      // H1 should be near EC1, H2 near EC2
      const ec1X = result.get('EC1').x;
      const ec2X = result.get('EC2').x;
      const h1X = result.get('H1').x;
      const h2X = result.get('H2').x;
      // H1 should be closer to EC1 than to EC2
      expect(Math.abs(h1X - ec1X)).toBeLessThanOrEqual(Math.abs(h1X - ec2X) + 1);
    });

    it('handles unassigned LAN nodes (no WAN parent)', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'H1', type: 'host' },
        { id: 'H2', type: 'host' },
      ];
      const links = [
        { from: 'EC1', to: 'H1' },
        // H2 has no links to any WAN node
      ];
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(3);
      expect(result.has('H2')).toBe(true);
    });

    it('handles WAN-only topology (no cloud, no LAN)', () => {
      const nodes = [
        { id: 'R1', type: 'router' },
        { id: 'R2', type: 'router' },
        { id: 'FW1', type: 'firewall' },
      ];
      const links = [
        { from: 'R1', to: 'R2' },
        { from: 'R2', to: 'FW1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(3);
    });

    it('handles nodes not in standard tiers (connector, shape types)', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'CON1', type: 'connector' },
        { id: 'TXT1', type: 'text' },
      ];
      const links = [
        { from: 'EC1', to: 'CON1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(3);
      // Unrecognized types should still get positions
      expect(result.has('TXT1')).toBe(true);
    });

    it('stacks LAN children into rows when many children', () => {
      const nodes = [{ id: 'EC1', type: 'ec' }];
      const links = [];
      // Add 6 hosts connected to EC1
      for (let i = 1; i <= 6; i++) {
        nodes.push({ id: `H${i}`, type: 'host' });
        links.push({ from: 'EC1', to: `H${i}` });
      }
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(7);
      // All hosts should be below EC1
      const ecY = result.get('EC1').y;
      for (let i = 1; i <= 6; i++) {
        expect(result.get(`H${i}`).y).toBeGreaterThan(ecY);
      }
    });

    it('positions snap to grid', () => {
      const nodes = [
        { id: 'INET', type: 'cloud' },
        { id: 'EC1', type: 'ec' },
        { id: 'H1', type: 'host' },
      ];
      const links = [
        { from: 'INET', to: 'EC1' },
        { from: 'EC1', to: 'H1' },
      ];
      const result = LayoutEngine.network(nodes, links, { snapGrid: 12 });
      result.forEach(pos => {
        expect(pos.x % 12).toBe(0);
        expect(pos.y % 12).toBe(0);
      });
    });

    it('accepts Map inputs', () => {
      const nodes = new Map([
        ['EC1', { id: 'EC1', type: 'ec' }],
        ['H1', { id: 'H1', type: 'host' }],
      ]);
      const links = new Map([
        ['l1', { from: 'EC1', to: 'H1' }],
      ]);
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(2);
    });

    it('handles LAN nodes connected only to other LAN nodes via second pass', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'SW1', type: 'switch' },
        { id: 'H1', type: 'host' },
      ];
      const links = [
        { from: 'EC1', to: 'SW1' },
        { from: 'SW1', to: 'H1' },  // H1 connected to LAN peer SW1, not directly to EC1
      ];
      const result = LayoutEngine.network(nodes, links);
      expect(result.size).toBe(3);
      // Both SW1 and H1 should be below EC1
      const ecY = result.get('EC1').y;
      expect(result.get('SW1').y).toBeGreaterThan(ecY);
    });

    it('handles overlayCloud type as cloud tier', () => {
      const nodes = [
        { id: 'OC', type: 'overlayCloud' },
        { id: 'EC1', type: 'ec' },
      ];
      const links = [{ from: 'OC', to: 'EC1' }];
      const result = LayoutEngine.network(nodes, links);
      expect(result.get('OC').y).toBeLessThan(result.get('EC1').y);
    });

    it('handles switchEnterprise, ap, idcard as LAN tier', () => {
      const nodes = [
        { id: 'EC1', type: 'ec' },
        { id: 'SE1', type: 'switchEnterprise' },
        { id: 'AP1', type: 'ap' },
        { id: 'ID1', type: 'idcard' },
      ];
      const links = [
        { from: 'EC1', to: 'SE1' },
        { from: 'EC1', to: 'AP1' },
        { from: 'EC1', to: 'ID1' },
      ];
      const result = LayoutEngine.network(nodes, links);
      const ecY = result.get('EC1').y;
      expect(result.get('SE1').y).toBeGreaterThan(ecY);
      expect(result.get('AP1').y).toBeGreaterThan(ecY);
      expect(result.get('ID1').y).toBeGreaterThan(ecY);
    });
  });

  describe('apply', () => {
    it('updates node positions on a topology-like object', () => {
      const topo = {
        _nodes: new Map([
          ['A', { id: 'A', x: 0, y: 0 }],
          ['B', { id: 'B', x: 0, y: 0 }],
        ]),
        _mounted: false,
        render: () => {},
      };

      const positions = new Map([
        ['A', { x: 100, y: 200 }],
        ['B', { x: 300, y: 400 }],
      ]);

      LayoutEngine.apply(topo, positions, false);
      expect(topo._nodes.get('A').x).toBe(100);
      expect(topo._nodes.get('A').y).toBe(200);
      expect(topo._nodes.get('B').x).toBe(300);
      expect(topo._nodes.get('B').y).toBe(400);
    });

    it('ignores positions for non-existent nodes', () => {
      const topo = {
        _nodes: new Map([['A', { id: 'A', x: 0, y: 0 }]]),
        _mounted: false,
        render: () => {},
      };
      const positions = new Map([
        ['A', { x: 50, y: 50 }],
        ['Z', { x: 999, y: 999 }],
      ]);
      LayoutEngine.apply(topo, positions, false);
      expect(topo._nodes.get('A').x).toBe(50);
    });

    it('calls render when mounted', () => {
      let renderCalled = false;
      const topo = {
        _nodes: new Map([['A', { id: 'A', x: 0, y: 0 }]]),
        _mounted: true,
        render: () => { renderCalled = true; },
      };
      LayoutEngine.apply(topo, new Map([['A', { x: 10, y: 10 }]]), false);
      expect(renderCalled).toBe(true);
    });

    it('does not call render when not mounted (animate=false)', () => {
      let renderCalled = false;
      const topo = {
        _nodes: new Map([['A', { id: 'A', x: 0, y: 0 }]]),
        _mounted: false,
        render: () => { renderCalled = true; },
      };
      LayoutEngine.apply(topo, new Map([['A', { x: 10, y: 10 }]]), false);
      expect(renderCalled).toBe(false);
    });

    it('starts animated transition when animate=true', () => {
      const rafCallbacks = [];
      // Mock requestAnimationFrame to capture callbacks
      globalThis.requestAnimationFrame = (cb) => { rafCallbacks.push(cb); return rafCallbacks.length; };

      const topo = {
        _nodes: new Map([
          ['A', { id: 'A', x: 0, y: 0 }],
          ['B', { id: 'B', x: 100, y: 100 }],
        ]),
        _mounted: true,
        render: () => {},
      };

      const positions = new Map([
        ['A', { x: 200, y: 300 }],
        ['B', { x: 400, y: 500 }],
      ]);

      LayoutEngine.apply(topo, positions, true);

      // requestAnimationFrame should have been called once to kick off animation
      expect(rafCallbacks.length).toBe(1);

      // Simulate the animation frame at t=0 (beginning)
      const startTime = performance.now();
      rafCallbacks[0](startTime);
      // At t=0, ease=0, positions should stay near start
      // Another rAF should be queued since t < 1
      expect(rafCallbacks.length).toBe(2);

      // Simulate the animation completing at t >= duration (500ms past start)
      rafCallbacks[1](startTime + 600);
      // At t>=1, ease=1, nodes should reach final positions
      expect(topo._nodes.get('A').x).toBe(200);
      expect(topo._nodes.get('A').y).toBe(300);
      expect(topo._nodes.get('B').x).toBe(400);
      expect(topo._nodes.get('B').y).toBe(500);
      // No more rAF should be queued (t >= 1)
      expect(rafCallbacks.length).toBe(2);

      delete globalThis.requestAnimationFrame;
    });

    it('animated apply ignores non-existent node ids', () => {
      const rafCallbacks = [];
      globalThis.requestAnimationFrame = (cb) => { rafCallbacks.push(cb); return 1; };

      const topo = {
        _nodes: new Map([['A', { id: 'A', x: 10, y: 20 }]]),
        _mounted: true,
        render: () => {},
      };

      const positions = new Map([
        ['A', { x: 50, y: 60 }],
        ['MISSING', { x: 999, y: 999 }],
      ]);

      LayoutEngine.apply(topo, positions, true);
      expect(rafCallbacks.length).toBe(1);

      // Complete the animation
      rafCallbacks[0](performance.now() + 600);
      expect(topo._nodes.get('A').x).toBe(50);
      expect(topo._nodes.get('A').y).toBe(60);

      delete globalThis.requestAnimationFrame;
    });

    it('animated apply calls render on each frame', () => {
      const rafCallbacks = [];
      globalThis.requestAnimationFrame = (cb) => { rafCallbacks.push(cb); return 1; };

      let renderCount = 0;
      const topo = {
        _nodes: new Map([['A', { id: 'A', x: 0, y: 0 }]]),
        _mounted: true,
        render: () => { renderCount++; },
      };

      LayoutEngine.apply(topo, new Map([['A', { x: 100, y: 100 }]]), true);

      const start = performance.now();
      rafCallbacks[0](start);       // frame 1 (t~0)
      rafCallbacks[1](start + 250); // frame 2 (t~0.5)
      rafCallbacks[2](start + 600); // frame 3 (t>=1, final)

      expect(renderCount).toBe(3);

      delete globalThis.requestAnimationFrame;
    });
  });

  describe('module export fallback', () => {
    it('exports LayoutEngine via module.exports in Node environment', () => {
      // We are running in Node/Vitest, so module.exports path is used
      expect(LayoutEngine).toBeDefined();
      expect(typeof LayoutEngine.circular).toBe('function');
      expect(typeof LayoutEngine.grid).toBe('function');
      expect(typeof LayoutEngine.hierarchical).toBe('function');
      expect(typeof LayoutEngine.forceDirected).toBe('function');
      expect(typeof LayoutEngine.apply).toBe('function');
    });

    it('forceDirected moves nodes that all start at the same position (#152)', () => {
      // All 4 nodes start at identical coordinates — previously a no-op
      const nodes = [
        { id: 'A', x: 100, y: 100 },
        { id: 'B', x: 100, y: 100 },
        { id: 'C', x: 100, y: 100 },
        { id: 'D', x: 100, y: 100 },
      ];
      const links = [
        { from: 'A', to: 'B' },
        { from: 'B', to: 'C' },
        { from: 'C', to: 'D' },
      ];
      const positions = LayoutEngine.forceDirected(nodes, links, { iterations: 200 });

      // Collect unique positions — nodes must have spread apart
      const coords = Array.from(positions.values()).map(p => `${p.x},${p.y}`);
      const unique = new Set(coords);
      expect(unique.size).toBeGreaterThan(1);

      // Verify at least one node moved away from the starting point
      const moved = Array.from(positions.values()).some(p => p.x !== 100 || p.y !== 100);
      expect(moved).toBe(true);
    });

    it('would set window.LayoutEngine when module is not available', () => {
      // The window fallback (lines 545-546) is the else-if branch.
      // In Node env, module.exports is used. We verify by checking that
      // the required export is the LayoutEngine class itself.
      const RequiredLE = require('../design-system/modules/layout-engine.js');
      expect(RequiredLE).toBe(LayoutEngine);
      expect(RequiredLE.name).toBe('LayoutEngine');
    });
  });
});
