import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Temporal Digital Twin', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Test' });
    topo.reducedMotion = true;
    topo.node('A', { type: 'server', x: 100, y: 100, label: 'Server A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'Router B' })
        .link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' })
        .act('act1', { label: 'Act One', color: '#01a982' })
        .addStep('step1', {
          act: 'act1', name: 'Step One', goal: 'Show all',
          focus: ['A', 'B'],
          phases: [{ show: ['A', 'B', 'l1'], diff: 'All appear' }],
        });
    topo._buildIndex();
  });

  describe('constructor defaults', () => {
    it('defaults temporalMode to design', () => {
      const t = new TopologyDesigner();
      expect(t.temporalMode).toBe('design');
    });

    it('accepts custom temporalMode', () => {
      const t = new TopologyDesigner({ temporalMode: 'operational' });
      expect(t.temporalMode).toBe('operational');
    });

    it('initializes empty _incidentData map', () => {
      const t = new TopologyDesigner();
      expect(t._incidentData).toBeInstanceOf(Map);
      expect(t._incidentData.size).toBe(0);
    });
  });

  describe('setTemporalMode()', () => {
    it('sets mode and returns this', () => {
      const result = topo.setTemporalMode('operational');
      expect(result).toBe(topo);
      expect(topo.temporalMode).toBe('operational');
    });

    it('accepts incident mode', () => {
      topo.setTemporalMode('incident');
      expect(topo.temporalMode).toBe('incident');
    });

    it('rejects invalid modes', () => {
      topo.setTemporalMode('design');
      topo.setTemporalMode('bogus');
      expect(topo.temporalMode).toBe('design');
    });

    it('defaults to design', () => {
      expect(topo.temporalMode).toBe('design');
    });
  });

  describe('setElementState()', () => {
    it('stores state data and returns this', () => {
      const result = topo.setElementState('A', { status: 'healthy', latency: 10 });
      expect(result).toBe(topo);
      expect(topo._incidentData.get('A')).toEqual({ status: 'healthy', latency: 10 });
    });

    it('overwrites existing state', () => {
      topo.setElementState('A', { status: 'healthy' });
      topo.setElementState('A', { status: 'down' });
      expect(topo._incidentData.get('A').status).toBe('down');
    });

    it('stores a copy of the data (not a reference)', () => {
      const data = { status: 'degraded', latency: 50 };
      topo.setElementState('A', data);
      data.status = 'healthy';
      expect(topo._incidentData.get('A').status).toBe('degraded');
    });
  });

  describe('setStateData()', () => {
    it('bulk-sets state data for multiple elements', () => {
      const result = topo.setStateData({
        A: { status: 'healthy', latency: 5 },
        B: { status: 'degraded', latency: 120, jitter: 15 },
      });
      expect(result).toBe(topo);
      expect(topo._incidentData.get('A').status).toBe('healthy');
      expect(topo._incidentData.get('B').status).toBe('degraded');
      expect(topo._incidentData.get('B').jitter).toBe(15);
    });
  });

  describe('_getTemporalEffect()', () => {
    it('returns empty effect in design mode', () => {
      topo.setTemporalMode('design');
      const effect = topo._getTemporalEffect('A');
      expect(effect.filter).toBe('');
      expect(effect.statusColor).toBe('');
      expect(effect.particleSpeed).toBe(2);
      expect(effect.overlay).toBe('');
    });

    it('returns healthy defaults in operational mode with no data', () => {
      topo.setTemporalMode('operational');
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('#05cc93');
      expect(effect.particleSpeed).toBe(2);
    });

    it('returns empty statusColor in incident mode with no data', () => {
      topo.setTemporalMode('incident');
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('');
    });

    it('returns correct effect for healthy status', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'healthy' });
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('#05cc93');
      expect(effect.filter).toBe('');
      expect(effect.particleSpeed).toBe(2);
    });

    it('returns correct effect for degraded status', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'degraded', latency: 100 });
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('#deb146');
      expect(effect.filter).toContain('tds-temporal-jitter');
      expect(effect.overlay).toBe('degraded');
      expect(effect.particleSpeed).toBeGreaterThan(2);
    });

    it('returns correct effect for down status', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'down' });
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('#fc6161');
      expect(effect.filter).toContain('tds-temporal-down');
      expect(effect.particleSpeed).toBe(0);
      expect(effect.overlay).toBe('down');
    });

    it('returns correct effect for breached status', () => {
      topo.setTemporalMode('incident');
      topo.setElementState('A', { status: 'breached' });
      const effect = topo._getTemporalEffect('A');
      expect(effect.statusColor).toBe('#fc6161');
      expect(effect.filter).toContain('tds-temporal-breach');
      expect(effect.particleSpeed).toBe(0.5);
      expect(effect.overlay).toBe('breached');
    });

    it('returns empty effect for unknown status', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'unknown-status' });
      const effect = topo._getTemporalEffect('A');
      expect(effect.filter).toBe('');
      expect(effect.statusColor).toBe('');
    });
  });

  describe('_renderTemporalBadge()', () => {
    it('returns empty string in design mode', () => {
      topo.setTemporalMode('design');
      topo.setElementState('A', { status: 'down' });
      expect(topo._renderTemporalBadge(100, 100, 'A')).toBe('');
    });

    it('returns empty string when no incident data exists', () => {
      topo.setTemporalMode('operational');
      expect(topo._renderTemporalBadge(100, 100, 'A')).toBe('');
    });

    it('returns SVG badge in operational mode with data', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'degraded', latency: 50, jitter: 10 });
      const badge = topo._renderTemporalBadge(100, 100, 'A');
      expect(badge).toContain('<circle');
      expect(badge).toContain('#deb146');
      expect(badge).toContain('50ms');
    });

    it('returns SVG badge in incident mode with data', () => {
      topo.setTemporalMode('incident');
      topo.setElementState('A', { status: 'down', loss: 100 });
      const badge = topo._renderTemporalBadge(100, 100, 'A');
      expect(badge).toContain('<circle');
      expect(badge).toContain('#fc6161');
      expect(badge).toContain('100%');
    });

    it('includes metrics label when latency/jitter/loss present', () => {
      topo.setTemporalMode('operational');
      topo.setElementState('A', { status: 'degraded', latency: 30, jitter: 5, loss: 2 });
      const badge = topo._renderTemporalBadge(100, 100, 'A');
      expect(badge).toContain('30ms');
      expect(badge).toContain('±5ms');
      expect(badge).toContain('2%↓');
    });
  });
});
