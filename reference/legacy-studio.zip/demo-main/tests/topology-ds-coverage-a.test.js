import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: create a basic topo with nodes, a link, an act, and a step showing them.
 */
function buildBasicTopo() {
  const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 250, label: 'Node A' });
  topo.node('B', { type: 'switch', x: 600, y: 250, label: 'Node B' });
  topo.link('link1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show elements',
    focus: [],
    phases: [{ show: ['A', 'B', 'link1'], diff: 'All visible' }],
  });
  topo._buildIndex();
  topo.step = 1;
  return topo;
}

// ─── 1. Graph shim fallback ───
describe('Graph shim fallback', () => {
  it('uses __nodes/__links/__anchors maps when _graph is null', () => {
    const topo = new TopologyDesigner({ title: 'Shim Test' });
    // Force shim path
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    topo.node('A', { type: 'router', x: 100, y: 200, label: 'A' });
    topo.anchor('pt1', { x: 300, y: 400 });
    topo.link('l1', { type: 'line', from: 'A', to: 'pt1', color: '#01a982' });

    expect(topo.__nodes.has('A')).toBe(true);
    expect(topo.__nodes.get('A').id).toBe('A');
    expect(topo.__anchors.has('pt1')).toBe(true);
    expect(topo.__anchors.get('pt1').x).toBe(300);
    expect(topo.__links.has('l1')).toBe(true);
    expect(topo.__links.get('l1').id).toBe('l1');
  });

  it('graph getter returns null when _graph is null', () => {
    const topo = new TopologyDesigner({ title: 'Shim Test' });
    topo._graph = null;
    expect(topo.graph).toBe(null);
  });

  it('_nodes/_links/_anchors accessors use shim maps when _graph is null', () => {
    const topo = new TopologyDesigner({ title: 'Shim Test' });
    topo._graph = null;
    topo.__nodes = new Map();
    topo.__links = new Map();
    topo.__anchors = new Map();

    topo.node('X', { type: 'host', x: 10, y: 20 });
    expect(topo._nodes.get('X')).toBeDefined();
    expect(topo._links.size).toBe(0);
    expect(topo._anchors.size).toBe(0);
  });
});

// ─── 2. _buildIndex with act.steps.length === 0 ───
describe('_buildIndex with empty act', () => {
  it('skips acts with no steps', () => {
    const topo = new TopologyDesigner({ title: 'Empty Act' });
    topo.act('a1', { label: 'Empty Act' });
    // Don't add any steps to a1
    topo._buildIndex();
    const act = topo._acts[0];
    // act.start should be undefined since the early return skips assignment
    expect(act.start).toBeUndefined();
    expect(act.count).toBeUndefined();
  });
});

// ─── 3. _renderSingleElement ───
describe('_renderSingleElement', () => {
  it('renders a node and returns SVG with data attribute', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderSingleElement('A');
    expect(svg).toContain('data-tds-node="A"');
  });

  it('renders a link element', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderSingleElement('link1');
    expect(svg).toContain('data-tds-link="link1"');
  });

  it('returns empty string for non-existent element', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderSingleElement('NONEXISTENT');
    expect(svg).toBe('');
  });
});

// ─── 4. _snapshotPositions ───
describe('_snapshotPositions', () => {
  it('captures node positions in _nodePositionSnapshots', () => {
    const topo = buildBasicTopo();
    topo._snapshotPositions();
    expect(topo._nodePositionSnapshots.has(topo.step)).toBe(true);
    const snapshot = topo._nodePositionSnapshots.get(topo.step);
    expect(snapshot.get('A')).toEqual({ x: 100, y: 250 });
    expect(snapshot.get('B')).toEqual({ x: 600, y: 250 });
  });
});

// ─── 5. _interpolateStep early exit paths ───
describe('_interpolateStep early exits', () => {
  it('calls onComplete immediately when already interpolating', () => {
    const topo = buildBasicTopo();
    topo._interpolating = true;
    const cb = vi.fn();
    topo._interpolateStep(0, 1, cb);
    expect(cb).toHaveBeenCalledOnce();
  });

  it('calls onComplete immediately when reducedMotion is true', () => {
    const topo = buildBasicTopo();
    topo.reducedMotion = true;
    const cb = vi.fn();
    topo._interpolateStep(0, 1, cb);
    expect(cb).toHaveBeenCalledOnce();
  });
});

// ─── 6. _interpolateStep with moving nodes ───
describe('_interpolateStep with moving nodes', () => {
  it('sets _interpolating true when nodes have position keyframes', () => {
    const topo = buildBasicTopo();
    // Set up position keyframes
    topo._nodes.get('A')._positions = { 2: { x: 400, y: 250 } };
    // Mock requestAnimationFrame
    const rafMock = vi.fn();
    vi.stubGlobal('requestAnimationFrame', rafMock);
    // Mock document.getElementById for the animate callback
    const mockEl = { innerHTML: '' };
    vi.spyOn(document, 'getElementById').mockReturnValue(mockEl);

    topo._interpolateStep(1, 2, () => {});
    expect(topo._interpolating).toBe(true);
    expect(rafMock).toHaveBeenCalledOnce();

    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('calls onComplete when no nodes have position changes', () => {
    const topo = buildBasicTopo();
    const cb = vi.fn();
    topo._interpolateStep(0, 1, cb);
    // No _positions defined, so should complete immediately
    expect(cb).toHaveBeenCalledOnce();
  });
});

// ─── 7. overlayCloud spanning ───
describe('renderOverlayCloud with spans', () => {
  it('renders ellipse when spans has resolved positions', () => {
    const svg = TopologyDesigner.renderOverlayCloud(300, 200, {
      _resolvedSpans: [{ x: 100, y: 200 }, { x: 500, y: 200 }],
      label: 'TestCloud',
      color: '#7764fc',
    });
    expect(svg).toContain('ellipse');
    expect(svg).toContain('TestCloud');
  });

  it('falls back to renderCloud when spans is insufficient', () => {
    const svg = TopologyDesigner.renderOverlayCloud(300, 200, {
      _resolvedSpans: [{ x: 100, y: 200 }],
      label: 'Small',
    });
    // Should fall back to renderCloud output (no spanning ellipse)
    expect(svg).toBeDefined();
  });
});

// ─── 8. renderText with sublabel ───
describe('renderText with sublabel', () => {
  it('renders both label and multi-line sublabel', () => {
    const svg = TopologyDesigner.renderText(100, 200, {
      label: 'Title',
      sublabel: 'line1\nline2',
    });
    expect(svg).toContain('Title');
    expect(svg).toContain('line1');
    expect(svg).toContain('line2');
  });
});

// ─── 9. _renderCallout ───
describe('_renderCallout', () => {
  it('renders callout badge with lines', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderCallout('s1', 0, 50, 50, 120, 40,
      [{ text: 'Hello', color: '#fff', size: '10', weight: '700' }],
      '#01a982', 1);
    expect(svg).toContain('Hello');
    expect(svg).toContain('rect');
    expect(svg).toContain('#01a982');
  });

  it('returns empty string when step not visible', () => {
    const topo = buildBasicTopo();
    topo.step = 0;
    const svg = topo._renderCallout('s1', 0, 50, 50, 120, 40,
      [{ text: 'Hello' }], '#01a982', 1);
    expect(svg).toBe('');
  });
});

// ─── 10. _renderZoneLabel ───
describe('_renderZoneLabel', () => {
  it('renders zone label with dashed rect', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderZoneLabel('s1', 0, 200, 300, 'Zone A', '#01a982', 1);
    expect(svg).toContain('Zone A');
    expect(svg).toContain('stroke-dasharray');
    expect(svg).toContain('#01a982');
  });
});

// ─── 11. _renderNodeLabel with sublabel ───
describe('_renderNodeLabel with sublabel', () => {
  it('renders both label and sublabel text', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderNodeLabel(100, 200, 'Label', 'Sub', '#e6e8e9');
    expect(svg).toContain('Label');
    expect(svg).toContain('Sub');
    expect(svg).toContain('#e6e8e9');
  });
});

// ─── 12. _renderSideLabel ───
describe('_renderSideLabel', () => {
  it('renders side label with sublabel', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderSideLabel(100, 200, 'Side', 'SubSide', '#01a982', 'start');
    expect(svg).toContain('Side');
    expect(svg).toContain('SubSide');
    expect(svg).toContain('text-anchor="start"');
  });
});

// ─── 13. _renderZoneIndicator ───
describe('_renderZoneIndicator', () => {
  it('renders WAN/LAN for right side', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderZoneIndicator(100, 200, 'right');
    expect(svg).toContain('WAN');
    expect(svg).toContain('LAN');
    expect(svg).toContain('text-anchor="start"');
  });

  it('renders WAN/LAN for left side', () => {
    const topo = buildBasicTopo();
    const svg = topo._renderZoneIndicator(100, 200, 'left');
    expect(svg).toContain('WAN');
    expect(svg).toContain('LAN');
    expect(svg).toContain('text-anchor="end"');
  });
});

// ─── 14. EC VRRP active/standby ───
describe('EC VRRP rendering', () => {
  it('renders VRRP active badge with pulsing glow for generic variant', () => {
    const svg = TopologyDesigner.renderEC(100, 200, { variant: 'generic', vrrpState: 'active' });
    expect(svg).toContain('VRRP');
    expect(svg).toContain('#05cc93');
    expect(svg).toContain('animate');
  });

  it('renders VRRP standby label for physical variant', () => {
    const svg = TopologyDesigner.renderEC(100, 200, { variant: 'physical', vrrpState: 'standby' });
    expect(svg).toContain('VRRP');
    expect(svg).toContain('#deb146');
  });

  it('renders VRRP active badge for physical variant', () => {
    const svg = TopologyDesigner.renderEC(100, 200, { variant: 'physical', vrrpState: 'active' });
    expect(svg).toContain('VRRP');
    expect(svg).toContain('#05cc93');
    expect(svg).toContain('animate');
  });
});

// ─── 15. renderSaaS without logoUrl (renderApp equivalent) ───
describe('renderSaaS without logoUrl', () => {
  it('renders colored squares pattern when no logoUrl', () => {
    const svg = TopologyDesigner.renderSaaS(100, 200, {});
    expect(svg).toContain('rx="2"');
    // Should have multiple rect elements for the icon grid
    const rectCount = (svg.match(/rx="2"/g) || []).length;
    expect(rectCount).toBeGreaterThanOrEqual(4);
  });

  it('renders image when logoUrl is provided', () => {
    const svg = TopologyDesigner.renderSaaS(100, 200, { logoUrl: 'https://example.com/logo.png' });
    expect(svg).toContain('image');
    expect(svg).toContain('https://example.com/logo.png');
  });
});

// ─── 16. Link routing with obstructions ───
describe('Link routing with obstructions', () => {
  it('detects obstruction and returns a detour path', () => {
    const topo = new TopologyDesigner({ title: 'Route Test', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.node('C', { type: 'router', x: 350, y: 250, label: 'C' }); // obstruction in between
    topo.node('B', { type: 'router', x: 600, y: 250, label: 'B' });
    topo.link('link1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Step 1', goal: 'Show all',
      focus: [],
      phases: [{ show: ['A', 'B', 'C', 'link1'], diff: 'All visible' }],
    });
    topo._buildIndex();
    topo.step = 1;

    const path = topo._routeLink({ x: 100, y: 250 }, { x: 600, y: 250 }, 'link1');
    expect(path).not.toBeNull();
    expect(path).toContain('M');
    expect(path).toContain('Q');
    expect(path).toContain('L');
  });
});

// ─── 17. Custom phase function ───
describe('Custom phase function', () => {
  it('renders custom SVG from a function', () => {
    const topo = new TopologyDesigner({ title: 'Custom', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Step 1', goal: 'Custom phase',
      focus: [],
      phases: [
        { show: ['A'], diff: 'Node A' },
        { show: [], custom: (ctx) => '<circle r="5" data-custom="fn"/>', diff: 'Custom fn' },
      ],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('data-custom="fn"');
  });

  it('renders custom SVG from a string', () => {
    const topo = new TopologyDesigner({ title: 'Custom', viewBox: '0 0 800 500' });
    topo.node('A', { type: 'router', x: 100, y: 250, label: 'A' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Step 1', goal: 'Custom string',
      focus: [],
      phases: [
        { show: ['A'], diff: 'Node A' },
        { show: [], custom: '<rect data-custom="str"/>', diff: 'Custom str' },
      ],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('data-custom="str"');
  });
});

// ─── 18. _findShowPhase ───
describe('_findShowPhase', () => {
  it('returns stepId and phaseNum for a known element', () => {
    const topo = buildBasicTopo();
    const result = topo._findShowPhase('A');
    expect(result).toEqual({ stepId: 's1', phaseNum: 0 });
  });

  it('returns null for an unknown element', () => {
    const topo = buildBasicTopo();
    const result = topo._findShowPhase('UNKNOWN');
    expect(result).toBeNull();
  });
});
