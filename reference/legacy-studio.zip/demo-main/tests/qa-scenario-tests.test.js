/**
 * QA Scenario Tests — End-to-end scenario testing simulating real user workflows.
 * Covers: node placement, link creation, anchors, choreography, flow paths,
 * glossary, URL state, playback, serialization, and edge cases.
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 1: Basic Node Placement
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 1: Basic Node Placement', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Node Test' });
  });

  const nodeTypes = [
    'router', 'switch', 'host', 'cloud', 'ec', 'firewall',
    'server', 'database', 'connector', 'ap', 'idcard', 'saas', 'apps',
  ];

  nodeTypes.forEach(type => {
    it(`registers ${type} node without throwing`, () => {
      expect(() => {
        topo.node(`n_${type}`, { type, x: 100, y: 100, label: `Test ${type}` });
      }).not.toThrow();
    });

    it(`${type} node is stored in _nodes map`, () => {
      topo.node(`n_${type}`, { type, x: 100, y: 100, label: `Test ${type}` });
      expect(topo._nodes.has(`n_${type}`)).toBe(true);
    });

    it(`${type} node has correct type property`, () => {
      topo.node(`n_${type}`, { type, x: 200, y: 300 });
      expect(topo._nodes.get(`n_${type}`).type).toBe(type);
    });
  });

  it('registers overlayCloud node', () => {
    topo.node('R1', { type: 'router', x: 200, y: 200 });
    topo.node('R2', { type: 'router', x: 400, y: 200 });
    expect(() => {
      topo.node('OC1', {
        type: 'overlayCloud',
        x: 0, y: 0,
        label: 'SD-WAN',
        color: '#7764fc',
        spans: ['R1', 'R2'],
        padding: 60,
      });
    }).not.toThrow();
    expect(topo._nodes.has('OC1')).toBe(true);
  });

  it('static renderRouter returns SVG string', () => {
    const svg = TopologyDesigner.renderRouter(100, 100, { color: '#01a982' });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderSwitch returns SVG string', () => {
    const svg = TopologyDesigner.renderSwitch(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderFirewall returns SVG string', () => {
    const svg = TopologyDesigner.renderFirewall(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderDatabase returns SVG string', () => {
    const svg = TopologyDesigner.renderDatabase(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderIdCard returns SVG string', () => {
    const svg = TopologyDesigner.renderIdCard(100, 100, { mode: 'auth', user: 'test@acme.com', host: 'LAPTOP', role: 'MANAGED' });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderAP returns SVG string', () => {
    const svg = TopologyDesigner.renderAP(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderSaaS returns SVG string', () => {
    const svg = TopologyDesigner.renderSaaS(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderApps returns SVG string', () => {
    const svg = TopologyDesigner.renderApps(100, 100, {});
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('static renderCloud returns SVG string with sub1/sub2', () => {
    const svg = TopologyDesigner.renderCloud(300, 100, {
      label: 'HPE SSE', sub1: 'SWG · ZTNA', sub2: 'PDP', innerClouds: 'both',
    });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('EC node with all variants renders', () => {
    const variants = ['generic', 'virtual', 'physical', 'aws', 'azure', 'gcp', 'oracle'];
    variants.forEach(variant => {
      const svg = TopologyDesigner.renderEC(100, 100, { variant });
      expect(typeof svg).toBe('string');
      expect(svg.length).toBeGreaterThan(0);
    });
  });

  it('EC node with vrrp active/standby renders', () => {
    const svgA = TopologyDesigner.renderEC(100, 100, { vrrp: 'active' });
    const svgS = TopologyDesigner.renderEC(100, 100, { vrrp: 'standby' });
    expect(typeof svgA).toBe('string');
    expect(typeof svgS).toBe('string');
  });

  it('idcard node with mode:id renders', () => {
    const svg = TopologyDesigner.renderIdCard(100, 100, { mode: 'id', user: 'alice', host: 'PC-001', role: 'ADMIN' });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('connector node with pe:true renders', () => {
    const svg = TopologyDesigner.renderConnector(100, 100, { pe: true, label: 'PE Connector' });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('switchEnterprise with copper/fiber ports renders', () => {
    const svg = TopologyDesigner.renderSwitchEnterprise(200, 200, { copperPorts: 24, fiberPorts: 4 });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('host with managed + agent renders', () => {
    const svg = TopologyDesigner.renderHost(100, 100, { managed: true, agent: true, agentColor: '#65aef9' });
    expect(typeof svg).toBe('string');
    expect(svg.length).toBeGreaterThan(0);
  });

  it('text node registers and stores label', () => {
    topo.node('T1', { type: 'text', x: 100, y: 100, label: 'My Header', fontSize: 16, fontWeight: '600' });
    expect(topo._nodes.get('T1').label).toBe('My Header');
  });

  it('shape node types register without throwing', () => {
    const shapeTypes = ['shapeArrow', 'shapeSquare', 'shapeRectangle', 'shapeTriangle',
      'shapeCircle', 'shapeEllipse', 'shapeDiamond', 'shapePentagon',
      'shapeHexagon', 'shapeStar', 'shapeCross'];
    shapeTypes.forEach(type => {
      expect(() => {
        topo.node(`s_${type}`, { type, x: 200, y: 200, size: 30 });
      }).not.toThrow();
    });
  });

  it('custom node type via registerNodeType renders', () => {
    TopologyDesigner.registerNodeType('myCustomDevice', (x, y, cfg) => {
      return `<rect x="${x - 20}" y="${y - 20}" width="40" height="40" fill="#292d3a" stroke="${cfg.color || '#01a982'}"/>`;
    });
    topo.node('CUSTOM1', { type: 'myCustomDevice', x: 300, y: 200, color: '#fc6161' });
    expect(topo._nodes.has('CUSTOM1')).toBe(true);
    expect(TopologyDesigner.getRegisteredNodeTypes()).toContain('myCustomDevice');
  });

  it('node with zoneIndicator stores correctly', () => {
    topo.node('R1', { type: 'router', x: 300, y: 200, zoneIndicator: 'left' });
    expect(topo._nodes.get('R1').zoneIndicator).toBe('left');
  });

  it('node.label() method returns this for chaining', () => {
    const result = topo.node('R1', { type: 'router', x: 100, y: 100, label: 'Test' });
    expect(result).toBe(topo);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 2: Link Creation
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 2: Link Creation', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Link Test' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.node('C', { type: 'host', x: 700, y: 200 });
    topo.node('AP', { type: 'ap', x: 400, y: 400 });
  });

  const linkTypes = ['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'];

  linkTypes.forEach(type => {
    it(`registers ${type} link without throwing`, () => {
      expect(() => {
        topo.link(`l_${type}`, { type, from: 'A', to: 'B', color: '#01a982' });
      }).not.toThrow();
    });

    it(`${type} link is stored in _links map`, () => {
      topo.link(`l_${type}`, { type, from: 'A', to: 'B', color: '#01a982' });
      expect(topo._links.has(`l_${type}`)).toBe(true);
    });

    it(`${type} link has correct from/to`, () => {
      topo.link(`l_${type}`, { type, from: 'A', to: 'B', color: '#01a982' });
      const lnk = topo._links.get(`l_${type}`);
      expect(lnk.from).toBe('A');
      expect(lnk.to).toBe('B');
    });
  });

  it('line link with dashed:true stores property', () => {
    topo.link('dashed-line', { type: 'line', from: 'A', to: 'B', color: '#01a982', dashed: true });
    expect(topo._links.get('dashed-line').dashed).toBe(true);
  });

  const dashStyles = ['solid', 'dashed', 'dotted', 'longDash', 'dashDot', 'dashDotDot', 'dense', 'sparse'];
  dashStyles.forEach(style => {
    it(`dashStyle '${style}' stores correctly`, () => {
      topo.link(`dl_${style}`, { type: 'line', from: 'A', to: 'B', dashStyle: style });
      expect(topo._links.get(`dl_${style}`).dashStyle).toBe(style);
    });
  });

  it('animateFlow stores on line link', () => {
    topo.link('animated', { type: 'line', from: 'A', to: 'B', animateFlow: true, animateSpeed: 2 });
    const lnk = topo._links.get('animated');
    expect(lnk.animateFlow).toBe(true);
    expect(lnk.animateSpeed).toBe(2);
  });

  it('fromLabel and toLabel store correctly', () => {
    topo.link('port-link', {
      type: 'line', from: 'A', to: 'B', color: '#01a982',
      fromLabel: 'ge0/1', toLabel: 'eth0',
    });
    const lnk = topo._links.get('port-link');
    expect(lnk.fromLabel).toBe('ge0/1');
    expect(lnk.toLabel).toBe('eth0');
  });

  it('tunnel link with label and dots stores correctly', () => {
    topo.link('ipsec', { type: 'tunnel', from: 'A', to: 'B', color: '#65aef9', label: 'IPsec Tunnel', dots: true });
    const lnk = topo._links.get('ipsec');
    expect(lnk.label).toBe('IPsec Tunnel');
    expect(lnk.dots).toBe(true);
  });

  it('blocked link with reason stores reason', () => {
    topo.link('blk', { type: 'blocked', from: 'A', to: 'C', reason: 'No authorized path' });
    expect(topo._links.get('blk').reason).toBe('No authorized path');
  });

  it('flow link with custom path stores path', () => {
    topo.link('flowpath', {
      type: 'flow', from: 'A', to: 'C',
      color: '#01a982',
      path: 'M100,200 C200,100 300,100 400,200',
      labelPos: { x: 250, y: 140 },
    });
    const lnk = topo._links.get('flowpath');
    expect(lnk.path).toContain('M100');
    expect(lnk.labelPos.x).toBe(250);
  });

  it('packet link with sublabel stores sublabel', () => {
    topo.link('pkt', { type: 'packet', from: 'A', to: 'B', color: '#deb146', label: 'RADIUS', sublabel: '802.1X EAP' });
    expect(topo._links.get('pkt').sublabel).toBe('802.1X EAP');
  });

  it('link with zOrder stores correctly', () => {
    topo.link('top', { type: 'line', from: 'A', to: 'B', zOrder: 10 });
    expect(topo._links.get('top').zOrder).toBe(10);
  });

  it('getRegisteredLinkTypes returns built-in types', () => {
    const types = TopologyDesigner.getRegisteredLinkTypes();
    const expected = ['line', 'tunnel', 'wireguard', 'flow', 'packet', 'blocked', 'wifi', 'poe', 'optical'];
    expected.forEach(t => expect(types).toContain(t));
  });

  it('custom link type registration', () => {
    TopologyDesigner.registerLinkType('myLink', {
      render(fromPt, toPt, cfg) {
        return `<line x1="${fromPt.x}" y1="${fromPt.y}" x2="${toPt.x}" y2="${toPt.y}" stroke="${cfg.color || '#01a982'}" stroke-width="2"/>`;
      },
      defaults: { color: '#01a982' },
    });
    expect(TopologyDesigner.getRegisteredLinkTypes()).toContain('myLink');
  });

  it('link() method returns this for chaining', () => {
    const result = topo.link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    expect(result).toBe(topo);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 3: Anchor Placement
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 3: Anchor Placement', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Anchor Test' });
    topo.node('N1', { type: 'router', x: 100, y: 200 });
    topo.node('N2', { type: 'switch', x: 500, y: 200 });
  });

  it('registers an anchor without throwing', () => {
    expect(() => {
      topo.anchor('anc1', { x: 300, y: 200, label: 'Waypoint' });
    }).not.toThrow();
  });

  it('anchor is stored in _anchors map', () => {
    topo.anchor('anc1', { x: 300, y: 200 });
    expect(topo._anchors.has('anc1')).toBe(true);
  });

  it('anchor stores x/y correctly', () => {
    topo.anchor('anc1', { x: 350, y: 250 });
    const a = topo._anchors.get('anc1');
    expect(a.x).toBe(350);
    expect(a.y).toBe(250);
  });

  it('anchor stores optional label', () => {
    topo.anchor('anc1', { x: 300, y: 200, label: 'Midpoint' });
    expect(topo._anchors.get('anc1').label).toBe('Midpoint');
  });

  it('anchor stores labelOffsetX and labelOffsetY', () => {
    topo.anchor('anc1', { x: 300, y: 200, labelOffsetX: 10, labelOffsetY: -5 });
    const a = topo._anchors.get('anc1');
    expect(a.labelOffsetX).toBe(10);
    expect(a.labelOffsetY).toBe(-5);
  });

  it('anchor stores hideId flag', () => {
    topo.anchor('anc1', { x: 300, y: 200, hideId: true });
    expect(topo._anchors.get('anc1').hideId).toBe(true);
  });

  it('link from node to anchor stores correctly', () => {
    topo.anchor('anc1', { x: 300, y: 200 });
    topo.link('n1-anc', { type: 'tunnel', from: 'N1', to: 'anc1', color: '#65aef9' });
    const lnk = topo._links.get('n1-anc');
    expect(lnk.from).toBe('N1');
    expect(lnk.to).toBe('anc1');
  });

  it('link between two anchors stores correctly', () => {
    topo.anchor('anc1', { x: 200, y: 200 });
    topo.anchor('anc2', { x: 400, y: 200 });
    topo.link('anc-anc', { type: 'line', from: 'anc1', to: 'anc2', color: '#01a982' });
    const lnk = topo._links.get('anc-anc');
    expect(lnk.from).toBe('anc1');
    expect(lnk.to).toBe('anc2');
  });

  it('multiple anchors can exist', () => {
    topo.anchor('a1', { x: 100, y: 100 });
    topo.anchor('a2', { x: 200, y: 100 });
    topo.anchor('a3', { x: 300, y: 100 });
    expect(topo._anchors.size).toBe(3);
  });

  it('_pos returns anchor position correctly', () => {
    topo.anchor('anc1', { x: 350, y: 275 });
    topo._buildIndex();
    const pos = topo._pos('anc1');
    expect(pos.x).toBe(350);
    expect(pos.y).toBe(275);
  });

  it('anchor() returns this for chaining', () => {
    const result = topo.anchor('anc1', { x: 300, y: 200 });
    expect(result).toBe(topo);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 4: Acts, Steps & Phases (Choreography)
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 4: Acts, Steps & Phases', () => {
  let topo;

  function buildChoreographyTopo() {
    topo = new TopologyDesigner({ title: 'Choreography Test', phaseMs: 500 });
    topo.reducedMotion = true;

    topo.node('R1', { type: 'router', x: 100, y: 200, label: 'Router 1' });
    topo.node('SW1', { type: 'switch', x: 300, y: 200, label: 'Switch 1' });
    topo.node('FW1', { type: 'firewall', x: 500, y: 200, label: 'Firewall' });
    topo.node('HOST', { type: 'host', x: 700, y: 200, label: 'Host' });
    topo.anchor('anc1', { x: 400, y: 100 });

    topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982' });
    topo.link('sw1-fw', { type: 'tunnel', from: 'SW1', to: 'FW1', color: '#65aef9' });
    topo.link('fw-host', { type: 'line', from: 'FW1', to: 'HOST', color: '#fc6161' });

    topo.act('a1', { label: 'Act 1 · Setup', color: '#01a982', intro: ['Phase 1 of setup.'] });
    topo.act('a2', { label: 'Act 2 · Security', color: '#fc6161', intro: ['Security layer.'] });

    topo.addStep('step1', {
      act: 'a1', name: 'Deploy Routers', goal: 'Get routers online.',
      focus: ['R1'],
      phases: [
        { show: ['R1'], diff: 'Router appears' },
        { show: ['SW1', 'r1-sw1'], diff: 'Switch connects' },
      ],
    });

    topo.addStep('step2', {
      act: 'a1', name: 'Core Network', goal: 'Full core deployed.',
      focus: ['R1', 'SW1'],
      phases: [
        { show: [], diff: 'No new elements, narrative moment' },
      ],
    });

    topo.addStep('step3', {
      act: 'a2', name: 'Firewall', goal: 'Secure the perimeter.',
      focus: ['FW1', 'HOST'],
      phases: [
        { show: ['FW1', 'sw1-fw'], diff: 'Firewall deployed' },
        { show: ['HOST', 'fw-host'], diff: 'Host behind firewall' },
      ],
    });

    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildChoreographyTopo();
  });

  it('acts are registered', () => {
    expect(topo._acts).toHaveLength(2);
    expect(topo._acts[0].id).toBe('a1');
    expect(topo._acts[1].id).toBe('a2');
  });

  it('act labels are stored', () => {
    expect(topo._acts[0].label).toBe('Act 1 · Setup');
    expect(topo._acts[1].label).toBe('Act 2 · Security');
  });

  it('act intro arrays are stored', () => {
    expect(topo._acts[0].intro).toEqual(['Phase 1 of setup.']);
  });

  it('steps are registered in order', () => {
    expect(topo._steps).toHaveLength(3);
    expect(topo._steps[0].id).toBe('step1');
    expect(topo._steps[1].id).toBe('step2');
    expect(topo._steps[2].id).toBe('step3');
  });

  it('step names stored correctly', () => {
    expect(topo._steps[0].name).toBe('Deploy Routers');
    expect(topo._steps[2].name).toBe('Firewall');
  });

  it('step focus arrays stored correctly', () => {
    expect(topo._steps[0].focus).toEqual(['R1']);
    expect(topo._steps[1].focus).toEqual(['R1', 'SW1']);
    expect(topo._steps[2].focus).toEqual(['FW1', 'HOST']);
  });

  it('step phases stored correctly', () => {
    expect(topo._steps[0].phases).toHaveLength(2);
    expect(topo._steps[0].phases[0].show).toContain('R1');
    expect(topo._steps[0].phases[1].show).toContain('SW1');
  });

  it('step index is built correctly (1-based)', () => {
    expect(topo._stepIndex['step1']).toBe(1);
    expect(topo._stepIndex['step2']).toBe(2);
    expect(topo._stepIndex['step3']).toBe(3);
  });

  it('_vis returns false at step 0 for any step', () => {
    topo.step = 0;
    expect(topo._vis('step1')).toBe(false);
    expect(topo._vis('step2')).toBe(false);
  });

  it('_vis returns true when step is reached', () => {
    topo.step = 1;
    expect(topo._vis('step1')).toBe(true);
    expect(topo._vis('step2')).toBe(false);
  });

  it('_vis returns true for all past steps', () => {
    topo.step = 3;
    expect(topo._vis('step1')).toBe(true);
    expect(topo._vis('step2')).toBe(true);
    expect(topo._vis('step3')).toBe(true);
  });

  it('_ph returns show:false before step', () => {
    topo.step = 0;
    expect(topo._ph('step1', 0).show).toBe(false);
  });

  it('_ph returns show:true at current step', () => {
    topo.step = 1;
    expect(topo._ph('step1', 0).show).toBe(true);
  });

  it('_ph returns show:true for past step', () => {
    topo.step = 3;
    expect(topo._ph('step1', 0).show).toBe(true);
    expect(topo._ph('step1', 1).show).toBe(true);
  });

  it('_ph with reducedMotion returns anim:false', () => {
    topo.reducedMotion = true;
    topo.step = 1;
    expect(topo._ph('step1', 0).anim).toBe(false);
    expect(topo._ph('step1', 1).anim).toBe(false);
  });

  it('_ph at current step with reduced motion off returns anim:true for phase > 0', () => {
    topo.reducedMotion = false;
    topo.step = 1;
    expect(topo._ph('step1', 1).anim).toBe(true);
  });

  it('phase delay increases with phase number', () => {
    topo.reducedMotion = false;
    topo.phaseMs = 600;
    topo.step = 1;
    const p0 = topo._ph('step1', 0);
    const p1 = topo._ph('step1', 1);
    expect(p1.delay).toBeGreaterThan(p0.delay);
  });

  it('empty phase show[] works (narrative moment)', () => {
    topo.step = 2;
    const ph = topo._ph('step2', 0);
    expect(ph.show).toBe(true);
  });

  it('focus spotlight dims non-focused elements', () => {
    topo.step = 1;
    // R1 is focused in step1
    const dimR1 = topo._dimFor('R1');
    const dimSW1 = topo._dimFor('SW1');
    expect(dimR1).toBe(1.0);
    expect(dimSW1).toBeLessThan(1.0);
  });

  it('empty focus array means full brightness for all', () => {
    // step2 has focus: ['R1', 'SW1'] — but let's build a custom step with empty focus
    const topo2 = new TopologyDesigner({ title: 'Empty Focus Test' });
    topo2.node('A', { type: 'router', x: 100, y: 200 });
    topo2.node('B', { type: 'switch', x: 300, y: 200 });
    topo2.act('a1', { label: 'Act 1', color: '#01a982' });
    topo2.addStep('s1', {
      act: 'a1', name: 'All visible', goal: 'Everything bright',
      focus: [],
      phases: [{ show: ['A', 'B'], diff: 'All appear' }],
    });
    topo2._buildIndex();
    topo2.step = 1;
    expect(topo2._dimFor('A')).toBe(1.0);
    expect(topo2._dimFor('B')).toBe(1.0);
  });

  it('onRender hook is stored on step', () => {
    const topo2 = new TopologyDesigner({ title: 'onRender Test' });
    topo2.node('A', { type: 'router', x: 100, y: 200 });
    topo2.act('a1', { label: 'Act 1', color: '#01a982' });
    const hook = (ctx) => `<rect x="0" y="0" width="10" height="10"/>`;
    topo2.addStep('s1', {
      act: 'a1', name: 'Custom', goal: 'onRender test',
      focus: [],
      phases: [{ show: ['A'], diff: 'A appears' }],
      onRender: hook,
    });
    topo2._buildIndex();
    expect(topo2._steps[0].onRender).toBe(hook);
  });

  it('act and addStep return this for chaining', () => {
    const topo2 = new TopologyDesigner({ title: 'Chain Test' });
    const r1 = topo2.act('a1', { label: 'Act 1', color: '#01a982' });
    expect(r1).toBe(topo2);
    topo2.node('X', { type: 'router', x: 100, y: 200 });
    const r2 = topo2.addStep('s1', {
      act: 'a1', name: 'Step 1', goal: 'G', phases: [{ show: ['X'] }],
    });
    expect(r2).toBe(topo2);
  });

  it('showDuring registers element visibility range', () => {
    expect(() => {
      topo.showDuring(['r1-sw1'], { from: 'step1', until: 'step2' });
    }).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 5: Flow Paths
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 5: Flow Paths', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Flow Path Test' });
    topo.node('A', { type: 'host', x: 100, y: 200 });
    topo.node('SW1', { type: 'switch', x: 300, y: 200 });
    topo.node('FW1', { type: 'firewall', x: 500, y: 200 });
    topo.node('INET', { type: 'cloud', x: 700, y: 200 });
  });

  it('flowPath registers without throwing', () => {
    expect(() => {
      topo.flowPath('fp1', {
        waypoints: ['A', 'SW1', 'FW1', 'INET'],
        color: '#01a982',
        animation: 'particles',
        speed: 2,
        direction: 'forward',
        label: 'User Traffic',
      });
    }).not.toThrow();
  });

  it('flowPath with dashed animation registers', () => {
    expect(() => {
      topo.flowPath('fp2', {
        waypoints: ['A', 'SW1'],
        color: '#65aef9',
        animation: 'dashed',
        direction: 'reverse',
      });
    }).not.toThrow();
  });

  it('flowPath with pulse animation registers', () => {
    expect(() => {
      topo.flowPath('fp3', {
        waypoints: ['SW1', 'FW1'],
        color: '#deb146',
        animation: 'pulse',
        direction: 'bidirectional',
      });
    }).not.toThrow();
  });

  it('setFlowPaths bulk-sets flow paths', () => {
    expect(() => {
      topo.setFlowPaths([
        ['fp_1', { waypoints: ['A', 'SW1', 'FW1'], color: '#01a982' }],
        ['fp_2', { waypoints: ['SW1', 'INET'], color: '#65aef9' }],
      ]);
    }).not.toThrow();
  });

  it('flowPath with layer assignment stores layer', () => {
    topo.layer('flow_1', { name: 'Traffic', type: 'flow', visible: true, opacity: 0.8 });
    topo.flowPath('fp4', {
      waypoints: ['A', 'INET'],
      color: '#01a982',
      layer: 'flow_1',
    });
    // Should not throw and layer should be stored
    expect(true).toBe(true); // Flow path registered without error
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 6: Glossary
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 6: Glossary', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Glossary Test' });
  });

  it('glossary() registers terms without throwing', () => {
    expect(() => {
      topo.glossary([
        { t: 'SSE', d: 'Security Service Edge.' },
        { t: 'ZTNA', d: 'Zero Trust Network Access.' },
        { t: 'SD-WAN', d: 'Software-Defined Wide Area Network.' },
      ]);
    }).not.toThrow();
  });

  it('glossary terms are stored', () => {
    topo.glossary([
      { t: 'SSE', d: 'Security Service Edge.' },
      { t: 'ZTNA', d: 'Zero Trust Network Access.' },
    ]);
    expect(topo._glossary).toHaveLength(2);
    expect(topo._glossary[0].t).toBe('SSE');
    expect(topo._glossary[1].t).toBe('ZTNA');
  });

  it('glossary term descriptions are stored', () => {
    topo.glossary([{ t: 'NAC', d: 'Network Access Control.' }]);
    expect(topo._glossary[0].d).toBe('Network Access Control.');
  });

  it('glossary() returns this for chaining', () => {
    const result = topo.glossary([{ t: 'Test', d: 'A test.' }]);
    expect(result).toBe(topo);
  });

  it('multiple glossary() calls accumulate terms', () => {
    topo.glossary([{ t: 'A', d: 'First.' }]);
    topo.glossary([{ t: 'B', d: 'Second.' }]);
    // Either it accumulates or replaces — check behavior
    // According to the API, it's likely a setter, not accumulator
    // Let's verify it doesn't crash
    expect(topo._glossary.length).toBeGreaterThan(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 7: URL State
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 7: URL State', () => {
  it('_updateURL does not throw when no location available', () => {
    const topo = new TopologyDesigner({ title: 'URL Test' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: 'G', phases: [{ show: ['A'] }] });
    topo._buildIndex();
    topo.step = 1;
    // Should not throw even in jsdom context
    expect(() => topo._updateURL?.()).not.toThrow();
  });

  it('goTo() sets correct step number', () => {
    const topo = new TopologyDesigner({ title: 'GoTo Test' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: 'G', phases: [{ show: ['A'] }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: 'G', phases: [{ show: [] }] });
    topo.addStep('s3', { act: 'a1', name: 'S3', goal: 'G', phases: [{ show: [] }] });
    topo._buildIndex();
    topo.goTo(2);
    expect(topo.step).toBe(2);
    topo.goTo(0);
    expect(topo.step).toBe(0);
  });

  it('goTo() clamps to valid range (max steps)', () => {
    const topo = new TopologyDesigner({ title: 'GoTo Clamp Test' });
    topo.node('A', { type: 'router', x: 100, y: 100 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: 'G', phases: [{ show: ['A'] }] });
    topo._buildIndex();
    topo.goTo(999);
    // Should clamp to max (1 step)
    expect(topo.step).toBeLessThanOrEqual(1);
  });

  it('mode is stored and accessible', () => {
    const topo = new TopologyDesigner({ title: 'Mode Test', mode: 'auto' });
    expect(topo.mode).toBe('auto');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 8: Playback
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 8: Playback', () => {
  let topo;

  function buildPlaybackTopo() {
    topo = new TopologyDesigner({ title: 'Playback Test', mode: 'manual' });
    topo.reducedMotion = true;
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 300, y: 200 });
    topo.node('C', { type: 'host', x: 500, y: 200 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.link('bc', { type: 'line', from: 'B', to: 'C', color: '#01a982' });
    topo.act('a1', { label: 'Act 1', color: '#01a982' });
    topo.act('a2', { label: 'Act 2', color: '#65aef9' });
    topo.addStep('s1', {
      act: 'a1', name: 'Step 1', goal: 'G1',
      focus: [], phases: [{ show: ['A'], diff: 'A' }],
    });
    topo.addStep('s2', {
      act: 'a1', name: 'Step 2', goal: 'G2',
      focus: [], phases: [{ show: ['B', 'ab'], diff: 'B' }],
    });
    topo.addStep('s3', {
      act: 'a2', name: 'Step 3', goal: 'G3',
      focus: [], phases: [{ show: ['C', 'bc'], diff: 'C' }],
    });
    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildPlaybackTopo();
  });

  it('initial step is 0', () => {
    expect(topo.step).toBe(0);
  });

  it('next() advances step by 1', () => {
    topo.next();
    expect(topo.step).toBe(1);
  });

  it('next() multiple times advances correctly', () => {
    topo.next();
    topo.next();
    expect(topo.step).toBe(2);
  });

  it('next() does not exceed total steps', () => {
    topo.goTo(3);
    topo.next();
    expect(topo.step).toBe(3); // stays at last step
  });

  it('prev() goes back one step', () => {
    topo.goTo(2);
    topo.prev();
    expect(topo.step).toBe(1);
  });

  it('prev() does not go below 0', () => {
    topo.step = 0;
    topo.prev();
    expect(topo.step).toBe(0);
  });

  it('reset() goes to step 0', () => {
    topo.goTo(3);
    topo.reset();
    expect(topo.step).toBe(0);
  });

  it('goTo() jumps to arbitrary step', () => {
    topo.goTo(3);
    expect(topo.step).toBe(3);
  });

  it('goTo(0) resets', () => {
    topo.goTo(2);
    topo.goTo(0);
    expect(topo.step).toBe(0);
  });

  it('pause() stops playing', () => {
    topo.playing = true;
    topo.pause();
    expect(topo.playing).toBe(false);
  });

  it('play() does nothing with reducedMotion', () => {
    topo.reducedMotion = true;
    topo.play();
    expect(topo.playing).toBe(false);
  });

  it('play() activates in non-reduced motion mode', () => {
    topo.reducedMotion = false;
    topo.mode = 'auto';
    topo.play();
    expect(topo.playing).toBe(true);
    topo.pause(); // cleanup
  });

  it('manual mode stays at step after next()', () => {
    topo.mode = 'manual';
    topo.next();
    expect(topo.step).toBe(1);
    expect(topo.playing).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 9: Serialization (toJSON / fromJSON round-trip)
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 9: Serialization Round-Trip', () => {
  let topo;

  function buildRichTopo() {
    topo = new TopologyDesigner({
      title: 'Rich Topology',
      subtitle: 'Full feature test',
      viewBox: '0 0 900 600',
      phaseMs: 500,
      drawDuration: 0.6,
      fadeDuration: 0.4,
    });

    // Nodes of various types
    topo.node('R1', { type: 'router', x: 100, y: 200, label: 'Router 1', color: '#01a982' });
    topo.node('SW1', { type: 'switch', x: 300, y: 200, label: 'Switch' });
    topo.node('FW1', { type: 'firewall', x: 500, y: 200, label: 'Firewall' });
    topo.node('HOST', { type: 'host', x: 700, y: 200, label: 'Host', managed: true });
    topo.node('EC1', { type: 'ec', x: 200, y: 400, label: 'EC', variant: 'aws' });
    topo.node('CLOUD', { type: 'cloud', x: 600, y: 50, label: 'Internet', sub1: 'ISP', sub2: 'CDN' });
    topo.node('DB1', { type: 'database', x: 400, y: 400, label: 'DB' });

    // Anchor
    topo.anchor('mid', { x: 350, y: 100, label: 'Midpoint' });

    // Links of various types
    topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982', fromLabel: 'eth0', toLabel: 'ge1' });
    topo.link('sw1-fw', { type: 'tunnel', from: 'SW1', to: 'FW1', color: '#65aef9', label: 'IPsec', dots: true });
    topo.link('fw-host', { type: 'line', from: 'FW1', to: 'HOST', color: '#fc6161', dashed: true });
    topo.link('r1-mid', { type: 'line', from: 'R1', to: 'mid', color: '#b1b9be' });
    topo.link('blk1', { type: 'blocked', from: 'R1', to: 'CLOUD', reason: 'No tunnel' });

    // Acts and Steps
    topo.act('a1', { label: 'Act 1 · Setup', color: '#01a982', intro: ['Setting up the network.'] });
    topo.act('a2', { label: 'Act 2 · Security', color: '#fc6161' });

    topo.addStep('s1', {
      act: 'a1', name: 'Deploy Core', goal: 'Get infrastructure up.',
      focus: ['R1', 'SW1'],
      phases: [
        { show: ['R1'], diff: 'Router 1 appears' },
        { show: ['SW1', 'r1-sw1'], diff: 'Switch connects' },
      ],
    });
    topo.addStep('s2', {
      act: 'a1', name: 'Cloud Connect', goal: 'Connect to cloud.',
      focus: ['CLOUD'],
      phases: [
        { show: ['CLOUD'], diff: 'Internet cloud' },
      ],
    });
    topo.addStep('s3', {
      act: 'a2', name: 'Security', goal: 'Add firewall.',
      focus: ['FW1', 'HOST'],
      phases: [
        { show: ['FW1', 'sw1-fw'], diff: 'Firewall + tunnel' },
        { show: ['HOST', 'fw-host'], diff: 'Host behind FW' },
      ],
    });

    topo.glossary([
      { t: 'IPsec', d: 'IP Security' },
      { t: 'ZTNA', d: 'Zero Trust Network Access' },
    ]);

    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildRichTopo();
  });

  it('toJSON exports title and subtitle', () => {
    const json = topo.toJSON();
    expect(json.title).toBe('Rich Topology');
    expect(json.subtitle).toBe('Full feature test');
  });

  it('toJSON exports all node types', () => {
    const json = topo.toJSON();
    expect(json.nodes['R1'].type).toBe('router');
    expect(json.nodes['EC1'].type).toBe('ec');
    expect(json.nodes['EC1'].variant).toBe('aws');
    expect(json.nodes['CLOUD'].sub1).toBe('ISP');
  });

  it('toJSON exports anchor', () => {
    const json = topo.toJSON();
    expect(json.anchors['mid']).toBeDefined();
    expect(json.anchors['mid'].x).toBe(350);
  });

  it('toJSON exports all link types', () => {
    const json = topo.toJSON();
    expect(json.links['r1-sw1'].type).toBe('line');
    expect(json.links['sw1-fw'].type).toBe('tunnel');
    expect(json.links['blk1'].type).toBe('blocked');
    expect(json.links['blk1'].reason).toBe('No tunnel');
  });

  it('toJSON exports link port labels', () => {
    const json = topo.toJSON();
    expect(json.links['r1-sw1'].fromLabel).toBe('eth0');
    expect(json.links['r1-sw1'].toLabel).toBe('ge1');
  });

  it('toJSON exports acts with intro', () => {
    const json = topo.toJSON();
    expect(json.acts).toHaveLength(2);
    const act1 = json.acts.find(a => a.id === 'a1');
    expect(act1.intro).toEqual(['Setting up the network.']);
  });

  it('toJSON exports steps with phases', () => {
    const json = topo.toJSON();
    expect(json.steps).toHaveLength(3);
    const s1 = json.steps.find(s => s.id === 's1');
    expect(s1.phases[0].show).toContain('R1');
    expect(s1.focus).toContain('R1');
  });

  it('toJSON exports glossary', () => {
    const json = topo.toJSON();
    expect(json.glossary).toHaveLength(2);
    expect(json.glossary[0].t).toBe('IPsec');
  });

  it('toJSON produces valid JSON string', () => {
    const json = topo.toJSON();
    expect(() => JSON.stringify(json)).not.toThrow();
  });

  it('fromJSON restores full topology', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json);
    expect(topo2.title).toBe('Rich Topology');
    expect(topo2._nodes.size).toBe(7);
    expect(topo2._links.size).toBe(5);
    expect(topo2._anchors.size).toBe(1);
    expect(topo2._acts).toHaveLength(2);
    expect(topo2._steps).toHaveLength(3);
    expect(topo2._glossary).toHaveLength(2);
  });

  it('fromJSON restores node types', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json);
    expect(topo2._nodes.get('R1').type).toBe('router');
    expect(topo2._nodes.get('EC1').variant).toBe('aws');
  });

  it('fromJSON restores link port labels', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json);
    const lnk = topo2._links.get('r1-sw1');
    expect(lnk.fromLabel).toBe('eth0');
    expect(lnk.toLabel).toBe('ge1');
  });

  it('fromJSON restores step focus arrays', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json);
    expect(topo2._steps[0].focus).toContain('R1');
  });

  it('toJSON -> fromJSON -> toJSON produces identical structure', () => {
    const json1 = topo.toJSON();
    const topo2 = new TopologyDesigner();
    topo2.fromJSON(json1);
    const json2 = topo2.toJSON();

    expect(json2.title).toBe(json1.title);
    expect(Object.keys(json2.nodes).sort()).toEqual(Object.keys(json1.nodes).sort());
    expect(Object.keys(json2.links).sort()).toEqual(Object.keys(json1.links).sort());
    expect(json2.acts.length).toBe(json1.acts.length);
    expect(json2.steps.length).toBe(json1.steps.length);
    expect(json2.glossary.length).toBe(json1.glossary.length);
  });

  it('fromJSON clears previous data', () => {
    const topo2 = new TopologyDesigner();
    topo2.node('OLD', { type: 'host', x: 0, y: 0 });
    topo2.fromJSON(topo.toJSON());
    expect(topo2._nodes.has('OLD')).toBe(false);
  });

  it('fromJSON with empty object does not crash', () => {
    const topo2 = new TopologyDesigner();
    expect(() => topo2.fromJSON({})).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO 10: Edge Cases
// ─────────────────────────────────────────────────────────────────────────────
describe('Scenario 10: Edge Cases', () => {
  it('empty focus array results in full brightness for all visible elements', () => {
    const topo = new TopologyDesigner({ title: 'Edge: Empty Focus' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 300, y: 200 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [],
      phases: [{ show: ['A', 'B'], diff: 'All' }],
    });
    topo._buildIndex();
    topo.step = 1;
    expect(topo._dimFor('A')).toBe(1.0);
    expect(topo._dimFor('B')).toBe(1.0);
  });

  it('step with no phases does not crash', () => {
    const topo = new TopologyDesigner({ title: 'Edge: No Phases' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    expect(() => {
      topo.addStep('s1', {
        act: 'a1', name: 'Empty Step', goal: 'Nothing happens',
        focus: [], phases: [],
      });
      topo._buildIndex();
    }).not.toThrow();
  });

  it('overlayCloud with spans renders without crashing', () => {
    const topo = new TopologyDesigner({ title: 'Edge: Overlay Cloud' });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    topo.node('R2', { type: 'router', x: 400, y: 200 });
    topo.node('OC', {
      type: 'overlayCloud', x: 0, y: 0,
      label: 'WAN Fabric', color: '#7764fc',
      spans: ['R1', 'R2'], padding: 80,
    });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['R1', 'R2', 'OC'], diff: 'All' }],
    });
    topo._buildIndex();
    topo.step = 1;
    expect(() => topo._renderNodeSVG('OC', { show: true, anim: false, delay: 0 }, 1)).not.toThrow();
  });

  it('custom node type render function is called', () => {
    let renderCalled = false;
    TopologyDesigner.registerNodeType('testCustom2', (x, y, cfg) => {
      renderCalled = true;
      return `<circle cx="${x}" cy="${y}" r="20" fill="${cfg.color || '#01a982'}"/>`;
    });
    const topo = new TopologyDesigner({ title: 'Custom Node' });
    topo.node('C1', { type: 'testCustom2', x: 200, y: 200, color: '#deb146' });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['C1'], diff: 'Custom' }],
    });
    topo._buildIndex();
    topo.step = 1;
    // _renderNodeSVG takes (nodeCfg) not (id, phaseState, step)
    const nodeCfg = topo._nodes.get('C1');
    topo._renderNodeSVG(nodeCfg);
    expect(renderCalled).toBe(true);
  });

  it('ghosting constructor option stores correctly (as ghostingEnabled)', () => {
    // BUG: constructor option `ghosting` is stored as `ghostingEnabled`, not `ghosting`
    // The USER-MANUAL documents `topo.ghosting` but the actual property is `topo.ghostingEnabled`
    const topo = new TopologyDesigner({ title: 'Ghosting Test', ghosting: false });
    expect(topo.ghostingEnabled).toBe(false);  // actual property name
    expect(topo.ghosting).toBeUndefined();       // documented property does NOT exist
  });

  it('ghosting defaults to true (stored as ghostingEnabled)', () => {
    // BUG: documented as `ghosting` but stored as `ghostingEnabled`
    const topo = new TopologyDesigner({ title: 'Ghosting Default' });
    expect(topo.ghostingEnabled).toBe(true);    // actual property name
    expect(topo.ghosting).toBeUndefined();       // documented property does NOT exist
  });

  it('isometricMode constructor option stores correctly', () => {
    const topo = new TopologyDesigner({ title: 'Iso Test', isometricMode: true });
    expect(topo.isometricMode).toBe(true);
  });

  it('toggleIsometric() toggles the mode', () => {
    const topo = new TopologyDesigner({ title: 'Iso Toggle' });
    const initial = topo.isometricMode;
    topo.toggleIsometric();
    expect(topo.isometricMode).toBe(!initial);
    topo.toggleIsometric();
    expect(topo.isometricMode).toBe(initial);
  });

  it('toggleIsometric(true) forces enable', () => {
    const topo = new TopologyDesigner({ title: 'Iso Force' });
    topo.toggleIsometric(true);
    expect(topo.isometricMode).toBe(true);
  });

  it('blast radius getBlastRadius returns set', () => {
    const topo = new TopologyDesigner({ title: 'Blast Radius', blastRadiusHops: 2 });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    topo.node('SW1', { type: 'switch', x: 300, y: 200 });
    topo.node('HOST', { type: 'host', x: 500, y: 200 });
    topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1' });
    topo.link('sw1-host', { type: 'line', from: 'SW1', to: 'HOST' });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['R1', 'SW1', 'HOST', 'r1-sw1', 'sw1-host'] }],
    });
    topo._buildIndex();
    const radius = topo.getBlastRadius('R1', 2);
    expect(radius).toBeDefined();
    // R1 itself + SW1 (hop 1) + HOST (hop 2)
    expect(radius.has('R1')).toBe(true);
  });

  it('setState and getState round-trip', () => {
    const topo = new TopologyDesigner({ title: 'State Test' });
    topo.setState('firewall.status', 'breached');
    expect(topo.getState('firewall.status')).toBe('breached');
  });

  it('setState with multiple keys works', () => {
    const topo = new TopologyDesigner({ title: 'Multi-State' });
    topo.setState('a', 1);
    topo.setState('b', 'hello');
    topo.setState('c', true);
    expect(topo.getState('a')).toBe(1);
    expect(topo.getState('b')).toBe('hello');
    expect(topo.getState('c')).toBe(true);
  });

  it('getState returns undefined for unset key', () => {
    const topo = new TopologyDesigner({ title: 'State Miss' });
    expect(topo.getState('nonexistent')).toBeUndefined();
  });

  it('layer registration without throwing', () => {
    const topo = new TopologyDesigner({ title: 'Layer Test' });
    expect(() => {
      topo.layer('flow_1', {
        name: 'Traffic Flow',
        type: 'flow',
        visible: true,
        opacity: 0.8,
        color: '#65aef9',
        order: 1,
      });
      topo.layer('policy_1', {
        name: 'Security Policies',
        type: 'policy',
        visible: true,
        opacity: 1,
        color: '#fc6161',
        order: 2,
      });
    }).not.toThrow();
  });

  it('setLayers bulk-set works', () => {
    const topo = new TopologyDesigner({ title: 'Layer Bulk' });
    expect(() => {
      topo.setLayers([
        { id: 'physical', name: 'Physical', type: 'physical', visible: true, opacity: 1, locked: false, color: '#01a982', order: 0 },
        { id: 'flow_1', name: 'Traffic', type: 'flow', visible: true, opacity: 0.8, color: '#65aef9', order: 1 },
      ]);
    }).not.toThrow();
  });

  it('policyMarker registration without throwing', () => {
    const topo = new TopologyDesigner({ title: 'Policy Marker' });
    topo.node('FW1', { type: 'firewall', x: 300, y: 200 });
    expect(() => {
      topo.policyMarker('pm1', {
        nodeId: 'FW1',
        type: 'inspect',
        color: '#deb146',
        label: 'DPI',
      });
    }).not.toThrow();
  });

  it('all policy marker types register without throwing', () => {
    const topo = new TopologyDesigner({ title: 'Policy Types' });
    topo.node('FW1', { type: 'firewall', x: 300, y: 200 });
    const types = ['inspect', 'allow', 'deny', 'redirect', 'encrypt', 'decrypt', 'nat', 'load-balance', 'log'];
    types.forEach(type => {
      expect(() => {
        topo.policyMarker(`pm_${type}`, { nodeId: 'FW1', type });
      }).not.toThrow();
    });
  });

  it('setPolicyMarkers bulk-set works', () => {
    const topo = new TopologyDesigner({ title: 'Policy Bulk' });
    topo.node('FW1', { type: 'firewall', x: 300, y: 200 });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    expect(() => {
      topo.setPolicyMarkers([
        ['pm_1', { nodeId: 'FW1', type: 'inspect', color: '#deb146' }],
        ['pm_2', { nodeId: 'R1', type: 'allow', color: '#01a982' }],
      ]);
    }).not.toThrow();
  });

  it('step with onRender hook executes', () => {
    const topo = new TopologyDesigner({ title: 'onRender Exec' });
    topo.reducedMotion = true;
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    let hookCalled = false;
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['A'] }],
      onRender: (ctx) => {
        hookCalled = true;
        return '<g/>';
      },
    });
    topo._buildIndex();
    topo.step = 1;
    // _renderSVG should call onRender
    expect(() => topo._renderSVG()).not.toThrow();
    expect(hookCalled).toBe(true);
  });

  it('validatePath returns a result object', () => {
    const topo = new TopologyDesigner({ title: 'Path Validation' });
    topo.node('A', { type: 'host', x: 100, y: 200 });
    topo.node('FW', { type: 'firewall', x: 300, y: 200 });
    topo.node('SRV', { type: 'server', x: 500, y: 200 });
    topo.link('a-fw', { type: 'line', from: 'A', to: 'FW' });
    topo.link('fw-srv', { type: 'line', from: 'FW', to: 'SRV' });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['A', 'FW', 'SRV', 'a-fw', 'fw-srv'] }],
    });
    topo._buildIndex();
    const result = topo.validatePath('A', 'SRV');
    expect(result).toBeDefined();
    expect(typeof result.valid).toBe('boolean');
  });

  it('lifecycle hooks register without throwing', () => {
    const topo = new TopologyDesigner({ title: 'Hooks' });
    expect(() => {
      topo.on('beforeRender', (ctx) => {});
      topo.on('afterRender', (ctx) => {});
      topo.on('onStepChange', ({ prevStep, step }) => {});
    }).not.toThrow();
  });

  it('onStepChange hook does NOT fire without mount (BUG: hooks require mount)', () => {
    // BUG: onStepChange hooks only fire inside render(), which returns early when not mounted.
    // The API doc implies hooks work any time after topo.on() is called, but they only
    // work after mount(). Steps still advance, but hooks are never called without mount.
    const topo = new TopologyDesigner({ title: 'Hook Fires' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['A'] }],
    });
    topo._buildIndex();

    let stepChangeFired = false;
    topo.on('onStepChange', ({ step }) => {
      stepChangeFired = true;
    });
    topo.next();
    // Step advances correctly
    expect(topo.step).toBe(1);
    // But hooks don't fire without mount — this is the bug
    expect(stepChangeFired).toBe(false); // hooks require mount() to fire
  });

  it('_pos returns node position', () => {
    const topo = new TopologyDesigner({ title: 'Pos Test' });
    topo.node('R1', { type: 'router', x: 250, y: 350 });
    topo._buildIndex();
    const pos = topo._pos('R1');
    expect(pos.x).toBe(250);
    expect(pos.y).toBe(350);
  });

  it('_pos returns 0,0 for unknown id (warns)', () => {
    const topo = new TopologyDesigner({ title: 'Pos Unknown' });
    topo._buildIndex();
    const pos = topo._pos('unknown_id');
    expect(pos.x).toBe(0);
    expect(pos.y).toBe(0);
  });

  it('pathThrough generates SVG path string', () => {
    const topo = new TopologyDesigner({ title: 'PathThrough' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 300, y: 200 });
    topo.node('C', { type: 'host', x: 500, y: 200 });
    topo._buildIndex();
    const path = topo.pathThrough('A', 'B', 'C');
    expect(typeof path).toBe('string');
    expect(path).toContain('M');
    expect(path).toContain('L');
  });

  it('pathBetween generates cubic bezier path', () => {
    const topo = new TopologyDesigner({ title: 'PathBetween' });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 500, y: 200 });
    topo._buildIndex();
    const path = topo.pathBetween('A', 'B', { bulge: 50 });
    expect(typeof path).toBe('string');
    expect(path).toContain('M');
  });

  it('conditional step logic: setState/getState works for condition evaluation', () => {
    const topo = new TopologyDesigner({ title: 'Conditional Steps' });
    topo.node('FW', { type: 'firewall', x: 300, y: 200 });
    topo.link('tunnel', { type: 'tunnel', from: 'FW', to: 'FW', color: '#65aef9' });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('quarantine', {
      act: 'a1', name: 'Quarantine', goal: 'Block on breach.',
      focus: ['FW'],
      phases: [
        {
          show: ['tunnel'],
          condition: 'firewall.status == "breached"',
          actions: [
            { changeLink: 'tunnel', toType: 'blocked', reason: 'Quarantine' },
            { setState: { 'quarantine.active': true } },
          ],
        },
      ],
    });
    topo._buildIndex();
    topo.setState('firewall.status', 'breached');
    expect(topo.getState('firewall.status')).toBe('breached');
    // No crash on render
    expect(() => {
      topo.step = 1;
    }).not.toThrow();
  });

  it('setNodePositions stores positions for choreography smoothing', () => {
    const topo = new TopologyDesigner({ title: 'Pos Keyframes' });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    topo.node('SW1', { type: 'switch', x: 300, y: 200 });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [], phases: [{ show: ['R1', 'SW1'] }],
    });
    topo.addStep('s2', {
      act: 'a1', name: 'S2', goal: 'G2',
      focus: [], phases: [{ show: [] }],
    });
    topo._buildIndex();
    expect(() => {
      topo.setNodePositions('s2', {
        'R1': { x: 300, y: 200 },
        'SW1': { x: 500, y: 300 },
      });
    }).not.toThrow();
  });

  it('getRegisteredNodeTypes returns all built-in types', () => {
    const types = TopologyDesigner.getRegisteredNodeTypes();
    const builtIn = ['ec', 'switch', 'cloud', 'host', 'connector', 'apps', 'saas',
      'server', 'router', 'firewall', 'database', 'idcard', 'ap', 'overlayCloud'];
    builtIn.forEach(t => expect(types).toContain(t));
  });

  it('autoLayout does not crash with nodes', () => {
    const topo = new TopologyDesigner({ title: 'AutoLayout' });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    topo.node('SW1', { type: 'switch', x: 300, y: 200 });
    topo.node('HOST', { type: 'host', x: 500, y: 400 });
    topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1' });
    topo.link('sw1-host', { type: 'line', from: 'SW1', to: 'HOST' });
    expect(() => {
      topo.autoLayout('force-directed');
    }).not.toThrow();
  });

  it('temporal mode switching works', () => {
    const topo = new TopologyDesigner({ title: 'Temporal', temporalMode: 'design' });
    expect(topo.temporalMode).toBe('design');
    topo.setTemporalMode('operational');
    expect(topo.temporalMode).toBe('operational');
    topo.setTemporalMode('incident');
    expect(topo.temporalMode).toBe('incident');
  });

  it('setElementState stores state', () => {
    const topo = new TopologyDesigner({ title: 'Elem State' });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    expect(() => {
      topo.setElementState('R1', { status: 'degraded', latency: 120, jitter: 30, loss: 1.2 });
    }).not.toThrow();
  });

  it('setStateData bulk-sets states', () => {
    const topo = new TopologyDesigner({ title: 'Bulk State' });
    topo.node('R1', { type: 'router', x: 100, y: 200 });
    topo.node('FW1', { type: 'firewall', x: 300, y: 200 });
    expect(() => {
      topo.setStateData({
        'R1': { status: 'healthy', latency: 5 },
        'FW1': { status: 'degraded', latency: 120 },
      });
    }).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO: SVG Rendering (node types render valid SVG)
// ─────────────────────────────────────────────────────────────────────────────
describe('SVG Rendering: All Node Types', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'SVG Render Test' });
    topo.reducedMotion = true;
    topo.act('a1', { label: 'A1', color: '#01a982' });
  });

  const nodeTypesToTest = [
    { id: 'router', cfg: { type: 'router', x: 100, y: 200, label: 'R1' } },
    { id: 'switch', cfg: { type: 'switch', x: 200, y: 200, label: 'SW1' } },
    { id: 'host', cfg: { type: 'host', x: 300, y: 200, label: 'HOST', managed: true, agent: true } },
    { id: 'cloud', cfg: { type: 'cloud', x: 400, y: 50, label: 'Cloud', sub1: 'SWG', sub2: 'ZTNA' } },
    { id: 'ec', cfg: { type: 'ec', x: 100, y: 400, label: 'EC', variant: 'aws' } },
    { id: 'firewall', cfg: { type: 'firewall', x: 200, y: 400, label: 'FW' } },
    { id: 'server', cfg: { type: 'server', x: 300, y: 400, label: 'SRV' } },
    { id: 'database', cfg: { type: 'database', x: 400, y: 400, label: 'DB' } },
    { id: 'connector', cfg: { type: 'connector', x: 500, y: 200, label: 'Conn' } },
    { id: 'ap', cfg: { type: 'ap', x: 600, y: 200, label: 'AP' } },
    { id: 'idcard', cfg: { type: 'idcard', x: 700, y: 200, mode: 'auth', user: 'alice', host: 'PC1', role: 'ADMIN' } },
    { id: 'saas', cfg: { type: 'saas', x: 800, y: 200, label: 'SaaS' } },
    { id: 'apps', cfg: { type: 'apps', x: 900, y: 200, label: 'Apps' } },
  ];

  nodeTypesToTest.forEach(({ id, cfg }) => {
    it(`${cfg.type} node renders SVG without error`, () => {
      topo.node(id, cfg);
      topo.addStep('s1', {
        act: 'a1', name: 'S1', goal: 'G',
        focus: [], phases: [{ show: [id], diff: `${cfg.type} shows` }],
      });
      topo._buildIndex();
      topo.step = 1;
      // _renderNodeSVG(nodeCfg) takes the node config object, not an id
      const nodeCfg = topo._nodes.get(id);
      expect(nodeCfg).toBeDefined();
      const svg = topo._renderNodeSVG(nodeCfg);
      expect(typeof svg).toBe('string');
      expect(svg.length).toBeGreaterThan(0);
    });
  });

  it('link rendering: all link types render SVG in full _renderSVG', () => {
    // Use _renderSVG which is the proper way to trigger link rendering
    // (individual link render methods are private/internal with different signatures)
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.node('C', { type: 'host', x: 600, y: 200 });

    const linkTypes = [
      { id: 'l_line', cfg: { type: 'line', from: 'A', to: 'B', color: '#01a982', fromLabel: 'eth0', toLabel: 'ge1' } },
      { id: 'l_tunnel', cfg: { type: 'tunnel', from: 'A', to: 'B', color: '#65aef9', label: 'IPsec', dots: false } },
      { id: 'l_blocked', cfg: { type: 'blocked', from: 'A', to: 'C', reason: 'No path' } },
      { id: 'l_poe', cfg: { type: 'poe', from: 'A', to: 'B', color: '#deb146' } },
      { id: 'l_optical', cfg: { type: 'optical', from: 'B', to: 'C', color: '#fc6161' } },
    ];
    linkTypes.forEach(({ id, cfg }) => topo.link(id, cfg));

    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'G',
      focus: [],
      phases: [{ show: ['A', 'B', 'C', ...linkTypes.map(l => l.id)] }],
    });
    topo._buildIndex();
    topo.step = 1;

    expect(() => {
      const svg = topo._renderSVG();
      expect(typeof svg).toBe('string');
      expect(svg.length).toBeGreaterThan(0);
    }).not.toThrow();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIO: DOM Mount (integration)
// ─────────────────────────────────────────────────────────────────────────────
describe('DOM Mount Integration', () => {
  let container;

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('mounts a full topology to DOM without errors', () => {
    container = document.createElement('div');
    container.id = 'qa-test-mount';
    document.body.appendChild(container);

    const topo = new TopologyDesigner({
      title: 'Full Integration Test',
      subtitle: 'QA Scenario',
      viewBox: '0 0 800 500',
      phaseMs: 500,
      mode: 'manual',
    });

    topo.node('R1', { type: 'router', x: 200, y: 200, label: 'Router 1' });
    topo.node('SW1', { type: 'switch', x: 450, y: 200, label: 'Switch 1' });
    topo.node('HOST', { type: 'host', x: 600, y: 300, label: 'Host', managed: true });
    topo.anchor('anc1', { x: 325, y: 150, label: 'Midpoint' });
    topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982', fromLabel: 'eth0', toLabel: 'ge1' });
    topo.link('sw1-host', { type: 'tunnel', from: 'SW1', to: 'HOST', color: '#65aef9' });
    topo.link('r1-anc', { type: 'line', from: 'R1', to: 'anc1', color: '#b1b9be' });

    topo.act('a1', { label: 'Act 1 · Infrastructure', color: '#01a982', intro: ['Build the network.'] });
    topo.addStep('s1', {
      act: 'a1', name: 'Deploy Router', goal: 'Get router online.',
      focus: ['R1'],
      phases: [{ show: ['R1'], diff: 'Router 1 appears' }],
    });
    topo.addStep('s2', {
      act: 'a1', name: 'Deploy Switch', goal: 'Connect switch.',
      focus: ['SW1'],
      phases: [{ show: ['SW1', 'r1-sw1'], diff: 'Switch connects' }],
    });
    topo.addStep('s3', {
      act: 'a1', name: 'Add Host', goal: 'Host behind switch.',
      focus: ['HOST', 'SW1'],
      phases: [{ show: ['HOST', 'sw1-host'], diff: 'Host appears' }],
    });

    topo.glossary([
      { t: 'iBGP', d: 'Internal BGP routing.' },
    ]);

    expect(() => topo.mount('qa-test-mount')).not.toThrow();

    // Verify DOM was created
    const svg = container.querySelector('svg');
    expect(svg).not.toBeNull();
  });

  it('stepwise playback through all steps works', () => {
    container = document.createElement('div');
    container.id = 'qa-playback-test';
    document.body.appendChild(container);

    const topo = new TopologyDesigner({ title: 'Playback Integration', mode: 'manual' });
    topo.reducedMotion = true;

    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 300, y: 200 });
    topo.node('C', { type: 'host', x: 500, y: 200 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
    topo.link('bc', { type: 'line', from: 'B', to: 'C', color: '#01a982' });
    topo.act('a1', { label: 'A1', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: 'G', focus: [], phases: [{ show: ['A'] }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: 'G', focus: [], phases: [{ show: ['B', 'ab'] }] });
    topo.addStep('s3', { act: 'a1', name: 'S3', goal: 'G', focus: [], phases: [{ show: ['C', 'bc'] }] });
    topo.mount('qa-playback-test');

    // NOTE: jsdom shares location across tests, so after mount(), _loadURL() may have
    // restored a step from a previous test's URL state. We use goTo(0) to reset.
    topo.goTo(0);

    // Step through all steps
    expect(topo.step).toBe(0);
    topo.next();
    expect(topo.step).toBe(1);
    topo.next();
    expect(topo.step).toBe(2);
    topo.next();
    expect(topo.step).toBe(3);
    topo.next(); // at last step, should stay
    expect(topo.step).toBe(3);
    topo.reset();
    expect(topo.step).toBe(0);
    topo.pause();
  });
});
