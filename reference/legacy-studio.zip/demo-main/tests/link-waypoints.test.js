import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Link Waypoints & Orthogonal Routing', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner({
      title: 'Waypoint Test',
      viewBox: '0 0 800 600',
    });
    topo.node('A', { type: 'server', x: 100, y: 100, label: 'A' })
        .node('B', { type: 'server', x: 500, y: 400, label: 'B' })
        .link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  });

  describe('_buildLinkPath', () => {
    it('builds a straight path with no waypoints', () => {
      const d = topo._buildLinkPath({ x: 0, y: 0 }, { x: 100, y: 100 }, [], null);
      expect(d).toBe('M0,0 L100,100');
    });

    it('builds straight segments through waypoints', () => {
      const d = topo._buildLinkPath(
        { x: 0, y: 0 },
        { x: 300, y: 300 },
        [{ x: 100, y: 50 }, { x: 200, y: 150 }],
        null
      );
      expect(d).toBe('M0,0 L100,50 L200,150 L300,300');
    });

    it('builds orthogonal (right-angle) path with no waypoints', () => {
      const d = topo._buildLinkPath({ x: 0, y: 0 }, { x: 100, y: 200 }, [], 'orthogonal');
      // Should go horizontal then vertical: M0,0 L100,0 L100,200
      expect(d).toBe('M0,0 L100,0 L100,200');
    });

    it('builds orthogonal path through waypoints', () => {
      const d = topo._buildLinkPath(
        { x: 0, y: 0 },
        { x: 300, y: 300 },
        [{ x: 150, y: 100 }],
        'orthogonal'
      );
      // from(0,0) → wp(150,100): L150,0 L150,100
      // wp(150,100) → to(300,300): L300,100 L300,300
      expect(d).toBe('M0,0 L150,0 L150,100 L300,100 L300,300');
    });
  });

  describe('_renderLinkSVG with waypoints', () => {
    it('renders a line link through waypoints using flow renderer', () => {
      topo.addWaypoint('l1', { x: 250, y: 150 });
      topo.addWaypoint('l1', { x: 350, y: 300 });

      // _buildLinkPath is called inside _renderLinkSVG; verify the path directly
      const from = topo._pos('A');
      const to = topo._pos('B');
      const linkCfg = topo._links.get('l1');
      const path = topo._buildLinkPath(from, to, linkCfg.waypoints, linkCfg.lineStyle);
      expect(path).toContain('250,150');
      expect(path).toContain('350,300');
      // Path starts at from and ends at to
      expect(path).toMatch(/^M/);
      expect(path).toContain(`${to.x},${to.y}`);
    });

    it('renders orthogonal routing with right-angle segments', () => {
      topo.addWaypoint('l1', { x: 300, y: 200 });
      topo.setLinkRouting('l1', 'orthogonal');

      const from = topo._pos('A');
      const to = topo._pos('B');
      const linkCfg = topo._links.get('l1');
      const path = topo._buildLinkPath(from, to, linkCfg.waypoints, linkCfg.lineStyle);
      // Orthogonal: from(100,100) → wp(300,200): L300,100 L300,200
      // wp(300,200) → to(500,400): L500,200 L500,400
      expect(path).toContain('L300,100');
      expect(path).toContain('L300,200');
      expect(path).toContain('L500,200');
      expect(path).toContain('L500,400');
    });

    it('_renderLinkSVG uses waypoint path when waypoints present', () => {
      topo.addWaypoint('l1', { x: 250, y: 150 });

      // Stub _ph to always show
      const origPh = topo._ph.bind(topo);
      topo._ph = () => ({ show: true, anim: false, delay: 0 });

      const linkCfg = topo._links.get('l1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      // Should use _renderFlow (path-based) which outputs <path> elements
      expect(svg).toContain('<path');
      expect(svg).toContain('250,150');
      expect(svg.length).toBeGreaterThan(0);

      topo._ph = origPh;
    });

    it('falls back to normal line rendering when no waypoints', () => {
      const origPh = topo._ph.bind(topo);
      topo._ph = () => ({ show: true, anim: false, delay: 0 });

      const linkCfg = topo._links.get('l1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      // Should render as a normal line element
      expect(svg).toContain('line');
      expect(svg.length).toBeGreaterThan(0);

      topo._ph = origPh;
    });
  });

  describe('Serialization round-trip', () => {
    it('toJSON includes waypoints and lineStyle on links', () => {
      topo.addWaypoint('l1', { x: 200, y: 150 });
      topo.addWaypoint('l1', { x: 350, y: 250 });
      topo.setLinkRouting('l1', 'orthogonal');

      const json = topo.toJSON();
      const linkData = json.links.l1;
      expect(linkData.waypoints).toEqual([{ x: 200, y: 150 }, { x: 350, y: 250 }]);
      expect(linkData.lineStyle).toBe('orthogonal');
    });

    it('fromJSON restores waypoints and lineStyle', () => {
      topo.addWaypoint('l1', { x: 200, y: 150 });
      topo.setLinkRouting('l1', 'orthogonal');

      const json = topo.toJSON();

      const topo2 = new TopologyDesigner({ viewBox: '0 0 800 600' });
      topo2.fromJSON(json);

      const restored = topo2._links.get('l1');
      expect(restored.waypoints).toEqual([{ x: 200, y: 150 }]);
      expect(restored.lineStyle).toBe('orthogonal');
    });

    it('links without waypoints do not include waypoints key', () => {
      const json = topo.toJSON();
      const linkData = json.links.l1;
      // Should not have waypoints key or it should be undefined/empty
      expect(!linkData.waypoints || linkData.waypoints.length === 0).toBe(true);
    });
  });

  describe('Waypoint management API', () => {
    it('addWaypoint inserts at specific index', () => {
      topo.addWaypoint('l1', { x: 200, y: 150 });
      topo.addWaypoint('l1', { x: 400, y: 350 });
      topo.addWaypoint('l1', { x: 300, y: 250 }, 1);
      const link = topo._links.get('l1');
      expect(link.waypoints).toEqual([
        { x: 200, y: 150 },
        { x: 300, y: 250 },
        { x: 400, y: 350 },
      ]);
    });

    it('removeWaypoint removes by index', () => {
      topo.addWaypoint('l1', { x: 100, y: 100 });
      topo.addWaypoint('l1', { x: 200, y: 200 });
      topo.addWaypoint('l1', { x: 300, y: 300 });
      topo.removeWaypoint('l1', 1);
      const link = topo._links.get('l1');
      expect(link.waypoints).toEqual([
        { x: 100, y: 100 },
        { x: 300, y: 300 },
      ]);
    });

    it('clearWaypoints removes all waypoints', () => {
      topo.addWaypoint('l1', { x: 100, y: 100 });
      topo.addWaypoint('l1', { x: 200, y: 200 });
      topo.clearWaypoints('l1');
      const link = topo._links.get('l1');
      expect(link.waypoints).toEqual([]);
    });

    it('setLinkRouting sets lineStyle', () => {
      topo.setLinkRouting('l1', 'orthogonal');
      expect(topo._links.get('l1').lineStyle).toBe('orthogonal');
      topo.setLinkRouting('l1', null);
      expect(topo._links.get('l1').lineStyle).toBeNull();
    });
  });

  describe('Tunnel and wireguard links with waypoints', () => {
    it('tunnel link with waypoints uses path-based tunnel renderer', () => {
      topo.link('t1', { type: 'tunnel', from: 'A', to: 'B', label: 'VPN', color: '#ff6600' });
      topo.addWaypoint('t1', { x: 300, y: 200 });

      const origPh = topo._ph.bind(topo);
      topo._ph = () => ({ show: true, anim: false, delay: 0 });

      const linkCfg = topo._links.get('t1');
      const svg = topo._renderLinkSVG(linkCfg, 's1', 0);
      expect(svg).toContain('<path');
      expect(svg).toContain('300,200');

      topo._ph = origPh;
    });

    it('orthogonal tunnel link routes through right angles', () => {
      topo.link('t1', { type: 'tunnel', from: 'A', to: 'B', label: 'VPN' });
      topo.addWaypoint('t1', { x: 300, y: 250 });
      topo.setLinkRouting('t1', 'orthogonal');

      const from = topo._pos('A');
      const to = topo._pos('B');
      const linkCfg = topo._links.get('t1');
      const path = topo._buildLinkPath(from, to, linkCfg.waypoints, linkCfg.lineStyle);
      // Orthogonal: from(100,100) -> wp(300,250): L300,100 L300,250
      // wp(300,250) -> to(500,400): L500,250 L500,400
      expect(path).toBe('M100,100 L300,100 L300,250 L500,250 L500,400');
    });
  });

  describe('Edge cases', () => {
    it('_buildLinkPath with single waypoint straight', () => {
      const d = topo._buildLinkPath({ x: 0, y: 0 }, { x: 200, y: 200 }, [{ x: 100, y: 50 }], null);
      expect(d).toBe('M0,0 L100,50 L200,200');
    });

    it('_buildLinkPath with empty waypoints array behaves like no waypoints', () => {
      const d = topo._buildLinkPath({ x: 10, y: 20 }, { x: 100, y: 200 }, [], null);
      expect(d).toBe('M10,20 L100,200');
    });

    it('_buildLinkPath with null waypoints behaves like no waypoints', () => {
      const d = topo._buildLinkPath({ x: 10, y: 20 }, { x: 100, y: 200 }, null, null);
      expect(d).toBe('M10,20 L100,200');
    });

    it('orthogonal with collinear points produces valid path', () => {
      const d = topo._buildLinkPath({ x: 0, y: 100 }, { x: 200, y: 100 }, [{ x: 100, y: 100 }], 'orthogonal');
      expect(d).toMatch(/^M0,100/);
      expect(d).toContain('200,100');
    });
  });
});
