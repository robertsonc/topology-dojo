/**
 * Phase 1 & Phase 2 Regression Tests
 * Covers features from issues #135, #137, #138, #139, #140, #141, #142, #146, #147, #148
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function buildBasicTopo() {
  const topo = new TopologyDesigner({ title: 'Regression Test', viewBox: '0 0 1050 700' });
  topo.node('A', { type: 'router',   x: 100, y: 200, label: 'Router A' });
  topo.node('B', { type: 'switch',   x: 400, y: 200, label: 'Switch B' });
  topo.node('C', { type: 'server',   x: 700, y: 200, label: 'Server C' });
  topo.node('D', { type: 'firewall', x: 250, y: 450, label: 'Firewall D' });
  topo.link('l1', { type: 'line',   from: 'A', to: 'B', color: '#01a982' });
  topo.link('l2', { type: 'tunnel', from: 'B', to: 'C', color: '#65aef9' });
  topo.link('l3', { type: 'line',   from: 'B', to: 'D', color: '#deb146' });
  topo.act('a1', { label: 'Act 1', color: '#01a982' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show all',
    focus: ['A', 'B'],
    phases: [
      { show: ['A', 'B', 'l1'], diff: 'Router + Switch' },
      { show: ['C', 'D', 'l2', 'l3'], diff: 'Server + Firewall' },
    ],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Focus firewall',
    focus: ['D'],
    phases: [{ show: ['D', 'l3'], diff: 'Firewall detail' }],
  });
  topo._buildIndex();
  return topo;
}

// ─────────────────────────────────────────────
// #140 — Zone / Region Annotations
// ─────────────────────────────────────────────

describe('Zone annotations (#140)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('registers a zone with nodes array', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    expect(topo._zones.has('z1')).toBe(true);
  });

  it('zone stores all config properties', () => {
    topo.zone('z1', { label: 'DMZ', nodes: ['C', 'D'], color: '#ff6666', borderStyle: 'dashed', description: 'DMZ zone', padding: 50 });
    const z = topo._zones.get('z1');
    expect(z.label).toBe('DMZ');
    expect(z.nodes).toContain('C');
    expect(z.nodes).toContain('D');
    expect(z.color).toBe('#ff6666');
    expect(z.borderStyle).toBe('dashed');
    expect(z.description).toBe('DMZ zone');
    expect(z.padding).toBe(50);
  });

  it('zone auto-computes bounding box from node positions via _renderZoneRect', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    const z = topo._zones.get('z1');
    // Nodes A(100,200) B(400,200) — bounding box should encompass both
    const svgStr = topo._renderZoneRect({ ...z, id: 'z1' });
    expect(typeof svgStr).toBe('string');
    expect(svgStr).toContain('tds-zone');
    // Should include both node x positions in the rect
    expect(svgStr.length).toBeGreaterThan(0);
  });

  it('zone serializes in toJSON', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    const json = topo.toJSON();
    expect(json.zones).toBeDefined();
    expect(Array.isArray(json.zones)).toBe(true);
    const zEntry = json.zones.find(([id]) => id === 'z1');
    expect(zEntry).toBeDefined();
    expect(zEntry[1].label).toBe('LAN');
    expect(zEntry[1].nodes).toContain('A');
  });

  it('zone restores correctly via fromJSON', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    const json = topo.toJSON();

    const topo2 = new TopologyDesigner({ title: 'Restore Test', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);

    expect(topo2._zones.has('z1')).toBe(true);
    const z = topo2._zones.get('z1');
    expect(z.label).toBe('LAN');
    expect(z.nodes).toContain('A');
    expect(z.nodes).toContain('B');
  });

  it('round-trip preserves zone nodes array intact', () => {
    topo.zone('zNet', { label: 'Network', nodes: ['A', 'B', 'C', 'D'], color: '#deb146' });
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'RT', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);
    const z = topo2._zones.get('zNet');
    expect(z.nodes).toHaveLength(4);
    expect(z.nodes).toEqual(['A', 'B', 'C', 'D']);
  });

  it('multiple zones can coexist', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'] });
    topo.zone('z2', { label: 'DMZ', nodes: ['C'] });
    topo.zone('z3', { label: 'Mgmt', nodes: ['D'] });
    expect(topo._zones.size).toBe(3);
  });

  it('removeZone deletes a zone', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A'] });
    topo.removeZone('z1');
    expect(topo._zones.has('z1')).toBe(false);
  });

  it('setZones replaces all zones at once', () => {
    topo.zone('z1', { label: 'LAN', nodes: ['A'] });
    const entries = [['z2', { label: 'DMZ', nodes: ['C'] }]];
    topo.setZones(entries);
    expect(topo._zones.has('z1')).toBe(false);
    expect(topo._zones.has('z2')).toBe(true);
  });

  it('_renderZoneRect returns empty string for zone with no nodes', () => {
    const svgStr = topo._renderZoneRect({ id: 'empty', label: 'Empty', nodes: [] });
    expect(svgStr).toBe('');
  });

  it('_renderZoneRect generates SVG without stroke-dasharray for solid borderStyle', () => {
    topo.zone('zSolid', { label: 'Solid', nodes: ['A', 'B'], borderStyle: 'solid' });
    const z = topo._zones.get('zSolid');
    const svgStr = topo._renderZoneRect({ ...z, id: 'zSolid' });
    // borderStyle:solid means dash='none' → no stroke-dasharray attr added
    expect(svgStr).not.toContain('stroke-dasharray');
    expect(svgStr).toContain('<rect');
  });

  it('zones appear in toJSON zones array', () => {
    topo.zone('z1', { label: 'A', nodes: ['A'] });
    topo.zone('z2', { label: 'B', nodes: ['B'] });
    const json = topo.toJSON();
    expect(json.zones.length).toBe(2);
  });
});

// ─────────────────────────────────────────────
// #139 — Link waypoints + orthogonal routing
// ─────────────────────────────────────────────

describe('Link waypoints & routing (#139)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('creates link with waypoints array stored', () => {
    topo.link('lWP', {
      type: 'line', from: 'A', to: 'C',
      waypoints: [{ x: 200, y: 100 }, { x: 500, y: 100 }],
    });
    const lk = topo._links.get('lWP');
    expect(lk.waypoints).toBeDefined();
    expect(lk.waypoints).toHaveLength(2);
    expect(lk.waypoints[0]).toEqual({ x: 200, y: 100 });
  });

  it('creates link with routing:orthogonal accepted', () => {
    topo.link('lOrtho', { type: 'line', from: 'A', to: 'B', routing: 'orthogonal' });
    const lk = topo._links.get('lOrtho');
    expect(lk.routing).toBe('orthogonal');
  });

  it('addWaypoint adds a waypoint to existing link', () => {
    topo.addWaypoint('l1', { x: 250, y: 150 });
    const lk = topo._links.get('l1');
    expect(lk.waypoints).toBeDefined();
    expect(lk.waypoints.length).toBeGreaterThan(0);
    expect(lk.waypoints[0]).toEqual({ x: 250, y: 150 });
  });

  it('addWaypoint inserts at specific index', () => {
    topo.addWaypoint('l1', { x: 150, y: 100 });
    topo.addWaypoint('l1', { x: 300, y: 100 }, 0); // insert at beginning
    const lk = topo._links.get('l1');
    expect(lk.waypoints[0]).toEqual({ x: 300, y: 100 });
  });

  it('removeWaypoint removes a waypoint by index', () => {
    topo.addWaypoint('l1', { x: 150, y: 100 });
    topo.addWaypoint('l1', { x: 300, y: 200 });
    topo.removeWaypoint('l1', 0);
    const lk = topo._links.get('l1');
    expect(lk.waypoints[0]).toEqual({ x: 300, y: 200 });
  });

  it('clearWaypoints removes all waypoints', () => {
    topo.addWaypoint('l1', { x: 150, y: 100 });
    topo.addWaypoint('l1', { x: 300, y: 200 });
    topo.clearWaypoints('l1');
    const lk = topo._links.get('l1');
    expect(lk.waypoints).toHaveLength(0);
  });

  it('waypoints persist in toJSON', () => {
    topo.link('lWP', {
      type: 'line', from: 'A', to: 'C',
      waypoints: [{ x: 200, y: 100 }],
      routing: 'orthogonal',
    });
    const json = topo.toJSON();
    const lk = json.links['lWP'];
    expect(lk.waypoints).toBeDefined();
    expect(lk.waypoints[0]).toEqual({ x: 200, y: 100 });
    expect(lk.routing).toBe('orthogonal');
  });

  it('waypoints restore correctly in fromJSON', () => {
    topo.link('lWP', { type: 'line', from: 'A', to: 'C', waypoints: [{ x: 200, y: 100 }, { x: 500, y: 50 }] });
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'RT', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);
    const lk = topo2._links.get('lWP');
    expect(lk.waypoints).toHaveLength(2);
    expect(lk.waypoints[1]).toEqual({ x: 500, y: 50 });
  });

  it('setLinkRouting sets lineStyle on a link', () => {
    topo.setLinkRouting('l2', 'orthogonal');
    const lk = topo._links.get('l2');
    expect(lk.lineStyle).toBe('orthogonal');
  });

  it('setLinkRouting accepts straight style', () => {
    topo.setLinkRouting('l2', 'straight');
    const lk = topo._links.get('l2');
    expect(lk.lineStyle).toBe('straight');
  });

  it('removeWaypoint is a no-op for non-existent link', () => {
    expect(() => topo.removeWaypoint('nonexistent', 0)).not.toThrow();
  });

  it('clearWaypoints is a no-op for non-existent link', () => {
    expect(() => topo.clearWaypoints('nonexistent')).not.toThrow();
  });
});

// ─────────────────────────────────────────────
// #146 — Auto-layout engine improvements
// ─────────────────────────────────────────────

describe('Auto-layout engine (#146)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  // autoLayout requires LayoutEngine (loaded in browser), so we test the graceful degradation
  it('autoLayout returns this (chainable) even when LayoutEngine not loaded', () => {
    const result = topo.autoLayout('hierarchical');
    // Should return this (not throw), graceful degradation with console.warn
    expect(result).toBe(topo);
  });

  it('autoLayout returns this for circular algorithm (graceful)', () => {
    const result = topo.autoLayout('circular');
    expect(result).toBe(topo);
  });

  it('autoLayout returns this for force algorithm (graceful)', () => {
    const result = topo.autoLayout('force');
    expect(result).toBe(topo);
  });

  it('autoLayout returns this for unknown algorithm (graceful)', () => {
    const result = topo.autoLayout('nonexistentAlgorithm');
    expect(result).toBe(topo);
  });

  it('autoLayout does not crash on empty topology', () => {
    const emptyTopo = new TopologyDesigner({ title: 'Empty', viewBox: '0 0 1050 700' });
    emptyTopo._buildIndex();
    expect(() => emptyTopo.autoLayout('hierarchical')).not.toThrow();
  });

  it('autoLayout preserves existing node coordinates when LayoutEngine not available', () => {
    const initialA = { x: topo._nodes.get('A').x, y: topo._nodes.get('A').y };
    topo.autoLayout('hierarchical');
    // Positions should be unchanged since LayoutEngine is not loaded in test env
    expect(topo._nodes.get('A').x).toBe(initialA.x);
    expect(topo._nodes.get('A').y).toBe(initialA.y);
  });

  it('all nodes have valid x/y coordinates after attempted autoLayout', () => {
    topo.autoLayout('circular');
    for (const [id, node] of topo._nodes) {
      expect(typeof node.x).toBe('number');
      expect(typeof node.y).toBe('number');
      expect(isNaN(node.x)).toBe(false);
      expect(isNaN(node.y)).toBe(false);
    }
  });

  it('autoLayout with options object does not throw', () => {
    expect(() => topo.autoLayout('hierarchical', { width: 800, height: 600, removeOverlaps: false })).not.toThrow();
  });
});

// ─────────────────────────────────────────────
// Serialization round-trip — extended (#phase1+2)
// ─────────────────────────────────────────────

describe('Extended serialization round-trip', () => {
  it('toJSON includes zones in output', () => {
    const topo = buildBasicTopo();
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    const json = topo.toJSON();
    expect(json.zones).toBeDefined();
    expect(Array.isArray(json.zones)).toBe(true);
    expect(json.zones.length).toBe(1);
  });

  it('toJSON includes link waypoints in output', () => {
    const topo = buildBasicTopo();
    topo._links.get('l1').waypoints = [{ x: 200, y: 150 }];
    const json = topo.toJSON();
    expect(json.links.l1.waypoints).toBeDefined();
    expect(json.links.l1.waypoints[0]).toEqual({ x: 200, y: 150 });
  });

  it('toJSON includes link routing property', () => {
    const topo = buildBasicTopo();
    topo._links.get('l1').routing = 'orthogonal';
    const json = topo.toJSON();
    expect(json.links.l1.routing).toBe('orthogonal');
  });

  it('full round-trip: zones, waypoints, routing all preserved', () => {
    const topo = buildBasicTopo();
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'], color: '#01a982' });
    topo.zone('z2', { label: 'DMZ', nodes: ['C'], color: '#ff6666' });
    topo.link('lWP', { type: 'line', from: 'A', to: 'C', waypoints: [{ x: 300, y: 100 }], routing: 'orthogonal' });

    const json = topo.toJSON();

    const topo2 = new TopologyDesigner({ title: 'Restore', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);

    // Zones
    expect(topo2._zones.size).toBe(2);
    expect(topo2._zones.get('z1').label).toBe('LAN');
    expect(topo2._zones.get('z2').nodes).toContain('C');

    // Waypoints
    const lk = topo2._links.get('lWP');
    expect(lk.waypoints).toBeDefined();
    expect(lk.waypoints[0]).toEqual({ x: 300, y: 100 });
    expect(lk.routing).toBe('orthogonal');
  });

  it('fromJSON preserves all node coordinates', () => {
    const topo = buildBasicTopo();
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'Restore', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);

    expect(topo2._nodes.get('A').x).toBe(100);
    expect(topo2._nodes.get('A').y).toBe(200);
    expect(topo2._nodes.get('C').x).toBe(700);
    expect(topo2._nodes.get('C').y).toBe(200);
  });

  it('fromJSON preserves all steps and phases', () => {
    const topo = buildBasicTopo();
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'Restore', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);

    expect(topo2._steps.length).toBe(2);
    expect(topo2._steps[0].phases.length).toBe(2);
    expect(topo2._steps[0].phases[0].show).toContain('A');
  });

  it('double round-trip remains stable', () => {
    const topo = buildBasicTopo();
    topo.zone('z1', { label: 'LAN', nodes: ['A', 'B'] });
    const json1 = topo.toJSON();

    const topo2 = new TopologyDesigner({ title: 'R1', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json1);
    const json2 = topo2.toJSON();

    const topo3 = new TopologyDesigner({ title: 'R2', viewBox: '0 0 1050 700' });
    topo3.fromJSON(json2);

    expect(topo3._zones.get('z1').label).toBe('LAN');
    expect(topo3._nodes.size).toBe(topo._nodes.size);
  });
});

// ─────────────────────────────────────────────
// #141 — Step thumbnail previews
// ─────────────────────────────────────────────

describe('Step thumbnail previews (#141)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('_renderThumbnail method exists', () => {
    expect(typeof topo._renderThumbnail).toBe('function');
  });

  it('_renderThumbnail returns SVG string for valid step', () => {
    const svg = topo._renderThumbnail(1);
    expect(typeof svg).toBe('string');
    expect(svg).toContain('<svg');
    expect(svg).toContain('</svg>');
  });

  it('_renderThumbnail uses specified width and height', () => {
    const svg = topo._renderThumbnail(1, 200, 120);
    expect(svg).toContain('width="200"');
    expect(svg).toContain('height="120"');
  });

  it('_renderThumbnail returns empty string for step 0 (invalid)', () => {
    const svg = topo._renderThumbnail(0);
    expect(svg).toBe('');
  });

  it('_renderThumbnail returns empty string for step > total steps', () => {
    const svg = topo._renderThumbnail(999);
    expect(svg).toBe('');
  });

  it('_renderThumbnail includes circle elements for visible nodes', () => {
    const svg = topo._renderThumbnail(1);
    expect(svg).toContain('<circle');
  });

  it('_renderThumbnail restores current step after generating thumbnail', () => {
    topo.step = 2;
    topo._renderThumbnail(1);
    expect(topo.step).toBe(2);
  });

  it('_renderThumbnail works for all valid steps', () => {
    for (let i = 1; i <= topo._steps.length; i++) {
      const svg = topo._renderThumbnail(i);
      expect(typeof svg).toBe('string');
      expect(svg).toContain('<svg');
    }
  });
});

// ─────────────────────────────────────────────
// #137 — PNG / SVG / PDF export
// ─────────────────────────────────────────────

describe('Export capabilities (#137)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('exportPNG method exists', () => {
    expect(typeof topo.exportPNG).toBe('function');
  });

  it('exportSVG method exists', () => {
    expect(typeof topo.exportSVG).toBe('function');
  });

  it('_showExportMenu method exists', () => {
    expect(typeof topo._showExportMenu).toBe('function');
  });

  it('exportSVG does not throw when no SVG element is in DOM', () => {
    // Should gracefully return when no #tds-diagram element exists
    expect(() => topo.exportSVG()).not.toThrow();
  });

  it('exportPNG returns a promise (or undefined) without throwing', async () => {
    // exportPNG uses document.getElementById('tds-diagram') — will return early when missing
    const result = topo.exportPNG();
    // If it returns a promise, await it; otherwise just verify no throw
    if (result && typeof result.then === 'function') {
      await expect(result).resolves.not.toThrow();
    }
  });
});

// ─────────────────────────────────────────────
// #142 — draw.io XML import
// ─────────────────────────────────────────────

describe('draw.io XML import (#142)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'Drawio Test', viewBox: '0 0 1050 700' });
    topo._buildIndex();
  });

  const SIMPLE_DRAWIO_XML = `<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="Router A" style="shape=mxgraph.network.router;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="3" value="Server B" style="shape=mxgraph.network.server;" vertex="1" parent="1">
      <mxGeometry x="400" y="100" width="60" height="60" as="geometry"/>
    </mxCell>
    <mxCell id="4" value="Link" edge="1" source="2" target="3" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>`;

  const MALFORMED_XML = `<not valid xml <<< >>>`;

  it('importDrawio method exists', () => {
    expect(typeof topo.importDrawio).toBe('function');
  });

  it('importDrawio parses valid XML and creates nodes', () => {
    topo.importDrawio(SIMPLE_DRAWIO_XML);
    // Should have imported at least the 2 vertex nodes
    expect(topo._nodes.size).toBeGreaterThanOrEqual(2);
  });

  it('importDrawio maps router shape to router node type', () => {
    topo.importDrawio(SIMPLE_DRAWIO_XML);
    let hasRouter = false;
    for (const [id, node] of topo._nodes) {
      if (node.type === 'router') hasRouter = true;
    }
    expect(hasRouter).toBe(true);
  });

  it('importDrawio maps server shape to server node type', () => {
    topo.importDrawio(SIMPLE_DRAWIO_XML);
    let hasServer = false;
    for (const [id, node] of topo._nodes) {
      if (node.type === 'server') hasServer = true;
    }
    expect(hasServer).toBe(true);
  });

  it('importDrawio creates links between nodes', () => {
    topo.importDrawio(SIMPLE_DRAWIO_XML);
    expect(topo._links.size).toBeGreaterThanOrEqual(1);
  });

  it('importDrawio is chainable (returns this)', () => {
    const result = topo.importDrawio(SIMPLE_DRAWIO_XML);
    expect(result).toBe(topo);
  });

  it('importDrawio handles malformed XML gracefully', () => {
    // Should not throw, just log error and return this
    expect(() => topo.importDrawio(MALFORMED_XML)).not.toThrow();
    const result = topo.importDrawio(MALFORMED_XML);
    expect(result).toBe(topo);
  });

  it('importDrawio respects offsetX/offsetY options', () => {
    const topo2 = new TopologyDesigner({ title: 'Offset', viewBox: '0 0 1050 700' });
    topo2._buildIndex();
    topo2.importDrawio(SIMPLE_DRAWIO_XML, { offsetX: 50, offsetY: 30 });
    // Nodes should have offset coordinates applied
    let found = false;
    for (const [id, node] of topo2._nodes) {
      if (node.x !== undefined) found = true;
    }
    expect(found).toBe(true);
  });

  it('importDrawio with empty XML string handles gracefully', () => {
    expect(() => topo.importDrawio('')).not.toThrow();
  });

  it('importDrawio with XML that has no mxCell nodes returns this', () => {
    const emptyXml = `<?xml version="1.0"?><mxGraphModel><root></root></mxGraphModel>`;
    const result = topo.importDrawio(emptyXml);
    expect(result).toBe(topo);
  });
});

// ─────────────────────────────────────────────
// #148 — Drag-to-reposition with coordinate readback
// ─────────────────────────────────────────────

describe('Drag-to-reposition / coordinate readback (#148)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('nodes have x/y coordinates accessible after placement', () => {
    const node = topo._nodes.get('B');
    expect(typeof node.x).toBe('number');
    expect(typeof node.y).toBe('number');
  });

  it('node coordinate can be updated directly in _nodes map', () => {
    topo._nodes.get('A').x = 999;
    topo._nodes.get('A').y = 888;
    expect(topo._nodes.get('A').x).toBe(999);
    expect(topo._nodes.get('A').y).toBe(888);
  });

  it('_pos (position resolution) resolves correct coordinates', () => {
    const pos = topo._pos('A');
    expect(pos).toBeDefined();
    expect(pos.x).toBe(100);
    expect(pos.y).toBe(200);
  });

  it('_showCoordTooltip method exists (coordinate readback)', () => {
    expect(typeof topo._showCoordTooltip).toBe('function');
  });

  it('_showCoordTooltip does not throw when called', () => {
    expect(() => topo._showCoordTooltip(100, 200, 'A', 500, 400)).not.toThrow();
  });

  it('onNodeReposition callback is called when configured', () => {
    const callback = vi.fn();
    const topo2 = new TopologyDesigner({
      title: 'Callback Test',
      viewBox: '0 0 1050 700',
      onNodeReposition: callback,
    });
    // Verify the callback was registered
    expect(topo2._onNodeReposition).toBe(callback);
  });

  it('_draggingNode initializes to null', () => {
    expect(topo._draggingNode).toBeNull();
  });

  it('_dragNodeOffset initializes correctly', () => {
    expect(topo._dragNodeOffset).toEqual({ x: 0, y: 0 });
  });

  it('coordinate update persists in toJSON after reposition', () => {
    topo._nodes.get('A').x = 350;
    topo._nodes.get('A').y = 450;
    const json = topo.toJSON();
    expect(json.nodes.A.x).toBe(350);
    expect(json.nodes.A.y).toBe(450);
  });
});

// ─────────────────────────────────────────────
// #135 — Sticky node placement mode
// ─────────────────────────────────────────────

describe('Sticky node placement mode (#135)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('_pendingNodeType is a recognized property (placement mode state)', () => {
    // Sticky placement tracks pending node type; initially null or undefined
    const val = topo._pendingNodeType;
    expect(val === null || val === undefined || typeof val === 'string').toBe(true);
  });

  it('node can be added programmatically after another (simulating sticky mode)', () => {
    const sizeBefore = topo._nodes.size;
    topo.node('NewNode1', { type: 'router', x: 200, y: 300 });
    topo.node('NewNode2', { type: 'router', x: 300, y: 300 });
    expect(topo._nodes.size).toBe(sizeBefore + 2);
  });

  it('multiple nodes of same type can be placed sequentially', () => {
    // Simulates sticky placement mode behavior
    ['r1', 'r2', 'r3'].forEach((id, i) => {
      topo.node(id, { type: 'router', x: 100 + i * 100, y: 400 });
    });
    expect(topo._nodes.has('r1')).toBe(true);
    expect(topo._nodes.has('r2')).toBe(true);
    expect(topo._nodes.has('r3')).toBe(true);
  });
});

// ─────────────────────────────────────────────
// #138 — Node type browser
// ─────────────────────────────────────────────

describe('Node type browser (#138)', () => {
  it('getNodeTypeCatalog static method exists', () => {
    expect(typeof TopologyDesigner.getNodeTypeCatalog).toBe('function');
  });

  it('getNodeTypeCatalog returns an array of categories', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    expect(Array.isArray(catalog)).toBe(true);
    expect(catalog.length).toBeGreaterThan(0);
  });

  it('getNodeTypeCatalog has Network and Shapes categories', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    const cats = catalog.map(c => c.category);
    expect(cats).toContain('Network');
    expect(cats).toContain('Shapes');
  });

  it('getNodeTypeCatalog Network category includes router, switch, server', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    const network = catalog.find(c => c.category === 'Network');
    const typeNames = network.types.map(t => t.name);
    expect(typeNames).toContain('router');
    expect(typeNames).toContain('switch');
    expect(typeNames).toContain('server');
  });

  it('getNodeTypeCatalog Shapes category includes basic shapes', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    const shapes = catalog.find(c => c.category === 'Shapes');
    expect(shapes).toBeDefined();
    // Should have at least some shape entries (if registered)
    expect(Array.isArray(shapes.types)).toBe(true);
  });

  it('each catalog type has name and description', () => {
    const catalog = TopologyDesigner.getNodeTypeCatalog();
    for (const cat of catalog) {
      for (const t of cat.types) {
        expect(typeof t.name).toBe('string');
        expect(typeof t.description).toBe('string');
      }
    }
  });

  it('renderNodePreview static method exists', () => {
    expect(typeof TopologyDesigner.renderNodePreview).toBe('function');
  });

  it('renderNodePreview returns SVG for router type', () => {
    const svg = TopologyDesigner.renderNodePreview('router');
    expect(svg).toContain('<svg');
    expect(svg).toContain('</svg>');
  });

  it('renderNodePreview returns empty string for unknown type', () => {
    const svg = TopologyDesigner.renderNodePreview('nonexistent_type_xyz');
    expect(svg).toBe('');
  });

  it('renderNodePreview accepts custom size parameter', () => {
    const svg = TopologyDesigner.renderNodePreview('switch', 60);
    expect(svg).toContain('width="60"');
    expect(svg).toContain('height="60"');
  });

  it('getRegisteredNodeTypes returns array of type names', () => {
    const types = TopologyDesigner.getRegisteredNodeTypes();
    expect(Array.isArray(types)).toBe(true);
    expect(types).toContain('router');
    expect(types).toContain('server');
  });

  it('getRegisteredLinkTypes returns array including built-in types', () => {
    const types = TopologyDesigner.getRegisteredLinkTypes();
    expect(Array.isArray(types)).toBe(true);
    expect(types).toContain('line');
    expect(types).toContain('tunnel');
  });
});

// ─────────────────────────────────────────────
// #147 — Mobile quick-edit mode
// ─────────────────────────────────────────────

describe('Mobile quick-edit mode (#147)', () => {
  let topo;
  beforeEach(() => { topo = buildBasicTopo(); });

  it('enableMobileQuickEdit method exists', () => {
    expect(typeof topo.enableMobileQuickEdit).toBe('function');
  });

  it('disableMobileQuickEdit method exists', () => {
    expect(typeof topo.disableMobileQuickEdit).toBe('function');
  });

  it('enableMobileQuickEdit sets _mobileQuickEditEnabled to true', () => {
    topo.enableMobileQuickEdit();
    expect(topo._mobileQuickEditEnabled).toBe(true);
  });

  it('disableMobileQuickEdit sets _mobileQuickEditEnabled to false', () => {
    topo.enableMobileQuickEdit();
    topo.disableMobileQuickEdit();
    expect(topo._mobileQuickEditEnabled).toBe(false);
  });

  it('enableMobileQuickEdit is idempotent (calling twice is safe)', () => {
    topo.enableMobileQuickEdit();
    expect(() => topo.enableMobileQuickEdit()).not.toThrow();
    expect(topo._mobileQuickEditEnabled).toBe(true);
  });

  it('_mobileQuickEditEnabled defaults to falsy before enabling', () => {
    const fresh = new TopologyDesigner({ title: 'Fresh', viewBox: '0 0 1050 700' });
    expect(fresh._mobileQuickEditEnabled).toBeFalsy();
  });
});
