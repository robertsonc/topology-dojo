import { describe, it, expect, beforeEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ══════════════════════════════════════════
   #144 — Natural Language Topology Generation
   ══════════════════════════════════════════ */
describe('NL Topology Generation (#144)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner();
  });

  describe('_parseAITopologyDescription', () => {
    it('generates a 3-tier topology', () => {
      const result = topo._parseAITopologyDescription('Create a 3-tier web architecture');
      expect(result.nodes.length).toBeGreaterThanOrEqual(4); // LB + 3 app + DB
      expect(result.links.length).toBeGreaterThanOrEqual(4); // LB->apps + apps->DB
      // Should have a load balancer and database
      const types = result.nodes.map(n => n.type);
      expect(types).toContain('ec');       // LB
      expect(types).toContain('database'); // DB
      expect(types).toContain('host');     // App servers
    });

    it('generates a hub-and-spoke topology', () => {
      const result = topo._parseAITopologyDescription('Design a hub and spoke network');
      // Hub + 5 spokes
      expect(result.nodes.length).toBe(6);
      expect(result.links.length).toBe(5);
      // Hub should be a router
      expect(result.nodes[0].type).toBe('router');
      expect(result.nodes[0].label).toBe('Hub Router');
    });

    it('generates a star topology', () => {
      const result = topo._parseAITopologyDescription('Create a star topology');
      expect(result.nodes.length).toBe(6);
      expect(result.links.length).toBe(5);
    });

    it('scales explicit hub/spoke counts for medium prompts', () => {
      const result = topo._parseAITopologyDescription('medium 10 sites - 2 hub 8 spoke');
      expect(result.nodes.length).toBe(10);
      expect(result.links.length).toBe(9);
      expect(result.nodes.filter(n => /Hub/.test(n.label)).length).toBe(2);
      expect(result.nodes.filter(n => /Spoke Site/.test(n.label)).length).toBe(8);
    });

    it('scales explicit hub/spoke counts for large prompts', () => {
      const result = topo._parseAITopologyDescription('large 4 hub 32 spoke');
      expect(result.nodes.length).toBe(36);
      expect(result.links.length).toBe(38);
      expect(result.nodes.filter(n => /Hub/.test(n.label)).length).toBe(4);
      expect(result.nodes.filter(n => /Spoke Site/.test(n.label)).length).toBe(32);
    });

    it('generates a mesh topology', () => {
      const result = topo._parseAITopologyDescription('Build a full mesh network');
      expect(result.nodes.length).toBe(4);
      // Full mesh of 4 nodes = 6 links (n*(n-1)/2)
      expect(result.links.length).toBe(6);
      // Should use tunnel link type
      expect(result.links.every(l => l.type === 'tunnel')).toBe(true);
    });

    it('parses free-form description with known keywords', () => {
      const result = topo._parseAITopologyDescription('I need a firewall, a router, and a database');
      expect(result.nodes.length).toBe(3);
      const types = result.nodes.map(n => n.type);
      expect(types).toContain('firewall');
      expect(types).toContain('router');
      expect(types).toContain('database');
    });

    it('handles counted components (e.g. "3 servers")', () => {
      const result = topo._parseAITopologyDescription('Deploy 3 servers and a database');
      const servers = result.nodes.filter(n => n.type === 'host');
      expect(servers.length).toBe(3);
      const dbs = result.nodes.filter(n => n.type === 'database');
      expect(dbs.length).toBe(1);
    });

    it('creates chain links when no explicit connections are given', () => {
      const result = topo._parseAITopologyDescription('A firewall, a switch, and a server');
      expect(result.nodes.length).toBe(3);
      // Chain: firewall->switch->server
      expect(result.links.length).toBe(2);
    });

    it('falls back to a default 3-node topology for unrecognizable input', () => {
      const result = topo._parseAITopologyDescription('something completely unrelated');
      expect(result.nodes.length).toBe(3);
      expect(result.links.length).toBe(2);
      // Default: Client -> Server -> Database
      const labels = result.nodes.map(n => n.label);
      expect(labels).toContain('Client');
      expect(labels).toContain('Server');
      expect(labels).toContain('Database');
    });

    it('assigns x/y positions to all nodes', () => {
      const result = topo._parseAITopologyDescription('Build a hub-spoke network');
      for (const node of result.nodes) {
        expect(node.x).toBeDefined();
        expect(node.y).toBeDefined();
        expect(typeof node.x).toBe('number');
        expect(typeof node.y).toBe('number');
      }
    });

    it('assigns unique IDs to all generated nodes', () => {
      const result = topo._parseAITopologyDescription('3-tier architecture');
      const ids = result.nodes.map(n => n.id);
      expect(new Set(ids).size).toBe(ids.length);
    });

    it('detects connection phrases like "connects to"', () => {
      const result = topo._parseAITopologyDescription('A firewall connects to a server');
      const types = result.nodes.map(n => n.type);
      expect(types).toContain('firewall');
      expect(types).toContain('host');
      // Should have explicit link between them
      expect(result.links.length).toBeGreaterThanOrEqual(1);
    });
  });

  describe('_applyGeneratedTopology', () => {
    it('adds nodes and links to the topology', () => {
      const result = {
        nodes: [
          { id: 'n1', type: 'router', label: 'R1', x: 100, y: 200 },
          { id: 'n2', type: 'switch', label: 'S1', x: 300, y: 200 },
        ],
        links: [
          { from: 'n1', to: 'n2', type: 'line', label: 'link1' },
        ],
      };
      topo._applyGeneratedTopology(result);
      expect(topo._nodes.get('n1')).toBeDefined();
      expect(topo._nodes.get('n2')).toBeDefined();
      expect(topo._links.get('n1__n2')).toBeDefined();
    });

    it('handles null/undefined result gracefully', () => {
      expect(() => topo._applyGeneratedTopology(null)).not.toThrow();
      expect(() => topo._applyGeneratedTopology(undefined)).not.toThrow();
    });

    it('applies result from _parseAITopologyDescription end-to-end', () => {
      const result = topo._parseAITopologyDescription('mesh network');
      topo._applyGeneratedTopology(result);
      expect(topo._nodes.size).toBe(result.nodes.length);
      expect(topo._links.size).toBe(result.links.length);
    });
  });
});


/* ══════════════════════════════════════════
   #145 — Step-View Engagement Analytics
   ══════════════════════════════════════════ */
describe('Step-View Engagement Analytics (#145)', () => {
  let topo;

  beforeEach(() => {
    topo = new TopologyDesigner();
    // Set up steps for analytics tracking
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'line', from: 'A', to: 'B' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('step1', { act: 'a1', name: 'Step 1', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }] });
    topo.addStep('step2', { act: 'a1', name: 'Step 2', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }] });
    topo.addStep('step3', { act: 'a1', name: 'Step 3', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }] });
    topo._buildIndex();
  });

  describe('_trackAnalytics', () => {
    it('records interaction events', () => {
      topo._trackAnalytics('click', { nodeId: 'A' });
      topo._trackAnalytics('next', {});
      expect(topo._analytics.interactions.length).toBe(2);
      expect(topo._analytics.interactions[0].type).toBe('click');
      expect(topo._analytics.interactions[1].type).toBe('next');
    });

    it('does nothing if _analytics is null', () => {
      topo._analytics = null;
      expect(() => topo._trackAnalytics('click', {})).not.toThrow();
    });
  });

  describe('_trackStepView', () => {
    it('records step views and initializes step tracking', () => {
      topo._trackStepView('step1');
      expect(topo._analytics.stepViews['step1']).toBeDefined();
      expect(topo._analytics.stepViews['step1'].count).toBe(1);
    });

    it('increments count on repeated views', () => {
      topo._trackStepView('step1');
      topo._trackStepView('step2');
      topo._trackStepView('step1');
      expect(topo._analytics.stepViews['step1'].count).toBe(2);
    });

    it('accumulates dwell time between step transitions', () => {
      const start = Date.now();
      vi.spyOn(Date, 'now').mockReturnValue(start);
      topo._trackStepView('step1');

      vi.spyOn(Date, 'now').mockReturnValue(start + 5000);
      topo._trackStepView('step2');

      // step1 should have ~5000ms of dwell time
      expect(topo._analytics.stepViews['step1'].totalMs).toBe(5000);
      vi.restoreAllMocks();
    });

    it('updates completion rate based on furthest step viewed', () => {
      topo._trackStepView('step1');
      expect(topo._analytics.completionRate).toBeCloseTo(1 / 3, 1);

      topo._trackStepView('step2');
      expect(topo._analytics.completionRate).toBeCloseTo(2 / 3, 1);

      topo._trackStepView('step3');
      expect(topo._analytics.completionRate).toBe(1);
    });

    it('does nothing if stepId is falsy', () => {
      topo._trackStepView(null);
      topo._trackStepView(undefined);
      topo._trackStepView('');
      expect(Object.keys(topo._analytics.stepViews).length).toBe(0);
    });

    it('does nothing if _analytics is null', () => {
      topo._analytics = null;
      expect(() => topo._trackStepView('step1')).not.toThrow();
    });
  });

  describe('getAnalytics', () => {
    it('returns summary with all expected fields', () => {
      topo._trackStepView('step1');
      topo._trackAnalytics('next', {});
      topo._trackStepView('step2');

      const analytics = topo.getAnalytics();
      expect(analytics).toHaveProperty('sessionDuration');
      expect(analytics).toHaveProperty('stepsViewed');
      expect(analytics).toHaveProperty('totalStepTransitions');
      expect(analytics).toHaveProperty('completionRate');
      expect(analytics).toHaveProperty('averageStepDwell');
      expect(analytics).toHaveProperty('stepBreakdown');
      expect(analytics).toHaveProperty('interactionLog');
    });

    it('calculates session duration', () => {
      const analytics = topo.getAnalytics();
      expect(analytics.sessionDuration).toBeGreaterThanOrEqual(0);
    });

    it('counts unique steps viewed', () => {
      topo._trackStepView('step1');
      topo._trackStepView('step2');
      topo._trackStepView('step1');
      const analytics = topo.getAnalytics();
      expect(analytics.stepsViewed).toBe(2);
    });

    it('counts step transitions from interaction log', () => {
      topo._trackAnalytics('next', {});
      topo._trackAnalytics('prev', {});
      topo._trackAnalytics('click', { nodeId: 'A' });
      const analytics = topo.getAnalytics();
      expect(analytics.totalStepTransitions).toBe(2); // next + prev only
    });

    it('calculates average step dwell time', () => {
      const start = Date.now();
      vi.spyOn(Date, 'now').mockReturnValue(start);
      topo._trackStepView('step1');

      vi.spyOn(Date, 'now').mockReturnValue(start + 4000);
      topo._trackStepView('step2');

      vi.spyOn(Date, 'now').mockReturnValue(start + 10000);
      const analytics = topo.getAnalytics();

      // step1: 4000ms, step2: 6000ms -> avg 5000ms
      expect(analytics.averageStepDwell).toBe(5000);
      vi.restoreAllMocks();
    });

    it('returns a copy of stepBreakdown and interactionLog', () => {
      topo._trackStepView('step1');
      topo._trackAnalytics('click', {});
      const a1 = topo.getAnalytics();
      const a2 = topo.getAnalytics();
      // Should be different object references (copies)
      expect(a1.stepBreakdown).not.toBe(a2.stepBreakdown);
      expect(a1.interactionLog).not.toBe(a2.interactionLog);
    });

    it('handles empty analytics gracefully', () => {
      const analytics = topo.getAnalytics();
      expect(analytics.stepsViewed).toBe(0);
      expect(analytics.totalStepTransitions).toBe(0);
      expect(analytics.averageStepDwell).toBe(0);
      expect(analytics.completionRate).toBe(0);
    });
  });
});


/* ══════════════════════════════════════════
   #147 — Mobile Quick-Edit Mode
   ══════════════════════════════════════════ */
describe('Mobile Quick-Edit Mode (#147)', () => {
  let topo;

  beforeEach(() => {
    document.body.innerHTML = '<div id="topo-container"></div>';
    topo = new TopologyDesigner();
    topo._containerId = 'topo-container';
    topo.node('A', { type: 'router', x: 100, y: 200, label: 'Router A' });
    topo.node('B', { type: 'switch', x: 400, y: 200, label: 'Switch B' });
  });

  describe('enableMobileQuickEdit', () => {
    it('creates FAB and panel in the container', () => {
      topo.enableMobileQuickEdit();
      const container = document.getElementById('topo-container');
      expect(container.querySelector('.tds-mobile-fab')).not.toBeNull();
      expect(container.querySelector('.tds-mobile-qe-panel')).not.toBeNull();
    });

    it('returns this for chaining', () => {
      expect(topo.enableMobileQuickEdit()).toBe(topo);
    });

    it('sets _mobileQuickEditEnabled flag', () => {
      topo.enableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(true);
    });

    it('does not duplicate elements on repeated calls', () => {
      topo.enableMobileQuickEdit();
      topo.enableMobileQuickEdit();
      const container = document.getElementById('topo-container');
      expect(container.querySelectorAll('.tds-mobile-fab').length).toBe(1);
      expect(container.querySelectorAll('.tds-mobile-qe-panel').length).toBe(1);
    });

    it('creates node type buttons for quick add', () => {
      topo.enableMobileQuickEdit();
      const typeButtons = document.querySelectorAll('.tds-mobile-qe-type-btn');
      expect(typeButtons.length).toBeGreaterThan(0);
      const types = Array.from(typeButtons).map(b => b.textContent);
      expect(types).toContain('router');
      expect(types).toContain('switch');
      expect(types).toContain('firewall');
    });

    it('FAB toggles panel open/close', () => {
      topo.enableMobileQuickEdit();
      const fab = document.querySelector('.tds-mobile-fab');
      const panel = document.querySelector('.tds-mobile-qe-panel');

      fab.click();
      expect(panel.classList.contains('open')).toBe(true);
      expect(fab.classList.contains('active')).toBe(true);

      fab.click();
      expect(panel.classList.contains('open')).toBe(false);
      expect(fab.classList.contains('active')).toBe(false);
    });

    it('close button closes the panel', () => {
      topo.enableMobileQuickEdit();
      const fab = document.querySelector('.tds-mobile-fab');
      fab.click(); // Open panel

      const closeBtn = document.querySelector('.tds-mobile-qe-close');
      closeBtn.click();
      const panel = document.querySelector('.tds-mobile-qe-panel');
      expect(panel.classList.contains('open')).toBe(false);
    });

    it('type button adds a node to the topology', () => {
      topo.enableMobileQuickEdit();
      const initialCount = topo._nodes.size;
      const typeBtn = document.querySelector('.tds-mobile-qe-type-btn');
      typeBtn.click();
      expect(topo._nodes.size).toBe(initialCount + 1);
    });
  });

  describe('disableMobileQuickEdit', () => {
    it('removes FAB and panel from DOM', () => {
      topo.enableMobileQuickEdit();
      topo.disableMobileQuickEdit();
      const container = document.getElementById('topo-container');
      expect(container.querySelector('.tds-mobile-fab')).toBeNull();
      expect(container.querySelector('.tds-mobile-qe-panel')).toBeNull();
    });

    it('clears _mobileQuickEditEnabled flag', () => {
      topo.enableMobileQuickEdit();
      topo.disableMobileQuickEdit();
      expect(topo._mobileQuickEditEnabled).toBe(false);
    });

    it('returns this for chaining', () => {
      expect(topo.disableMobileQuickEdit()).toBe(topo);
    });

    it('handles call without prior enable gracefully', () => {
      expect(() => topo.disableMobileQuickEdit()).not.toThrow();
    });
  });

  describe('action buttons', () => {
    it('export-json triggers download', () => {
      topo.enableMobileQuickEdit();
      // Mock URL.createObjectURL and URL.revokeObjectURL
      const origCreate = URL.createObjectURL;
      const origRevoke = URL.revokeObjectURL;
      URL.createObjectURL = vi.fn(() => 'blob:test');
      URL.revokeObjectURL = vi.fn();

      const exportBtn = document.querySelector('[data-action="export-json"]');
      expect(() => exportBtn.click()).not.toThrow();

      URL.createObjectURL = origCreate;
      URL.revokeObjectURL = origRevoke;
    });

    it('undo-move calls _lastMoveUndo if available', () => {
      topo.enableMobileQuickEdit();
      topo._lastMoveUndo = vi.fn();
      const undoBtn = document.querySelector('[data-action="undo-move"]');
      undoBtn.click();
      expect(topo._lastMoveUndo).toHaveBeenCalled();
    });

    it('delete-node removes selected node', () => {
      topo.enableMobileQuickEdit();
      topo._selectedElement = 'A';
      const initialCount = topo._nodes.size;
      const deleteBtn = document.querySelector('[data-action="delete-node"]');
      deleteBtn.click();
      expect(topo._nodes.size).toBe(initialCount - 1);
      expect(topo._nodes.has('A')).toBe(false);
      expect(topo._selectedElement).toBeNull();
    });
  });
});
