/**
 * Additional coverage tests for TopologyGraph — iteration helpers,
 * anchor utilities, and edge cases missed by graph.test.js.
 */
import { describe, it, expect, beforeEach } from 'vitest';

const TopologyGraph = require('../design-system/core/graph.js');

describe('TopologyGraph — iteration and utility coverage', () => {
  let g;

  beforeEach(() => {
    g = new TopologyGraph();
    g.addNode('A', { type: 'server', x: 0, y: 0 });
    g.addNode('B', { type: 'router', x: 100, y: 0 });
    g.addNode('C', { type: 'host', x: 200, y: 0 });
    g.addLink('ab', { type: 'line', from: 'A', to: 'B' });
    g.addLink('bc', { type: 'line', from: 'B', to: 'C' });
    g.addAnchor('pt1', { x: 50, y: 50 });
    g.addAnchor('pt2', { x: 150, y: 150 });
  });

  /* ── nodeEntries ── */

  describe('nodeEntries', () => {
    it('returns an iterator of [id, config] pairs', () => {
      const entries = [...g.nodeEntries()];
      expect(entries).toHaveLength(3);
      expect(entries[0][0]).toBe('A');
      expect(entries[0][1].type).toBe('server');
    });

    it('reflects mutations', () => {
      g.addNode('D', { type: 'switch', x: 300, y: 0 });
      const ids = [...g.nodeEntries()].map(([id]) => id);
      expect(ids).toContain('D');
    });
  });

  /* ── nodeIds ── */

  describe('nodeIds', () => {
    it('returns an iterator of node ID strings', () => {
      const ids = [...g.nodeIds()];
      expect(ids).toEqual(['A', 'B', 'C']);
    });

    it('is empty when graph has no nodes', () => {
      g.clear();
      expect([...g.nodeIds()]).toEqual([]);
    });
  });

  /* ── linkEntries ── */

  describe('linkEntries', () => {
    it('returns an iterator of [id, config] pairs', () => {
      const entries = [...g.linkEntries()];
      expect(entries).toHaveLength(2);
      expect(entries[0][0]).toBe('ab');
      expect(entries[0][1].from).toBe('A');
    });
  });

  /* ── linkIds ── */

  describe('linkIds', () => {
    it('returns an iterator of link ID strings', () => {
      const ids = [...g.linkIds()];
      expect(ids).toEqual(['ab', 'bc']);
    });

    it('is empty after clearing all links', () => {
      g.removeLink('ab');
      g.removeLink('bc');
      expect([...g.linkIds()]).toEqual([]);
    });
  });

  /* ── links iteration ── */

  describe('links', () => {
    it('iterates all links as [id, config] entries', () => {
      const all = [...g.links()];
      expect(all).toHaveLength(2);
      expect(all.map(([id]) => id)).toEqual(['ab', 'bc']);
    });
  });

  /* ── hasAnchor ── */

  describe('hasAnchor', () => {
    it('returns true for existing anchor', () => {
      expect(g.hasAnchor('pt1')).toBe(true);
    });

    it('returns false for missing anchor', () => {
      expect(g.hasAnchor('missing')).toBe(false);
    });

    it('returns false after anchor removal', () => {
      g.removeAnchor('pt1');
      expect(g.hasAnchor('pt1')).toBe(false);
    });
  });

  /* ── anchorCount ── */

  describe('anchorCount', () => {
    it('reports correct count', () => {
      expect(g.anchorCount).toBe(2);
    });

    it('decrements on removal', () => {
      g.removeAnchor('pt1');
      expect(g.anchorCount).toBe(1);
    });

    it('is 0 on empty graph', () => {
      g.clear();
      expect(g.anchorCount).toBe(0);
    });
  });

  /* ── anchors iteration ── */

  describe('anchors', () => {
    it('iterates all anchors as [id, pos] entries', () => {
      const all = [...g.anchors()];
      expect(all).toHaveLength(2);
      expect(all[0][0]).toBe('pt1');
      expect(all[0][1]).toEqual({ x: 50, y: 50 });
    });

    it('is empty after clear', () => {
      g.clear();
      expect([...g.anchors()]).toEqual([]);
    });
  });

  /* ── blastRadius edge cases ── */

  describe('blastRadius — edge cases', () => {
    it('returns empty sets for isolated node', () => {
      g.clear();
      g.addNode('solo', { type: 'host', x: 0, y: 0 });
      const br = g.blastRadius('solo');
      expect(br.isolated.size ?? br.isolated.length).toBe(0);
      expect(br.affected.size ?? br.affected.length).toBe(0);
    });

    it('returns empty for non-existent node', () => {
      const br = g.blastRadius('nonexistent');
      expect(br.isolated.size ?? br.isolated.length).toBe(0);
      expect(br.affected.size ?? br.affected.length).toBe(0);
    });
  });

  /* ── getLinksForAnchor with no links ── */

  describe('getLinksForAnchor — no links touching anchor', () => {
    it('returns empty set for unconnected anchor', () => {
      const links = g.getLinksForAnchor('pt1');
      expect(links.size).toBe(0);
    });

    it('returns links when anchor is an endpoint', () => {
      g.addLink('a-pt1', { type: 'line', from: 'A', to: 'pt1' });
      const links = g.getLinksForAnchor('pt1');
      expect(links.size).toBe(1);
      expect(links.has('a-pt1')).toBe(true);
    });
  });
});
