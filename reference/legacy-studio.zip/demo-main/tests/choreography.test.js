import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Choreography & Phase Logic', () => {
  let topo;

  function buildTopo() {
    topo = new TopologyDesigner({ title: 'Test' });
    topo.reducedMotion = true; // disable animations for predictable tests

    topo.node('A', { type: 'server', x: 100, y: 100, label: 'A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'B' })
        .node('C', { type: 'switch', x: 200, y: 300, label: 'C' })
        .link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' })
        .link('l2', { type: 'tunnel', from: 'B', to: 'C', color: '#65aef9' })
        .act('act1', { label: 'Act One', color: '#01a982' })
        .addStep('step1', {
          act: 'act1', name: 'Step One', goal: 'Show A',
          focus: ['A'],
          phases: [
            { show: ['A'], diff: 'A appears' },
            { show: ['l1'], diff: 'Link appears' },
          ],
        })
        .addStep('step2', {
          act: 'act1', name: 'Step Two', goal: 'Show B and C',
          focus: ['B', 'C'],
          phases: [
            { show: ['B'], diff: 'B appears' },
            { show: ['C', 'l2'], diff: 'C and link appear' },
          ],
        });
    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildTopo();
  });

  describe('_vis (visibility check)', () => {
    it('returns false when step is before the element step', () => {
      topo.step = 0;
      expect(topo._vis('step1')).toBe(false);
      expect(topo._vis('step2')).toBe(false);
    });

    it('returns true when step is at the element step', () => {
      topo.step = 1;
      expect(topo._vis('step1')).toBe(true);
    });

    it('returns true when step is past the element step', () => {
      topo.step = 2;
      expect(topo._vis('step1')).toBe(true);
      expect(topo._vis('step2')).toBe(true);
    });
  });

  describe('_ph (phase state)', () => {
    it('returns show:false when step is before', () => {
      topo.step = 0;
      const result = topo._ph('step1', 0);
      expect(result.show).toBe(false);
    });

    it('returns show:true, anim:false when step is after (reduced motion)', () => {
      topo.step = 2;
      const result = topo._ph('step1', 0);
      expect(result.show).toBe(true);
      expect(result.anim).toBe(false);
    });

    it('returns show:true, anim:false at current step with reduced motion', () => {
      topo.step = 1;
      const result = topo._ph('step1', 0);
      expect(result.show).toBe(true);
      expect(result.anim).toBe(false); // reduced motion disables animation
    });

    it('returns animation with delay when at current step without reduced motion', () => {
      topo.reducedMotion = false;
      topo.step = 1;
      const result = topo._ph('step1', 1); // second phase
      expect(result.show).toBe(true);
      expect(result.anim).toBe(true);
      expect(result.delay).toBeGreaterThan(0);
    });

    it('computes delay based on phase number and phaseMs', () => {
      topo.reducedMotion = false;
      topo.phaseMs = 600;
      topo.step = 1;
      const phase0 = topo._ph('step1', 0);
      const phase1 = topo._ph('step1', 1);
      expect(phase0.delay).toBe(0);
      expect(phase1.delay).toBeCloseTo(0.6, 1);
    });
  });

  describe('_phAttr (phase attribute string)', () => {
    it('returns null when phase should not show', () => {
      topo.step = 0;
      expect(topo._phAttr('step1', 0, 1)).toBeNull();
    });

    it('returns class string when phase should show', () => {
      topo.step = 2; // past step1
      const attr = topo._phAttr('step1', 0, 1);
      expect(attr).toContain('tds-fade');
      expect(attr).toContain('opacity:1');
    });
  });

  describe('_pw (phase-wrapped group)', () => {
    it('returns empty string when phase should not show', () => {
      topo.step = 0;
      expect(topo._pw('step1', 0, 1, '<rect/>')).toBe('');
    });

    it('wraps SVG in a group when phase should show', () => {
      topo.step = 2;
      const result = topo._pw('step1', 0, 1, '<rect/>');
      expect(result).toContain('<g');
      expect(result).toContain('<rect/>');
      expect(result).toContain('</g>');
    });

    it('adds blur filter for low opacity elements when step > 0', () => {
      topo.step = 2;
      const result = topo._pw('step1', 0, 0.3, '<rect/>');
      expect(result).toContain('filter="url(#tds-dof-blur)"');
    });
  });

  describe('_getFocus', () => {
    it('returns empty set at step 0', () => {
      topo.step = 0;
      expect(topo._getFocus().size).toBe(0);
    });

    it('returns focus set for step 1', () => {
      topo.step = 1;
      const focus = topo._getFocus();
      expect(focus.has('A')).toBe(true);
      expect(focus.size).toBe(1);
    });

    it('returns focus set for step 2', () => {
      topo.step = 2;
      const focus = topo._getFocus();
      expect(focus.has('B')).toBe(true);
      expect(focus.has('C')).toBe(true);
      expect(focus.size).toBe(2);
    });
  });

  describe('_dimFor', () => {
    it('returns 1 at step 0 (no dimming)', () => {
      topo.step = 0;
      expect(topo._dimFor('A')).toBe(1);
    });

    it('returns 1 for focused elements', () => {
      topo.step = 1; // focus: ['A']
      expect(topo._dimFor('A')).toBe(1);
    });

    it('returns 0.35 for non-focused elements', () => {
      topo.step = 1; // focus: ['A']
      expect(topo._dimFor('B')).toBe(0.35);
      expect(topo._dimFor('C')).toBe(0.35);
    });

    it('returns 1 when focus array is empty', () => {
      // Add a step with empty focus
      topo.addStep('step3', {
        act: 'act1', name: 'Step Three', goal: 'All bright',
        focus: [],
        phases: [{ show: ['A', 'B', 'C'] }],
      });
      topo._buildIndex();
      topo.step = 3;
      expect(topo._dimFor('A')).toBe(1);
      expect(topo._dimFor('B')).toBe(1);
    });
  });

  describe('_isFocused', () => {
    it('returns true at step 0 for any element', () => {
      topo.step = 0;
      expect(topo._isFocused('A')).toBe(true);
      expect(topo._isFocused('B')).toBe(true);
    });

    it('returns true for focused element', () => {
      topo.step = 1;
      expect(topo._isFocused('A')).toBe(true);
    });

    it('returns false for non-focused element', () => {
      topo.step = 1;
      expect(topo._isFocused('B')).toBe(false);
    });
  });

  describe('_findShowPhase', () => {
    it('finds the step and phase that first shows an element', () => {
      const result = topo._findShowPhase('A');
      expect(result).toEqual({ stepId: 'step1', phaseNum: 0 });
    });

    it('finds later elements', () => {
      const result = topo._findShowPhase('l1');
      expect(result).toEqual({ stepId: 'step1', phaseNum: 1 });
    });

    it('finds elements in later steps', () => {
      const result = topo._findShowPhase('B');
      expect(result).toEqual({ stepId: 'step2', phaseNum: 0 });
    });

    it('returns null for unknown elements', () => {
      expect(topo._findShowPhase('nonexistent')).toBeNull();
    });
  });

  describe('_pos (position resolution)', () => {
    it('returns node position', () => {
      expect(topo._pos('A')).toEqual({ x: 100, y: 100 });
    });

    it('returns anchor position', () => {
      topo.anchor('mid', { x: 500, y: 350 });
      expect(topo._pos('mid')).toEqual({ x: 500, y: 350 });
    });

    it('returns {0,0} for unknown ids', () => {
      expect(topo._pos('nonexistent')).toEqual({ x: 0, y: 0 });
    });
  });

  describe('navigation', () => {
    // Note: _mounted stays false so render() returns early without DOM access.
    // We test that step values change correctly.

    it('next() advances step', () => {
      topo._buildIndex();
      topo.step = 0;
      topo.next();
      expect(topo.step).toBe(1);
      topo.next();
      expect(topo.step).toBe(2);
    });

    it('next() does not go past total steps', () => {
      topo._buildIndex();
      topo.step = topo._steps.length;
      topo.next();
      expect(topo.step).toBe(topo._steps.length);
    });

    it('prev() goes back a step', () => {
      topo._buildIndex();
      topo.step = 2;
      topo.prev();
      expect(topo.step).toBe(1);
    });

    it('prev() does not go below 0', () => {
      topo._buildIndex();
      topo.step = 0;
      topo.prev();
      expect(topo.step).toBe(0);
    });

    it('goTo() clamps to valid range', () => {
      topo._buildIndex();
      topo.goTo(999);
      expect(topo.step).toBe(topo._steps.length);
      topo.goTo(-5);
      expect(topo.step).toBe(0);
    });

    it('reset() sets step to 0 and stops playing', () => {
      topo._buildIndex();
      topo.step = 2;
      topo.playing = true;
      topo.reset();
      expect(topo.step).toBe(0);
      expect(topo.playing).toBe(false);
    });
  });

  describe('_actFor / _curAct', () => {
    it('returns the act for a given step index', () => {
      topo._buildIndex();
      const act = topo._actFor(0);
      expect(act.id).toBe('act1');
    });

    it('returns current act based on step', () => {
      topo._buildIndex();
      topo.step = 1;
      expect(topo._curAct().id).toBe('act1');
    });

    it('returns null at step 0', () => {
      topo._buildIndex();
      topo.step = 0;
      expect(topo._curAct()).toBeNull();
    });
  });

  describe('per-phase timing (delayMs)', () => {
    it('uses delayMs override when specified', () => {
      topo.addStep('step3', {
        act: 'act1', name: 'Step Three', goal: 'Custom timing',
        focus: [],
        phases: [
          { show: ['A'], diff: 'fast phase', delayMs: 100 },
          { show: ['B'], diff: 'slow phase', delayMs: 2000 },
        ],
      });
      topo._buildIndex();
      topo.reducedMotion = false;
      topo.step = 3;
      expect(topo._ph('step3', 0).delay).toBeCloseTo(0.1, 2);
      expect(topo._ph('step3', 1).delay).toBeCloseTo(2.0, 2);
    });

    it('falls back to phaseNum * phaseMs when delayMs not set', () => {
      topo.reducedMotion = false;
      topo.phaseMs = 600;
      topo.step = 1;
      expect(topo._ph('step1', 0).delay).toBe(0);
      expect(topo._ph('step1', 1).delay).toBeCloseTo(0.6, 1);
    });
  });

  describe('position memoization', () => {
    it('caches positions within a render cycle', () => {
      topo._clearPosCache();
      const p1 = topo._posCached('A');
      const p2 = topo._posCached('A');
      expect(p1).toBe(p2); // same object reference
      expect(p1).toEqual({ x: 100, y: 100 });
    });

    it('clears cache on _clearPosCache', () => {
      const p1 = topo._posCached('A');
      topo._clearPosCache();
      const p2 = topo._posCached('A');
      expect(p1).not.toBe(p2); // different object
      expect(p1).toEqual(p2); // same values
    });
  });

  describe('path helpers', () => {
    it('pathThrough builds M/L path from node IDs', () => {
      topo._clearPosCache();
      const path = topo.pathThrough('A', 'B', 'C');
      expect(path).toBe('M100,100 L300,100 L200,300');
    });

    it('pathThrough returns empty string for no IDs', () => {
      expect(topo.pathThrough()).toBe('');
    });

    it('pathBetween builds a curved path', () => {
      topo._clearPosCache();
      const path = topo.pathBetween('A', 'B');
      expect(path).toContain('M100,100');
      expect(path).toContain('300,100');
      expect(path).toContain('C'); // cubic bezier
    });

    it('pathBetween with cx/cy uses quadratic', () => {
      topo._clearPosCache();
      const path = topo.pathBetween('A', 'B', { cx: 200, cy: 50 });
      expect(path).toBe('M100,100 Q200,50 300,100');
    });
  });

  describe('dimAll', () => {
    it('returns minimum dim across multiple elements', () => {
      topo.step = 1; // focus: ['A'] → A=1, B=0.35, C=0.35
      expect(topo._dimAll('A', 'B')).toBe(0.35);
      expect(topo._dimAll('A')).toBe(1);
      expect(topo._dimAll('B', 'C')).toBe(0.35);
    });

    it('returns 1 when all elements focused or no focus', () => {
      topo.step = 0; // no focus
      expect(topo._dimAll('A', 'B', 'C')).toBe(1);
    });
  });

  describe('showDuring (persistent visibility)', () => {
    it('injects elements into phase.show arrays across step range', () => {
      const t = new TopologyDesigner({ title: 'Test' });
      t.reducedMotion = true;
      t.node('X', { type: 'server', x: 50, y: 50 })
       .node('Y', { type: 'server', x: 150, y: 50 })
       .node('Z', { type: 'server', x: 250, y: 50 })
       .act('a', { label: 'A', color: '#fff' })
       .addStep('s1', { act: 'a', name: 'S1', phases: [{ show: ['X'], diff: 'x' }] })
       .addStep('s2', { act: 'a', name: 'S2', phases: [{ show: ['Y'], diff: 'y' }] })
       .addStep('s3', { act: 'a', name: 'S3', phases: [{ show: ['Z'], diff: 'z' }] })
       .showDuring(['X'], { from: 's1', until: 's3' });
      t._buildIndex();
      // X should be in first phase of s2 and s3 too
      expect(t._steps[1].phases[0].show).toContain('X');
      expect(t._steps[2].phases[0].show).toContain('X');
    });
  });

  describe('declarative phase rendering', () => {
    it('_renderDeclarativePhase returns empty string for plain phases', () => {
      topo._buildIndex();
      topo.step = 1;
      topo._clearPosCache();
      const step = topo._steps[0];
      const result = topo._renderDeclarativePhase(step, 0, step.phases[0]);
      expect(result).toBe('');
    });

    it('_renderDeclarativePhase renders a label', () => {
      topo.addStep('step3', {
        act: 'act1', name: 'Step Three', goal: 'Label test',
        focus: [],
        phases: [
          { show: ['A'], diff: 'label test',
            label: { at: 'A', text: 'Hello', color: '#ff0000', offsetY: 30 } },
        ],
      });
      topo._buildIndex();
      topo.step = 3;
      topo._clearPosCache();
      const step = topo._steps[2];
      const result = topo._renderDeclarativePhase(step, 0, step.phases[0]);
      expect(result).toContain('Hello');
      expect(result).toContain('#ff0000');
    });

    it('_renderDeclarativePhase renders a badge', () => {
      topo.addStep('step3', {
        act: 'act1', name: 'Step Three', goal: 'Badge test',
        focus: [],
        phases: [
          { show: ['A'], diff: 'badge test',
            badge: { at: 'A', text: 'STATUS OK', color: '#05cc93', offsetY: 50 } },
        ],
      });
      topo._buildIndex();
      topo.step = 3;
      topo._clearPosCache();
      const step = topo._steps[2];
      const result = topo._renderDeclarativePhase(step, 0, step.phases[0]);
      expect(result).toContain('STATUS OK');
      expect(result).toContain('#05cc93');
      expect(result).toContain('tds-labelGlass');
    });
  });

  describe('_buildRenderContext', () => {
    it('includes new helpers in context', () => {
      topo._buildIndex();
      topo._clearPosCache();
      const ctx = topo._buildRenderContext(topo._steps[0]);
      expect(typeof ctx.dimAll).toBe('function');
      expect(typeof ctx.pathThrough).toBe('function');
      expect(typeof ctx.pathBetween).toBe('function');
      expect(typeof ctx.pos).toBe('function');
      expect(typeof ctx.vis).toBe('function');
    });
  });
});
