import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/**
 * Helper: create a mounted topo with 3 steps for analytics tests.
 */
function buildMountedTopo() {
  document.body.innerHTML = '<div id="topo-mount"></div>';
  const topo = new TopologyDesigner({ title: 'Analytics Test', viewBox: '0 0 900 600' });
  topo.node('n1', { type: 'router', x: 100, y: 250, label: 'Router' });
  topo.node('n2', { type: 'switch', x: 400, y: 250, label: 'Switch' });
  topo.node('n3', { type: 'host', x: 700, y: 250, label: 'Server' });
  topo.link('l1', { type: 'line', from: 'n1', to: 'n2' });
  topo.link('l2', { type: 'line', from: 'n2', to: 'n3' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show router and switch',
    phases: [{ show: ['n1', 'n2', 'l1'], diff: 'Phase 1' }],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Show server',
    phases: [{ show: ['n3', 'l2'], diff: 'Phase 2' }],
  });
  topo.addStep('s3', {
    act: 'a1', name: 'Step 3', goal: 'All visible',
    phases: [{ show: ['n1', 'n2', 'n3', 'l1', 'l2'], diff: 'Phase 3' }],
  });
  topo._buildIndex();
  topo.mount('topo-mount');
  return topo;
}

/* ══════════════════════════════════════════════════════════════
   AI-ASSISTED AUTHORING — _parseAITopologyDescription
   ══════════════════════════════════════════════════════════════ */
describe('_parseAITopologyDescription', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner();
  });

  it('generates 5 nodes and 6 links for a 3-tier pattern', () => {
    const result = topo._parseAITopologyDescription('Build a 3-tier application');
    // LB + 3 App Servers + DB = 5 nodes
    expect(result.nodes.length).toBe(5);
    // LB -> 3 apps = 3, 3 apps -> DB = 3, total = 6
    expect(result.links.length).toBe(6);
    const types = result.nodes.map(n => n.type);
    expect(types.filter(t => t === 'ec').length).toBe(1);       // Load Balancer
    expect(types.filter(t => t === 'host').length).toBe(3);     // App Servers
    expect(types.filter(t => t === 'database').length).toBe(1); // Database
  });

  it('places LB at top and DB at bottom in 3-tier layout', () => {
    const result = topo._parseAITopologyDescription('3-tier web architecture');
    const lb = result.nodes.find(n => n.label === 'Load Balancer');
    const db = result.nodes.find(n => n.label === 'Database');
    expect(lb.y).toBeLessThan(db.y);
  });

  it('generates hub + 5 spokes for simple hub-and-spoke', () => {
    const result = topo._parseAITopologyDescription('hub-and-spoke network');
    expect(result.nodes.length).toBe(6);
    expect(result.links.length).toBe(5);
    expect(result.nodes[0].type).toBe('router');
    expect(result.nodes[0].label).toBe('Hub Router');
    // Spokes are switches labeled Site 1..5
    const spokes = result.nodes.filter(n => /Site \d/.test(n.label));
    expect(spokes.length).toBe(5);
    expect(spokes.every(s => s.type === 'switch')).toBe(true);
  });

  it('treats "hub spoke" (without dash) as hub-and-spoke', () => {
    const result = topo._parseAITopologyDescription('Build a hub spoke topology');
    expect(result.nodes.length).toBe(6);
    expect(result.links.length).toBe(5);
  });

  it('generates 4 nodes and 6 full-mesh links for mesh', () => {
    const result = topo._parseAITopologyDescription('full mesh network');
    expect(result.nodes.length).toBe(4);
    // C(4,2) = 6 links
    expect(result.links.length).toBe(6);
    expect(result.links.every(l => l.type === 'tunnel')).toBe(true);
    // All nodes are routers
    expect(result.nodes.every(n => n.type === 'router')).toBe(true);
  });

  it('generates 3 nodes for "2 firewalls and a database"', () => {
    const result = topo._parseAITopologyDescription('2 firewalls and a database');
    const firewalls = result.nodes.filter(n => n.type === 'firewall');
    const dbs = result.nodes.filter(n => n.type === 'database');
    expect(firewalls.length).toBe(2);
    expect(dbs.length).toBe(1);
    expect(result.nodes.length).toBe(3);
  });

  it('labels counted nodes with index suffix', () => {
    const result = topo._parseAITopologyDescription('3 servers');
    const servers = result.nodes.filter(n => n.type === 'host');
    expect(servers.length).toBe(3);
    expect(servers[0].label).toBe('Server 1');
    expect(servers[1].label).toBe('Server 2');
    expect(servers[2].label).toBe('Server 3');
  });

  it('creates link for "server connects to database"', () => {
    const result = topo._parseAITopologyDescription('server connects to database');
    const serverNode = result.nodes.find(n => n.type === 'host');
    const dbNode = result.nodes.find(n => n.type === 'database');
    expect(serverNode).toBeDefined();
    expect(dbNode).toBeDefined();
    const explicitLink = result.links.find(
      l => l.from === serverNode.id && l.to === dbNode.id
    );
    expect(explicitLink).toBeDefined();
    expect(explicitLink.type).toBe('line');
  });

  it('falls back to client-server-database for unrecognizable text', () => {
    const result = topo._parseAITopologyDescription('xyzzy plugh nothing');
    expect(result.nodes.length).toBe(3);
    expect(result.links.length).toBe(2);
    const labels = result.nodes.map(n => n.label);
    expect(labels).toContain('Client');
    expect(labels).toContain('Server');
    expect(labels).toContain('Database');
    // Chain links
    expect(result.links[0].from).toBe(result.nodes[0].id);
    expect(result.links[0].to).toBe(result.nodes[1].id);
    expect(result.links[1].from).toBe(result.nodes[1].id);
    expect(result.links[1].to).toBe(result.nodes[2].id);
  });

  it('falls back to client-server-database for empty string', () => {
    const result = topo._parseAITopologyDescription('');
    expect(result.nodes.length).toBe(3);
    expect(result.links.length).toBe(2);
  });

  it('uses tunnel link type for hub-spoke with SD-WAN keyword', () => {
    const result = topo._parseAITopologyDescription('3 hubs and 6 spokes sd-wan');
    const spokeLinks = result.links.filter(l => /spoke/.test(l.to) || /hub/.test(l.from));
    expect(spokeLinks.length).toBeGreaterThan(0);
    // All links to spokes should use tunnel type
    const hubToSpokeLinks = result.links.filter(l => l.type === 'tunnel');
    expect(hubToSpokeLinks.length).toBeGreaterThan(0);
  });

  it('uses ec node type for hubs when SD-WAN keyword is present', () => {
    const result = topo._parseAITopologyDescription('2 hubs 4 spokes sd-wan overlay');
    const hubs = result.nodes.filter(n => /Hub/.test(n.label));
    expect(hubs.every(h => h.type === 'ec')).toBe(true);
    const spokes = result.nodes.filter(n => /Spoke/.test(n.label));
    expect(spokes.every(s => s.type === 'ec')).toBe(true);
  });

  it('creates exactly 3 hubs and 10 spokes for explicit counts', () => {
    const result = topo._parseAITopologyDescription('3 hubs and 10 spokes');
    const hubs = result.nodes.filter(n => /Hub/.test(n.label));
    const spokes = result.nodes.filter(n => /Spoke/.test(n.label));
    expect(hubs.length).toBe(3);
    expect(spokes.length).toBe(10);
    expect(result.nodes.length).toBe(13);
  });

  it('creates hub mesh links between multiple hubs', () => {
    const result = topo._parseAITopologyDescription('3 hubs and 5 spokes');
    // 3 hubs => C(3,2) = 3 hub mesh links
    const meshLinks = result.links.filter(l => l.label === 'Hub Mesh');
    expect(meshLinks.length).toBe(3);
  });

  it('treats star topology same as hub-spoke', () => {
    const result = topo._parseAITopologyDescription('star topology');
    expect(result.nodes.length).toBe(6); // hub + 5 default spokes
    expect(result.links.length).toBe(5);
  });

  it('creates chain links when keywords found but no explicit connections', () => {
    const result = topo._parseAITopologyDescription('a router and a switch and a firewall');
    expect(result.nodes.length).toBe(3);
    // No "connects to" found, so chain links are created
    expect(result.links.length).toBe(2);
    expect(result.links[0].from).toBe(result.nodes[0].id);
    expect(result.links[0].to).toBe(result.nodes[1].id);
  });

  it('assigns unique IDs to all generated nodes', () => {
    const result = topo._parseAITopologyDescription('3-tier web app');
    const ids = result.nodes.map(n => n.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('assigns x/y positions to all nodes', () => {
    const result = topo._parseAITopologyDescription('mesh network');
    for (const node of result.nodes) {
      expect(typeof node.x).toBe('number');
      expect(typeof node.y).toBe('number');
    }
  });

  it('clamps spoke count to maximum 48', () => {
    const result = topo._parseAITopologyDescription('1 hub and 100 spokes');
    const spokes = result.nodes.filter(n => /Spoke/.test(n.label));
    expect(spokes.length).toBe(48);
  });

  it('clamps hub count to maximum 8', () => {
    const result = topo._parseAITopologyDescription('20 hubs and 5 spokes');
    const hubs = result.nodes.filter(n => /Hub/.test(n.label));
    expect(hubs.length).toBe(8);
  });

  it('detects "talks to" as a connection phrase', () => {
    const result = topo._parseAITopologyDescription('firewall talks to router');
    const fw = result.nodes.find(n => n.type === 'firewall');
    const rt = result.nodes.find(n => n.type === 'router');
    expect(fw).toBeDefined();
    expect(rt).toBeDefined();
    const link = result.links.find(l => l.from === fw.id && l.to === rt.id);
    expect(link).toBeDefined();
  });

  it('grid-lays out keyword-detected nodes', () => {
    const result = topo._parseAITopologyDescription('a firewall and a router and a database and a switch');
    expect(result.nodes.length).toBe(4);
    // Each node should have a unique position
    const positions = result.nodes.map(n => `${n.x},${n.y}`);
    expect(new Set(positions).size).toBe(positions.length);
  });
});

/* ══════════════════════════════════════════════════════════════
   AI-ASSISTED AUTHORING — _applyGeneratedTopology
   ══════════════════════════════════════════════════════════════ */
describe('_applyGeneratedTopology', () => {
  let topo;
  beforeEach(() => {
    document.body.innerHTML = '<div id="topo-apply"></div>';
    topo = new TopologyDesigner({ title: 'Apply Test' });
    topo.mount('topo-apply');
  });

  it('adds nodes and links from a generated result', () => {
    const result = {
      nodes: [
        { id: 'r1', type: 'router', label: 'Router 1', x: 100, y: 200 },
        { id: 's1', type: 'switch', label: 'Switch 1', x: 300, y: 200 },
        { id: 'h1', type: 'host', label: 'Host 1', x: 500, y: 200 },
      ],
      links: [
        { from: 'r1', to: 's1', type: 'line', label: '' },
        { from: 's1', to: 'h1', type: 'tunnel', label: 'vpn' },
      ],
    };
    topo._applyGeneratedTopology(result);
    expect(topo._nodes.has('r1')).toBe(true);
    expect(topo._nodes.has('s1')).toBe(true);
    expect(topo._nodes.has('h1')).toBe(true);
    expect(topo._links.has('r1__s1')).toBe(true);
    expect(topo._links.has('s1__h1')).toBe(true);
  });

  it('generates link IDs as from__to', () => {
    const result = {
      nodes: [
        { id: 'a', type: 'router', label: 'A', x: 100, y: 100 },
        { id: 'b', type: 'switch', label: 'B', x: 200, y: 100 },
      ],
      links: [
        { from: 'a', to: 'b', type: 'line', label: '' },
      ],
    };
    topo._applyGeneratedTopology(result);
    expect(topo._links.has('a__b')).toBe(true);
  });

  it('handles duplicate link IDs by appending index suffix', () => {
    const result = {
      nodes: [
        { id: 'x', type: 'router', label: 'X', x: 100, y: 100 },
        { id: 'y', type: 'switch', label: 'Y', x: 300, y: 100 },
      ],
      links: [
        { from: 'x', to: 'y', type: 'line', label: 'first' },
        { from: 'x', to: 'y', type: 'tunnel', label: 'second' },
      ],
    };
    topo._applyGeneratedTopology(result);
    expect(topo._links.has('x__y')).toBe(true);
    // Second link gets index suffix because x__y already exists
    expect(topo._links.has('x__y__1')).toBe(true);
  });

  it('calls render() after applying topology', () => {
    const renderSpy = vi.spyOn(topo, 'render');
    const result = {
      nodes: [{ id: 'p', type: 'host', label: 'P', x: 50, y: 50 }],
      links: [],
    };
    topo._applyGeneratedTopology(result);
    expect(renderSpy).toHaveBeenCalled();
    renderSpy.mockRestore();
  });

  it('no-ops on null input', () => {
    const nodesBefore = topo._nodes.size;
    topo._applyGeneratedTopology(null);
    expect(topo._nodes.size).toBe(nodesBefore);
  });

  it('no-ops on undefined input', () => {
    const nodesBefore = topo._nodes.size;
    topo._applyGeneratedTopology(undefined);
    expect(topo._nodes.size).toBe(nodesBefore);
  });

  it('works end-to-end with _parseAITopologyDescription output', () => {
    const result = topo._parseAITopologyDescription('3-tier web app');
    topo._applyGeneratedTopology(result);
    expect(topo._nodes.size).toBe(result.nodes.length);
    expect(topo._links.size).toBe(result.links.length);
  });
});

/* ══════════════════════════════════════════════════════════════
   AI-ASSISTED AUTHORING — showAIAssist (DOM modal)
   ══════════════════════════════════════════════════════════════ */
describe('showAIAssist', () => {
  let topo;
  beforeEach(() => {
    document.body.innerHTML = '<div id="topo-ai"></div>';
    topo = new TopologyDesigner({ title: 'AI Assist Test' });
    topo.mount('topo-ai');
  });

  afterEach(() => {
    const backdrop = document.querySelector('.tds-ai-backdrop');
    if (backdrop) backdrop.remove();
  });

  it('creates the AI modal backdrop', () => {
    topo.showAIAssist();
    const backdrop = document.querySelector('.tds-ai-backdrop');
    expect(backdrop).not.toBeNull();
  });

  it('toggles the modal off on second call', () => {
    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).not.toBeNull();
    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();
  });

  it('contains a textarea for input', () => {
    topo.showAIAssist();
    const textarea = document.querySelector('.tds-ai-textarea');
    expect(textarea).not.toBeNull();
    expect(textarea.tagName.toLowerCase()).toBe('textarea');
  });

  it('contains chip buttons with predefined prompts', () => {
    topo.showAIAssist();
    const chips = document.querySelectorAll('.tds-ai-chip');
    expect(chips.length).toBe(4);
    const prompts = Array.from(chips).map(c => c.dataset.prompt);
    expect(prompts).toContain('3-tier web app');
    expect(prompts).toContain('hub-and-spoke network');
    expect(prompts).toContain('mesh VPN topology');
    expect(prompts).toContain('microservices architecture');
  });

  it('clicking a chip fills the textarea with its prompt', () => {
    topo.showAIAssist();
    const chip = document.querySelector('.tds-ai-chip');
    const textarea = document.querySelector('.tds-ai-textarea');
    chip.click();
    expect(textarea.value).toBe(chip.dataset.prompt);
  });

  it('generate button calls _parseAITopologyDescription and shows result', () => {
    topo.showAIAssist();
    const textarea = document.querySelector('.tds-ai-textarea');
    textarea.value = 'mesh VPN topology';
    const generateBtn = document.querySelector('.tds-ai-generate');
    generateBtn.click();
    const summary = document.querySelector('.tds-ai-result-summary');
    expect(summary.textContent).toMatch(/Generated \d+ nodes and \d+ links/);
    const resultDiv = document.querySelector('.tds-ai-result');
    expect(resultDiv.classList.contains('visible')).toBe(true);
  });

  it('generate button does nothing when textarea is empty', () => {
    topo.showAIAssist();
    const textarea = document.querySelector('.tds-ai-textarea');
    textarea.value = '';
    const generateBtn = document.querySelector('.tds-ai-generate');
    generateBtn.click();
    const resultDiv = document.querySelector('.tds-ai-result');
    expect(resultDiv.classList.contains('visible')).toBe(false);
  });

  it('apply button adds generated topology and closes modal', () => {
    topo.showAIAssist();
    const textarea = document.querySelector('.tds-ai-textarea');
    textarea.value = 'hub-and-spoke network';
    document.querySelector('.tds-ai-generate').click();

    const nodesBefore = topo._nodes.size;
    document.querySelector('.tds-ai-apply').click();

    expect(topo._nodes.size).toBeGreaterThan(nodesBefore);
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();
  });

  it('apply button does nothing when no result has been generated', () => {
    topo.showAIAssist();
    const nodesBefore = topo._nodes.size;
    document.querySelector('.tds-ai-apply').click();
    expect(topo._nodes.size).toBe(nodesBefore);
  });

  it('clicking outside the modal closes it', () => {
    topo.showAIAssist();
    const backdrop = document.querySelector('.tds-ai-backdrop');
    // Simulate click on backdrop itself (not the modal content)
    backdrop.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();
  });
});

/* ══════════════════════════════════════════════════════════════
   ENGAGEMENT ANALYTICS — _trackAnalytics
   ══════════════════════════════════════════════════════════════ */
describe('_trackAnalytics', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner();
  });

  it('pushes interaction events onto the analytics array', () => {
    topo._trackAnalytics('click', { nodeId: 'n1' });
    topo._trackAnalytics('hover', { nodeId: 'n2' });
    expect(topo._analytics.interactions.length).toBe(2);
    expect(topo._analytics.interactions[0].type).toBe('click');
    expect(topo._analytics.interactions[0].target).toEqual({ nodeId: 'n1' });
    expect(topo._analytics.interactions[1].type).toBe('hover');
  });

  it('records a timestamp on each interaction', () => {
    const before = Date.now();
    topo._trackAnalytics('next', {});
    const after = Date.now();
    const ts = topo._analytics.interactions[0].timestamp;
    expect(ts).toBeGreaterThanOrEqual(before);
    expect(ts).toBeLessThanOrEqual(after);
  });

  it('stores empty object as target when detail is undefined', () => {
    topo._trackAnalytics('next');
    expect(topo._analytics.interactions[0].target).toEqual({});
  });

  it('does nothing when _analytics is null', () => {
    topo._analytics = null;
    expect(() => topo._trackAnalytics('click', { x: 1 })).not.toThrow();
  });
});

/* ══════════════════════════════════════════════════════════════
   ENGAGEMENT ANALYTICS — _trackStepView
   ══════════════════════════════════════════════════════════════ */
describe('_trackStepView', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner();
    topo.node('n1', { type: 'router', x: 100, y: 200 });
    topo.node('n2', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'line', from: 'n1', to: 'n2' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'Step 2', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo.addStep('s3', { act: 'a1', name: 'Step 3', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo._buildIndex();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('initializes step tracking on first view', () => {
    topo._trackStepView('s1');
    expect(topo._analytics.stepViews['s1']).toBeDefined();
    expect(topo._analytics.stepViews['s1'].count).toBe(1);
    expect(topo._analytics.stepViews['s1'].totalMs).toBe(0);
  });

  it('increments count on repeated views of the same step', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo._trackStepView('s1');
    expect(topo._analytics.stepViews['s1'].count).toBe(2);
  });

  it('accumulates dwell time when transitioning between steps', () => {
    const t0 = 1000000;
    vi.spyOn(Date, 'now').mockReturnValue(t0);
    topo._trackStepView('s1');

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 3000);
    topo._trackStepView('s2');

    // s1 was active for 3000ms
    expect(topo._analytics.stepViews['s1'].totalMs).toBe(3000);

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 8000);
    topo._trackStepView('s3');

    // s2 was active for 5000ms
    expect(topo._analytics.stepViews['s2'].totalMs).toBe(5000);
  });

  it('updates completion rate to 1/3 after viewing first step', () => {
    topo._trackStepView('s1');
    expect(topo._analytics.completionRate).toBeCloseTo(1 / 3, 5);
  });

  it('updates completion rate to 2/3 after viewing second step', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    expect(topo._analytics.completionRate).toBeCloseTo(2 / 3, 5);
  });

  it('updates completion rate to 1 after viewing all steps', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo._trackStepView('s3');
    expect(topo._analytics.completionRate).toBe(1);
  });

  it('does nothing for null stepId', () => {
    topo._trackStepView(null);
    expect(Object.keys(topo._analytics.stepViews).length).toBe(0);
  });

  it('does nothing for undefined stepId', () => {
    topo._trackStepView(undefined);
    expect(Object.keys(topo._analytics.stepViews).length).toBe(0);
  });

  it('does nothing for empty string stepId', () => {
    topo._trackStepView('');
    expect(Object.keys(topo._analytics.stepViews).length).toBe(0);
  });

  it('does nothing when _analytics is null', () => {
    topo._analytics = null;
    expect(() => topo._trackStepView('s1')).not.toThrow();
  });

  it('sets _analyticsLastStep to the current step', () => {
    topo._trackStepView('s2');
    expect(topo._analyticsLastStep).toBe('s2');
  });

  it('sets _analyticsStepStart to current time', () => {
    const t0 = 5000000;
    vi.spyOn(Date, 'now').mockReturnValue(t0);
    topo._trackStepView('s1');
    expect(topo._analyticsStepStart).toBe(t0);
  });
});

/* ══════════════════════════════════════════════════════════════
   ENGAGEMENT ANALYTICS — getAnalytics
   ══════════════════════════════════════════════════════════════ */
describe('getAnalytics', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner();
    topo.node('n1', { type: 'router', x: 100, y: 200 });
    topo.node('n2', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'line', from: 'n1', to: 'n2' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'Step 2', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo.addStep('s3', { act: 'a1', name: 'Step 3', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo._buildIndex();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('returns all expected fields', () => {
    const a = topo.getAnalytics();
    expect(a).toHaveProperty('sessionDuration');
    expect(a).toHaveProperty('stepsViewed');
    expect(a).toHaveProperty('totalStepTransitions');
    expect(a).toHaveProperty('completionRate');
    expect(a).toHaveProperty('averageStepDwell');
    expect(a).toHaveProperty('stepBreakdown');
    expect(a).toHaveProperty('interactionLog');
  });

  it('returns sessionDuration as time since startTime', () => {
    const startTime = topo._analytics.startTime;
    const a = topo.getAnalytics();
    expect(a.sessionDuration).toBeGreaterThanOrEqual(0);
    // sessionDuration = now - startTime, should be small during tests
    expect(a.sessionDuration).toBeLessThan(5000);
  });

  it('counts unique steps viewed', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo._trackStepView('s1'); // revisit
    const a = topo.getAnalytics();
    expect(a.stepsViewed).toBe(2);
  });

  it('counts only next/prev as step transitions', () => {
    topo._trackAnalytics('next', {});
    topo._trackAnalytics('prev', {});
    topo._trackAnalytics('click', { nodeId: 'n1' });
    topo._trackAnalytics('hover', {});
    const a = topo.getAnalytics();
    expect(a.totalStepTransitions).toBe(2);
  });

  it('calculates correct average step dwell', () => {
    const t0 = 1000000;
    vi.spyOn(Date, 'now').mockReturnValue(t0);
    topo._trackStepView('s1');

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 6000);
    topo._trackStepView('s2');

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 10000);
    // s1: 6000ms, s2: will be closed out by getAnalytics at t0+10000, so 4000ms
    const a = topo.getAnalytics();
    // avg = (6000 + 4000) / 2 = 5000
    expect(a.averageStepDwell).toBe(5000);
  });

  it('returns 0 for averageStepDwell when no steps viewed', () => {
    const a = topo.getAnalytics();
    expect(a.averageStepDwell).toBe(0);
  });

  it('returns copies of stepBreakdown and interactionLog', () => {
    topo._trackStepView('s1');
    topo._trackAnalytics('click', {});
    const a1 = topo.getAnalytics();
    const a2 = topo.getAnalytics();
    expect(a1.stepBreakdown).not.toBe(a2.stepBreakdown);
    expect(a1.interactionLog).not.toBe(a2.interactionLog);
  });

  it('returns completionRate matching what _trackStepView set', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    const a = topo.getAnalytics();
    expect(a.completionRate).toBeCloseTo(2 / 3, 5);
  });

  it('returns empty metrics when no activity has occurred', () => {
    const a = topo.getAnalytics();
    expect(a.stepsViewed).toBe(0);
    expect(a.totalStepTransitions).toBe(0);
    expect(a.averageStepDwell).toBe(0);
    expect(a.completionRate).toBe(0);
    expect(a.interactionLog).toEqual([]);
    expect(a.stepBreakdown).toEqual({});
  });

  it('closes out current step dwell on getAnalytics call', () => {
    const t0 = 2000000;
    vi.spyOn(Date, 'now').mockReturnValue(t0);
    topo._trackStepView('s1');

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 7000);
    const a = topo.getAnalytics();
    // s1 should have 7000ms of accumulated dwell
    expect(a.stepBreakdown['s1'].totalMs).toBe(7000);
  });

  it('resets _analyticsStepStart after closing out dwell', () => {
    const t0 = 3000000;
    vi.spyOn(Date, 'now').mockReturnValue(t0);
    topo._trackStepView('s1');

    vi.spyOn(Date, 'now').mockReturnValue(t0 + 2000);
    topo.getAnalytics();
    // _analyticsStepStart should be reset to the "now" at time of getAnalytics call
    expect(topo._analyticsStepStart).toBe(t0 + 2000);
  });
});

/* ══════════════════════════════════════════════════════════════
   ENGAGEMENT ANALYTICS — showAnalyticsDashboard (DOM modal)
   ══════════════════════════════════════════════════════════════ */
describe('showAnalyticsDashboard', () => {
  let topo;
  beforeEach(() => {
    document.body.innerHTML = '<div id="topo-dash"></div>';
    topo = new TopologyDesigner({ title: 'Dashboard Test' });
    topo.node('n1', { type: 'router', x: 100, y: 200 });
    topo.node('n2', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'line', from: 'n1', to: 'n2' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'Step 2', goal: '', phases: [{ show: ['n1', 'n2', 'l1'], diff: '' }] });
    topo._buildIndex();
    topo.mount('topo-dash');
  });

  afterEach(() => {
    const backdrop = document.querySelector('.tds-analytics-backdrop');
    if (backdrop) backdrop.remove();
  });

  it('creates a .tds-analytics-backdrop modal', () => {
    topo.showAnalyticsDashboard();
    const backdrop = document.querySelector('.tds-analytics-backdrop');
    expect(backdrop).not.toBeNull();
  });

  it('appends the modal to document.body', () => {
    topo.showAnalyticsDashboard();
    const backdrop = document.querySelector('.tds-analytics-backdrop');
    expect(backdrop.parentElement).toBe(document.body);
  });

  it('displays session duration in the modal', () => {
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    expect(modal.textContent).toContain('Session Duration');
  });

  it('displays completion percentage', () => {
    topo._trackStepView('s1');
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    expect(modal.textContent).toContain('Completion');
    expect(modal.textContent).toMatch(/\d+%/);
  });

  it('displays steps viewed count', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    expect(modal.textContent).toContain('Steps Viewed');
    expect(modal.textContent).toContain('2 / 2');
  });

  it('displays step transitions count', () => {
    topo._trackAnalytics('next', {});
    topo._trackAnalytics('next', {});
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    expect(modal.textContent).toContain('Step Transitions');
  });

  it('displays average step dwell', () => {
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    expect(modal.textContent).toContain('Avg Step Dwell');
  });

  it('renders chart bars when step views exist', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo.showAnalyticsDashboard();
    const bars = document.querySelectorAll('.tds-analytics-chart-bar');
    expect(bars.length).toBe(2);
  });

  it('does not render chart section when no steps viewed', () => {
    topo.showAnalyticsDashboard();
    const chart = document.querySelector('.tds-analytics-chart');
    expect(chart).toBeNull();
  });

  it('closes when clicking the backdrop', () => {
    topo.showAnalyticsDashboard();
    const backdrop = document.querySelector('.tds-analytics-backdrop');
    backdrop.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    expect(document.querySelector('.tds-analytics-backdrop')).toBeNull();
  });

  it('does not close when clicking inside the modal', () => {
    topo.showAnalyticsDashboard();
    const modal = document.querySelector('.tds-analytics-modal');
    modal.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    // Backdrop should still exist since click target was not the backdrop
    expect(document.querySelector('.tds-analytics-backdrop')).not.toBeNull();
  });

  it('renders chart labels for each step', () => {
    topo._trackStepView('s1');
    topo._trackStepView('s2');
    topo.showAnalyticsDashboard();
    const labels = document.querySelectorAll('.tds-analytics-chart-label');
    expect(labels.length).toBe(2);
  });

  it('truncates long step IDs in chart labels', () => {
    // Use a step ID longer than 8 characters
    topo._analytics.stepViews['longStepIdHere'] = { count: 1, totalMs: 1000 };
    topo.showAnalyticsDashboard();
    const labels = document.querySelectorAll('.tds-analytics-chart-label');
    const longLabel = Array.from(labels).find(l => l.textContent.includes('..'));
    expect(longLabel).toBeDefined();
    // Should be truncated to 8 chars + '..'
    expect(longLabel.textContent.length).toBeLessThanOrEqual(10);
  });
});

/* ══════════════════════════════════════════════════════════════
   INTEGRATION: AI Assist + Analytics together
   ══════════════════════════════════════════════════════════════ */
describe('AI Assist + Analytics integration', () => {
  let topo;
  beforeEach(() => {
    document.body.innerHTML = '<div id="topo-int"></div>';
    topo = new TopologyDesigner({ title: 'Integration Test' });
    topo.mount('topo-int');
  });

  afterEach(() => {
    const aiBackdrop = document.querySelector('.tds-ai-backdrop');
    if (aiBackdrop) aiBackdrop.remove();
    const analyticsBackdrop = document.querySelector('.tds-analytics-backdrop');
    if (analyticsBackdrop) analyticsBackdrop.remove();
  });

  it('generates topology and then shows analytics for it', () => {
    const result = topo._parseAITopologyDescription('3-tier web app');
    topo._applyGeneratedTopology(result);
    expect(topo._nodes.size).toBe(5);
    expect(topo._links.size).toBe(6);
    // Analytics should still work on the topology
    const a = topo.getAnalytics();
    expect(a).toHaveProperty('sessionDuration');
  });

  it('both modals can be opened and closed independently', () => {
    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).not.toBeNull();

    topo.showAnalyticsDashboard();
    expect(document.querySelector('.tds-analytics-backdrop')).not.toBeNull();

    // Both should be present
    expect(document.querySelector('.tds-ai-backdrop')).not.toBeNull();
    expect(document.querySelector('.tds-analytics-backdrop')).not.toBeNull();

    // Close AI modal
    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();
    expect(document.querySelector('.tds-analytics-backdrop')).not.toBeNull();
  });
});
