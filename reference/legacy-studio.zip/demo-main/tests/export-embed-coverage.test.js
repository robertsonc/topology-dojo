/**
 * Export & Embed Coverage Tests
 *
 * Deep coverage for export and embed APIs in topology-ds.js:
 *  - exportSVG()            (line ~5603)
 *  - exportPNG()            (line ~5576)
 *  - exportPDF()            (line ~5617)
 *  - exportStandaloneHTML() (line ~6100)
 *  - copyEmbedCode()        (line ~6147)
 *  - _showExportMenu()      (line ~5541)
 *  - _exportFilename()      (line ~5566)
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ── Helpers ── */

let _cid = 0;

function makeTopo(opts = {}) {
  return new TopologyDesigner({
    title: opts.title || 'Export Test',
    viewBox: opts.viewBox || '0 0 1050 700',
    ...opts,
  });
}

function makeFullTopo(opts = {}) {
  const topo = makeTopo(opts);
  topo.node('A', { type: 'router', x: 100, y: 100, label: 'Router A' });
  topo.node('B', { type: 'switch', x: 400, y: 100, label: 'Switch B' });
  topo.node('C', { type: 'host', x: 700, y: 100, label: 'Host C' });
  topo.link('ab', { type: 'line', from: 'A', to: 'B', color: '#01a982' });
  topo.link('bc', { type: 'line', from: 'B', to: 'C', color: '#ff6600' });
  topo.act('a1', { label: 'Act 1' });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show A and B',
    focus: [],
    phases: [{ show: ['A', 'B', 'ab'], diff: 'A-B visible' }],
  });
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Show C',
    focus: [],
    phases: [{ show: ['C', 'bc'], diff: 'C visible' }],
  });
  topo._buildIndex();
  return topo;
}

function mountTopo(topo) {
  const id = `tds-export-test-${++_cid}`;
  const container = document.createElement('div');
  container.id = id;
  document.body.appendChild(container);
  topo.mount(id);
  return container;
}

/* ══════════════════════════════════════════
   1. _exportFilename
   ══════════════════════════════════════════ */

describe('_exportFilename', () => {
  it('returns title with extension when at step 0', () => {
    const topo = makeTopo({ title: 'NetworkDiagram' });
    expect(topo._exportFilename('svg')).toBe('NetworkDiagram.svg');
    expect(topo._exportFilename('png')).toBe('NetworkDiagram.png');
    expect(topo._exportFilename('pdf')).toBe('NetworkDiagram.pdf');
  });

  it('sanitizes special characters in title', () => {
    const topo = makeTopo({ title: 'My Net/Work & Design! @2024' });
    const filename = topo._exportFilename('svg');
    // All non-alphanumeric/underscore/hyphen chars become underscores
    expect(filename).toBe('My_Net_Work___Design___2024.svg');
    expect(filename).not.toMatch(/[^a-zA-Z0-9_.\-]/);
  });

  it('includes step number and name when on a step', () => {
    const topo = makeTopo({ title: 'Test' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'Init', goal: 'Start',
      focus: [], phases: [],
    });
    topo.addStep('s2', {
      act: 'a1', name: 'Deploy', goal: 'Deploy',
      focus: [], phases: [],
    });
    topo._buildIndex();
    topo.step = 2;

    const filename = topo._exportFilename('png');
    expect(filename).toContain('Step_2');
    expect(filename).toContain('Deploy');
    expect(filename).toContain('.png');
  });

  it('sanitizes step name special characters', () => {
    const topo = makeTopo({ title: 'Test' });
    topo.act('a1', { label: 'Act' });
    topo.addStep('s1', {
      act: 'a1', name: 'Deploy & Configure!', goal: 'Goal',
      focus: [], phases: [],
    });
    topo._buildIndex();
    topo.step = 1;

    const filename = topo._exportFilename('svg');
    expect(filename).toContain('Deploy___Configure_');
    expect(filename).not.toMatch(/[&!]/);
  });

  it('handles step with empty name', () => {
    const topo = makeTopo({ title: 'Test' });
    topo.act('a1', { label: 'Act' });
    topo.addStep('s1', {
      act: 'a1', name: '', goal: 'Goal',
      focus: [], phases: [],
    });
    topo._buildIndex();
    topo.step = 1;

    const filename = topo._exportFilename('svg');
    expect(filename).toContain('Step_1_');
    expect(filename).toContain('.svg');
  });

  it('handles step with no name property', () => {
    const topo = makeTopo({ title: 'Test' });
    topo.act('a1', { label: 'Act' });
    topo.addStep('s1', {
      act: 'a1', goal: 'Goal',
      focus: [], phases: [],
    });
    topo._buildIndex();
    topo.step = 1;

    const filename = topo._exportFilename('pdf');
    expect(filename).toBe('Test_Step_1_.pdf');
  });

  it('uses different extensions correctly', () => {
    const topo = makeTopo({ title: 'Doc' });
    expect(topo._exportFilename('html')).toBe('Doc.html');
    expect(topo._exportFilename('json')).toBe('Doc.json');
  });
});

/* ══════════════════════════════════════════
   2. exportSVG
   ══════════════════════════════════════════ */

describe('exportSVG', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    const menu = document.getElementById('tds-export-menu');
    if (menu) menu.remove();
  });

  it('returns early without error when no tds-diagram in DOM', () => {
    const topo = makeTopo();
    expect(() => topo.exportSVG()).not.toThrow();
  });

  it('creates a blob with SVG MIME type and triggers download', () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const clickSpy = vi.fn();
    let capturedDownload = '';
    let capturedHref = '';
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return {
          _href: '',
          set href(v) { capturedHref = v; this._href = v; },
          get href() { return this._href; },
          set download(v) { capturedDownload = v; },
          get download() { return capturedDownload; },
          click: clickSpy,
        };
      }
      return origCreateElement(tag);
    });

    const createSpy = vi.fn(() => 'blob:svg-test-url');
    const revokeSpy = vi.fn();
    global.URL.createObjectURL = createSpy;
    global.URL.revokeObjectURL = revokeSpy;

    topo.exportSVG();

    expect(createSpy).toHaveBeenCalledOnce();
    const blob = createSpy.mock.calls[0][0];
    expect(blob).toBeInstanceOf(Blob);
    expect(blob.type).toBe('image/svg+xml;charset=utf-8');

    expect(clickSpy).toHaveBeenCalledOnce();
    expect(capturedDownload).toContain('.svg');
    expect(revokeSpy).toHaveBeenCalledWith('blob:svg-test-url');

    container.remove();
  });

  it('includes viewBox dimensions and SVG namespace in the exported content', () => {
    const topo = makeFullTopo({ viewBox: '0 0 800 500' });
    const container = mountTopo(topo);

    let capturedBlob = null;
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:x'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn((b) => { capturedBlob = b; return 'blob:x'; });
    global.URL.revokeObjectURL = vi.fn();

    topo.exportSVG();

    expect(capturedBlob).not.toBeNull();
    expect(capturedBlob.size).toBeGreaterThan(0);

    container.remove();
  });

  it('uses _exportFilename to set the download attribute', () => {
    const topo = makeFullTopo({ title: 'MyDiagram' });
    const container = mountTopo(topo);
    topo.step = 0; // reset to step 0 so filename has no step suffix

    let downloadName = '';
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return {
          set href(v) {},
          get href() { return 'blob:x'; },
          set download(v) { downloadName = v; },
          get download() { return downloadName; },
          click: vi.fn(),
        };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn(() => 'blob:x');
    global.URL.revokeObjectURL = vi.fn();

    topo.exportSVG();

    expect(downloadName).toBe('MyDiagram.svg');

    container.remove();
  });
});

/* ══════════════════════════════════════════
   3. exportPNG
   ══════════════════════════════════════════ */

describe('exportPNG', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('returns early without error when no tds-diagram in DOM', async () => {
    const topo = makeTopo();
    // exportPNG returns undefined when no SVG element is found
    const result = await topo.exportPNG();
    expect(result).toBeUndefined();
  });

  it('creates a canvas with correct dimensions based on viewBox', async () => {
    const topo = makeFullTopo({ viewBox: '0 0 1050 700' });
    const container = mountTopo(topo);

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    let canvasWidth = 0;
    let canvasHeight = 0;
    const mockCtx = {
      fillStyle: '',
      fillRect: vi.fn(),
      drawImage: vi.fn(),
    };
    const mockCanvas = document.createElement('canvas');
    // Intercept width/height assignment
    const origWidthDesc = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, 'width');
    const origHeightDesc = Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype, 'height');

    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(new Blob(['png-data'], { type: 'image/png' })));

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') {
        canvasWidth = 2400;
        canvasHeight = Math.round(2400 * 700 / 1050);
        return mockCanvas;
      }
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });

    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onload) this.onload(); }
      get src() { return ''; }
    };

    global.URL.createObjectURL = vi.fn(() => 'blob:png-url');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportPNG();

    // Expected: w=2400, h=round(2400*700/1050)=1600
    expect(canvasWidth).toBe(2400);
    expect(canvasHeight).toBe(1600);
    expect(mockCtx.fillRect).toHaveBeenCalled();
    expect(mockCtx.drawImage).toHaveBeenCalled();
    expect(mockCanvas.toBlob).toHaveBeenCalled();

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });

  it('fills the canvas background with dark theme color', async () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    const mockCtx = {
      fillStyle: '',
      fillRect: vi.fn(),
      drawImage: vi.fn(),
    };
    const mockCanvas = document.createElement('canvas');
    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(new Blob(['test'], { type: 'image/png' })));

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') return mockCanvas;
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });

    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onload) this.onload(); }
      get src() { return ''; }
    };

    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportPNG();

    // Should set dark background color
    expect(mockCtx.fillStyle).toBe('#1d1f27');

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });

  it('triggers download with correct PNG filename', async () => {
    const topo = makeFullTopo({ title: 'PNGExport' });
    const container = mountTopo(topo);
    topo.step = 0; // reset to step 0 so filename has no step suffix

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    const mockCtx = {
      fillStyle: '',
      fillRect: vi.fn(),
      drawImage: vi.fn(),
    };
    const mockCanvas = document.createElement('canvas');
    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(new Blob(['test'], { type: 'image/png' })));

    let downloadName = '';
    const clickSpy = vi.fn();
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') return mockCanvas;
      if (tag === 'a') {
        return {
          set href(v) {},
          get href() { return 'blob:test'; },
          set download(v) { downloadName = v; },
          get download() { return downloadName; },
          click: clickSpy,
        };
      }
      return origCreateElement(tag);
    });

    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onload) this.onload(); }
      get src() { return ''; }
    };

    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportPNG();

    expect(downloadName).toBe('PNGExport.png');
    expect(clickSpy).toHaveBeenCalledOnce();

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });

  it('revokes the image object URL after loading', async () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    const mockCtx = { fillStyle: '', fillRect: vi.fn(), drawImage: vi.fn() };
    const mockCanvas = document.createElement('canvas');
    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(new Blob(['x'], { type: 'image/png' })));

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') return mockCanvas;
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });

    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onload) this.onload(); }
      get src() { return ''; }
    };

    const revokeSpy = vi.fn();
    global.URL.createObjectURL = vi.fn(() => 'blob:img-url');
    global.URL.revokeObjectURL = revokeSpy;

    await topo.exportPNG();

    // Should revoke both the SVG image URL and the PNG download URL
    expect(revokeSpy).toHaveBeenCalled();
    expect(revokeSpy.mock.calls.length).toBeGreaterThanOrEqual(2);

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });

  it('handles null blob from toBlob gracefully', async () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    const mockCtx = { fillStyle: '', fillRect: vi.fn(), drawImage: vi.fn() };
    const mockCanvas = document.createElement('canvas');
    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(null)); // null blob

    const clickSpy = vi.fn();
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') return mockCanvas;
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: clickSpy };
      }
      return origCreateElement(tag);
    });

    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onload) this.onload(); }
      get src() { return ''; }
    };

    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportPNG();

    // When blob is null, no download should trigger
    expect(clickSpy).not.toHaveBeenCalled();

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });

  it('handles image load error gracefully', async () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const originalXMLSerializer = global.XMLSerializer;
    global.XMLSerializer = class {
      serializeToString() { return '<svg></svg>'; }
    };

    const mockCtx = { fillStyle: '', fillRect: vi.fn(), drawImage: vi.fn() };
    const mockCanvas = document.createElement('canvas');
    vi.spyOn(mockCanvas, 'getContext').mockReturnValue(mockCtx);
    mockCanvas.toBlob = vi.fn((cb) => cb(new Blob(['test'], { type: 'image/png' })));

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'canvas') return mockCanvas;
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });

    // Image fires onerror instead of onload
    const origImage = global.Image;
    global.Image = class {
      set src(v) { if (this.onerror) this.onerror(new Error('load failed')); }
      get src() { return ''; }
    };

    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    // Should resolve without throwing even on image error
    await expect(topo.exportPNG()).resolves.not.toThrow();

    global.XMLSerializer = originalXMLSerializer;
    global.Image = origImage;
    container.remove();
  });
});

/* ══════════════════════════════════════════
   4. exportPDF
   ══════════════════════════════════════════ */

describe('exportPDF', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('returns early without error when no tds-diagram in DOM', () => {
    const topo = makeTopo();
    expect(() => topo.exportPDF()).not.toThrow();
  });

  it('opens a new window and writes SVG HTML for printing', () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const mockWin = {
      document: {
        write: vi.fn(),
        close: vi.fn(),
      },
      focus: vi.fn(),
      print: vi.fn(),
    };
    vi.spyOn(window, 'open').mockReturnValue(mockWin);

    topo.exportPDF();

    expect(window.open).toHaveBeenCalledWith('', '_blank');
    expect(mockWin.document.write).toHaveBeenCalledOnce();

    const htmlContent = mockWin.document.write.mock.calls[0][0];
    expect(htmlContent).toContain('<!DOCTYPE html>');
    expect(htmlContent).toContain('<svg');
    expect(htmlContent).toContain('@page');
    expect(htmlContent).toContain('size: landscape');
    expect(htmlContent).toContain('@media print');

    expect(mockWin.document.close).toHaveBeenCalledOnce();

    container.remove();
  });

  it('includes the export filename in the title element', () => {
    const topo = makeFullTopo({ title: 'PDFTest' });
    const container = mountTopo(topo);
    topo.step = 0; // reset to step 0 so filename has no step suffix

    const mockWin = {
      document: { write: vi.fn(), close: vi.fn() },
      print: vi.fn(),
    };
    vi.spyOn(window, 'open').mockReturnValue(mockWin);

    topo.exportPDF();

    const htmlContent = mockWin.document.write.mock.calls[0][0];
    expect(htmlContent).toContain('<title>PDFTest.pdf</title>');

    container.remove();
  });

  it('falls back to iframe when window.open returns null', () => {
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    vi.spyOn(window, 'open').mockReturnValue(null);

    // Should not throw when falling back to iframe
    expect(() => topo.exportPDF()).not.toThrow();

    // An iframe should have been appended to the document body
    const iframes = document.querySelectorAll('iframe');
    expect(iframes.length).toBeGreaterThan(0);

    // Clean up iframes
    iframes.forEach(f => f.remove());
    container.remove();
  });

  it('includes SVG content with correct dimensions from viewBox', () => {
    const topo = makeFullTopo({ viewBox: '0 0 800 500' });
    const container = mountTopo(topo);

    const mockWin = {
      document: { write: vi.fn(), close: vi.fn() },
      print: vi.fn(),
    };
    vi.spyOn(window, 'open').mockReturnValue(mockWin);

    topo.exportPDF();

    const htmlContent = mockWin.document.write.mock.calls[0][0];
    expect(htmlContent).toContain('width="800"');
    expect(htmlContent).toContain('height="500"');
    expect(htmlContent).toContain('viewBox="0 0 800 500"');

    container.remove();
  });

  it('triggers print after a timeout', () => {
    vi.useFakeTimers();
    const topo = makeFullTopo();
    const container = mountTopo(topo);

    const mockWin = {
      document: { write: vi.fn(), close: vi.fn() },
      print: vi.fn(),
    };
    vi.spyOn(window, 'open').mockReturnValue(mockWin);

    topo.exportPDF();

    expect(mockWin.print).not.toHaveBeenCalled();
    vi.advanceTimersByTime(500);
    expect(mockWin.print).toHaveBeenCalledOnce();

    vi.useRealTimers();
    container.remove();
  });
});

/* ══════════════════════════════════════════
   5. exportStandaloneHTML
   ══════════════════════════════════════════ */

describe('exportStandaloneHTML', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    if (global.fetch && global.fetch.mockRestore) {
      global.fetch.mockRestore();
    }
    delete global.fetch;
  });

  it('fetches both CSS and JS files', async () => {
    const topo = makeFullTopo();

    global.fetch = vi.fn((url) =>
      Promise.resolve({ text: () => Promise.resolve(url.includes('.css') ? '/* CSS */' : '/* JS */') })
    );

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportStandaloneHTML();

    expect(global.fetch).toHaveBeenCalledTimes(2);
    const fetchCalls = global.fetch.mock.calls.map(c => c[0]);
    expect(fetchCalls).toContain('topology-ds.css');
    expect(fetchCalls).toContain('topology-ds.js');
  });

  it('creates a downloadable HTML blob', async () => {
    const topo = makeFullTopo({ title: 'StandaloneTest' });

    global.fetch = vi.fn(() =>
      Promise.resolve({ text: () => Promise.resolve('mock-content') })
    );

    let capturedBlob = null;
    let downloadName = '';
    const clickSpy = vi.fn();
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return {
          set href(v) {},
          get href() { return 'blob:test'; },
          set download(v) { downloadName = v; },
          get download() { return downloadName; },
          click: clickSpy,
        };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn((b) => { capturedBlob = b; return 'blob:standalone'; });
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportStandaloneHTML();

    expect(capturedBlob).not.toBeNull();
    expect(capturedBlob).toBeInstanceOf(Blob);
    expect(capturedBlob.type).toBe('text/html;charset=utf-8');
    expect(clickSpy).toHaveBeenCalledOnce();
    expect(downloadName).toBe('StandaloneTest_standalone.html');
  });

  it('sanitizes title in the download filename', async () => {
    const topo = makeFullTopo({ title: 'My Net! @Work' });

    global.fetch = vi.fn(() =>
      Promise.resolve({ text: () => Promise.resolve('content') })
    );

    let downloadName = '';
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return {
          set href(v) {},
          get href() { return 'blob:test'; },
          set download(v) { downloadName = v; },
          get download() { return downloadName; },
          click: vi.fn(),
        };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn(() => 'blob:test');
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportStandaloneHTML();

    expect(downloadName).toBe('My_Net___Work_standalone.html');
  });

  it('embeds the topology JSON via toJSON()', async () => {
    const topo = makeFullTopo({ title: 'JSONEmbed' });

    let fetchedCSS = '';
    let fetchedJS = '';
    global.fetch = vi.fn((url) => {
      if (url.includes('.css')) {
        return Promise.resolve({ text: () => Promise.resolve('body { color: red; }') });
      }
      return Promise.resolve({ text: () => Promise.resolve('function TopologyDesigner(){}') });
    });

    let blobContent = null;
    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        return { set href(v) {}, get href() { return 'blob:test'; }, set download(v) {}, click: vi.fn() };
      }
      return origCreateElement(tag);
    });
    global.URL.createObjectURL = vi.fn((b) => { blobContent = b; return 'blob:test'; });
    global.URL.revokeObjectURL = vi.fn();

    await topo.exportStandaloneHTML();

    expect(blobContent).not.toBeNull();
    expect(blobContent.size).toBeGreaterThan(0);
  });

  it('revokes object URL after download', async () => {
    const topo = makeFullTopo();

    global.fetch = vi.fn(() =>
      Promise.resolve({ text: () => Promise.resolve('content') })
    );

    const origCreateElement = document.createElement.bind(document);
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      if (tag === 'a') {
        let storedHref = '';
        return {
          set href(v) { storedHref = v; },
          get href() { return storedHref; },
          set download(v) {},
          click: vi.fn(),
        };
      }
      return origCreateElement(tag);
    });
    const revokeSpy = vi.fn();
    global.URL.createObjectURL = vi.fn(() => 'blob:standalone-url');
    global.URL.revokeObjectURL = revokeSpy;

    await topo.exportStandaloneHTML();

    expect(revokeSpy).toHaveBeenCalledWith('blob:standalone-url');
  });

  it('logs error to console when fetch fails', async () => {
    const topo = makeFullTopo();

    global.fetch = vi.fn(() => Promise.reject(new Error('network error')));
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    await topo.exportStandaloneHTML();

    expect(errorSpy).toHaveBeenCalled();
    const errorMsg = errorSpy.mock.calls[0][0];
    expect(errorMsg).toContain('Export standalone HTML failed');

    errorSpy.mockRestore();
  });
});

/* ══════════════════════════════════════════
   6. copyEmbedCode
   ══════════════════════════════════════════ */

describe('copyEmbedCode', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    const toasts = document.querySelectorAll('.tds-toast');
    toasts.forEach(t => t.remove());
  });

  it('writes iframe embed code to clipboard', async () => {
    const topo = makeTopo({ title: 'EmbedTest' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    expect(writeTextSpy).toHaveBeenCalledOnce();
    const code = writeTextSpy.mock.calls[0][0];
    expect(code).toContain('<iframe');
    expect(code).toContain('</iframe>');
    expect(code).toContain('EmbedTest_standalone.html');
  });

  it('embed code includes correct iframe attributes', async () => {
    const topo = makeTopo({ title: 'AttrTest' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    const code = writeTextSpy.mock.calls[0][0];
    expect(code).toContain('width="100%"');
    expect(code).toContain('height="600"');
    expect(code).toContain('frameborder="0"');
    expect(code).toContain('loading="lazy"');
    expect(code).toContain('allowfullscreen');
    expect(code).toContain('border-radius:12px');
  });

  it('sanitizes special characters in the filename portion', async () => {
    const topo = makeTopo({ title: 'Net/Work & Stuff!' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    const code = writeTextSpy.mock.calls[0][0];
    expect(code).toContain('Net_Work___Stuff__standalone.html');
    expect(code).not.toContain('/Work');
    expect(code).not.toContain('& Stuff');
  });

  it('includes a helpful comment about replacing the src', async () => {
    const topo = makeTopo({ title: 'Test' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    const code = writeTextSpy.mock.calls[0][0];
    expect(code).toContain('<!-- Replace the src with your hosted URL -->');
  });

  it('shows a toast notification on successful copy', async () => {
    const topo = makeTopo({ title: 'ToastTest' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    await vi.waitFor(() => {
      const toast = document.querySelector('.tds-toast');
      expect(toast).not.toBeNull();
      expect(toast.textContent).toContain('Embed code copied');
      expect(toast.textContent).toContain('src attribute');
    });
  });

  it('toast is removed after timeout', async () => {
    vi.useFakeTimers();
    const topo = makeTopo({ title: 'Test' });
    const writeTextSpy = vi.fn(() => Promise.resolve());
    navigator.clipboard = { writeText: writeTextSpy };

    topo.copyEmbedCode();

    // Wait for the promise to resolve
    await Promise.resolve();
    await Promise.resolve();

    const toast = document.querySelector('.tds-toast');
    expect(toast).not.toBeNull();

    vi.advanceTimersByTime(3000);

    // Toast should be removed after 2500ms
    expect(document.querySelector('.tds-toast')).toBeNull();

    vi.useRealTimers();
  });

  it('handles clipboard write failure gracefully', async () => {
    const topo = makeTopo({ title: 'FailTest' });
    navigator.clipboard = {
      writeText: vi.fn(() => Promise.reject(new Error('clipboard denied'))),
    };
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    topo.copyEmbedCode();

    await vi.waitFor(() => expect(errorSpy).toHaveBeenCalled());

    const errorArgs = errorSpy.mock.calls[0];
    expect(errorArgs[0]).toContain('Copy failed');

    errorSpy.mockRestore();
  });

  it('does not create a toast on clipboard failure', async () => {
    const topo = makeTopo({ title: 'NoToast' });
    navigator.clipboard = {
      writeText: vi.fn(() => Promise.reject(new Error('denied'))),
    };
    vi.spyOn(console, 'error').mockImplementation(() => {});

    topo.copyEmbedCode();

    // Give time for async ops
    await new Promise(r => setTimeout(r, 50));

    const toast = document.querySelector('.tds-toast');
    expect(toast).toBeNull();

    vi.restoreAllMocks();
  });
});

/* ══════════════════════════════════════════
   7. _showExportMenu
   ══════════════════════════════════════════ */

describe('_showExportMenu', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    const menu = document.getElementById('tds-export-menu');
    if (menu) menu.remove();
  });

  it('creates export menu DOM element with correct id', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    const menu = document.getElementById('tds-export-menu');
    expect(menu).not.toBeNull();
    expect(menu.tagName.toLowerCase()).toBe('div');

    btn.remove();
  });

  it('menu contains all six export options', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    const menu = document.getElementById('tds-export-menu');
    const items = menu.querySelectorAll('div');
    const labels = Array.from(items).map(d => d.textContent.trim());

    expect(labels).toContain('Export PNG');
    expect(labels).toContain('Export SVG');
    expect(labels).toContain('Export PDF');
    expect(labels).toContain('Export Standalone HTML');
    expect(labels).toContain('Copy Embed Code');
    expect(labels).toContain('Analytics');

    btn.remove();
  });

  it('menu is appended as child of the button', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    btn.id = 'test-export-btn';
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    const menu = document.getElementById('tds-export-menu');
    expect(menu.parentElement).toBe(btn);

    btn.remove();
  });

  it('sets button position to relative and high z-index', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    expect(btn.style.position).toBe('relative');
    expect(btn.style.zIndex).toBe('9999');

    btn.remove();
  });

  it('stores designer reference on button as _tdsDesigner', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    expect(btn._tdsDesigner).toBe(topo);

    btn.remove();
  });

  it('toggles menu off when called a second time', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);
    expect(document.getElementById('tds-export-menu')).not.toBeNull();

    // Call again to toggle off
    topo._showExportMenu(btn);
    expect(document.getElementById('tds-export-menu')).toBeNull();

    btn.remove();
  });

  it('removes existing menu before creating a new one', () => {
    const topo = makeTopo();
    const btn1 = document.createElement('button');
    const btn2 = document.createElement('button');
    document.body.appendChild(btn1);
    document.body.appendChild(btn2);

    topo._showExportMenu(btn1);
    expect(document.getElementById('tds-export-menu')).not.toBeNull();

    // When calling _showExportMenu and menu already exists, it removes it and returns
    topo._showExportMenu(btn2);
    // The existing menu was removed (toggle behavior)
    // A second call should create a new one
    topo._showExportMenu(btn2);
    const menu = document.getElementById('tds-export-menu');
    expect(menu).not.toBeNull();
    expect(menu.parentElement).toBe(btn2);

    btn1.remove();
    btn2.remove();
  });

  it('menu items have correct inline styles for hover behavior', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    const menu = document.getElementById('tds-export-menu');
    const items = menu.querySelectorAll('div');

    items.forEach(item => {
      expect(item.style.cursor).toBe('pointer');
      expect(item.style.fontSize).toBe('10px');
      expect(item.getAttribute('onmouseover')).toBeTruthy();
      expect(item.getAttribute('onmouseout')).toBeTruthy();
    });

    btn.remove();
  });

  it('menu items have onclick handlers referencing designer methods', () => {
    const topo = makeTopo();
    const btn = document.createElement('button');
    btn.id = 'test-btn';
    document.body.appendChild(btn);

    topo._showExportMenu(btn);

    const menu = document.getElementById('tds-export-menu');
    const items = menu.querySelectorAll('div');
    const onclicks = Array.from(items).map(d => d.getAttribute('onclick'));

    expect(onclicks.some(h => h.includes('exportPNG'))).toBe(true);
    expect(onclicks.some(h => h.includes('exportSVG'))).toBe(true);
    expect(onclicks.some(h => h.includes('exportPDF'))).toBe(true);
    expect(onclicks.some(h => h.includes('exportStandaloneHTML'))).toBe(true);
    expect(onclicks.some(h => h.includes('copyEmbedCode'))).toBe(true);
    expect(onclicks.some(h => h.includes('showAnalyticsDashboard'))).toBe(true);

    btn.remove();
  });

  it('document click listener removes menu when clicking outside', async () => {
    vi.useFakeTimers();
    const topo = makeTopo();
    const btn = document.createElement('button');
    document.body.appendChild(btn);

    topo._showExportMenu(btn);
    expect(document.getElementById('tds-export-menu')).not.toBeNull();

    // Advance past the setTimeout(10) that registers the close listener
    vi.advanceTimersByTime(20);

    // Simulate click outside the menu and button
    const outsideEl = document.createElement('div');
    document.body.appendChild(outsideEl);
    const clickEvent = new MouseEvent('click', { bubbles: true });
    outsideEl.dispatchEvent(clickEvent);

    expect(document.getElementById('tds-export-menu')).toBeNull();

    outsideEl.remove();
    btn.remove();
    vi.useRealTimers();
  });
});
