import { describe, it, expect, beforeEach, afterEach } from 'vitest';

// Mock window.matchMedia for jsdom
window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');
const LayoutEngine = require('../design-system/modules/layout-engine.js');
globalThis.LayoutEngine = LayoutEngine;

function buildLargeTopo(nodeCount) {
  const container = document.createElement('div');
  container.id = 'perf-container';
  document.body.appendChild(container);

  const topo = new TopologyDesigner({
    title: 'Perf Test',
    subtitle: `${nodeCount} nodes`,
    viewBox: '0 0 1200 800',
    mode: 'manual',
  });

  // Add nodes
  for (let i = 0; i < nodeCount; i++) {
    topo.node(`N${i}`, {
      type: 'router',
      x: 100 + (i % 5) * 30,
      y: 100 + Math.floor(i / 5) * 30,
      label: `Node ${i}`,
    });
  }

  // Connect each node to the next, plus cross-links
  for (let i = 0; i < nodeCount - 1; i++) {
    topo.link(`L${i}`, { from: `N${i}`, to: `N${i + 1}` });
  }
  for (let i = 0; i < nodeCount - 3; i += 3) {
    topo.link(`X${i}`, { from: `N${i}`, to: `N${i + 3}` });
  }

  topo.act('a1', { label: 'Act 1', color: '#01a982' });
  topo.addStep('s1', {
    act: 'a1', name: 'Show All', goal: 'Show',
    phases: [{ show: Array.from({ length: nodeCount }, (_, i) => `N${i}`) }],
  });

  topo.mount('perf-container');
  return { topo, container };
}

describe('autoLayout performance with 25+ nodes', () => {
  let topo, container;

  beforeEach(() => {
    const result = buildLargeTopo(25);
    topo = result.topo;
    container = result.container;
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('circular layout completes with 25 nodes and positions change', () => {
    const origPositions = new Map();
    for (const [id, node] of topo._nodes) {
      origPositions.set(id, { x: node.x, y: node.y });
    }

    // animate=false so positions update synchronously
    topo.autoLayout('circular', {}, false);

    let changed = 0;
    for (const [id, node] of topo._nodes) {
      const orig = origPositions.get(id);
      if (orig && (node.x !== orig.x || node.y !== orig.y)) changed++;
    }
    expect(changed).toBeGreaterThan(0);
  });

  it('hierarchical layout completes with 25 nodes and positions change', () => {
    const origPositions = new Map();
    for (const [id, node] of topo._nodes) {
      origPositions.set(id, { x: node.x, y: node.y });
    }

    topo.autoLayout('hierarchical', {}, false);

    let changed = 0;
    for (const [id, node] of topo._nodes) {
      const orig = origPositions.get(id);
      if (orig && (node.x !== orig.x || node.y !== orig.y)) changed++;
    }
    expect(changed).toBeGreaterThan(0);
  });

  it('forceDirected layout completes with 25 nodes', () => {
    expect(() => topo.autoLayout('forceDirected', {}, false)).not.toThrow();
  });

  it('grid layout completes with 25 nodes and positions change', () => {
    const origPositions = new Map();
    for (const [id, node] of topo._nodes) {
      origPositions.set(id, { x: node.x, y: node.y });
    }

    topo.autoLayout('grid', {}, false);

    let changed = 0;
    for (const [id, node] of topo._nodes) {
      const orig = origPositions.get(id);
      if (orig && (node.x !== orig.x || node.y !== orig.y)) changed++;
    }
    expect(changed).toBeGreaterThan(0);
  });

  it('handles 30 nodes without performance issues', () => {
    document.body.innerHTML = '';
    const result = buildLargeTopo(30);
    const largeTopo = result.topo;

    const start = performance.now();
    largeTopo.autoLayout('circular', {}, false);
    const elapsed = performance.now() - start;

    // Should complete in under 5 seconds
    expect(elapsed).toBeLessThan(5000);
  });
});
