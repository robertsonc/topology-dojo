import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

function buildTopoWithZones() {
  const topo = new TopologyDesigner({ title: 'Zone Test', viewBox: '0 0 800 500' });
  topo.node('A', { type: 'router', x: 100, y: 100, label: 'Router A' });
  topo.node('B', { type: 'switch', x: 300, y: 100, label: 'Switch B' });
  topo.node('C', { type: 'server', x: 500, y: 100, label: 'Server C' });

  // Zone spanning A and B
  topo.zone('z1', { label: 'Campus', nodes: ['A', 'B'], color: '#01a982' });
  // Zone spanning C only
  topo.zone('z2', { label: 'DC', sublabel: 'East Region', nodes: ['C'], color: '#ff8300' });

  topo.act('a1', { label: 'Act 1' });
  // Step 1: only A and B visible
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Show campus',
    focus: [],
    phases: [{ show: ['A', 'B'], diff: 'Campus nodes' }],
  });
  // Step 2: C also visible
  topo.addStep('s2', {
    act: 'a1', name: 'Step 2', goal: 'Show DC',
    focus: [],
    phases: [{ show: ['C'], diff: 'DC node' }],
  });
  topo._buildIndex();
  return topo;
}

describe('Zone step-awareness', () => {
  it('renders zone when its nodes are visible in the current step', () => {
    const topo = buildTopoWithZones();
    topo.step = 1; // Step 1: A, B visible
    const svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z1"');
    expect(svg).toContain('Campus');
  });

  it('hides zone when none of its nodes are visible in the current step', () => {
    const topo = buildTopoWithZones();
    topo.step = 1; // Step 1: only A, B visible — C not visible
    const svg = topo._renderSVG();
    expect(svg).not.toContain('data-zone-id="z2"');
  });

  it('shows zone once its nodes become visible in a later step', () => {
    const topo = buildTopoWithZones();
    topo.step = 2; // Step 2: C now visible
    const svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="z2"');
    expect(svg).toContain('DC');
  });

  it('hides zones at step 0 when steps exist and no nodes are visible yet', () => {
    const topo = buildTopoWithZones();
    topo.step = 0; // Before any step — no nodes visible, zones should be hidden
    const svg = topo._renderSVG();
    expect(svg).not.toContain('data-zone-id="z1"');
    expect(svg).not.toContain('data-zone-id="z2"');
  });

  it('shows all zones when step is 0 and no steps are defined', () => {
    const topo = new TopologyDesigner({ title: 'No Steps', viewBox: '0 0 800 500' });
    topo.node('X', { type: 'router', x: 100, y: 100, label: 'X' });
    topo.zone('zx', { label: 'Test Zone', nodes: ['X'] });
    topo._buildIndex();
    topo.step = 0;
    const svg = topo._renderSVG();
    expect(svg).toContain('data-zone-id="zx"');
  });
});

describe('Zone sublabel rendering', () => {
  it('renders sublabel text below the label', () => {
    const topo = buildTopoWithZones();
    topo.step = 2;
    const svg = topo._renderSVG();
    expect(svg).toContain('East Region');
  });

  it('falls back to description when sublabel is not set', () => {
    const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
    topo.node('X', { type: 'router', x: 100, y: 100, label: 'X' });
    topo.zone('zDesc', { label: 'Fallback Zone', description: 'Legacy desc', nodes: ['X'] });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'test',
      focus: [],
      phases: [{ show: ['X'], diff: 'show' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Legacy desc');
  });

  it('prefers sublabel over description when both are set', () => {
    const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
    topo.node('X', { type: 'router', x: 100, y: 100, label: 'X' });
    topo.zone('zBoth', { label: 'Both', sublabel: 'Sub wins', description: 'Desc loses', nodes: ['X'] });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: 'test',
      focus: [],
      phases: [{ show: ['X'], diff: 'show' }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Sub wins');
    expect(svg).not.toContain('Desc loses');
  });
});
