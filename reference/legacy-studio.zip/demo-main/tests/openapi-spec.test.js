// @vitest-environment node
/**
 * Verifies the generated OpenAPI spec is consistent with api/server.js.
 *
 * - Every Express route (except the meta /openapi.json endpoint itself) is
 *   documented via an @openapi JSDoc block so it appears in the generated spec.
 * - The in-repo static `design-system/openapi.json` matches the live spec
 *   built from the annotated source.
 * - Every documented operation has a summary and tags.
 * - Every referenced schema exists in components.schemas.
 */
import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';

// Pre-install headless shim so server.js loads in the Node environment.
if (typeof global.window === 'undefined') {
  global.window = { matchMedia: () => ({ matches: false }) };
}

const swaggerJsdoc = require('swagger-jsdoc');
const definition = require('../api/openapi-definition.js');

const SERVER_PATH = path.join(__dirname, '..', 'api', 'server.js');
const STATIC_SPEC_PATH = path.join(__dirname, '..', 'design-system', 'openapi.json');

const liveSpec = swaggerJsdoc({
  definition,
  apis: [SERVER_PATH],
});

function collectOperations(spec) {
  const ops = [];
  for (const [p, methods] of Object.entries(spec.paths)) {
    for (const [m, op] of Object.entries(methods)) {
      if (['get', 'post', 'put', 'delete', 'patch'].includes(m)) {
        ops.push({ path: p, method: m.toUpperCase(), op });
      }
    }
  }
  return ops;
}

describe('OpenAPI spec consistency', () => {
  it('spec has at least 30 paths and 50 operations', () => {
    const paths = Object.keys(liveSpec.paths);
    const ops = collectOperations(liveSpec);
    expect(paths.length).toBeGreaterThanOrEqual(30);
    expect(ops.length).toBeGreaterThanOrEqual(50);
  });

  it('every documented operation has a summary and tags', () => {
    for (const { path: p, method, op } of collectOperations(liveSpec)) {
      expect(op.summary, `${method} ${p} is missing a summary`).toBeTruthy();
      expect(op.tags && op.tags.length > 0, `${method} ${p} is missing tags`).toBe(true);
    }
  });

  it('every Express route is documented in the spec', () => {
    // Read server.js and extract routes.
    const src = fs.readFileSync(SERVER_PATH, 'utf8');
    const lines = src.split('\n');
    const routes = [];
    for (const line of lines) {
      const m = /^app\.(get|post|put|delete|patch)\(['"`]([^'"`]+)['"`]/.exec(line);
      if (!m) continue;
      const [, method, routePath] = m;
      if (routePath === '/openapi.json') continue; // meta, not in spec
      if (routePath.startsWith('/api-docs')) continue;
      // Convert Express :param to OpenAPI {param}
      const specPath = routePath.replace(/:([A-Za-z]+)/g, (_, name) => `{${name}}`);
      routes.push({ method: method.toUpperCase(), path: specPath });
    }

    expect(routes.length).toBeGreaterThan(40);
    for (const { method, path: p } of routes) {
      const m = method.toLowerCase();
      expect(liveSpec.paths[p], `Spec is missing path ${p}`).toBeDefined();
      expect(liveSpec.paths[p][m], `Spec is missing ${method} ${p}`).toBeDefined();
    }
  });

  it('every $ref points to a defined schema', () => {
    const defined = new Set(Object.keys(liveSpec.components.schemas));
    const params = new Set(Object.keys(liveSpec.components.parameters || {}));
    const json = JSON.stringify(liveSpec);
    const refs = [...json.matchAll(/"\$ref":\s*"#\/components\/(schemas|parameters)\/([^"]+)"/g)];
    expect(refs.length).toBeGreaterThan(0);
    for (const [, kind, name] of refs) {
      if (kind === 'schemas') {
        expect(defined.has(name), `Missing schema: ${name}`).toBe(true);
      } else if (kind === 'parameters') {
        expect(params.has(name), `Missing parameter: ${name}`).toBe(true);
      }
    }
  });

  it('static openapi.json matches the live spec (regenerate with api/generate-spec.js)', () => {
    const staticSpec = JSON.parse(fs.readFileSync(STATIC_SPEC_PATH, 'utf8'));
    // Structural equality on the operation set (not byte-identical, since
    // swagger-jsdoc may reorder tags or reformat whitespace).
    expect(Object.keys(staticSpec.paths).sort()).toEqual(
      Object.keys(liveSpec.paths).sort()
    );
    for (const p of Object.keys(liveSpec.paths)) {
      const liveMethods = Object.keys(liveSpec.paths[p]).filter(m =>
        ['get', 'post', 'put', 'delete', 'patch'].includes(m)
      ).sort();
      const staticMethods = Object.keys(staticSpec.paths[p]).filter(m =>
        ['get', 'post', 'put', 'delete', 'patch'].includes(m)
      ).sort();
      expect(staticMethods, `${p} method mismatch`).toEqual(liveMethods);
    }
    expect(Object.keys(staticSpec.components.schemas).sort()).toEqual(
      Object.keys(liveSpec.components.schemas).sort()
    );
  });

  it('tag declarations cover every tag used on operations', () => {
    const declared = new Set((liveSpec.tags || []).map(t => t.name));
    for (const { path: p, method, op } of collectOperations(liveSpec)) {
      for (const tag of op.tags || []) {
        expect(declared.has(tag), `${method} ${p} uses undeclared tag "${tag}"`).toBe(true);
      }
    }
  });

  it('domain schemas exist for every Layer/FlowPath/PolicyMarker route', () => {
    const required = ['Layer', 'FlowPath', 'PolicyMarker', 'DeleteResult', 'HealthStatus'];
    for (const name of required) {
      expect(liveSpec.components.schemas[name], `Missing schema: ${name}`).toBeDefined();
    }
  });

  it('layer routes reference the Layer schema', () => {
    const get = liveSpec.paths['/api/topologies/{topologyId}/layers'].get;
    const put = liveSpec.paths['/api/topologies/{topologyId}/layers/{layerId}'].put;
    const del = liveSpec.paths['/api/topologies/{topologyId}/layers/{layerId}'].delete;
    expect(JSON.stringify(get.responses['200'])).toContain('Layer');
    expect(JSON.stringify(put.requestBody)).toContain('Layer');
    expect(JSON.stringify(put.responses['200'])).toContain('Layer');
    expect(JSON.stringify(del.responses['200'])).toContain('DeleteResult');
  });

  it('flow-path routes reference the FlowPath schema', () => {
    const get = liveSpec.paths['/api/topologies/{topologyId}/flow-paths'].get;
    const put = liveSpec.paths['/api/topologies/{topologyId}/flow-paths/{flowPathId}'].put;
    const del = liveSpec.paths['/api/topologies/{topologyId}/flow-paths/{flowPathId}'].delete;
    expect(JSON.stringify(get.responses['200'])).toContain('FlowPath');
    expect(JSON.stringify(put.requestBody)).toContain('FlowPath');
    expect(JSON.stringify(put.responses['200'])).toContain('FlowPath');
    expect(JSON.stringify(del.responses['200'])).toContain('DeleteResult');
  });

  it('policy-marker routes reference the PolicyMarker schema', () => {
    const get = liveSpec.paths['/api/topologies/{topologyId}/policy-markers'].get;
    const put = liveSpec.paths['/api/topologies/{topologyId}/policy-markers/{markerId}'].put;
    const del = liveSpec.paths['/api/topologies/{topologyId}/policy-markers/{markerId}'].delete;
    expect(JSON.stringify(get.responses['200'])).toContain('PolicyMarker');
    expect(JSON.stringify(put.requestBody)).toContain('PolicyMarker');
    expect(JSON.stringify(put.responses['200'])).toContain('PolicyMarker');
    expect(JSON.stringify(del.responses['200'])).toContain('DeleteResult');
  });

  it('act and step PUT operations have response schemas', () => {
    const actPut = liveSpec.paths['/api/topologies/{topologyId}/acts/{actId}'].put;
    const stepPut = liveSpec.paths['/api/topologies/{topologyId}/steps/{stepId}'].put;
    expect(actPut.responses['200'].content).toBeDefined();
    expect(JSON.stringify(actPut.responses['200'])).toContain('ActConfig');
    expect(stepPut.responses['200'].content).toBeDefined();
    expect(JSON.stringify(stepPut.responses['200'])).toContain('StepConfig');
  });

  it('every path that uses topologyId resolves a topology and references the Error schema on 404', () => {
    // Spot-check a representative set of routes that all share the same 404
    // pattern: requireTopology() returns null and writes a 404.
    const samples = [
      ['/api/topologies/{topologyId}/layers', 'get'],
      ['/api/topologies/{topologyId}/flow-paths', 'get'],
      ['/api/topologies/{topologyId}/policy-markers', 'get'],
    ];
    for (const [p, m] of samples) {
      const op = liveSpec.paths[p][m];
      expect(op.responses['404'], `${m.toUpperCase()} ${p} missing 404`).toBeDefined();
      expect(JSON.stringify(op.responses['404'])).toContain('Error');
    }
  });

  it('health endpoint references the HealthStatus schema', () => {
    const get = liveSpec.paths['/api/health'].get;
    expect(JSON.stringify(get.responses['200'])).toContain('HealthStatus');
  });
});
