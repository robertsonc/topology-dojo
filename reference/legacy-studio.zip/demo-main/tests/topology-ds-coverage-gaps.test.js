/**
 * Coverage gap tests for TopologyDesigner — getChildZones, exportPDF,
 * copyEmbedCode, showAnalyticsDashboard, showAIAssist, and _exportFilename.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

/* ── Helpers ── */

let _containerId = 0;

function makeTopo(title = 'Test Topo') {
  const topo = new TopologyDesigner({ title, viewBox: '0 0 1050 700' });
  topo.node('A', { type: 'router', x: 100, y: 100, label: 'Router A' });
  topo.node('B', { type: 'switch', x: 300, y: 100, label: 'Switch B' });
  topo.node('C', { type: 'host', x: 500, y: 100, label: 'Host C' });
  topo.link('ab', { type: 'line', from: 'A', to: 'B' });
  topo.link('bc', { type: 'line', from: 'B', to: 'C' });
  return topo;
}

function mountTopo(topo) {
  const id = `tds-gap-test-${++_containerId}`;
  const container = document.createElement('div');
  container.id = id;
  document.body.appendChild(container);
  topo.mount(id);
  return container;
}

/* ══════════════════════════════════════════
   getChildZones
   ══════════════════════════════════════════ */

describe('getChildZones', () => {
  it('returns child zone IDs for a parent zone', () => {
    const topo = makeTopo();
    topo.zone('parent', { label: 'Campus', nodes: ['A', 'B'] });
    topo.zone('child1', { label: 'Building 1', nodes: ['A'], parentZone: 'parent' });
    topo.zone('child2', { label: 'Building 2', nodes: ['B'], parentZone: 'parent' });
    topo.zone('other', { label: 'DC', nodes: ['C'] });

    const children = topo.getChildZones('parent');
    expect(children).toEqual(['child1', 'child2']);
  });

  it('returns empty array when no children exist', () => {
    const topo = makeTopo();
    topo.zone('z1', { label: 'Solo Zone', nodes: ['A'] });
    expect(topo.getChildZones('z1')).toEqual([]);
  });

  it('returns empty array for non-existent zone', () => {
    const topo = makeTopo();
    expect(topo.getChildZones('missing')).toEqual([]);
  });

  it('handles nested hierarchy', () => {
    const topo = makeTopo();
    topo.zone('root', { label: 'Root', nodes: ['A', 'B', 'C'] });
    topo.zone('mid', { label: 'Middle', nodes: ['A', 'B'], parentZone: 'root' });
    topo.zone('leaf', { label: 'Leaf', nodes: ['A'], parentZone: 'mid' });

    expect(topo.getChildZones('root')).toEqual(['mid']);
    expect(topo.getChildZones('mid')).toEqual(['leaf']);
    expect(topo.getChildZones('leaf')).toEqual([]);
  });
});

/* ══════════════════════════════════════════
   _exportFilename
   ══════════════════════════════════════════ */

describe('_exportFilename', () => {
  it('sanitizes title and appends extension', () => {
    const topo = new TopologyDesigner({ title: 'My Network!', viewBox: '0 0 800 500' });
    expect(topo._exportFilename('svg')).toBe('My_Network_.svg');
  });

  it('includes step name when on a step', () => {
    const topo = makeTopo();
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Init', goal: 'Start', focus: [], phases: [] });
    topo.addStep('s2', { act: 'a1', name: 'Deploy', goal: 'Deploy', focus: [], phases: [] });
    const container = mountTopo(topo);
    topo.goTo(1); // step 2
    const filename = topo._exportFilename('png');
    expect(filename).toContain('Step_');
    expect(filename).toContain('.png');
    container.remove();
  });

  it('does not include step info at step 0', () => {
    const topo = new TopologyDesigner({ title: 'Clean', viewBox: '0 0 800 500' });
    expect(topo._exportFilename('pdf')).toBe('Clean.pdf');
  });
});

/* ══════════════════════════════════════════
   exportPDF
   ══════════════════════════════════════════ */

describe('exportPDF', () => {
  it('does nothing when no SVG element exists', () => {
    const topo = makeTopo();
    // No mount — no SVG in DOM
    expect(() => topo.exportPDF()).not.toThrow();
  });

  it('runs PDF export flow when SVG is present', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    // Verify SVG was created, then exercise exportPDF
    expect(document.getElementById('tds-diagram')).not.toBeNull();
    // In jsdom window.open returns null, triggering iframe fallback
    expect(() => topo.exportPDF()).not.toThrow();

    container.remove();
  });
});

/* ══════════════════════════════════════════
   copyEmbedCode
   ══════════════════════════════════════════ */

describe('copyEmbedCode', () => {
  it('writes embed code to clipboard', async () => {
    const topo = new TopologyDesigner({ title: 'My Topo', viewBox: '0 0 800 500' });
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });

    topo.copyEmbedCode();

    expect(writeText).toHaveBeenCalledOnce();
    const code = writeText.mock.calls[0][0];
    expect(code).toContain('<iframe');
    expect(code).toContain('My_Topo_standalone.html');
  });

  it('sanitizes special characters in the filename portion', async () => {
    const topo = new TopologyDesigner({ title: 'Net/Work & Stuff!', viewBox: '0 0 800 500' });
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });

    topo.copyEmbedCode();

    const code = writeText.mock.calls[0][0];
    // The src attribute filename should have special chars replaced with _
    expect(code).toContain('Net_Work___Stuff__standalone.html');
  });

  it('shows toast after successful copy', async () => {
    const topo = new TopologyDesigner({ title: 'Test', viewBox: '0 0 800 500' });
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.assign(navigator, { clipboard: { writeText } });

    topo.copyEmbedCode();

    // Wait for the promise to resolve and DOM to update
    await vi.waitFor(() => {
      const toast = document.querySelector('.tds-toast');
      expect(toast).not.toBeNull();
      expect(toast.textContent).toContain('Embed code copied');
    });
  });
});

/* ══════════════════════════════════════════
   showAnalyticsDashboard
   ══════════════════════════════════════════ */

describe('showAnalyticsDashboard', () => {
  afterEach(() => {
    document.querySelectorAll('.tds-analytics-backdrop').forEach(el => el.remove());
  });

  it('creates analytics modal in DOM', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAnalyticsDashboard();

    const backdrop = document.querySelector('.tds-analytics-backdrop');
    expect(backdrop).not.toBeNull();
    expect(backdrop.textContent).toContain('Engagement Analytics');
    expect(backdrop.textContent).toContain('Session Duration');
    expect(backdrop.textContent).toContain('Completion');

    container.remove();
  });

  it('displays step count and transition stats', () => {
    const topo = makeTopo();
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: 'G1', focus: [], phases: [] });
    topo.addStep('s2', { act: 'a1', name: 'Step 2', goal: 'G2', focus: [], phases: [] });
    const container = mountTopo(topo);

    topo.showAnalyticsDashboard();

    const backdrop = document.querySelector('.tds-analytics-backdrop');
    expect(backdrop.textContent).toContain('Steps Viewed');
    expect(backdrop.textContent).toContain('Step Transitions');
    expect(backdrop.textContent).toContain('Avg Step Dwell');

    container.remove();
  });

  it('closes when backdrop is clicked', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAnalyticsDashboard();

    const backdrop = document.querySelector('.tds-analytics-backdrop');
    expect(backdrop).not.toBeNull();

    // Simulate click on backdrop itself
    backdrop.dispatchEvent(new Event('click', { bubbles: true }));
    expect(document.querySelector('.tds-analytics-backdrop')).toBeNull();

    container.remove();
  });
});

/* ══════════════════════════════════════════
   showAIAssist
   ══════════════════════════════════════════ */

describe('showAIAssist', () => {
  afterEach(() => {
    document.querySelectorAll('.tds-ai-backdrop').forEach(el => el.remove());
  });

  it('creates AI modal in DOM', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();

    const backdrop = document.querySelector('.tds-ai-backdrop');
    expect(backdrop).not.toBeNull();
    expect(backdrop.textContent).toContain('AI-Assisted Topology Generation');

    const textarea = backdrop.querySelector('.tds-ai-textarea');
    expect(textarea).not.toBeNull();

    const chips = backdrop.querySelectorAll('.tds-ai-chip');
    expect(chips.length).toBe(4);

    container.remove();
  });

  it('toggles off if already open', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).not.toBeNull();

    // Call again — should remove
    topo.showAIAssist();
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();

    container.remove();
  });

  it('fills textarea when chip is clicked', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();

    const chip = document.querySelector('.tds-ai-chip');
    const textarea = document.querySelector('.tds-ai-textarea');
    chip.click();

    expect(textarea.value).toBe(chip.dataset.prompt);

    container.remove();
  });

  it('generates topology when generate button is clicked', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();

    const textarea = document.querySelector('.tds-ai-textarea');
    textarea.value = 'A firewall connects to a server';

    const genBtn = document.querySelector('.tds-ai-generate');
    genBtn.click();

    const summary = document.querySelector('.tds-ai-result-summary');
    expect(summary.textContent).toContain('Generated');
    expect(summary.textContent).toMatch(/\d+ nodes/);

    container.remove();
  });

  it('closes when backdrop is clicked', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();

    const backdrop = document.querySelector('.tds-ai-backdrop');
    backdrop.dispatchEvent(new Event('click', { bubbles: true }));
    expect(document.querySelector('.tds-ai-backdrop')).toBeNull();

    container.remove();
  });

  it('does nothing for generate with empty textarea', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    topo.showAIAssist();

    const resultDiv = document.querySelector('.tds-ai-result');
    const genBtn = document.querySelector('.tds-ai-generate');
    genBtn.click();

    // Result should not be visible
    expect(resultDiv.classList.contains('visible')).toBe(false);

    container.remove();
  });
});

/* ══════════════════════════════════════════
   getAnalytics
   ══════════════════════════════════════════ */

describe('getAnalytics', () => {
  it('returns analytics summary object', () => {
    const topo = makeTopo();
    const container = mountTopo(topo);

    const analytics = topo.getAnalytics();
    expect(analytics).toHaveProperty('sessionDuration');
    expect(analytics).toHaveProperty('stepsViewed');
    expect(analytics).toHaveProperty('totalStepTransitions');
    expect(analytics).toHaveProperty('completionRate');
    expect(analytics).toHaveProperty('averageStepDwell');
    expect(analytics).toHaveProperty('stepBreakdown');
    expect(analytics).toHaveProperty('interactionLog');

    container.remove();
  });

  it('tracks step views correctly', () => {
    const topo = makeTopo();
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'Step 1', goal: 'G1', focus: [], phases: [{ show: ['A'] }] });
    topo.addStep('s2', { act: 'a1', name: 'Step 2', goal: 'G2', focus: [], phases: [{ show: ['B'] }] });
    const container = mountTopo(topo);

    topo.next(); // go to step 1
    topo.next(); // go to step 2

    const analytics = topo.getAnalytics();
    expect(analytics.stepsViewed).toBeGreaterThan(0);

    container.remove();
  });
});
