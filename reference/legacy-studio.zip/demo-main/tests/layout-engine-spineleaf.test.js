/**
 * Tests for LayoutEngine.spineLeaf() — data center spine-leaf layout algorithm.
 *
 * Covers node classification (spine vs leaf), fallback logic, position bounds,
 * visual grouping, and custom options.
 */
import { describe, it, expect } from 'vitest';

const LayoutEngine = require('../design-system/modules/layout-engine.js');

describe('LayoutEngine.spineLeaf', () => {
  it('returns empty map for empty input', () => {
    const result = LayoutEngine.spineLeaf([], []);
    expect(result.size).toBe(0);
  });

  it('classifies high-degree switches/routers as spine nodes', () => {
    const nodes = [
      { id: 'spine1', type: 'switch', x: 0, y: 0 },
      { id: 'spine2', type: 'switch', x: 0, y: 0 },
      { id: 'leaf1', type: 'host', x: 0, y: 0 },
      { id: 'leaf2', type: 'host', x: 0, y: 0 },
      { id: 'leaf3', type: 'host', x: 0, y: 0 },
      { id: 'leaf4', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 'spine1', to: 'leaf1' },
      { from: 'spine1', to: 'leaf2' },
      { from: 'spine1', to: 'leaf3' },
      { from: 'spine2', to: 'leaf2' },
      { from: 'spine2', to: 'leaf3' },
      { from: 'spine2', to: 'leaf4' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links);
    expect(result.size).toBe(6);

    // Spine nodes (high-degree switches) should be in the top row
    const spine1Y = result.get('spine1').y;
    const leaf1Y = result.get('leaf1').y;
    expect(spine1Y).toBeLessThan(leaf1Y);
  });

  it('places spine nodes at spineY and leaves at leafY', () => {
    const nodes = [
      { id: 's1', type: 'router', x: 0, y: 0 },
      { id: 's2', type: 'router', x: 0, y: 0 },
      { id: 'l1', type: 'host', x: 0, y: 0 },
      { id: 'l2', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 's1', to: 'l1' },
      { from: 's1', to: 'l2' },
      { from: 's1', to: 's2' },
      { from: 's2', to: 'l1' },
      { from: 's2', to: 'l2' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links, {
      width: 1000, height: 600, padding: 50,
    });

    // Default spineY=0.25, leafY=0.7
    const expectedSpineY = Math.round(50 + 0.25 * (600 - 2 * 50));
    const expectedLeafY = Math.round(50 + 0.7 * (600 - 2 * 50));

    // Spine nodes at spineY row
    expect(result.get('s1').y).toBe(expectedSpineY);
    expect(result.get('s2').y).toBe(expectedSpineY);

    // Leaf nodes at leafY row
    expect(result.get('l1').y).toBe(expectedLeafY);
    expect(result.get('l2').y).toBe(expectedLeafY);
  });

  it('falls back to degree-based split when no spine types match', () => {
    // All nodes are generic (no SPINE_TYPES), so fallback kicks in
    const nodes = [
      { id: 'A', type: 'ec', x: 0, y: 0 },
      { id: 'B', type: 'ec', x: 0, y: 0 },
      { id: 'C', type: 'ec', x: 0, y: 0 },
      { id: 'D', type: 'ec', x: 0, y: 0 },
    ];
    const links = [
      { from: 'A', to: 'B' },
      { from: 'A', to: 'C' },
      { from: 'A', to: 'D' },
      { from: 'B', to: 'C' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links);
    expect(result.size).toBe(4);

    // All positions should be valid numbers
    for (const [, pos] of result) {
      expect(typeof pos.x).toBe('number');
      expect(typeof pos.y).toBe('number');
      expect(Number.isNaN(pos.x)).toBe(false);
      expect(Number.isNaN(pos.y)).toBe(false);
    }
  });

  it('positions nodes within width/height bounds', () => {
    const nodes = [
      { id: 's1', type: 'switch', x: 0, y: 0 },
      { id: 'l1', type: 'host', x: 0, y: 0 },
      { id: 'l2', type: 'host', x: 0, y: 0 },
      { id: 'l3', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 's1', to: 'l1' },
      { from: 's1', to: 'l2' },
      { from: 's1', to: 'l3' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links, {
      width: 800, height: 500, padding: 60,
    });

    for (const [, pos] of result) {
      expect(pos.x).toBeGreaterThanOrEqual(60);
      expect(pos.x).toBeLessThanOrEqual(800 - 60);
      expect(pos.y).toBeGreaterThanOrEqual(60);
      expect(pos.y).toBeLessThanOrEqual(500 - 60);
    }
  });

  it('handles single node input', () => {
    const result = LayoutEngine.spineLeaf([{ id: 'A', x: 0, y: 0 }], []);
    expect(result.size).toBe(1);
    const pos = result.get('A');
    expect(typeof pos.x).toBe('number');
    expect(typeof pos.y).toBe('number');
  });

  it('accepts Map input for nodes and links', () => {
    const nodeMap = new Map([
      ['s1', { id: 's1', type: 'switch', x: 0, y: 0 }],
      ['l1', { id: 'l1', type: 'host', x: 0, y: 0 }],
      ['l2', { id: 'l2', type: 'host', x: 0, y: 0 }],
      ['l3', { id: 'l3', type: 'host', x: 0, y: 0 }],
    ]);
    const linkMap = new Map([
      ['link1', { from: 's1', to: 'l1' }],
      ['link2', { from: 's1', to: 'l2' }],
      ['link3', { from: 's1', to: 'l3' }],
    ]);
    const result = LayoutEngine.spineLeaf(nodeMap, linkMap);
    expect(result.size).toBe(4);
    expect(result.has('s1')).toBe(true);
    expect(result.has('l1')).toBe(true);
  });

  it('sorts leaf nodes by their connected spine x-position', () => {
    const nodes = [
      { id: 'spL', type: 'switch', x: 0, y: 0 },
      { id: 'spR', type: 'switch', x: 0, y: 0 },
      { id: 'leafA', type: 'host', x: 0, y: 0 },
      { id: 'leafB', type: 'host', x: 0, y: 0 },
    ];
    // spL connected to leafA, spR connected to leafB
    const links = [
      { from: 'spL', to: 'leafA' },
      { from: 'spL', to: 'leafB' },
      { from: 'spL', to: 'spR' },
      { from: 'spR', to: 'leafA' },
      { from: 'spR', to: 'leafB' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links);
    expect(result.size).toBe(4);

    // Spine nodes should be in top row, leaves in bottom
    expect(result.get('spL').y).toBeLessThan(result.get('leafA').y);
  });

  it('respects custom spineY and leafY options', () => {
    const nodes = [
      { id: 's1', type: 'switch', x: 0, y: 0 },
      { id: 'l1', type: 'host', x: 0, y: 0 },
      { id: 'l2', type: 'host', x: 0, y: 0 },
      { id: 'l3', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 's1', to: 'l1' },
      { from: 's1', to: 'l2' },
      { from: 's1', to: 'l3' },
    ];

    const result = LayoutEngine.spineLeaf(nodes, links, {
      spineY: 0.1,
      leafY: 0.9,
      width: 1050,
      height: 700,
      padding: 80,
    });

    const expectedSpineY = Math.round(80 + 0.1 * (700 - 2 * 80));
    const expectedLeafY = Math.round(80 + 0.9 * (700 - 2 * 80));

    expect(result.get('s1').y).toBe(expectedSpineY);
    expect(result.get('l1').y).toBe(expectedLeafY);
  });

  it('treats firewall and switchEnterprise as spine types', () => {
    const nodes = [
      { id: 'fw', type: 'firewall', x: 0, y: 0 },
      { id: 'se', type: 'switchEnterprise', x: 0, y: 0 },
      { id: 'h1', type: 'host', x: 0, y: 0 },
      { id: 'h2', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 'fw', to: 'h1' },
      { from: 'fw', to: 'h2' },
      { from: 'fw', to: 'se' },
      { from: 'se', to: 'h1' },
      { from: 'se', to: 'h2' },
    ];
    const result = LayoutEngine.spineLeaf(nodes, links);
    expect(result.size).toBe(4);

    // Spine types (firewall, switchEnterprise) should be in top row
    const fwY = result.get('fw').y;
    const h1Y = result.get('h1').y;
    expect(fwY).toBeLessThan(h1Y);
  });

  it('handles topology with no links (all nodes become spine via fallback)', () => {
    const nodes = [
      { id: 'A', type: 'switch', x: 0, y: 0 },
      { id: 'B', type: 'host', x: 0, y: 0 },
      { id: 'C', type: 'host', x: 0, y: 0 },
    ];
    const result = LayoutEngine.spineLeaf(nodes, []);
    expect(result.size).toBe(3);

    // With no links and no spine types matching degree threshold,
    // fallback splits by degree (all zero), top 30% become spine
    for (const [, pos] of result) {
      expect(typeof pos.x).toBe('number');
      expect(typeof pos.y).toBe('number');
    }
  });

  it('respects minSpineConnections option', () => {
    const nodes = [
      { id: 's1', type: 'switch', x: 0, y: 0 },
      { id: 'l1', type: 'host', x: 0, y: 0 },
      { id: 'l2', type: 'host', x: 0, y: 0 },
    ];
    const links = [
      { from: 's1', to: 'l1' },
      { from: 's1', to: 'l2' },
    ];

    // With minSpineConnections=5, the switch (degree 2) won't qualify as spine
    // So fallback logic triggers
    const result = LayoutEngine.spineLeaf(nodes, links, { minSpineConnections: 5 });
    expect(result.size).toBe(3);
  });
});
