import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const designSystem = join(root, 'design-system');
const brandDir = join(designSystem, 'assets', 'brand');

function readDesignFile(file) {
  return readFileSync(join(designSystem, file), 'utf8');
}

describe('Topology Studio brand integration', () => {
  it('ships canonical brand assets with the design system UI', () => {
    expect(existsSync(join(brandDir, 'topology_studio_logo.svg'))).toBe(true);
    expect(existsSync(join(brandDir, 'topology_studio_logo_mono.svg'))).toBe(true);
    expect(existsSync(join(brandDir, 'topology_studio_icon.png'))).toBe(true);
    expect(existsSync(join(brandDir, 'topology_studio_logo.png'))).toBe(true);
  });

  it('uses the primary brand lockup and cyan/magenta tokens on the landing page', () => {
    const html = readDesignFile('landing.html');
    expect(html).toContain('landing-brand-lockup');
    expect(html).toContain('assets/brand/topology_studio_logo.svg');
    expect(html).toContain('--brand-cyan: #2EA8FF');
    expect(html).toContain('--brand-magenta: #D84DFF');
  });

  it('uses the brand mark in the shared topology runtime chrome', () => {
    const js = readDesignFile('topology-ds.js');
    const css = readDesignFile('topology-ds.css');
    expect(js).toContain('tds-brand-lockup');
    expect(js).toContain('assets/brand/topology_studio_icon.png');
    expect(css).toContain('.tds-brand-mark');
  });

  it('adds the brand mark to product navigation surfaces', () => {
    ['editor.html', 'viewer.html', 'manual.html', 'api-docs.html', 'demo-templates.html'].forEach(file => {
      const html = readDesignFile(file);
      expect(html, file).toContain('assets/brand/topology_studio_icon.png');
      expect(html, file).toContain('aria-label="Topology Studio"');
    });
  });
});
