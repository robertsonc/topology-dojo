/**
 * Tests for LayoutEngine.apply() — applies computed positions to
 * TopologyDesigner instances with optional animation.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

const LayoutEngine = require('../design-system/modules/layout-engine.js');

// Minimal TopologyDesigner shim matching the interface LayoutEngine.apply expects
function makeTopo(nodes) {
  const nodeMap = new Map();
  for (const n of nodes) {
    nodeMap.set(n.id, { ...n });
  }
  return {
    _nodes: nodeMap,
    _mounted: false,
    render: vi.fn(),
  };
}

describe('LayoutEngine.apply', () => {
  it('applies positions without animation when animate=false', () => {
    const topo = makeTopo([
      { id: 'A', x: 0, y: 0 },
      { id: 'B', x: 0, y: 0 },
    ]);

    const positions = new Map([
      ['A', { x: 100, y: 200 }],
      ['B', { x: 300, y: 400 }],
    ]);

    LayoutEngine.apply(topo, positions, false);

    expect(topo._nodes.get('A').x).toBe(100);
    expect(topo._nodes.get('A').y).toBe(200);
    expect(topo._nodes.get('B').x).toBe(300);
    expect(topo._nodes.get('B').y).toBe(400);
  });

  it('skips nodes that do not exist in the topology', () => {
    const topo = makeTopo([{ id: 'A', x: 0, y: 0 }]);

    const positions = new Map([
      ['A', { x: 50, y: 60 }],
      ['missing', { x: 999, y: 999 }],
    ]);

    LayoutEngine.apply(topo, positions, false);

    expect(topo._nodes.get('A').x).toBe(50);
    expect(topo._nodes.has('missing')).toBe(false);
  });

  it('calls render when topo is mounted', () => {
    const topo = makeTopo([{ id: 'A', x: 0, y: 0 }]);
    topo._mounted = true;

    const positions = new Map([['A', { x: 10, y: 20 }]]);
    LayoutEngine.apply(topo, positions, false);

    expect(topo.render).toHaveBeenCalled();
  });

  it('does not call render when topo is not mounted', () => {
    const topo = makeTopo([{ id: 'A', x: 0, y: 0 }]);
    topo._mounted = false;

    const positions = new Map([['A', { x: 10, y: 20 }]]);
    LayoutEngine.apply(topo, positions, false);

    expect(topo.render).not.toHaveBeenCalled();
  });

  it('triggers requestAnimationFrame when animate=true', () => {
    const topo = makeTopo([{ id: 'A', x: 0, y: 0 }]);

    const rafSpy = vi.spyOn(globalThis, 'requestAnimationFrame')
      .mockImplementation(() => 0);

    const positions = new Map([['A', { x: 100, y: 200 }]]);
    LayoutEngine.apply(topo, positions, true);

    expect(rafSpy).toHaveBeenCalled();
    rafSpy.mockRestore();
  });
});
