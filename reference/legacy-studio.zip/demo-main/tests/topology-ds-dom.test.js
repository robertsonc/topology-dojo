import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

function buildAndMount() {
  const container = document.createElement('div');
  container.id = 'test-dom-container';
  document.body.appendChild(container);

  const topo = new TopologyDesigner({
    title: 'DOM Test',
    subtitle: 'Sub',
    viewBox: '0 0 800 500',
    phaseMs: 600,
    mode: 'manual',
  });

  topo.node('R1', { type: 'router', x: 200, y: 250, label: 'Router' });
  topo.node('SW1', { type: 'switch', x: 500, y: 250, label: 'Switch' });
  topo.anchor('anc1', { x: 350, y: 250, label: 'Waypoint' });
  topo.link('r1-sw1', { type: 'line', from: 'R1', to: 'SW1', color: '#01a982', label: 'Uplink' });
  topo.link('r1-anc', { type: 'tunnel', from: 'R1', to: 'anc1', color: '#65aef9' });
  topo.act('a1', { label: 'Act 1', color: '#01a982', intro: ['Intro text'] });
  topo.addStep('s1', {
    act: 'a1', name: 'Step 1', goal: 'Goal 1',
    focus: [],
    phases: [
      { show: ['R1', 'SW1', 'anc1', 'r1-sw1', 'r1-anc'], diff: 'All shown' },
    ],
  });
  topo.glossary([{ t: 'Test', d: 'A test term' }]);
  topo.mount('test-dom-container');
  return { topo, container };
}

describe('Toolbar Slider Events', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('speed slider updates speedMs', () => {
    const slider = container.querySelector('#tds-speed');
    slider.value = '3000';
    slider.dispatchEvent(new Event('input'));
    expect(topo.speedMs).toBe(3000);
  });

  it('phaseMs slider updates phaseMs', () => {
    const slider = container.querySelector('#tds-phaseMs');
    slider.value = '800';
    slider.dispatchEvent(new Event('input'));
    expect(topo.phaseMs).toBe(800);
  });

  it('drawDur slider updates drawDuration', () => {
    const slider = container.querySelector('#tds-drawDur');
    slider.value = '1.2';
    slider.dispatchEvent(new Event('input'));
    expect(topo.drawDuration).toBeCloseTo(1.2);
  });

  it('fadeDur slider updates fadeDuration', () => {
    const slider = container.querySelector('#tds-fadeDur');
    slider.value = '0.8';
    slider.dispatchEvent(new Event('input'));
    expect(topo.fadeDuration).toBeCloseTo(0.8);
  });

  it('mode selector changes mode', () => {
    const sel = container.querySelector('#tds-modeSel');
    sel.value = 'presenter';
    sel.dispatchEvent(new Event('change'));
    expect(topo.mode).toBe('presenter');
    expect(topo.playing).toBe(false);
  });
});

describe('Properties Panel', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
    topo.next(); // go to step 1 so elements are visible
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('shows properties panel for anchor', () => {
    topo._showPropertiesPanel('anc1', 'anchor');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
    expect(panel.textContent).toContain('anchor');
    expect(panel.textContent).toContain('anc1');
    expect(panel.textContent).toContain('Delete');
  });

  it('shows properties panel for node', () => {
    topo._showPropertiesPanel('R1', 'node');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
    expect(panel.textContent).toContain('router');
    expect(panel.textContent).toContain('Router');
  });

  it('shows properties panel for link', () => {
    topo._showPropertiesPanel('r1-sw1', 'link');
    const panel = document.getElementById('tds-properties-panel');
    expect(panel).not.toBeNull();
    expect(panel.textContent).toContain('line');
    expect(panel.textContent).toContain('R1');
    expect(panel.textContent).toContain('SW1');
  });

  it('swap direction button works for links', () => {
    topo._showPropertiesPanel('r1-sw1', 'link');
    const swapBtn = document.getElementById('tds-props-swap');
    expect(swapBtn).not.toBeNull();
    swapBtn.click();
    const link = topo._links.get('r1-sw1');
    expect(link.from).toBe('SW1');
    expect(link.to).toBe('R1');
  });

  it('label input updates link label', () => {
    topo._showPropertiesPanel('r1-sw1', 'link');
    const input = document.getElementById('tds-props-label');
    input.value = 'New Label';
    input.dispatchEvent(new Event('input'));
    const link = topo._links.get('r1-sw1');
    expect(link.label).toBe('New Label');
  });

  it('fromLabel input updates link endpoint label', () => {
    topo._showPropertiesPanel('r1-sw1', 'link');
    const input = document.getElementById('tds-props-fromLabel');
    input.value = 'ge0/1';
    input.dispatchEvent(new Event('input'));
    const link = topo._links.get('r1-sw1');
    expect(link.fromLabel).toBe('ge0/1');
  });

  it('close button hides panel', () => {
    topo._showPropertiesPanel('R1', 'node');
    const closeBtn = document.getElementById('tds-props-close');
    closeBtn.click();
    const panel = document.getElementById('tds-properties-panel');
    expect(panel.style.display).toBe('none');
  });

  it('hidePropertiesPanel hides panel', () => {
    topo._showPropertiesPanel('R1', 'node');
    topo._hidePropertiesPanel();
    expect(topo._selectedElement).toBeNull();
  });

  it('delete button on anchor removes anchor', () => {
    topo._showPropertiesPanel('anc1', 'anchor');
    const delBtn = document.getElementById('tds-props-delete');
    delBtn.click();
    expect(topo._anchors.has('anc1')).toBe(false);
  });
});

describe('Glossary interaction', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('close button closes glossary', () => {
    topo._openGlossary();
    const closeBtn = container.querySelector('#tds-modalClose');
    closeBtn.click();
    const modal = container.querySelector('#tds-modalBg');
    expect(modal.style.display).toBe('none');
  });

  it('clicking backdrop closes glossary', () => {
    topo._openGlossary();
    const bg = container.querySelector('#tds-modalBg');
    bg.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    // If clicked on the bg element itself, it should close
  });

  it('G key opens glossary', () => {
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'g', bubbles: true }));
    const modal = container.querySelector('#tds-modalBg');
    expect(modal.style.display).not.toBe('none');
  });
});

describe('Narrator toggle', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('N key toggles narrator collapsed state', () => {
    const before = topo.narCollapsed;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'n', bubbles: true }));
    expect(topo.narCollapsed).toBe(!before);
  });
});

describe('Escape key', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('Escape hides properties panel', () => {
    topo._showPropertiesPanel('R1', 'node');
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    expect(topo._selectedElement).toBeNull();
  });

  it('Escape exits link mode', () => {
    topo.setMode('link');
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    expect(topo.interactiveMode).toBe('select');
  });
});

describe('Mode indicator', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('mode indicator click toggles mode', () => {
    const indicator = container.querySelector('#tds-mode-indicator');
    indicator.click();
    expect(topo.interactiveMode).toBe('link');
    indicator.click();
    expect(topo.interactiveMode).toBe('select');
  });
});

describe('Advanced rendering branches', () => {
  it('renders node with custom render function', () => {
    const topo = new TopologyDesigner();
    topo.node('C1', {
      type: 'custom', x: 100, y: 200,
      render: (x, y) => `<rect x="${x-10}" y="${y-10}" width="20" height="20"/>`,
    });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['C1'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('rect');
  });

  it('renders overlayCloud spanning nodes', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.node('OC', { type: 'overlayCloud', x: 0, y: 0, spans: ['A', 'B'], label: 'Overlay', color: '#7764fc' });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A', 'B', 'OC'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Overlay');
  });

  it('renders with isometric mode enabled', () => {
    const result = buildAndMount();
    result.topo.toggleIsometric(true);
    result.topo.next();
    const canvas = result.container.querySelector('.tds-canvas');
    expect(canvas.classList.contains('tds-isometric')).toBe(true);
    document.body.innerHTML = '';
  });

  it('renders with ghosting across acts', () => {
    const topo = new TopologyDesigner({ ghosting: true });
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.act('a1', { label: 'Act 1' });
    topo.act('a2', { label: 'Act 2' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo.addStep('s2', { act: 'a2', name: 'S2', goal: '', phases: [{ show: ['B'], diff: '' }] });
    topo._buildIndex();
    topo.step = 2;
    const svg = topo._renderSVG();
    // Ghost filter should be applied to elements from previous act
    expect(svg).toContain('tds-ghost');
  });

  it('renders showDuring elements', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('sd', { type: 'line', from: 'A', to: 'B', color: '#ff0000' });
    topo.act('a1', { label: 'Act 1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo.addStep('s2', { act: 'a1', name: 'S2', goal: '', phases: [{ show: ['B'], diff: '' }] });
    topo.showDuring(['sd'], { from: 's1', until: 's2' });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    // showDuring link should be rendered
    expect(svg.length).toBeGreaterThan(0);
  });

  it('renders temporal mode badges in operational mode', () => {
    const topo = new TopologyDesigner({ temporalMode: 'operational' });
    topo.node('A', { type: 'router', x: 100, y: 200, label: 'R1' });
    topo.setElementState('A', { status: 'degraded', latency: 45, jitter: 12, loss: 2 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    // Temporal badge renders status color (#deb146 for degraded) and metrics
    expect(svg).toContain('#deb146');
    expect(svg).toContain('45ms');
  });

  it('renders security mode blast radius', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('ab', { type: 'line', from: 'A', to: 'B' });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A', 'B', 'ab'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    topo._securityMode = true;
    topo._blastRadiusNode = 'A';
    const svg = topo._renderSVG();
    expect(svg).toContain('tds-blast-ring');
  });

  it('renders conditional phase with state', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.setState('test.enabled', true);
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        condition: 'test.enabled',
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg.length).toBeGreaterThan(0);
  });

  it('renders with multiple phase arrays (label, badge, callout)', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', {
      act: 'a1', name: 'S1', goal: '',
      phases: [{
        show: ['A'], diff: '',
        label: [
          { at: 'A', text: 'Label1', color: '#ff0000' },
          { at: 'A', text: 'Label2', color: '#00ff00', offsetY: 20 },
        ],
        badge: [
          { at: 'A', text: 'Badge1', color: '#01a982', offsetY: -30 },
        ],
      }],
    });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('Label1');
    expect(svg).toContain('Label2');
    expect(svg).toContain('Badge1');
  });
});

describe('Node rendering edge cases', () => {
  const renderFns = [
    ['ec', {}, 'triangle'],
    ['ec', { variant: 'aws' }, 'AWS'],
    ['ec', { variant: 'azure' }, 'Azure'],
    ['ec', { variant: 'gcp' }, 'GCP'],
    ['ec', { variant: 'oracle' }, 'Oracle'],
    ['ec', { variant: 'virtual' }, 'virtual'],
    ['ec', { variant: 'physical' }, 'physical'],
    ['ec', { vrrp: 'active' }, 'vrrp'],
    ['ec', { vrrp: 'standby' }, 'vrrp'],
    ['host', { managed: true }, 'shield'],
    ['host', { managed: true, agent: true }, 'agent'],
    ['connector', { pe: true }, 'PRIVATE'],
    ['idcard', { mode: 'auth', user: 'test@test.com', host: 'HOST1', role: 'ADMIN' }, 'AUTH'],
    ['cloud', { sub1: 'SWG', sub2: 'PDP', innerClouds: 'both' }, 'SWG'],
    ['cloud', { innerClouds: 'none' }, 'cloud'],
    ['ap', {}, 'signal'],
    ['database', {}, 'database'],
  ];

  it.each(renderFns)('renders %s type with options', (type, cfg) => {
    const topo = new TopologyDesigner();
    topo.node('N1', { type, x: 100, y: 200, label: 'Test', ...cfg });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['N1'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg.length).toBeGreaterThan(100);
  });
});

describe('Sidebar navigation', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('step links in sidebar are clickable', () => {
    const sidebar = container.querySelector('#tds-sidebar');
    const stepLinks = sidebar.querySelectorAll('[data-step]');
    if (stepLinks.length > 0) {
      stepLinks[0].click();
      expect(topo.step).toBeGreaterThan(0);
    }
  });
});

describe('_advance and presenter mode', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    topo.pause();
    document.body.innerHTML = '';
  });

  it('advance in auto mode increments step', () => {
    topo.mode = 'auto';
    topo.playing = true;
    topo.step = 0;
    topo._advance();
    expect(topo.step).toBe(1);
  });
});

describe('_updateUI', () => {
  let topo, container;

  beforeEach(() => {
    ({ topo, container } = buildAndMount());
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('updates step label text', () => {
    topo.next();
    const label = container.querySelector('#tds-stepLabel');
    expect(label.textContent).toContain('1');
  });

  it('updates progress pips', () => {
    topo.next();
    const pips = container.querySelector('#tds-progress');
    const activePips = pips.querySelectorAll('.active');
    // There should be at least one active pip after navigating
  });
});

describe('Link rendering with dashStyle', () => {
  it.each(['dashed', 'dotted', 'longDash', 'dashDot', 'dashDotDot', 'dense', 'sparse'])(
    'renders %s dash style', (style) => {
      const topo = new TopologyDesigner();
      topo.node('A', { type: 'router', x: 100, y: 200 });
      topo.node('B', { type: 'switch', x: 400, y: 200 });
      topo.link('l1', { type: 'line', from: 'A', to: 'B', dashStyle: style });
      topo.act('a1', { label: 'A1' });
      topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }] });
      topo._buildIndex();
      topo.step = 1;
      const svg = topo._renderSVG();
      expect(svg.length).toBeGreaterThan(0);
    }
  );
});

describe('Link rendering with animateMotion', () => {
  it('renders flow link with animated motion particles', () => {
    const topo = new TopologyDesigner();
    topo.node('A', { type: 'router', x: 100, y: 200 });
    topo.node('B', { type: 'switch', x: 400, y: 200 });
    topo.link('l1', { type: 'flow', from: 'A', to: 'B', path: 'M100,200 L400,200', labelPos: { x: 250, y: 190 } });
    topo.act('a1', { label: 'A1' });
    topo.addStep('s1', { act: 'a1', name: 'S1', goal: '', phases: [{ show: ['A', 'B', 'l1'], diff: '' }] });
    topo._buildIndex();
    topo.step = 1;
    const svg = topo._renderSVG();
    expect(svg).toContain('animateMotion');
  });
});
