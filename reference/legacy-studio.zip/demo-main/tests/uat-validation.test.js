/**
 * UAT Validation Tests
 * Programmatically re-creates each UAT topology and verifies:
 * - Topology instantiates without errors
 * - _buildIndex() completes
 * - Expected number of nodes/links are registered
 * - No JavaScript errors thrown
 * - toJSON() works and produces valid output
 */

import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};
Element.prototype.scrollIntoView = Element.prototype.scrollIntoView || function () {};

const TopologyDesigner = require('../design-system/topology-ds.js');

// ─────────────────────────────────────────────
// UAT 1: Basic 3-Tier Network
// ─────────────────────────────────────────────

describe('UAT: Basic 3-Tier Network (basic-topology.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({
      title: 'UAT · Basic 3-Tier Network',
      subtitle: 'Infrastructure · Security · Services',
      viewBox: '0 0 1050 700',
      phaseMs: 600,
    });
    topo.node('INET',   { type: 'cloud',    x: 525, y: 65,  label: 'Internet' });
    topo.node('ROUTER', { type: 'router',   x: 525, y: 190, label: 'Core Router', sublabel: 'BGP · OSPF' });
    topo.node('FW',     { type: 'firewall', x: 525, y: 330, label: 'Perimeter Firewall', sublabel: 'Stateful · IPS' });
    topo.node('SW',     { type: 'switch',   x: 525, y: 470, label: 'Distribution Switch' });
    topo.node('SRV1',   { type: 'server',   x: 270, y: 590, label: 'Web Server' });
    topo.node('SRV2',   { type: 'server',   x: 525, y: 590, label: 'App Server' });
    topo.node('SRV3',   { type: 'server',   x: 780, y: 590, label: 'Database' });
    topo.link('inet-router', { type: 'line',   from: 'INET',   to: 'ROUTER', color: '#b1b9be' });
    topo.link('router-fw',   { type: 'line',   from: 'ROUTER', to: 'FW',     color: '#b1b9be' });
    topo.link('fw-sw',       { type: 'line',   from: 'FW',     to: 'SW',     color: '#01a982' });
    topo.link('sw-srv1',     { type: 'line',   from: 'SW',     to: 'SRV1',   color: '#65aef9' });
    topo.link('sw-srv2',     { type: 'line',   from: 'SW',     to: 'SRV2',   color: '#65aef9' });
    topo.link('sw-srv3',     { type: 'line',   from: 'SW',     to: 'SRV3',   color: '#deb146' });
    topo.act('infra', { label: 'Infrastructure', color: '#01a982' });
    topo.addStep('s1', { act: 'infra', name: 'Internet Edge',    goal: 'Show edge', focus: ['INET', 'ROUTER'], phases: [{ show: ['INET', 'ROUTER', 'inet-router'], diff: 'Internet + Router' }] });
    topo.addStep('s2', { act: 'infra', name: 'Security Layer',   goal: 'Show FW',   focus: ['FW'],             phases: [{ show: ['FW', 'router-fw'], diff: 'Firewall' }] });
    topo.addStep('s3', { act: 'infra', name: 'Server Tier',      goal: 'Show svrs', focus: ['SRV1', 'SRV2', 'SRV3'], phases: [{ show: ['SW', 'SRV1', 'SRV2', 'SRV3', 'fw-sw', 'sw-srv1', 'sw-srv2', 'sw-srv3'], diff: 'All servers' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 7 nodes', () => { expect(topo._nodes.size).toBe(7); });
  it('registers 6 links', () => { expect(topo._links.size).toBe(6); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all nodes have valid x/y', () => {
    for (const [, n] of topo._nodes) {
      expect(typeof n.x).toBe('number');
      expect(typeof n.y).toBe('number');
    }
  });
  it('all links reference valid nodes', () => {
    for (const [, lk] of topo._links) {
      expect(topo._nodes.has(lk.from) || topo._anchors.has(lk.from)).toBe(true);
      expect(topo._nodes.has(lk.to)   || topo._anchors.has(lk.to)).toBe(true);
    }
  });
  it('toJSON() works', () => {
    const json = topo.toJSON();
    expect(json.title).toBe('UAT · Basic 3-Tier Network');
    expect(Object.keys(json.nodes).length).toBe(7);
    expect(Object.keys(json.links).length).toBe(6);
    expect(Array.isArray(json.zones)).toBe(true);
  });
  it('fromJSON round-trip restores topology', () => {
    const json = topo.toJSON();
    const topo2 = new TopologyDesigner({ title: 'Restore', viewBox: '0 0 1050 700' });
    topo2.fromJSON(json);
    expect(topo2._nodes.size).toBe(7);
    expect(topo2._links.size).toBe(6);
  });
});

// ─────────────────────────────────────────────
// UAT 2: All Link Types
// ─────────────────────────────────────────────

describe('UAT: All Link Types (all-link-types.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · All Link Types', viewBox: '0 0 1050 700', phaseMs: 600 });
    // Row of source nodes
    ['N1','N2','N3','N4','N5','N6','N7','N8','N9','N10'].forEach((id, i) => {
      topo.node(id, { type: 'router', x: 100 + i * 100, y: 200, label: id });
    });
    // Target node for each link type
    ['T1','T2','T3','T4','T5','T6','T7','T8','T9','T10'].forEach((id, i) => {
      topo.node(id, { type: 'server', x: 100 + i * 100, y: 400, label: id });
    });
    const types = ['line','tunnel','wireguard','flow','packet','blocked','wifi','poe','optical','line'];
    types.forEach((t, i) => {
      topo.link(`l${i+1}`, { type: t, from: `N${i+1}`, to: `T${i+1}`, color: '#01a982' });
    });
    topo.act('a1', { label: 'Link Types', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'All Links', goal: 'Show all link types', focus: [], phases: [{ show: ['N1','N2','N3','N4','N5','N6','N7','N8','N9','N10','T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','l1','l2','l3','l4','l5','l6','l7','l8','l9','l10'], diff: 'All' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 20 nodes', () => { expect(topo._nodes.size).toBe(20); });
  it('registers 10 links', () => { expect(topo._links.size).toBe(10); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all nodes have valid x/y', () => {
    for (const [, n] of topo._nodes) {
      expect(typeof n.x).toBe('number');
      expect(isNaN(n.x)).toBe(false);
    }
  });
  it('toJSON() produces valid output', () => {
    const json = topo.toJSON();
    expect(json.nodes).toBeDefined();
    expect(json.links).toBeDefined();
    expect(Object.keys(json.links).length).toBe(10);
  });
});

// ─────────────────────────────────────────────
// UAT 3: SD-WAN 3-Site
// ─────────────────────────────────────────────

describe('UAT: SD-WAN 3-Site (sdwan-3site.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · SD-WAN 3-Site', viewBox: '0 0 1050 700', phaseMs: 600 });
    // HQ site
    topo.node('HQ_EC1',  { type: 'ec',      x: 200, y: 200, label: 'HQ Edge Connect' });
    topo.node('HQ_FW',   { type: 'firewall',x: 200, y: 350, label: 'HQ Firewall' });
    topo.node('HQ_SW',   { type: 'switch',  x: 200, y: 480, label: 'HQ Switch' });
    topo.node('HQ_SRV',  { type: 'server',  x: 100, y: 600, label: 'HQ Server' });
    topo.node('HQ_USER', { type: 'host',    x: 300, y: 600, label: 'HQ User' });
    // Branch 1
    topo.node('BR1_EC',  { type: 'ec',      x: 525, y: 200, label: 'Branch 1 EC' });
    topo.node('BR1_SW',  { type: 'switch',  x: 525, y: 350, label: 'Branch 1 SW' });
    topo.node('BR1_PC',  { type: 'host',    x: 525, y: 480, label: 'Branch 1 PC' });
    // Branch 2
    topo.node('BR2_EC',  { type: 'ec',      x: 850, y: 200, label: 'Branch 2 EC' });
    topo.node('BR2_SW',  { type: 'switch',  x: 850, y: 350, label: 'Branch 2 SW' });
    topo.node('BR2_PC',  { type: 'host',    x: 850, y: 480, label: 'Branch 2 PC' });
    // Internet/orchestrator
    topo.node('INET',    { type: 'cloud',   x: 525, y: 60,  label: 'Internet' });
    topo.node('ORCH',    { type: 'cloud',   x: 350, y: 60,  label: 'Orchestrator' });
    // Cloud
    topo.node('CLOUD',   { type: 'cloud',   x: 700, y: 60,  label: 'Cloud' });
    topo.node('SaaS',    { type: 'saas',    x: 850, y: 60,  label: 'SaaS' });
    topo.node('CONNECTOR',{ type: 'connector',x: 700, y: 200, label: 'Connector' });
    // Links
    topo.link('hq-inet',  { type: 'tunnel', from: 'HQ_EC1',  to: 'INET',     color: '#01a982' });
    topo.link('br1-inet', { type: 'tunnel', from: 'BR1_EC',  to: 'INET',     color: '#01a982' });
    topo.link('br2-inet', { type: 'tunnel', from: 'BR2_EC',  to: 'INET',     color: '#01a982' });
    topo.link('hq-orch',  { type: 'tunnel', from: 'HQ_EC1',  to: 'ORCH',     color: '#65aef9' });
    topo.link('br1-orch', { type: 'tunnel', from: 'BR1_EC',  to: 'ORCH',     color: '#65aef9' });
    topo.link('br2-orch', { type: 'tunnel', from: 'BR2_EC',  to: 'ORCH',     color: '#65aef9' });
    topo.link('hq-fw',    { type: 'line',   from: 'HQ_EC1',  to: 'HQ_FW',   color: '#b1b9be' });
    topo.link('hq-sw',    { type: 'line',   from: 'HQ_FW',   to: 'HQ_SW',   color: '#b1b9be' });
    topo.link('hq-srv',   { type: 'line',   from: 'HQ_SW',   to: 'HQ_SRV',  color: '#b1b9be' });
    topo.link('hq-user',  { type: 'line',   from: 'HQ_SW',   to: 'HQ_USER', color: '#b1b9be' });
    topo.link('br1-sw',   { type: 'line',   from: 'BR1_EC',  to: 'BR1_SW',  color: '#b1b9be' });
    topo.link('br1-pc',   { type: 'line',   from: 'BR1_SW',  to: 'BR1_PC',  color: '#b1b9be' });
    topo.link('br2-sw',   { type: 'line',   from: 'BR2_EC',  to: 'BR2_SW',  color: '#b1b9be' });
    topo.link('br2-pc',   { type: 'line',   from: 'BR2_SW',  to: 'BR2_PC',  color: '#b1b9be' });
    topo.link('cloud-con',{ type: 'tunnel', from: 'CLOUD',   to: 'CONNECTOR',color: '#65aef9' });
    topo.link('inet-cloud',{ type: 'line',  from: 'INET',    to: 'CLOUD',   color: '#b1b9be' });
    topo.link('inet-saas',{ type: 'line',   from: 'INET',    to: 'SaaS',    color: '#b1b9be' });
    topo.link('hq-con',   { type: 'tunnel', from: 'HQ_EC1',  to: 'CONNECTOR',color: '#65aef9' });
    topo.link('br1-saas', { type: 'tunnel', from: 'BR1_EC',  to: 'SaaS',    color: '#deb146' });
    topo.link('br2-cloud',{ type: 'tunnel', from: 'BR2_EC',  to: 'CLOUD',   color: '#deb146' });
    topo.act('a1', { label: 'SD-WAN Foundation', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'Underlay',    goal: 'Show underlay', focus: [], phases: [{ show: ['INET','HQ_EC1','BR1_EC','BR2_EC','hq-inet','br1-inet','br2-inet'], diff: 'Internet connectivity' }] });
    topo.addStep('s2', { act: 'a1', name: 'Orchestration', goal: 'Show Orch', focus: [], phases: [{ show: ['ORCH','hq-orch','br1-orch','br2-orch'], diff: 'Orchestrator' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 16 nodes', () => { expect(topo._nodes.size).toBe(16); });
  it('registers 20 links', () => { expect(topo._links.size).toBe(20); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all nodes have valid coordinates', () => {
    for (const [, n] of topo._nodes) {
      expect(typeof n.x).toBe('number');
      expect(isNaN(n.x)).toBe(false);
    }
  });
  it('all links reference valid from/to nodes', () => {
    for (const [, lk] of topo._links) {
      const fromOk = topo._nodes.has(lk.from) || topo._anchors.has(lk.from);
      const toOk   = topo._nodes.has(lk.to)   || topo._anchors.has(lk.to);
      expect(fromOk).toBe(true);
      expect(toOk).toBe(true);
    }
  });
  it('toJSON produces correct node/link counts', () => {
    const json = topo.toJSON();
    expect(Object.keys(json.nodes).length).toBe(16);
    expect(Object.keys(json.links).length).toBe(20);
  });
});

// ─────────────────────────────────────────────
// UAT 4: Enterprise Full Topology
// ─────────────────────────────────────────────

describe('UAT: Enterprise Full (enterprise-full.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · Enterprise Full', viewBox: '0 0 1400 800', phaseMs: 600 });
    // Core layer
    const coreNodes = [
      ['INET',  'cloud',    200,  70, 'Internet'],
      ['INET2', 'cloud',    600,  70, 'MPLS WAN'],
      ['INET3', 'cloud',   1000,  70, 'LTE Backup'],
      ['FW1',   'firewall', 200, 180, 'Perimeter FW 1'],
      ['FW2',   'firewall', 600, 180, 'Perimeter FW 2'],
      ['FW3',   'firewall',1000, 180, 'Branch FW'],
      ['CORE1', 'switch',   300, 300, 'Core Switch 1'],
      ['CORE2', 'switch',   700, 300, 'Core Switch 2'],
      ['DIST1', 'switch',   200, 420, 'Dist Switch 1'],
      ['DIST2', 'switch',   500, 420, 'Dist Switch 2'],
      ['DIST3', 'switch',   800, 420, 'Dist Switch 3'],
      ['DIST4', 'switch',  1100, 420, 'Dist Switch 4'],
      ['SRV1',  'server',   100, 560, 'Web Farm 1'],
      ['SRV2',  'server',   300, 560, 'App Cluster'],
      ['SRV3',  'server',   500, 560, 'DB Primary'],
      ['SRV4',  'server',   700, 560, 'DB Replica'],
      ['SRV5',  'server',   900, 560, 'File Server'],
      ['SRV6',  'server',  1100, 560, 'Backup Server'],
      ['STOR',  'database',1300, 420, 'SAN Storage'],
      ['MGMT',  'router',  1300, 180, 'Mgmt Router'],
    ];
    coreNodes.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    // Links
    const links = [
      ['l1','line','INET','FW1','#b1b9be'],['l2','line','INET2','FW2','#b1b9be'],['l3','line','INET3','FW3','#b1b9be'],
      ['l4','line','FW1','CORE1','#01a982'],['l5','line','FW2','CORE2','#01a982'],['l6','line','FW3','DIST4','#01a982'],
      ['l7','line','CORE1','CORE2','#65aef9'],['l8','line','CORE1','DIST1','#65aef9'],['l9','line','CORE1','DIST2','#65aef9'],
      ['l10','line','CORE2','DIST3','#65aef9'],['l11','line','CORE2','DIST4','#65aef9'],
      ['l12','line','DIST1','SRV1','#b1b9be'],['l13','line','DIST2','SRV2','#b1b9be'],['l14','line','DIST2','SRV3','#b1b9be'],
      ['l15','line','DIST3','SRV4','#b1b9be'],['l16','line','DIST3','SRV5','#b1b9be'],['l17','line','DIST4','SRV6','#b1b9be'],
      ['l18','line','DIST4','STOR','#deb146'],['l19','line','MGMT','CORE1','#7d8a92'],['l20','line','MGMT','CORE2','#7d8a92'],
      ['l21','tunnel','INET','MGMT','#535c66'],['l22','line','CORE1','DIST3','#65aef9'],['l23','line','DIST1','SRV2','#b1b9be'],
      ['l24','line','DIST2','SRV4','#b1b9be'],
    ];
    links.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('a1', { label: 'Enterprise Architecture', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'Internet Edge', goal: 'Show edge', focus: [], phases: [{ show: ['INET','INET2','INET3','FW1','FW2','FW3','l1','l2','l3'], diff: 'Edge' }] });
    topo.addStep('s2', { act: 'a1', name: 'Core Layer', goal: 'Show core', focus: [], phases: [{ show: ['CORE1','CORE2','l4','l5','l7'], diff: 'Core' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 20 nodes', () => { expect(topo._nodes.size).toBe(20); });
  it('registers 24 links', () => { expect(topo._links.size).toBe(24); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all links reference valid nodes', () => {
    for (const [, lk] of topo._links) {
      expect(topo._nodes.has(lk.from) || topo._anchors.has(lk.from)).toBe(true);
      expect(topo._nodes.has(lk.to)   || topo._anchors.has(lk.to)).toBe(true);
    }
  });
  it('toJSON output is valid', () => {
    const json = topo.toJSON();
    expect(json.title).toBe('UAT · Enterprise Full');
    expect(Object.keys(json.nodes).length).toBe(20);
  });
});

// ─────────────────────────────────────────────
// UAT 5: Choreography Showcase
// ─────────────────────────────────────────────

describe('UAT: Choreography Showcase (choreography-showcase.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · Choreography', viewBox: '0 0 1050 700', phaseMs: 400 });
    const nodes = [
      ['USER',    'host',    100, 350, 'Remote User'],
      ['LAPTOP',  'host',    240, 350, 'Laptop'],
      ['ZTNA',    'cloud',   380, 200, 'ZTNA Cloud'],
      ['IdP',     'cloud',   380, 500, 'Identity Provider'],
      ['EC_Branch','ec',     520, 350, 'Branch EC'],
      ['FW',      'firewall',660, 200, 'HQ Firewall'],
      ['HQ_EC',   'ec',      660, 350, 'HQ EC'],
      ['CORE_SW', 'switch',  800, 350, 'Core Switch'],
      ['APP_SRV', 'server',  940, 200, 'App Server'],
      ['DB_SRV',  'server',  940, 350, 'DB Server'],
      ['FILE_SRV','server',  940, 500, 'File Server'],
      ['INET',    'cloud',   380, 350, 'Internet'],
      ['MGMT',    'server',  800, 500, 'MGMT Server'],
      ['LOG',     'server',  800, 200, 'Log Server'],
    ];
    nodes.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    const links = [
      ['l1','line','USER','LAPTOP','#b1b9be'],['l2','tunnel','LAPTOP','ZTNA','#01a982'],
      ['l3','line','LAPTOP','INET','#535c66'],['l4','tunnel','INET','EC_Branch','#01a982'],
      ['l5','tunnel','EC_Branch','HQ_EC','#01a982'],['l6','line','HQ_EC','FW','#01a982'],
      ['l7','line','FW','CORE_SW','#01a982'],['l8','line','CORE_SW','APP_SRV','#65aef9'],
      ['l9','line','CORE_SW','DB_SRV','#65aef9'],['l10','line','CORE_SW','FILE_SRV','#65aef9'],
      ['l11','tunnel','LAPTOP','IdP','#deb146'],['l12','line','CORE_SW','MGMT','#7d8a92'],
      ['l13','line','CORE_SW','LOG','#7d8a92'],['l14','tunnel','ZTNA','HQ_EC','#01a982'],
      ['l15','line','HQ_EC','CORE_SW','#01a982'],['l16','line','INET','ZTNA','#535c66'],
    ];
    links.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('auth', { label: 'Authentication', color: '#deb146' });
    topo.act('data', { label: 'Data Flow', color: '#01a982' });
    topo.addStep('s1', { act: 'auth', name: 'User Auth', goal: 'Show auth flow', focus: ['USER','LAPTOP','IdP'], phases: [{ show: ['USER','LAPTOP','IdP','l1','l11'], diff: 'Auth request' }] });
    topo.addStep('s2', { act: 'auth', name: 'ZTNA Policy', goal: 'ZTNA check', focus: ['ZTNA','INET'], phases: [{ show: ['ZTNA','INET','l2','l3','l16'], diff: 'ZTNA enforcement' }] });
    topo.addStep('s3', { act: 'data', name: 'Secure Tunnel', goal: 'Show tunnel', focus: ['EC_Branch','HQ_EC'], phases: [{ show: ['EC_Branch','HQ_EC','l4','l5'], diff: 'SD-WAN tunnel' }] });
    topo.addStep('s4', { act: 'data', name: 'HQ Access', goal: 'Show HQ', focus: ['APP_SRV','DB_SRV'], phases: [{ show: ['FW','CORE_SW','APP_SRV','DB_SRV','FILE_SRV','l6','l7','l8','l9','l10'], diff: 'HQ resources' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 14 nodes', () => { expect(topo._nodes.size).toBe(14); });
  it('registers 16 links', () => { expect(topo._links.size).toBe(16); });
  it('has 2 acts', () => { expect(topo._acts.length).toBe(2); });
  it('has 4 steps', () => { expect(topo._steps.length).toBe(4); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all nodes have valid coordinates', () => {
    for (const [, n] of topo._nodes) {
      expect(typeof n.x).toBe('number');
      expect(isNaN(n.x)).toBe(false);
    }
  });
  it('toJSON includes acts and steps', () => {
    const json = topo.toJSON();
    expect(json.acts.length).toBe(2);
    expect(json.steps.length).toBe(4);
  });
});

// ─────────────────────────────────────────────
// UAT 6: Traffic Flow Showcase
// ─────────────────────────────────────────────

describe('UAT: Traffic Flow Showcase (traffic-flow-showcase.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · Traffic Flow', viewBox: '0 0 1050 700', phaseMs: 600 });
    const nodes = [
      ['CLIENT', 'host',    100, 350, 'Client'],
      ['FW',     'firewall',250, 350, 'Firewall'],
      ['LB',     'router',  400, 350, 'Load Balancer'],
      ['WEB1',   'server',  550, 200, 'Web 1'],
      ['WEB2',   'server',  550, 350, 'Web 2'],
      ['WEB3',   'server',  550, 500, 'Web 3'],
      ['DB_PRI', 'database',750, 200, 'DB Primary'],
      ['DB_REP', 'database',750, 500, 'DB Replica'],
      ['CACHE',  'server',  750, 350, 'Redis Cache'],
    ];
    nodes.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    const links = [
      ['l1','line','CLIENT','FW','#b1b9be'],['l2','line','FW','LB','#01a982'],
      ['l3','line','LB','WEB1','#65aef9'],['l4','line','LB','WEB2','#65aef9'],
      ['l5','line','LB','WEB3','#65aef9'],['l6','line','WEB1','DB_PRI','#deb146'],
      ['l7','line','WEB2','CACHE','#deb146'],['l8','line','WEB3','DB_REP','#deb146'],
      ['l9','line','DB_PRI','DB_REP','#535c66'],['l10','line','WEB1','CACHE','#7d8a92'],
      ['l11','line','WEB2','DB_PRI','#7d8a92'],['l12','line','WEB3','CACHE','#7d8a92'],
    ];
    links.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('a1', { label: 'Traffic Flow', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'HTTP Request',  goal: 'Client to FW',  focus: ['CLIENT','FW'], phases: [{ show: ['CLIENT','FW','l1'], diff: 'Ingress' }] });
    topo.addStep('s2', { act: 'a1', name: 'Load Balancing', goal: 'LB distributes', focus: ['LB'], phases: [{ show: ['LB','WEB1','WEB2','WEB3','l2','l3','l4','l5'], diff: 'LB distributes' }] });
    topo.addStep('s3', { act: 'a1', name: 'Data Layer', goal: 'DB access', focus: ['DB_PRI','DB_REP'], phases: [{ show: ['DB_PRI','DB_REP','CACHE','l6','l7','l8','l9','l10'], diff: 'Data tier' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 9 nodes', () => { expect(topo._nodes.size).toBe(9); });
  it('registers 12 links', () => { expect(topo._links.size).toBe(12); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all links reference valid nodes', () => {
    for (const [, lk] of topo._links) {
      expect(topo._nodes.has(lk.from)).toBe(true);
      expect(topo._nodes.has(lk.to)).toBe(true);
    }
  });
  it('toJSON works', () => {
    const json = topo.toJSON();
    expect(Object.keys(json.nodes).length).toBe(9);
    expect(Object.keys(json.links).length).toBe(12);
  });
});

// ─────────────────────────────────────────────
// UAT 7: Serialization Round-Trip
// ─────────────────────────────────────────────

describe('UAT: Serialization Round-Trip (serialization-roundtrip.html)', () => {
  let original, restored;
  beforeEach(() => {
    original = new TopologyDesigner({ title: 'Serialization Test Topology', viewBox: '0 0 1050 700', phaseMs: 600 });
    original.node('INET', { type: 'cloud',    x: 525, y: 70,  label: 'Internet' });
    original.node('FW',   { type: 'firewall', x: 525, y: 200, label: 'Next-Gen Firewall' });
    original.node('ROUTER',{ type: 'router',  x: 300, y: 340, label: 'Core Router' });
    original.node('SWITCH',{ type: 'switch',  x: 750, y: 340, label: 'Core Switch' });
    original.node('SRV1', { type: 'server',   x: 200, y: 500, label: 'App Server 1' });
    original.node('SRV2', { type: 'server',   x: 500, y: 500, label: 'App Server 2' });
    original.node('DB',   { type: 'database', x: 800, y: 500, label: 'Database Cluster' });
    original.anchor('wan_pt', { x: 525, y: 135 });
    original.link('inet-wan',  { type: 'line',   from: 'INET',   to: 'wan_pt', color: '#b1b9be' });
    original.link('wan-fw',    { type: 'tunnel', from: 'wan_pt', to: 'FW',     color: '#b1b9be' });
    original.link('fw-router', { type: 'line',   from: 'FW',     to: 'ROUTER', color: '#01a982' });
    original.link('fw-switch', { type: 'line',   from: 'FW',     to: 'SWITCH', color: '#01a982' });
    original.link('router-srv1',{ type: 'line',  from: 'ROUTER', to: 'SRV1',   color: '#65aef9' });
    original.link('router-srv2',{ type: 'line',  from: 'ROUTER', to: 'SRV2',   color: '#65aef9' });
    original.link('switch-db', { type: 'line',   from: 'SWITCH', to: 'DB',     color: '#deb146' });
    original.act('infra', { label: 'Infrastructure', color: '#01a982' });
    original.addStep('s1', { act: 'infra', name: 'Internet Edge', goal: 'Edge', focus: ['INET','FW'], phases: [{ show: ['INET','FW','wan_pt','inet-wan','wan-fw'], diff: 'Edge' }] });
    original.addStep('s2', { act: 'infra', name: 'Distribution',  goal: 'Core', focus: ['ROUTER','SWITCH'], phases: [{ show: ['ROUTER','SWITCH','fw-router','fw-switch'], diff: 'Core' }] });
    original.addStep('s3', { act: 'infra', name: 'Servers',       goal: 'Svrs', focus: ['SRV1','SRV2','DB'], phases: [{ show: ['SRV1','SRV2','DB','router-srv1','router-srv2','switch-db'], diff: 'Servers' }] });
    original._buildIndex();

    // Perform round-trip
    const json = JSON.parse(JSON.stringify(original.toJSON()));
    restored = new TopologyDesigner({ title: 'Restore', viewBox: '0 0 1050 700' });
    restored.fromJSON(json);
  });

  it('original instantiates without error', () => { expect(original).toBeDefined(); });
  it('original has 7 nodes', () => { expect(original._nodes.size).toBe(7); });
  it('original has 7 links', () => { expect(original._links.size).toBe(7); });
  it('original has 1 anchor', () => { expect(original._anchors.size).toBe(1); });
  it('restored topology has same node count', () => { expect(restored._nodes.size).toBe(7); });
  it('restored topology has same link count', () => { expect(restored._links.size).toBe(7); });
  it('restored topology has same anchor', () => { expect(restored._anchors.has('wan_pt')).toBe(true); });
  it('restored topology title is correct', () => { expect(restored.title).toBe('Serialization Test Topology'); });
  it('restored topology has 3 steps', () => { expect(restored._steps.length).toBe(3); });
  it('restored node coordinates are preserved', () => {
    expect(restored._nodes.get('INET').x).toBe(525);
    expect(restored._nodes.get('INET').y).toBe(70);
  });
  it('_buildIndex() works on restored topology', () => { expect(() => restored._buildIndex()).not.toThrow(); });
  it('double round-trip is stable', () => {
    const json2 = JSON.parse(JSON.stringify(restored.toJSON()));
    const topo3 = new TopologyDesigner({ title: 'R2', viewBox: '0 0 1050 700' });
    topo3.fromJSON(json2);
    expect(topo3._nodes.size).toBe(7);
    expect(topo3._steps.length).toBe(3);
  });
});

// ─────────────────────────────────────────────
// UAT 8: Overlay Cloud
// ─────────────────────────────────────────────

describe('UAT: Overlay Cloud (overlay-cloud.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · Overlay Cloud', viewBox: '0 0 1050 700', phaseMs: 600 });
    const nodes = [
      ['INET',   'cloud',    525,  60, 'Internet'],
      ['FW1',    'firewall', 250, 160, 'FW East'],
      ['FW2',    'firewall', 800, 160, 'FW West'],
      ['EC1',    'ec',       250, 280, 'EC East'],
      ['EC2',    'ec',       800, 280, 'EC West'],
      ['SW1',    'switch',   250, 400, 'SW East'],
      ['SW2',    'switch',   800, 400, 'SW West'],
      ['SRV1',   'server',   150, 540, 'Server 1'],
      ['SRV2',   'server',   350, 540, 'Server 2'],
      ['SRV3',   'server',   700, 540, 'Server 3'],
      ['SRV4',   'server',   900, 540, 'Server 4'],
      ['CLOUD',  'overlayCloud', 525, 250, 'HPE GreenLake'],
    ];
    nodes.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    const links = [
      ['l1','line','INET','FW1','#b1b9be'],['l2','line','INET','FW2','#b1b9be'],
      ['l3','line','FW1','EC1','#01a982'],['l4','line','FW2','EC2','#01a982'],
      ['l5','line','EC1','SW1','#65aef9'],['l6','line','EC2','SW2','#65aef9'],
      ['l7','line','SW1','SRV1','#b1b9be'],['l8','line','SW1','SRV2','#b1b9be'],
      ['l9','line','SW2','SRV3','#b1b9be'],['l10','line','SW2','SRV4','#b1b9be'],
      ['l11','tunnel','EC1','EC2','#01a982'],['l12','tunnel','EC1','CLOUD','#65aef9'],
    ];
    links.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('a1', { label: 'Hybrid Cloud', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'Edge', goal: 'Show edge', focus: [], phases: [{ show: ['INET','FW1','FW2','l1','l2'], diff: 'Edge' }] });
    topo.addStep('s2', { act: 'a1', name: 'Cloud Fabric', goal: 'Overlay', focus: ['CLOUD','EC1','EC2'], phases: [{ show: ['CLOUD','EC1','EC2','l3','l4','l11','l12'], diff: 'Cloud overlay' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 12 nodes', () => { expect(topo._nodes.size).toBe(12); });
  it('registers 12 links', () => { expect(topo._links.size).toBe(12); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('includes overlayCloud node type', () => { expect(topo._nodes.get('CLOUD').type).toBe('overlayCloud'); });
  it('toJSON works', () => {
    const json = topo.toJSON();
    expect(Object.keys(json.nodes).length).toBe(12);
  });
});

// ─────────────────────────────────────────────
// UAT 9: SD-WAN 4-Site
// ─────────────────────────────────────────────

describe('UAT: SD-WAN 4-Site (sdwan-4site.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · SD-WAN 4-Site', viewBox: '0 0 1400 800', phaseMs: 600 });
    const nodeList = [
      ['INET',    'cloud',   700, 60,  'Internet'],
      ['ORCH',    'cloud',   400, 60,  'Orchestrator'],
      ['HQ_EC',   'ec',      200, 200, 'HQ EC'],
      ['HQ_FW',   'firewall',200, 340, 'HQ FW'],
      ['HQ_SW',   'switch',  200, 480, 'HQ SW'],
      ['HQ_SRV1', 'server',  100, 600, 'HQ App'],
      ['HQ_SRV2', 'server',  300, 600, 'HQ DB'],
      ['BR1_EC',  'ec',      500, 200, 'BR1 EC'],
      ['BR1_SW',  'switch',  500, 340, 'BR1 SW'],
      ['BR1_PC',  'host',    500, 480, 'BR1 PC'],
      ['BR2_EC',  'ec',      800, 200, 'BR2 EC'],
      ['BR2_SW',  'switch',  800, 340, 'BR2 SW'],
      ['BR2_PC',  'host',    800, 480, 'BR2 PC'],
      ['BR3_EC',  'ec',     1100, 200, 'BR3 EC'],
      ['BR3_SW',  'switch', 1100, 340, 'BR3 SW'],
      ['BR3_PC',  'host',   1100, 480, 'BR3 PC'],
      ['CLOUD1',  'cloud',  1000, 60,  'AWS'],
      ['CLOUD2',  'saas',   1200, 60,  'SaaS'],
      ['CON1',    'connector',1000, 200, 'AWS Connector'],
      ['MGMT',    'server', 1300, 340, 'MGMT'],
      ['MON',     'server', 1300, 200, 'Monitoring'],
      ['LOG',     'server', 1300, 480, 'Logging'],
    ];
    nodeList.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    const linkList = [
      ['l1','tunnel','HQ_EC','INET','#01a982'],['l2','tunnel','BR1_EC','INET','#01a982'],
      ['l3','tunnel','BR2_EC','INET','#01a982'],['l4','tunnel','BR3_EC','INET','#01a982'],
      ['l5','tunnel','HQ_EC','ORCH','#65aef9'],['l6','tunnel','BR1_EC','ORCH','#65aef9'],
      ['l7','tunnel','BR2_EC','ORCH','#65aef9'],['l8','tunnel','BR3_EC','ORCH','#65aef9'],
      ['l9','line','HQ_EC','HQ_FW','#b1b9be'],['l10','line','HQ_FW','HQ_SW','#b1b9be'],
      ['l11','line','HQ_SW','HQ_SRV1','#b1b9be'],['l12','line','HQ_SW','HQ_SRV2','#b1b9be'],
      ['l13','line','BR1_EC','BR1_SW','#b1b9be'],['l14','line','BR1_SW','BR1_PC','#b1b9be'],
      ['l15','line','BR2_EC','BR2_SW','#b1b9be'],['l16','line','BR2_SW','BR2_PC','#b1b9be'],
      ['l17','line','BR3_EC','BR3_SW','#b1b9be'],['l18','line','BR3_SW','BR3_PC','#b1b9be'],
      ['l19','line','INET','CLOUD1','#b1b9be'],['l20','tunnel','HQ_EC','CON1','#65aef9'],
      ['l21','line','CLOUD1','CON1','#b1b9be'],['l22','line','INET','CLOUD2','#b1b9be'],
      ['l23','line','MGMT','MON','#7d8a92'],['l24','line','MGMT','LOG','#7d8a92'],
      ['l25','tunnel','HQ_EC','MGMT','#7d8a92'],
    ];
    linkList.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('a1', { label: 'SD-WAN Fabric', color: '#01a982' });
    topo.addStep('s1', { act: 'a1', name: 'Underlay', goal: 'Connectivity', focus: [], phases: [{ show: ['INET','HQ_EC','BR1_EC','BR2_EC','BR3_EC','l1','l2','l3','l4'], diff: 'Internet' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 22 nodes', () => { expect(topo._nodes.size).toBe(22); });
  it('registers 25 links', () => { expect(topo._links.size).toBe(25); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all links reference valid nodes', () => {
    for (const [, lk] of topo._links) {
      expect(topo._nodes.has(lk.from) || topo._anchors.has(lk.from)).toBe(true);
      expect(topo._nodes.has(lk.to)   || topo._anchors.has(lk.to)).toBe(true);
    }
  });
  it('toJSON works', () => {
    const json = topo.toJSON();
    expect(Object.keys(json.nodes).length).toBe(22);
    expect(Object.keys(json.links).length).toBe(25);
  });
});

// ─────────────────────────────────────────────
// UAT 10: SD-WAN + ZTNA Fullstack
// ─────────────────────────────────────────────

describe('UAT: SD-WAN + ZTNA Fullstack (sdwan-ztna-fullstack.html)', () => {
  let topo;
  beforeEach(() => {
    topo = new TopologyDesigner({ title: 'UAT · SD-WAN ZTNA Fullstack', viewBox: '0 0 1400 800', phaseMs: 600 });
    const nodeList = [
      ['REMOTE_USER','host',    100, 400, 'Remote User'],
      ['LAPTOP',    'host',    220, 400, 'Laptop'],
      ['MOBILE',    'host',    220, 520, 'Mobile'],
      ['ZTNA_CLOUD','cloud',   400, 280, 'ZTNA Cloud'],
      ['IdP',       'cloud',   400, 520, 'Identity Provider'],
      ['INET',      'cloud',   400, 400, 'Internet'],
      ['EC_HQ',     'ec',      600, 400, 'HQ Edge Connect'],
      ['EC_BR1',    'ec',      600, 200, 'Branch 1 EC'],
      ['EC_BR2',    'ec',      600, 600, 'Branch 2 EC'],
      ['FW_HQ',     'firewall',760, 400, 'HQ Firewall'],
      ['CORE_SW',   'switch',  920, 400, 'Core Switch'],
      ['APP1',      'server', 1080, 200, 'App Server 1'],
      ['APP2',      'server', 1080, 340, 'App Server 2'],
      ['DB_PRI',    'database',1080,480, 'DB Primary'],
      ['DB_REP',    'database',1080,620, 'DB Replica'],
      ['STOR',      'database',1080,740, 'SAN Storage'],
      ['CON_AWS',   'connector',1240,200,'AWS Connector'],
      ['AWS',       'cloud',  1380, 200, 'AWS'],
      ['SAAS',      'saas',   1380, 400, 'SaaS'],
      ['ORCH',      'cloud',   400, 160, 'SD-WAN Orchestrator'],
      ['MON',       'server', 1240, 400, 'Monitoring'],
      ['MGMT',      'server', 1240, 600, 'MGMT Console'],
      ['BR1_SW',    'switch',  600,  80, 'BR1 Switch'],
      ['BR2_SW',    'switch',  600, 720, 'BR2 Switch'],
    ];
    nodeList.forEach(([id, type, x, y, label]) => topo.node(id, { type, x, y, label }));
    const linkList = [
      ['l1','line','REMOTE_USER','LAPTOP','#b1b9be'],['l2','line','REMOTE_USER','MOBILE','#b1b9be'],
      ['l3','tunnel','LAPTOP','ZTNA_CLOUD','#01a982'],['l4','tunnel','MOBILE','ZTNA_CLOUD','#01a982'],
      ['l5','tunnel','LAPTOP','INET','#535c66'],['l6','tunnel','MOBILE','INET','#535c66'],
      ['l7','tunnel','LAPTOP','IdP','#deb146'],['l8','tunnel','ZTNA_CLOUD','EC_HQ','#01a982'],
      ['l9','tunnel','INET','EC_HQ','#535c66'],['l10','line','EC_HQ','FW_HQ','#01a982'],
      ['l11','line','FW_HQ','CORE_SW','#01a982'],['l12','line','CORE_SW','APP1','#65aef9'],
      ['l13','line','CORE_SW','APP2','#65aef9'],['l14','line','CORE_SW','DB_PRI','#deb146'],
      ['l15','line','CORE_SW','DB_REP','#deb146'],['l16','line','CORE_SW','STOR','#7d8a92'],
      ['l17','line','DB_PRI','DB_REP','#535c66'],['l18','tunnel','EC_HQ','EC_BR1','#01a982'],
      ['l19','tunnel','EC_HQ','EC_BR2','#01a982'],['l20','tunnel','EC_HQ','ORCH','#65aef9'],
      ['l21','tunnel','EC_BR1','ORCH','#65aef9'],['l22','tunnel','EC_BR2','ORCH','#65aef9'],
      ['l23','line','EC_BR1','BR1_SW','#b1b9be'],['l24','line','EC_BR2','BR2_SW','#b1b9be'],
      ['l25','tunnel','EC_HQ','CON_AWS','#65aef9'],['l26','line','CON_AWS','AWS','#b1b9be'],
      ['l27','line','INET','SAAS','#b1b9be'],['l28','line','CORE_SW','MON','#7d8a92'],
      ['l29','line','CORE_SW','MGMT','#7d8a92'],
    ];
    linkList.forEach(([id, type, from, to, color]) => topo.link(id, { type, from, to, color }));
    topo.act('auth', { label: 'Zero Trust Auth', color: '#deb146' });
    topo.act('sdwan', { label: 'SD-WAN Fabric', color: '#01a982' });
    topo.act('data',  { label: 'Data & Apps', color: '#65aef9' });
    topo.addStep('s1', { act: 'auth', name: 'User Auth', goal: 'Auth', focus: [], phases: [{ show: ['REMOTE_USER','LAPTOP','MOBILE','ZTNA_CLOUD','IdP','l1','l2','l3','l4','l7'], diff: 'Zero Trust Auth' }] });
    topo.addStep('s2', { act: 'sdwan', name: 'SD-WAN Fabric', goal: 'Fabric', focus: [], phases: [{ show: ['INET','EC_HQ','EC_BR1','EC_BR2','ORCH','l5','l6','l9','l18','l19','l20','l21','l22'], diff: 'SD-WAN' }] });
    topo.addStep('s3', { act: 'data', name: 'App Access', goal: 'Apps', focus: [], phases: [{ show: ['FW_HQ','CORE_SW','APP1','APP2','DB_PRI','l10','l11','l12','l13','l14'], diff: 'App tier' }] });
    topo._buildIndex();
  });

  it('instantiates without error', () => { expect(topo).toBeDefined(); });
  it('registers 24 nodes', () => { expect(topo._nodes.size).toBe(24); });
  it('registers 29 links', () => { expect(topo._links.size).toBe(29); });
  it('has 3 acts', () => { expect(topo._acts.length).toBe(3); });
  it('_buildIndex() completes', () => { expect(() => topo._buildIndex()).not.toThrow(); });
  it('all links reference valid nodes', () => {
    for (const [, lk] of topo._links) {
      expect(topo._nodes.has(lk.from) || topo._anchors.has(lk.from)).toBe(true);
      expect(topo._nodes.has(lk.to)   || topo._anchors.has(lk.to)).toBe(true);
    }
  });
  it('toJSON works', () => {
    const json = topo.toJSON();
    expect(Object.keys(json.nodes).length).toBe(24);
    expect(Object.keys(json.links).length).toBe(29);
  });
  it('fromJSON round-trip preserves fullstack topology', () => {
    const json = JSON.parse(JSON.stringify(topo.toJSON()));
    const restored = new TopologyDesigner({ title: 'R', viewBox: '0 0 1400 800' });
    restored.fromJSON(json);
    expect(restored._nodes.size).toBe(24);
    expect(restored._links.size).toBe(29);
    expect(restored._acts.length).toBe(3);
  });
});
