import { describe, it, expect } from 'vitest';

// Load the module using CommonJS compatibility
const ThemeEngine = require('../design-system/modules/theme-engine.js');

describe('ThemeEngine', () => {

  describe('_hexToRGB', () => {
    it('converts standard hex colors correctly', () => {
      expect(ThemeEngine._hexToRGB('#ff0000')).toEqual({ r: 255, g: 0, b: 0 });
      expect(ThemeEngine._hexToRGB('#00ff00')).toEqual({ r: 0, g: 255, b: 0 });
      expect(ThemeEngine._hexToRGB('#0000ff')).toEqual({ r: 0, g: 0, b: 255 });
    });

    it('converts black and white', () => {
      expect(ThemeEngine._hexToRGB('#000000')).toEqual({ r: 0, g: 0, b: 0 });
      expect(ThemeEngine._hexToRGB('#ffffff')).toEqual({ r: 255, g: 255, b: 255 });
    });

    it('handles hex without # prefix', () => {
      expect(ThemeEngine._hexToRGB('01a982')).toEqual({ r: 1, g: 169, b: 130 });
    });

    it('converts the project brand color correctly', () => {
      expect(ThemeEngine._hexToRGB('#01a982')).toEqual({ r: 1, g: 169, b: 130 });
    });
  });

  describe('_hexToHSL', () => {
    it('converts pure red', () => {
      const hsl = ThemeEngine._hexToHSL('#ff0000');
      expect(hsl.h).toBe(0);
      expect(hsl.s).toBe(100);
      expect(hsl.l).toBe(50);
    });

    it('converts pure green', () => {
      const hsl = ThemeEngine._hexToHSL('#00ff00');
      expect(hsl.h).toBe(120);
      expect(hsl.s).toBe(100);
      expect(hsl.l).toBe(50);
    });

    it('converts pure blue', () => {
      const hsl = ThemeEngine._hexToHSL('#0000ff');
      expect(hsl.h).toBe(240);
      expect(hsl.s).toBe(100);
      expect(hsl.l).toBe(50);
    });

    it('converts achromatic colors (no saturation)', () => {
      const gray = ThemeEngine._hexToHSL('#808080');
      expect(gray.s).toBe(0);
      expect(gray.l).toBe(50);
    });

    it('converts black', () => {
      const black = ThemeEngine._hexToHSL('#000000');
      expect(black.l).toBe(0);
    });

    it('converts white', () => {
      const white = ThemeEngine._hexToHSL('#ffffff');
      expect(white.l).toBe(100);
    });
  });

  describe('_hslToHex', () => {
    it('converts pure red HSL back to hex', () => {
      expect(ThemeEngine._hslToHex({ h: 0, s: 100, l: 50 })).toBe('#ff0000');
    });

    it('converts pure green HSL back to hex', () => {
      expect(ThemeEngine._hslToHex({ h: 120, s: 100, l: 50 })).toBe('#00ff00');
    });

    it('converts pure blue HSL back to hex', () => {
      expect(ThemeEngine._hslToHex({ h: 240, s: 100, l: 50 })).toBe('#0000ff');
    });

    it('converts black', () => {
      expect(ThemeEngine._hslToHex({ h: 0, s: 0, l: 0 })).toBe('#000000');
    });

    it('converts white', () => {
      expect(ThemeEngine._hslToHex({ h: 0, s: 0, l: 100 })).toBe('#ffffff');
    });
  });

  describe('hex round-trip (hex -> HSL -> hex)', () => {
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffffff', '#000000'];

    colors.forEach(hex => {
      it(`round-trips ${hex} correctly`, () => {
        const hsl = ThemeEngine._hexToHSL(hex);
        const result = ThemeEngine._hslToHex(hsl);
        expect(result).toBe(hex);
      });
    });
  });

  describe('_relativeLuminance', () => {
    it('returns 0 for black', () => {
      expect(ThemeEngine._relativeLuminance('#000000')).toBeCloseTo(0, 4);
    });

    it('returns 1 for white', () => {
      expect(ThemeEngine._relativeLuminance('#ffffff')).toBeCloseTo(1, 4);
    });

    it('returns expected luminance for mid-gray', () => {
      const lum = ThemeEngine._relativeLuminance('#808080');
      expect(lum).toBeGreaterThan(0.15);
      expect(lum).toBeLessThan(0.25);
    });
  });

  describe('contrastRatio', () => {
    it('returns 21 for black on white', () => {
      expect(ThemeEngine.contrastRatio('#000000', '#ffffff')).toBeCloseTo(21, 0);
    });

    it('returns 1 for same color', () => {
      expect(ThemeEngine.contrastRatio('#ff0000', '#ff0000')).toBeCloseTo(1, 1);
    });

    it('is symmetric (order independent)', () => {
      const r1 = ThemeEngine.contrastRatio('#01a982', '#1d1f27');
      const r2 = ThemeEngine.contrastRatio('#1d1f27', '#01a982');
      expect(r1).toBeCloseTo(r2, 4);
    });

    it('is always >= 1', () => {
      expect(ThemeEngine.contrastRatio('#333333', '#555555')).toBeGreaterThanOrEqual(1);
    });
  });

  describe('passesWCAG_AA', () => {
    it('passes for black on white', () => {
      expect(ThemeEngine.passesWCAG_AA('#000000', '#ffffff')).toBe(true);
    });

    it('fails for similar colors', () => {
      expect(ThemeEngine.passesWCAG_AA('#777777', '#888888')).toBe(false);
    });

    it('checks the default-dark theme text on bg passes WCAG AA', () => {
      const preset = ThemeEngine.PRESETS['default-dark'];
      expect(ThemeEngine.passesWCAG_AA(preset.text, preset.bg)).toBe(true);
    });
  });

  describe('PRESETS', () => {
    it('has all expected preset names', () => {
      const keys = Object.keys(ThemeEngine.PRESETS);
      expect(keys).toContain('default-dark');
      expect(keys).toContain('midnight');
      expect(keys).toContain('charcoal');
      expect(keys).toContain('corporate');
      expect(keys).toContain('warm-dark');
    });

    it('all presets have required color keys', () => {
      const requiredKeys = ['name', 'bg', 'panel', 'text', 'muted', 'green', 'blue', 'purple', 'gold', 'red', 'teal'];
      Object.entries(ThemeEngine.PRESETS).forEach(([presetName, preset]) => {
        requiredKeys.forEach(key => {
          expect(preset).toHaveProperty(key);
        });
      });
    });

    it('all preset colors are valid hex strings', () => {
      const colorKeys = ['bg', 'panel', 'text', 'muted', 'green', 'blue', 'purple', 'gold', 'red', 'teal'];
      Object.values(ThemeEngine.PRESETS).forEach(preset => {
        colorKeys.forEach(key => {
          expect(preset[key]).toMatch(/^#[0-9a-f]{6}$/i);
        });
      });
    });
  });

  describe('generateFromPrimary', () => {
    it('generates a dark theme by default', () => {
      const theme = ThemeEngine.generateFromPrimary('#01a982');
      expect(theme.name).toBe('Custom Dark');
      expect(theme.bg).toBe('#1d1f27');
      expect(theme.text).toBe('#e6e8e9');
    });

    it('generates a light theme when mode is light', () => {
      const theme = ThemeEngine.generateFromPrimary('#01a982', { mode: 'light' });
      expect(theme.name).toBe('Custom Light');
      expect(theme.bg).toBe('#f8fafc');
      expect(theme.text).toBe('#1e293b');
    });

    it('generates all required color keys', () => {
      const theme = ThemeEngine.generateFromPrimary('#3b82f6');
      const requiredKeys = ['green', 'blue', 'purple', 'gold', 'red', 'teal'];
      requiredKeys.forEach(key => {
        expect(theme[key]).toMatch(/^#[0-9a-f]{6}$/i);
      });
    });

    it('produces valid hex colors for different primary inputs', () => {
      const primaries = ['#ff0000', '#00ff00', '#0000ff', '#ff8800', '#8800ff'];
      primaries.forEach(primary => {
        const theme = ThemeEngine.generateFromPrimary(primary);
        ['green', 'blue', 'purple', 'gold', 'red', 'teal'].forEach(key => {
          expect(theme[key]).toMatch(/^#[0-9a-f]{6}$/i);
        });
      });
    });
  });

  describe('toCSS', () => {
    it('generates valid CSS custom properties', () => {
      const theme = ThemeEngine.PRESETS['default-dark'];
      const css = ThemeEngine.toCSS(theme);
      expect(css).toContain(':root {');
      expect(css).toContain('--tds-bg: #1d1f27');
      expect(css).toContain('--tds-green: #01a982');
      expect(css).toContain('}');
    });

    it('only includes defined properties', () => {
      const css = ThemeEngine.toCSS({ bg: '#111', text: '#eee' });
      expect(css).toContain('--tds-bg: #111');
      expect(css).toContain('--tds-text: #eee');
      expect(css).not.toContain('--tds-green');
    });
  });

  describe('apply', () => {
    it('sets CSS custom properties on document root', () => {
      const theme = ThemeEngine.PRESETS['default-dark'];
      ThemeEngine.apply(theme);
      const root = document.documentElement;
      expect(root.style.getPropertyValue('--tds-bg')).toBe('#1d1f27');
      expect(root.style.getPropertyValue('--tds-green')).toBe('#01a982');
    });

    it('sets glow colors with rgba', () => {
      ThemeEngine.apply({ green: '#01a982' });
      const root = document.documentElement;
      const glow = root.style.getPropertyValue('--tds-glow-green');
      expect(glow).toContain('rgba(');
    });
  });
});
