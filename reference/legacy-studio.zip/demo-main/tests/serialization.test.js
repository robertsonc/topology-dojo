import { describe, it, expect, beforeEach } from 'vitest';

window.matchMedia = window.matchMedia || function () {
  return { matches: false, addListener: () => {}, removeListener: () => {} };
};

const TopologyDesigner = require('../design-system/topology-ds.js');

describe('Serialization (toJSON / fromJSON)', () => {
  let topo;

  function buildFullTopology() {
    topo = new TopologyDesigner({
      title: 'Test Topo',
      subtitle: 'Subtitle',
      viewBox: '0 0 800 600',
      phaseMs: 500,
      drawDuration: 0.5,
      fadeDuration: 0.4,
    });

    topo.node('A', { type: 'server', x: 100, y: 100, label: 'Server A' })
        .node('B', { type: 'router', x: 300, y: 100, label: 'Router B' })
        .node('C', { type: 'firewall', x: 200, y: 300, label: 'Firewall C' })
        .anchor('mid', { x: 200, y: 200 })
        .link('l1', { type: 'line', from: 'A', to: 'B', color: '#01a982' })
        .link('l2', { type: 'tunnel', from: 'B', to: 'C', color: '#65aef9', label: 'IPsec' })
        .act('a1', { label: 'Infrastructure', color: '#01a982', intro: ['Welcome'] })
        .addStep('s1', {
          act: 'a1', name: 'Servers', goal: 'Deploy servers',
          focus: ['A', 'B'],
          phases: [
            { show: ['A'], diff: 'Server A deployed' },
            { show: ['B', 'l1'], diff: 'Router B + link' },
          ],
        })
        .addStep('s2', {
          act: 'a1', name: 'Security', goal: 'Add firewall',
          focus: ['C'],
          phases: [
            { show: ['C', 'l2'], diff: 'Firewall + tunnel' },
          ],
        })
        .glossary([
          { t: 'IPsec', d: 'IP Security protocol' },
          { t: 'ZTNA', d: 'Zero Trust Network Access' },
        ]);

    topo._buildIndex();
    return topo;
  }

  beforeEach(() => {
    buildFullTopology();
  });

  describe('toJSON', () => {
    it('exports all metadata', () => {
      const json = topo.toJSON();
      expect(json.title).toBe('Test Topo');
      expect(json.subtitle).toBe('Subtitle');
      expect(json.viewBox).toBe('0 0 800 600');
      expect(json.phaseMs).toBe(500);
      expect(json.drawDuration).toBe(0.5);
      expect(json.fadeDuration).toBe(0.4);
    });

    it('exports all nodes as plain object', () => {
      const json = topo.toJSON();
      expect(json.nodes).toBeDefined();
      expect(json.nodes['A'].type).toBe('server');
      expect(json.nodes['B'].type).toBe('router');
      expect(json.nodes['C'].type).toBe('firewall');
    });

    it('exports all anchors', () => {
      const json = topo.toJSON();
      expect(json.anchors['mid']).toEqual({ x: 200, y: 200 });
    });

    it('exports all links', () => {
      const json = topo.toJSON();
      expect(json.links['l1'].from).toBe('A');
      expect(json.links['l2'].type).toBe('tunnel');
    });

    it('exports acts', () => {
      const json = topo.toJSON();
      expect(json.acts).toHaveLength(1);
      expect(json.acts[0].id).toBe('a1');
      expect(json.acts[0].label).toBe('Infrastructure');
    });

    it('exports steps with phases', () => {
      const json = topo.toJSON();
      expect(json.steps).toHaveLength(2);
      expect(json.steps[0].id).toBe('s1');
      expect(json.steps[0].phases).toHaveLength(2);
      expect(json.steps[0].phases[0].show).toContain('A');
    });

    it('exports glossary', () => {
      const json = topo.toJSON();
      expect(json.glossary).toHaveLength(2);
      expect(json.glossary[0].t).toBe('IPsec');
    });

    it('produces valid JSON (serializable)', () => {
      const json = topo.toJSON();
      const str = JSON.stringify(json);
      const parsed = JSON.parse(str);
      expect(parsed.title).toBe('Test Topo');
      expect(parsed.nodes.A.type).toBe('server');
    });
  });

  describe('fromJSON', () => {
    it('restores topology from JSON', () => {
      const json = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json);

      expect(newTopo.title).toBe('Test Topo');
      expect(newTopo.subtitle).toBe('Subtitle');
      expect(newTopo._nodes.size).toBe(3);
      expect(newTopo._links.size).toBe(2);
      expect(newTopo._anchors.size).toBe(1);
      expect(newTopo._acts).toHaveLength(1);
      expect(newTopo._steps).toHaveLength(2);
      expect(newTopo._glossary).toHaveLength(2);
    });

    it('rebuilds step index', () => {
      const json = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json);

      expect(newTopo._stepIndex['s1']).toBe(1);
      expect(newTopo._stepIndex['s2']).toBe(2);
    });

    it('clears previous data before loading', () => {
      const newTopo = new TopologyDesigner();
      newTopo.node('X', { type: 'host', x: 0, y: 0 });
      newTopo.link('oldLink', { type: 'line', from: 'X', to: 'X' });

      const json = topo.toJSON();
      newTopo.fromJSON(json);

      expect(newTopo._nodes.has('X')).toBe(false);
      expect(newTopo._links.has('oldLink')).toBe(false);
      expect(newTopo._nodes.size).toBe(3);
    });

    it('returns this for chaining', () => {
      const newTopo = new TopologyDesigner();
      expect(newTopo.fromJSON(topo.toJSON())).toBe(newTopo);
    });
  });

  describe('round-trip fidelity', () => {
    it('toJSON -> fromJSON -> toJSON produces identical output', () => {
      const json1 = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json1);
      const json2 = newTopo.toJSON();

      expect(json2.title).toBe(json1.title);
      expect(json2.subtitle).toBe(json1.subtitle);
      expect(json2.viewBox).toBe(json1.viewBox);
      expect(json2.phaseMs).toBe(json1.phaseMs);
      expect(Object.keys(json2.nodes)).toEqual(Object.keys(json1.nodes));
      expect(Object.keys(json2.links)).toEqual(Object.keys(json1.links));
      expect(Object.keys(json2.anchors)).toEqual(Object.keys(json1.anchors));
      expect(json2.acts.length).toBe(json1.acts.length);
      expect(json2.steps.length).toBe(json1.steps.length);
      expect(json2.glossary.length).toBe(json1.glossary.length);
    });

    it('preserves node positions through round-trip', () => {
      const json1 = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json1);

      expect(newTopo._nodes.get('A').x).toBe(100);
      expect(newTopo._nodes.get('A').y).toBe(100);
      expect(newTopo._nodes.get('B').x).toBe(300);
    });

    it('preserves phase show arrays through round-trip', () => {
      const json = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json);

      expect(newTopo._steps[0].phases[0].show).toContain('A');
      expect(newTopo._steps[0].phases[1].show).toContain('B');
      expect(newTopo._steps[0].phases[1].show).toContain('l1');
    });

    it('preserves focus arrays through round-trip', () => {
      const json = topo.toJSON();
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(json);

      expect(newTopo._steps[0].focus).toContain('A');
      expect(newTopo._steps[0].focus).toContain('B');
      expect(newTopo._steps[1].focus).toContain('C');
    });

    it('survives JSON.stringify -> JSON.parse cycle', () => {
      const json = topo.toJSON();
      const serialized = JSON.parse(JSON.stringify(json));
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON(serialized);

      expect(newTopo._nodes.size).toBe(3);
      expect(newTopo._links.size).toBe(2);
      expect(newTopo.title).toBe('Test Topo');
    });
  });

  describe('edge cases', () => {
    it('handles fromJSON with empty data', () => {
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON({});
      expect(newTopo._nodes.size).toBe(0);
      expect(newTopo._links.size).toBe(0);
      expect(newTopo._steps).toHaveLength(0);
    });

    it('handles fromJSON with partial data', () => {
      const newTopo = new TopologyDesigner();
      newTopo.fromJSON({ title: 'Partial', nodes: { X: { type: 'host', x: 0, y: 0 } } });
      expect(newTopo.title).toBe('Partial');
      expect(newTopo._nodes.size).toBe(1);
      expect(newTopo._links.size).toBe(0);
    });
  });

  describe('phase properties round-trip (issue #108)', () => {
    it('preserves delayMs, label, badge, callout, condition, actions on phases', () => {
      const richTopo = new TopologyDesigner({ title: 'Rich Phases' });
      richTopo.node('N1', { type: 'server', x: 0, y: 0, label: 'N1' })
        .act('a1', { label: 'Act1', color: '#000' })
        .addStep('step1', {
          act: 'a1', name: 'Step1', goal: 'Test phase props',
          focus: ['N1'],
          phases: [
            {
              show: ['N1'],
              diff: 'Phase with rich props',
              delayMs: 1500,
              label: 'Deploy',
              badge: 'NEW',
              callout: 'Important callout',
              condition: 'ready === true',
              actions: [{ type: 'highlight', target: 'N1' }],
            },
          ],
        });
      richTopo._buildIndex();

      const json = richTopo.toJSON();
      const phase = json.steps[0].phases[0];
      expect(phase.show).toEqual(['N1']);
      expect(phase.diff).toBe('Phase with rich props');
      expect(phase.delayMs).toBe(1500);
      expect(phase.label).toBe('Deploy');
      expect(phase.badge).toBe('NEW');
      expect(phase.callout).toBe('Important callout');
      expect(phase.condition).toBe('ready === true');
      expect(phase.actions).toEqual([{ type: 'highlight', target: 'N1' }]);

      // Round-trip
      const restored = new TopologyDesigner();
      restored.fromJSON(json);
      const rPhase = restored._steps[0].phases[0];
      expect(rPhase.delayMs).toBe(1500);
      expect(rPhase.label).toBe('Deploy');
      expect(rPhase.badge).toBe('NEW');
      expect(rPhase.callout).toBe('Important callout');
      expect(rPhase.condition).toBe('ready === true');
      expect(rPhase.actions).toEqual([{ type: 'highlight', target: 'N1' }]);
    });

    it('strips function properties from phases', () => {
      const funcTopo = new TopologyDesigner({ title: 'Func Test' });
      funcTopo.node('N1', { type: 'server', x: 0, y: 0, label: 'N1' })
        .act('a1', { label: 'Act1', color: '#000' })
        .addStep('step1', {
          act: 'a1', name: 'Step1', goal: 'Test func strip',
          focus: ['N1'],
          phases: [
            {
              show: ['N1'],
              diff: 'Has function',
              onEnter: () => console.log('enter'),
              custom: { nested: true },
            },
          ],
        });
      funcTopo._buildIndex();

      const json = funcTopo.toJSON();
      const phase = json.steps[0].phases[0];
      expect(phase.onEnter).toBeUndefined();
      expect(phase.custom).toEqual({ nested: true });
    });

    it('preserves step-level layerVisibility', () => {
      const lvTopo = new TopologyDesigner({ title: 'LayerVis Test' });
      lvTopo.node('N1', { type: 'server', x: 0, y: 0, label: 'N1' })
        .act('a1', { label: 'Act1', color: '#000' })
        .addStep('step1', {
          act: 'a1', name: 'Step1', goal: 'Test layerVisibility',
          focus: ['N1'],
          layerVisibility: {
            'underlay': { opacity: 0.3 },
            'overlay': { opacity: 1.0 },
          },
          phases: [
            { show: ['N1'], diff: 'Initial' },
          ],
        });
      lvTopo._buildIndex();

      const json = lvTopo.toJSON();
      expect(json.steps[0].layerVisibility).toEqual({
        'underlay': { opacity: 0.3 },
        'overlay': { opacity: 1.0 },
      });

      // Round-trip
      const restored = new TopologyDesigner();
      restored.fromJSON(json);
      expect(restored._steps[0].layerVisibility).toEqual({
        'underlay': { opacity: 0.3 },
        'overlay': { opacity: 1.0 },
      });
    });

    it('toJSON -> fromJSON -> toJSON preserves all phase properties', () => {
      const t1 = new TopologyDesigner({ title: 'Double RT' });
      t1.node('N1', { type: 'server', x: 0, y: 0, label: 'N1' })
        .act('a1', { label: 'Act1', color: '#000' })
        .addStep('step1', {
          act: 'a1', name: 'Step1', goal: 'Double round-trip',
          focus: ['N1'],
          layerVisibility: { 'layer1': { opacity: 0.5 } },
          phases: [
            {
              show: ['N1'],
              diff: 'Full props',
              delayMs: 800,
              label: 'Init',
              badge: 'OK',
              callout: 'Note',
              condition: 'x > 1',
              actions: [{ type: 'animate', target: 'N1' }],
              flow: 'forward',
              blocked: false,
              rerender: true,
            },
          ],
        });
      t1._buildIndex();

      const json1 = t1.toJSON();
      const t2 = new TopologyDesigner();
      t2.fromJSON(json1);
      const json2 = t2.toJSON();

      expect(json2.steps[0].phases[0]).toEqual(json1.steps[0].phases[0]);
      expect(json2.steps[0].layerVisibility).toEqual(json1.steps[0].layerVisibility);
    });
  });
});
