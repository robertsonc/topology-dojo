# Topology Studio QA Matrix

## Goal

Catch small UX regressions before they ship, especially around:

- undo / redo
- selection state
- editor property changes
- persistence
- keyboard shortcuts
- canvas interactions

The rule for any user-visible mutation is:

```text
Do action → see effect → undo → redo → save/load → verify exact state
```

---

## Test Pyramid

### 1. Engine / model tests
Use Vitest for:

- topology data mutations
- serialization / deserialization
- history snapshot semantics
- step / phase logic
- import / export transforms

### 2. Editor mutation tests
Use Vitest against editor behavior helpers / extracted state contracts for:

- property panel mutations
- history entry creation
- selection retention
- layer moves
- bulk edits
- zone / node / link mutation families

### 3. Browser UX smoke tests
Use Playwright for:

- real editor workflows
- keyboard shortcuts
- focus / selection issues
- modal apply / cancel flows
- drag/drop and click interactions
- import/export happy paths

### 4. Visual / state verification
Prefer state assertions first:

- selected IDs
- undo / redo depth
- node / link / zone properties
- current step / mode
- persisted JSON equality where practical

Add screenshot diffs only for high-value visual surfaces later.

---

## Core Invariants

### History invariants
- Every meaningful mutation creates exactly one undoable history entry unless intentionally grouped.
- Undo restores the exact prior state.
- Redo reapplies the exact changed state.
- No-op changes should not create junk history entries.
- Editing after undo clears redo history.

### Selection invariants
- Editing a selected object should keep it selected unless intentionally changed.
- Undo/redo should not silently switch selection to a different object.
- Deleting a selected object should clear or predictably re-home selection.

### Persistence invariants
- Save/load preserves visible state.
- Save/load preserves node/link/zone identity and key properties.
- Round-trip should not silently drop editor-only metadata unless explicitly documented.

### Rendering invariants
- Property changes show up on canvas.
- Hit targets remain usable after edits.
- Z-order and layering remain stable.

---

## Coverage Matrix

## Nodes
| Action | Model | Editor mutation | Undo/Redo | Save/Load | Playwright |
|---|---:|---:|---:|---:|---:|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| Rename label | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change color | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change type/variant | ✅ | ✅ | ✅ | ✅ | ✅ |
| Move / drag | ✅ | ✅ | ✅ | ✅ | ✅ |
| Resize / visual scale | ✅ | ✅ | ✅ | ✅ | ◻ |
| Layer move | ✅ | ✅ | ✅ | ✅ | ✅ |
| Duplicate | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete | ✅ | ✅ | ✅ | ✅ | ✅ |

## Links
| Action | Model | Editor mutation | Undo/Redo | Save/Load | Playwright |
|---|---:|---:|---:|---:|---:|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change color | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change type | ✅ | ✅ | ✅ | ✅ | ◻ |
| Change line style | ✅ | ✅ | ✅ | ✅ | ✅ |
| Add/remove waypoints | ✅ | ✅ | ✅ | ✅ | ◻ |
| Toggle 3D / animation | ✅ | ✅ | ✅ | ✅ | ◻ |
| Layer move | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete | ✅ | ✅ | ✅ | ✅ | ✅ |

## Zones
| Action | Model | Editor mutation | Undo/Redo | Save/Load | Playwright |
|---|---:|---:|---:|---:|---:|
| Create zone | ✅ | ✅ | ✅ | ✅ | ✅ |
| Rename label | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change description | ✅ | ✅ | ✅ | ✅ | ◻ |
| Change color | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change border style | ✅ | ✅ | ✅ | ✅ | ◻ |
| Change padding | ✅ | ✅ | ✅ | ✅ | ◻ |
| Add nodes to zone | ✅ | ✅ | ✅ | ✅ | ✅ |
| Remove nodes from zone | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete zone | ✅ | ✅ | ✅ | ✅ | ✅ |

## Steps / Acts / Phases / Timeline
| Action | Model | Editor mutation | Undo/Redo | Save/Load | Playwright |
|---|---:|---:|---:|---:|---:|
| Create act | ✅ | ✅ | ✅ | ✅ | ◻ |
| Create step | ✅ | ✅ | ✅ | ✅ | ✅ |
| Rename step | ✅ | ✅ | ✅ | ✅ | ✅ |
| Change focus/show lists | ✅ | ✅ | ✅ | ✅ | ✅ |
| Reorder steps | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete step | ✅ | ✅ | ✅ | ✅ | ◻ |
| Add phase to step | ✅ | ✅ | ✅ | ✅ | ◻ |
| Edit phase show / diff text | ✅ | ✅ | ✅ | ✅ | ◻ |
| Reorder phases within step | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete phase | ✅ | ✅ | ✅ | ✅ | ◻ |

## Anchors
| Action | Model | Editor mutation | Undo/Redo | Save/Load | Playwright |
|---|---:|---:|---:|---:|---:|
| Create anchor | ✅ | ✅ | ✅ | ✅ | ◻ |
| Move anchor | ✅ | ✅ | ✅ | ✅ | ◻ |
| Delete anchor | ✅ | ✅ | ✅ | ✅ | ◻ |
| Reference from link endpoint | ✅ | ✅ | ✅ | ✅ | ◻ |

## Layout Edit Mode
| Action | Vitest | Playwright |
|---|---:|---:|
| Enter / exit edit mode | ✅ | ◻ |
| Drag node — coordinate readback | ✅ | ◻ |
| `getPositionSnippet()` returns valid code | ✅ | ◻ |
| Edits do not corrupt undo stack | ✅ | ◻ |

## AI Assist
| Behavior | Vitest | Playwright |
|---|---:|---:|
| Modal open / close | ✅ | ◻ |
| Local NLP parser produces a topology | ✅ | ◻ |
| Cloudflare Worker fallback (mocked) | ✅ | ◻ |
| Generated topology applies to canvas | ✅ | ◻ |
| Empty / nonsense input handled gracefully | ✅ | ◻ |

## Analytics
| Behavior | Vitest | Playwright |
|---|---:|---:|
| `getAnalytics()` returns dwell + step counts | ✅ | ◻ |
| Dashboard renders without errors | ✅ | ◻ |
| Engagement events tracked across step changes | ✅ | ◻ |

## Standalone Export & Embed
| Behavior | Vitest | Playwright |
|---|---:|---:|
| `exportStandaloneHTML()` returns self-contained HTML | ✅ | ✅ |
| Exported file opens and replays without network | ✅ | ✅ |
| `copyEmbedCode()` writes a valid iframe snippet | ✅ | ◻ |

## Theme & Display Modes
| Behavior | Vitest | Playwright |
|---|---:|---:|
| `setTheme('dark')` / `setTheme('light')` | ✅ | ✅ |
| Theme persists across save/load | ✅ | ◻ |
| Isometric tilt toggle | ✅ | ◻ |
| Security mode toggle | ✅ | ◻ |
| Mobile quick-edit enable/disable | ✅ | ◻ |

## Mode coverage of REST API
The REST API has its own coverage gate (see `tests/openapi-spec.test.js` and
`tests/api-server.test.js`). Spec drift (route added without `@openapi` JSDoc,
or schema added without route reference) is caught by the `every $ref points
to a defined schema` and `every Express route is documented in the spec` tests.

## Global editor behaviors
| Behavior | Vitest | Playwright |
|---|---:|---:|
| Ctrl/Cmd+Z undo | ✅ | ✅ |
| Ctrl/Cmd+Shift+Z redo | ✅ | ✅ |
| Context-menu actions | ✅ | ✅ |
| Multi-select actions | ✅ | ✅ |
| Copy/paste | ✅ | ✅ |
| Save as JSON | ✅ | ✅ |
| Import JSON | ✅ | ✅ |
| Autosave restore | ✅ | ◻ |

---

## Mutation Family Template

Every editor mutation-family test should follow this structure:

1. create a minimal fixture
2. capture before-state
3. apply one mutation
4. verify visible/model delta
5. verify undo stack depth increased
6. undo and assert exact restoration
7. redo and assert exact reapplied state
8. serialize/deserialize and assert persisted state

Pseudo-shape:

```js
assertUndoableMutation({
  setup,
  readState,
  mutate,
  expectChanged,
  expectRestored,
  expectRedone,
  expectPersisted,
});
```

---

## Browser Smoke Pack

Minimum Playwright smoke pack should include:

1. editor loads cleanly
2. create node
3. create link
4. create zone from selection
5. edit zone color
6. undo zone color
7. redo zone color
8. edit node label
9. save/load round-trip
10. keyboard undo/redo

---

## Bug-to-Test Policy

For every UX bug:

1. add one direct regression test
2. add or extend one mutation-family test if the bug represents a broader class

Example:

- Bug: zone color change not undoable
- Direct regression: `zone color change creates undo history and round-trips via undo/redo`
- Family extension: `zone property mutations are undoable`

---

## Priority Rollout

### Phase 1
- Zone/node/link property mutation families
- Undo/redo stack assertions
- JSON persistence assertions

### Phase 2
- Playwright zone/node/link smoke flows
- Keyboard shortcuts
- modal apply/cancel coverage

### Phase 3
- Drag/drop edge cases
- history grouping behavior
- visual diff checks for export and presentation surfaces
