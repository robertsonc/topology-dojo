// @ts-check
import { defineConfig, devices } from '@playwright/test';

const isUATRun = process.argv.some(arg => arg.includes('uat-'));

export default defineConfig({
  testDir: './tests-e2e',
  timeout: isUATRun ? 60_000 : 30_000,
  expect: {
    timeout: 8_000,
  },
  fullyParallel: false, // serialized to avoid static server contention
  workers: isUATRun ? 2 : undefined,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],

  use: {
    baseURL: process.env.PLAYWRIGHT_TEST_BASE_URL || 'http://127.0.0.1:5432',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'off',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
  ],

  webServer: {
    command: 'node tests-e2e/static-server.mjs',
    url: process.env.PLAYWRIGHT_TEST_BASE_URL || 'http://127.0.0.1:5432/editor.html',
    reuseExistingServer: false,
    timeout: 60_000,
  },
});
